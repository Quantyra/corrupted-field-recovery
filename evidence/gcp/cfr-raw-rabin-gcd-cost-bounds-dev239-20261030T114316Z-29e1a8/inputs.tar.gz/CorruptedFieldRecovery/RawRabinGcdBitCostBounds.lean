import CorruptedFieldRecovery.RawRabinGcdBitCost

/-! A logarithmic-depth envelope for the declared charge of the actual
Euclidean recursion used by the raw Rabin gate. -/

namespace CorruptedFieldRecovery

private theorem rawRabinBitWidth_le_of_lt_pow {n k : Nat}
    (hn : n < 2 ^ k) : rawNatBitWidth n ≤ k + 1 := by
  unfold rawNatBitWidth
  by_cases hn0 : n = 0
  · simp [hn0]
  · have hk : 0 < k := by
      cases k with
      | zero => simp at hn
      | succ k => omega
    have hlog := rawLog2_lt_of_lt_pow hk hn
    omega

private theorem rawRabin_lt_pow_of_log_lt {n k : Nat}
    (h : Nat.log2 n < k) : n < 2 ^ k := by
  by_cases hn0 : n = 0
  · simp [hn0]
  · have hn : 0 < n := Nat.pos_of_ne_zero hn0
    have hlog : n < 2 ^ (Nat.log2 n + 1) := Nat.lt_log2_self
    have hp : 2 ^ (Nat.log2 n + 1) ≤ 2 ^ k := by
      gcongr
      omega
    exact lt_of_lt_of_le hlog hp

/-- The exact costed Euclidean recursion has logarithmic depth. Under a common
`A`-bit envelope for its two inputs, its declared charge is bounded by a
polynomial in `A` times `log₂(divisor)+2`. This is a theorem about the explicit
charge recurrence, not a claim about Lean's machine execution time. -/
theorem rawPolynomialGcdBitCosted_cost_le {a b A : Nat}
    (hA : 0 < A) (ha : a < 2 ^ A) (hb : b < 2 ^ A) :
    (rawPolynomialGcdBitCosted a b).2 ≤
      (Nat.log2 b + 2) * (40 * (3 * A + 6) ^ 2 * (A + 1)) := by
  induction Nat.log2 b using Nat.strong_induction_on generalizing a b with
  | h k ih =>
      have hk : Nat.log2 b = k := rfl
      by_cases hb0 : b = 0
      · simp [rawPolynomialGcdBitCosted, hb0]
        unfold rawNatBitWidth
        nlinarith [Nat.zero_le (Nat.log2 a), Nat.zero_le A]
      · by_cases hb1 : b = 1
        · simp [rawPolynomialGcdBitCosted, hb0, hb1, rawNatBitWidth]
          nlinarith [Nat.zero_le A]
        · have hbtwo : 1 < b := by omega
          have hlogbA : Nat.log2 b < A := rawLog2_lt_of_lt_pow hA hb
          let rem := rawPolynomialRemainderBitCosted a b
          have hrem : rem.1 < 2 ^ Nat.log2 b := by
            rw [show rem.1 = rawPolynomialRemainder a b by
              dsimp [rem]
              exact rawPolynomialRemainderBitCosted_fst a b]
            exact rawPolynomialRemainder_lt_pow_log hbtwo
          have hremLog : Nat.log2 rem.1 < Nat.log2 b :=
            rawLog2_lt_of_lt_pow (by omega) hrem
          rw [hk] at hremLog
          have hremA : rem.1 < 2 ^ A := by
            apply rawRabin_lt_pow_of_log_lt
            exact lt_of_lt_of_le hremLog (Nat.le_of_lt hlogbA)
          have hremCost := rawPolynomialRemainderBitCosted_cost_le
            hA ha hbtwo
          have hwidthB : rawNatBitWidth b ≤ A := by
            unfold rawNatBitWidth
            omega
          have hwidthLog : rawNatBitWidth (Nat.log2 b) ≤ A := by
            unfold rawNatBitWidth
            omega
          have hlocal : rawNatBitWidth b + rem.2 ≤
              40 * (3 * A + 6) ^ 2 * (A + 1) := by
            dsimp [rem] at hremCost ⊢
            nlinarith [hremCost, hwidthB, hwidthLog,
              Nat.zero_le (Nat.log2 b), Nat.zero_le A]
          have hrest := ih (Nat.log2 rem.1) hremLog b rem.1 hA hb hremA
          have hrec : (rawPolynomialGcdBitCosted b rem.1).2 ≤
              (Nat.log2 rem.1 + 2) * (40 * (3 * A + 6) ^ 2 * (A + 1)) := hrest
          simp only [rawPolynomialGcdBitCosted]
          dsimp [rem]
          have hdepth : Nat.log2 rem.1 + 2 ≤ Nat.log2 b + 1 := by omega
          nlinarith [hlocal, hrec, hdepth]

end CorruptedFieldRecovery
