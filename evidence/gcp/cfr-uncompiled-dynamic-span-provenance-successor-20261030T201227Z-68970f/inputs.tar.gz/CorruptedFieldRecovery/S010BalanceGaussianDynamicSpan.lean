import CorruptedFieldRecovery.S010BalanceGaussianKernelUniqueness
import CorruptedFieldRecovery.S010BalanceGaussianArrayDeterministicScan

open scoped Matrix

namespace CorruptedFieldRecovery

/-! A reusable polynomial-time span-membership primitive.  Given an ordered
family of `n` columns and a target vector, append the target as the last
column and run the deterministic full-column Gaussian scan.  A
kernel free-variable candidate with final coordinate one is exactly a span
witness.  This source and its Gaussian dependencies are uncompiled
preservation drafts; it does not construct the field-module orbit columns or
prove their independence. -/

/-- Augment a column family by the target as its final column. -/
def balanceGaussianSpanAugmentedMatrix {m n : Nat}
    (columns : Fin n → Fin m → ZMod 2) (target : Fin m → ZMod 2) :
    Matrix (Fin m) (Fin (n + 1)) (ZMod 2) :=
  fun row column => Fin.lastCases (target row)
    (fun j => columns j row) column

/-- The full deterministic scan of an augmented span system. -/
def balanceGaussianSpanScan {m n : Nat}
    (columns : Fin n → Fin m → ZMod 2) (target : Fin m → ZMod 2) :=
  balanceGaussianColumnScan (balanceGaussianSpanAugmentedMatrix columns target)
    ∅ (List.ofFn fun j : Fin (n + 1) => j)

/-- A left-to-right Boolean selector, kept generic so the first passing free
coordinate is deterministic. -/
def balanceGaussianSpanFirstPassing {α : Type*} (test : α → Bool) :
    List α → Option α
  | [] => none
  | a :: tail => if test a then some a else balanceGaussianSpanFirstPassing test tail

private theorem balanceGaussianSpanFirstPassing_sound {α : Type*}
    (test : α → Bool) (xs : List α) {a : α}
    (h : balanceGaussianSpanFirstPassing test xs = some a) : test a = true := by
  induction xs with
  | nil => simp [balanceGaussianSpanFirstPassing] at h
  | cons x xs ih =>
      by_cases hx : test x = true
      · simp [balanceGaussianSpanFirstPassing, hx] at h
        subst a
        exact hx
      · simp [balanceGaussianSpanFirstPassing, hx] at h
        exact ih h

private theorem balanceGaussianSpanFirstPassing_complete {α : Type*}
    (test : α → Bool) (xs : List α)
    (h : ∃ a, a ∈ xs ∧ test a = true) :
    ∃ a, balanceGaussianSpanFirstPassing test xs = some a ∧ test a = true := by
  induction xs with
  | nil => simpa using h
  | cons x xs ih =>
      by_cases hx : test x = true
      · exact ⟨x, by simp [balanceGaussianSpanFirstPassing, hx], hx⟩
      · rcases h with 𧺊, ha, htest⟩
        rcases List.mem_cons.mp ha with hax | htail
        · subst a
          simp [hx] at htest
        · obtain 𧺏ound, hfound, hfoundTest⟩ := ih 𧺊, htail, htest⟩
          exact 𧺏ound, by simp [balanceGaussianSpanFirstPassing, hx, hfound], hfoundTest⟩

/-- Free indices of a complete scan, in the original column order. -/
def balanceGaussianSpanFreeIndexList {m n : Nat}
    (pivots : List (Fin m × Fin n)) : List (balanceGaussianFreeIndex pivots) :=
  (List.ofFn fun j : Fin n => j).filterMap fun j =>
    if hj : j ∉ pivots.map Prod.snd then some ⟨j, hj⟩ else none

theorem balanceGaussianSpanFreeIndexList_complete {m n : Nat}
    (pivots : List (Fin m × Fin n))
    (free : balanceGaussianFreeIndex pivots) :
    free ∈ balanceGaussianSpanFreeIndexList pivots := by
  simp [balanceGaussianSpanFreeIndexList, free.property]

/-- Deterministically choose the first free kernel candidate whose augmented
coordinate is one.  `none` is the actual negative result of the scan. -/
def balanceGaussianSpanWitness? {m n : Nat}
    (columns : Fin n → Fin m → ZMod 2) (target : Fin m → ZMod 2) :=
  let run := balanceGaussianSpanScan columns target
  balanceGaussianSpanFirstPassing
    (fun free => decide
      (balanceGaussianFreeCandidateFamily run.1 run.2 free (Fin.last n) = 1))
    (balanceGaussianSpanFreeIndexList run.2)

/-- Every free-variable candidate of the augmented span scan is in the
augmented matrix kernel. This reuses pivot-unit and unused-row invariant
theorems from the uncompiled dependency chain, not an assumed reduced form. -/
theorem balanceGaussianSpanCandidate_mem_ker {m n : Nat}
    [Fintype (Fin (n + 1))]
    (columns : Fin n → Fin m → ZMod 2) (target : Fin m → ZMod 2)
    (free : balanceGaussianFreeIndex (balanceGaussianSpanScan columns target).2) :
    balanceGaussianSpanAugmentedMatrix columns target *ᵥ
      balanceGaussianFreeCandidateFamily (balanceGaussianSpanScan columns target).1
        (balanceGaussianSpanScan columns target).2 free = 0 := by
  let A := balanceGaussianSpanAugmentedMatrix columns target
  let pivots := (balanceGaussianSpanScan columns target).2
  have hrows : (pivots.map Prod.fst).Nodup := by
    simpa [pivots, balanceGaussianSpanScan] using
      balanceGaussianColumnScan_pivotRows_nodup
        (List.ofFn fun j : Fin (n + 1) => j) A ∅
  have hunit : ∀ pivot ∈ pivots, ∀ i,
      (balanceGaussianSpanScan columns target).1 i pivot.2 =
        if i = pivot.1 then 1 else 0 := by
    intro pivot hpivot i
    exact balanceGaussianColumnScan_recordedPivots_unit
      (List.ofFn fun j : Fin (n + 1) => j) A ∅ pivot
      (by simpa [pivots, balanceGaussianSpanScan] using hpivot) i
  have hzero : ∀ i, i ∉ pivots.map Prod.fst →
      (balanceGaussianSpanScan columns target).1 i = 0 := by
    intro i hi
    funext j
    exact balanceGaussianFullColumnScan_unusedRows_zero A i
      (by simpa [pivots, balanceGaussianSpanScan] using hi) j
  apply balanceGaussianFreeKernelCandidate_mem_ker
    (balanceGaussianSpanScan columns target).1 pivots free.1 free.2 hrows hunit
  intro i hi
  exact congrFun (hzero i hi) free.1

/-- If the deterministic selector returns a free candidate, that candidate is
a genuine augmented kernel witness with final coordinate one. -/
theorem balanceGaussianSpanWitness?_sound {m n : Nat}
    [Fintype (Fin (n + 1))]
    (columns : Fin n → Fin m → ZMod 2) (target : Fin m → ZMod 2)
    {free : balanceGaussianFreeIndex (balanceGaussianSpanScan columns target).2}
    (hout : balanceGaussianSpanWitness? columns target = some free) :
    balanceGaussianSpanAugmentedMatrix columns target *ᵥ
        balanceGaussianFreeCandidateFamily (balanceGaussianSpanScan columns target).1
          (balanceGaussianSpanScan columns target).2 free = 0 ∧
      balanceGaussianFreeCandidateFamily (balanceGaussianSpanScan columns target).1
        (balanceGaussianSpanScan columns target).2 free (Fin.last n) = 1 := by
  let run := balanceGaussianSpanScan columns target
  have htest := balanceGaussianSpanFirstPassing_sound
    (fun free => decide
      (balanceGaussianFreeCandidateFamily run.1 run.2 free (Fin.last n) = 1))
    (balanceGaussianSpanFreeIndexList run.2) hout
  constructor
  · exact balanceGaussianSpanCandidate_mem_ker columns target free
  · exact of_decide_eq_true htest

/-- Completeness: any solution of the augmented kernel system whose last
coordinate is one is found by the deterministic free-candidate selector. -/
theorem balanceGaussianSpanWitness?_complete {m n : Nat}
    [Fintype (Fin (n + 1))]
    (columns : Fin n → Fin m → ZMod 2)
    (target : Fin m → ZMod 2)
    (hconsistent : ∃ x : Fin (n + 1) → ZMod 2,
      balanceGaussianSpanAugmentedMatrix columns target *ᵥ x = 0 ∧
        x (Fin.last n) = 1) :
    ∃ free, balanceGaussianSpanWitness? columns target = some free := by
  let A := balanceGaussianSpanAugmentedMatrix columns target
  let run := balanceGaussianSpanScan columns target
  rcases hconsistent with ⟨x, hxker, hlast⟩
  have hscanKer : run.1 *ᵥ x = 0 := by
    exact (balanceGaussianColumnScan_kernel_iff
      (List.ofFn fun j : Fin (n + 1) => j) A ∅ x).mp hxker
  have hrepr := balanceGaussianFullColumnScan_candidates_reconstruct A x
    (by simpa [run, balanceGaussianSpanScan] using hscanKer)
  have hexists : ∃ free : balanceGaussianFreeIndex run.2,
      balanceGaussianFreeCandidateFamily run.1 run.2 free (Fin.last n) = 1 := by
    by_contra hnone
    have hzero : ∀ free : balanceGaussianFreeIndex run.2,
        balanceGaussianFreeCandidateFamily run.1 run.2 free (Fin.last n) = 0 := by
      intro free
      have hbits : balanceGaussianFreeCandidateFamily run.1 run.2 free
          (Fin.last n) = 0 ∨
          balanceGaussianFreeCandidateFamily run.1 run.2 free (Fin.last n) = 1 := by
        fin_cases balanceGaussianFreeCandidateFamily run.1 run.2 free (Fin.last n) <;> simp
      rcases hbits with h | h
      · exact h
      · exact False.elim (hnone ⟨free, h⟩)
    have hlastEq := congrFun hrepr (Fin.last n)
    rw [hlast] at hlastEq
    simp [run, Finset.sum_apply, hzero] at hlastEq
  obtain ⟨free, hfree⟩ := hexists
  have hmem := balanceGaussianSpanFreeIndexList_complete run.2 free
  have htest : decide
      (balanceGaussianFreeCandidateFamily run.1 run.2 free (Fin.last n) = 1) = true :=
    of_decide_eq_true hfree
  obtain ⟨found, hfound, _hfoundTest⟩ :=
    balanceGaussianSpanFirstPassing_complete
      (fun free => decide
        (balanceGaussianFreeCandidateFamily run.1 run.2 free (Fin.last n) = 1))
      (balanceGaussianSpanFreeIndexList run.2) ⟨free, hmem, htest⟩
  refine ⟨found, ?_⟩
  simpa [balanceGaussianSpanWitness?, run, balanceGaussianSpanScan] using hfound

/-- The array-backed deterministic scan executes the same dynamic augmented
system. Its returned view/transcript refinement is inherited from the accepted
array scan theorem. -/
def balanceGaussianSpanArrayScan {m n : Nat}
    (columns : Fin n → Fin m → ZMod 2) (target : Fin m → ZMod 2) :=
  actualBalanceGaussianArrayColumnScan
    (Array.ofFn fun i : Fin m =>
      Array.ofFn fun j : Fin (n + 1) =>
        balanceGaussianSpanAugmentedMatrix columns target i j)
    ∅ (List.ofFn fun j : Fin (n + 1) => j)

theorem balanceGaussianSpanArrayScan_refines {m n : Nat}
    (columns : Fin n → Fin m → ZMod 2) (target : Fin m → ZMod 2) :
    (actualBalanceGaussianArrayView
        (balanceGaussianSpanArrayScan columns target).1,
      (balanceGaussianSpanArrayScan columns target).2) =
      balanceGaussianSpanScan columns target := by
  unfold balanceGaussianSpanArrayScan balanceGaussianSpanScan
  rw [actualBalanceGaussianArrayColumnScan_refines]
  ext i j
  simp [actualBalanceGaussianArrayView]

end CorruptedFieldRecovery
