import CorruptedFieldRecovery
import CorruptedFieldRecovery.RawCandidateShapeCost

set_option pp.universes true
set_option pp.explicit false
set_option pp.fullNames true
set_option pp.piBinderTypes true
set_option pp.piBinderNames true
set_option pp.piBinderNames.hygienic true
set_option pp.proofs true
set_option pp.deepTerms true
set_option pp.maxSteps 1000000
set_option maxRecDepth 10000

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawBitsToNatBitCosted"
#check @CorruptedFieldRecovery.rawBitsToNatBitCosted
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawBitsToNatBitCosted"
#print axioms CorruptedFieldRecovery.rawBitsToNatBitCosted

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawBitsToNatBitCosted_fst"
#check @CorruptedFieldRecovery.rawBitsToNatBitCosted_fst
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawBitsToNatBitCosted_fst"
#print axioms CorruptedFieldRecovery.rawBitsToNatBitCosted_fst

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawFieldBitsToNatBitCosted"
#check @CorruptedFieldRecovery.rawFieldBitsToNatBitCosted
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawFieldBitsToNatBitCosted"
#print axioms CorruptedFieldRecovery.rawFieldBitsToNatBitCosted

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawFieldBitsToNatBitCosted_fst"
#check @CorruptedFieldRecovery.rawFieldBitsToNatBitCosted_fst
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawFieldBitsToNatBitCosted_fst"
#print axioms CorruptedFieldRecovery.rawFieldBitsToNatBitCosted_fst

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawShapeCompareCharge"
#check @CorruptedFieldRecovery.rawShapeCompareCharge
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawShapeCompareCharge"
#print axioms CorruptedFieldRecovery.rawShapeCompareCharge

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawShapeDivisionCharge"
#check @CorruptedFieldRecovery.rawShapeDivisionCharge
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawShapeDivisionCharge"
#print axioms CorruptedFieldRecovery.rawShapeDivisionCharge

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawFieldCandidateShapeCheckBitCosted"
#check @CorruptedFieldRecovery.rawFieldCandidateShapeCheckBitCosted
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawFieldCandidateShapeCheckBitCosted"
#print axioms CorruptedFieldRecovery.rawFieldCandidateShapeCheckBitCosted

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawFieldCandidateShapeCheckBitCosted_fst"
#check @CorruptedFieldRecovery.rawFieldCandidateShapeCheckBitCosted_fst
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawFieldCandidateShapeCheckBitCosted_fst"
#print axioms CorruptedFieldRecovery.rawFieldCandidateShapeCheckBitCosted_fst
