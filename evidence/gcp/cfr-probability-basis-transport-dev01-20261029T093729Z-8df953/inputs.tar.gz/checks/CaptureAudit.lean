import CorruptedFieldRecovery
import CorruptedFieldRecovery.ProbabilityBasisTransport

set_option pp.universes true
set_option pp.explicit false
set_option pp.fullNames true
set_option pp.piBinderTypes true
set_option pp.piBinderNames true
set_option pp.piBinderNames.hygienic true
set_option pp.proofs true
set_option pp.deepTerms true
set_option pp.maxSteps 1000000
set_option maxRecDepth 10000

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.sampled_basis_bad_coordinate_count"
#check @CorruptedFieldRecovery.sampled_basis_bad_coordinate_count
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.sampled_basis_bad_coordinate_count"
#print axioms CorruptedFieldRecovery.sampled_basis_bad_coordinate_count
