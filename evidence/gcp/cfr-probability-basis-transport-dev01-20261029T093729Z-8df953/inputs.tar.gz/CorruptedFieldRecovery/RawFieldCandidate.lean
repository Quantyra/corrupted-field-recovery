import Mathlib.Data.Array.Lemmas

/-! Executable raw-data checks for the serialized binary quotient-field
candidate. This module checks the canonical array shape and nonzero scalar
encoding. Polynomial irreducibility and the tensor representation are
intentionally not claimed here: they need an executable binary-polynomial
algorithm and a separate soundness bridge.
-/

namespace CorruptedFieldRecovery

/-- Little-endian raw bits used for polynomial and field-element encodings. -/
abbrev RawFieldBits := Array Bool

/-- Raw polynomial and coefficient arrays for an extension of degree `s`. -/
structure RawFieldCandidate (s : Nat) where
  modulus : RawFieldBits
  scalar : RawFieldBits

/-- Check exact serialized lengths, a set leading coefficient, and a scalar
array that is not the zero vector. This function uses only finite Boolean
array operations and is executable on every input. -/
def rawFieldCandidateCheck {s : Nat} (p : RawFieldCandidate s) : Bool :=
  decide (p.modulus.size = s + 1) &&
  decide (p.scalar.size = s) &&
  p.modulus[s]! &&
  decide (p.scalar != Array.replicate s false)

/-- Acceptance yields exactly the raw shape and nonzero-vector properties
tested by the executable gate. -/
theorem accepted_rawFieldCandidateCheck {s : Nat} (p : RawFieldCandidate s)
    (h : rawFieldCandidateCheck p = true) :
    p.modulus.size = s + 1 ∧
    p.scalar.size = s ∧
    p.modulus[s]! = true ∧
    p.scalar != Array.replicate s false := by
  simp only [rawFieldCandidateCheck, Bool.and_eq_true] at h
  rcases h with ⟨h₁, h₂, h₃, h₄⟩
  exact ⟨of_decide_eq_true h₁, of_decide_eq_true h₂, h₃, of_decide_eq_true h₄⟩

/-- The two valid degree-one modulus encodings both pass the shape gate; in
particular, it does not reject `X` because its constant coefficient is zero. -/
example : rawFieldCandidateCheck
    (⟨#[false, true], #[true]⟩ : RawFieldCandidate 1) = true := by decide

example : rawFieldCandidateCheck
    (⟨#[true, true], #[true]⟩ : RawFieldCandidate 1) = true := by decide

end CorruptedFieldRecovery
