import CorruptedFieldRecovery.RawCoefficientFitOutputBridge
import CorruptedFieldRecovery.RawExecutableTraceCertificate
import CorruptedFieldRecovery.S010ObservedCleanTensor
import Mathlib.LinearAlgebra.Dual.Lemmas
import Mathlib.LinearAlgebra.FiniteDimensional.Lemmas

/-! # Clean trace support separation from a small physical support

Uncompiled proof draft. The central claim is that a nonzero trace-scaled
determinant on a `3s`-dimensional binary space has full mode image: every
nonzero third-slot vector is detected by a trace-determinant contraction.
Consequently it cannot be absorbed into a pullback through a support map of
dimension at most `R` when `3s > R`. This rules out every coefficient fit
whose trace-scalar slots are all zero, provided the original model has its
explicit nonzero trace scalar. It does not prove model consistency or the
scalar-column expansion. -/

namespace CorruptedFieldRecovery

private theorem binaryTracePairing_nondegenerate_for_separation
    {K : Type*} [Field K] [Finite K] [Algebra BinaryField K]
    [FiniteDimensional BinaryField K] {a : K} (ha : a ≠ 0) :
    ∃ b : K, Algebra.trace BinaryField K (a * b) ≠ 0 := by
  have htrace := (traceForm_nondegenerate BinaryField K).1 a
  simp_rw [Algebra.traceForm_apply] at htrace
  by_contra! hbad
  exact ha (htrace hbad)

/-- The Q-transported trace determinant has zero dual coannihilator. For any
nonzero `z`, one of its three field coordinates is nonzero; choose the other
two coordinate basis vectors and use nondegeneracy of the finite-field trace
pairing to obtain a contraction that detects `z`. -/
theorem traceDeterminantTensor_dualCoannihilator_eq_bot
    {K : Type*} [Field K] [Finite K] [Algebra BinaryField K]
    [FiniteDimensional BinaryField K]
    {n : Nat} (Q : BinaryVector n ≃ₗ[BinaryField] FieldTriple K)
    (c : K) (hc : c ≠ 0) :
    (modeImage (traceDeterminantTensor K c Q.symm.toLinearMap)).dualCoannihilator = ⊥ := by
  classical
  ext z
  rw [Submodule.mem_dualCoannihilator, Submodule.mem_bot]
  constructor
  · intro hz
    by_contra hzne
    let v := Q z
    have hv : v ≠ 0 := by
      intro hzero
      apply hzne
      exact Q.injective (by simpa [v] using hzero)
    by_cases ha : v.1 ≠ 0
    · obtain ⟨t, ht⟩ := binaryTracePairing_nondegenerate_for_separation
        (a := c * v.1) (mul_ne_zero hc ha)
      let x := Q.symm (t • fieldBasis1 K)
      let y := Q.symm (fieldBasis2 K)
      have hmem : traceDeterminantTensor K c Q.symm.toLinearMap x y ∈
          modeImage (traceDeterminantTensor K c Q.symm.toLinearMap) :=
        Submodule.subset_span ⟨(x, y), rfl⟩
      have hzero := hz _ hmem
      have hvalue : traceDeterminantTensor K c Q.symm.toLinearMap x y z =
          Algebra.trace BinaryField K ((c * v.1) * t) := by
        rw [traceDeterminantTensor_apply]
        simp [x, y, v, Q.apply_symm_apply, fieldDet3, fieldBasis1,
          fieldBasis2]
        ring
      exact ht (by simpa [hvalue] using hzero)
    · by_cases hb : v.2.1 ≠ 0
      · obtain ⟨t, ht⟩ := binaryTracePairing_nondegenerate_for_separation
          (a := c * v.2.1) (mul_ne_zero hc hb)
        let x := Q.symm (t • fieldBasis2 K)
        let y := Q.symm (fieldBasis0 K)
        have hmem : traceDeterminantTensor K c Q.symm.toLinearMap x y ∈
            modeImage (traceDeterminantTensor K c Q.symm.toLinearMap) :=
          Submodule.subset_span ⟨(x, y), rfl⟩
        have hzero := hz _ hmem
        have hvalue : traceDeterminantTensor K c Q.symm.toLinearMap x y z =
            Algebra.trace BinaryField K ((c * v.2.1) * t) := by
          rw [traceDeterminantTensor_apply]
          simp [x, y, v, Q.apply_symm_apply, fieldDet3, fieldBasis0,
            fieldBasis2]
          ring
        exact ht (by simpa [hvalue] using hzero)
      · have hc3 : v.2.2 ≠ 0 := by
          intro hzero
          apply hv
          exact Prod.ext (by simp [v, ha]) (Prod.ext (by simp [v, hb]) hzero)
        obtain ⟨t, ht⟩ := binaryTracePairing_nondegenerate_for_separation
          (a := c * v.2.2) (mul_ne_zero hc hc3)
        let x := Q.symm (t • fieldBasis0 K)
        let y := Q.symm (fieldBasis1 K)
        have hmem : traceDeterminantTensor K c Q.symm.toLinearMap x y ∈
            modeImage (traceDeterminantTensor K c Q.symm.toLinearMap) :=
          Submodule.subset_span ⟨(x, y), rfl⟩
        have hzero := hz _ hmem
        have hvalue : traceDeterminantTensor K c Q.symm.toLinearMap x y z =
            Algebra.trace BinaryField K ((c * v.2.2) * t) := by
          rw [traceDeterminantTensor_apply]
          simp [x, y, v, Q.apply_symm_apply, fieldDet3, fieldBasis0,
            fieldBasis1]
          ring
        exact ht (by simpa [hvalue] using hzero)
  · intro hz
    simp [hz]

/-- Full mode-image rank of a nonzero trace-determinant tensor. The ambient
space has dimension `n`; zero dual coannihilator and the dual dimension formula
force the mode image to have dimension `n`. -/
theorem traceDeterminantTensor_modeImage_finrank
    {K : Type*} [Field K] [Finite K] [Algebra BinaryField K]
    [FiniteDimensional BinaryField K]
    {n : Nat} (Q : BinaryVector n ≃ₗ[BinaryField] FieldTriple K)
    (c : K) (hc : c ≠ 0) :
    Module.finrank BinaryField
      (modeImage (traceDeterminantTensor K c Q.symm.toLinearMap)) = n := by
  let W := modeImage (traceDeterminantTensor K c Q.symm.toLinearMap)
  have hcoann := traceDeterminantTensor_dualCoannihilator_eq_bot Q c hc
  have hV : Module.finrank BinaryField (BinaryVector n) = n := by
    rw [Module.finrank_eq_card_basis (Pi.basisFun BinaryField (Fin n))]
    simp
  have hsum := Subspace.finrank_add_finrank_dualCoannihilator_eq W
  rw [hcoann, Module.finrank_bot, Subspace.dual_finrank_eq, hV] at hsum
  simpa [W] using hsum

/-- If a compact fit has every scalar-column coefficient zero, its input
tensor factors through the supplied support map. The support coefficients
are decoded as an alternating tensor in the support coordinates; the
minor-basis identity supplies its pullback expansion. -/
theorem rawCoefficientFit_zeroScalar_implies_supported {s d : Nat}
    (candidate : RawFieldCandidate s)
    (hcheck : rawFieldCandidateCheck candidate = true)
    (inverse : RawCoordinateMatrix) (supportMatrix : RawBinaryArray)
    (raw : RawCoefficientArray)
    (coefficients : RawCoefficientFitColumnIndex s d → ZMod 2)
    (hfit : RawCoefficientFitAffineSolution candidate hcheck inverse
      supportMatrix raw)
    (hzero : ∀ j : Fin s, coefficients (Sum.inl j) = 0) :
    decodeRawArray (n := 3 * s) raw =
      pullback
        (decodeDenseInput (fun e : IncreasingTriple d => coefficients (Sum.inr e)))
        (rawSupportMap (n := 3 * s) (d := d) supportMatrix) := by
  classical
  have hsupportExpansion : ∀ row : IncreasingTriple (3 * s),
      encodeDenseInput
        (pullback
          (decodeDenseInput (fun e : IncreasingTriple d => coefficients (Sum.inr e)))
          (rawSupportMap (n := 3 * s) (d := d) supportMatrix)) row =
        ∑ e : IncreasingTriple d,
          rawExteriorSupportFitColumn supportMatrix e row * coefficients (Sum.inr e) := by
    intro row
    simp [encodeDenseInput, pullback_apply, decodeDenseInput,
      rawExteriorSupportFitColumn, LinearMap.sum_apply, LinearMap.smul_apply]
  have hcoeff : ∀ row : IncreasingTriple (3 * s),
      encodeDenseInput (decodeRawArray (n := 3 * s) raw) row =
        encodeDenseInput
          (pullback
            (decodeDenseInput (fun e : IncreasingTriple d => coefficients (Sum.inr e)))
            (rawSupportMap (n := 3 * s) (d := d) supportMatrix)) row := by
    intro row
    have hrow := hfit.2 row
    rw [Fintype.sum_sum_type] at hrow
    have hleft :
        (∑ j : Fin s,
          rawCoefficientFitEntry candidate hcheck inverse supportMatrix row (Sum.inl j) *
            coefficients (Sum.inl j)) = 0 := by
      simp [hzero]
    rw [hleft] at hrow
    rw [rawCoefficientFitRhs_eq_decoded] at hrow
    rw [hsupportExpansion row]
    simpa [rawCoefficientFitEntry, RawCoefficientFitColumnIndex] using hrow
  have hrightAlt : IsAlternating
      (pullback
        (decodeDenseInput (fun e : IncreasingTriple d => coefficients (Sum.inr e)))
        (rawSupportMap (n := 3 * s) (d := d) supportMatrix)) := by
    have hE := decodeDenseInput_isAlternating
      (fun e : IncreasingTriple d => coefficients (Sum.inr e))
    refine ⟨?_, ?_, ?_⟩
    · intro x z
      simpa only [pullback_apply] using hE.1
        (rawSupportMap supportMatrix x) (rawSupportMap supportMatrix z)
    · intro x y
      simpa only [pullback_apply] using hE.2.1
        (rawSupportMap supportMatrix x) (rawSupportMap supportMatrix y)
    · intro x y
      simpa only [pullback_apply] using hE.2.2
        (rawSupportMap supportMatrix x) (rawSupportMap supportMatrix y)
  apply binaryTensor_ext_of_increasing_coefficients
  · exact decodeRawArray_isAlternating (n := 3 * s) raw
  · exact hrightAlt
  · intro i j k hij hjk
    let row : IncreasingTriple (3 * s) := ⟨((i, j), k), ⟨hij, hjk⟩⟩
    have hr := hcoeff row
    simpa [row, encodeDenseInput_eq_semanticCoefficient] using hr

/-- Under the manuscript's actual model decomposition, no compact fit can
have an all-zero trace-scalar block when the clean field tensor has full mode
image and `d ≤ R < 3s`. This is the needed separation result for any
deterministic affine-solver output; it does not depend on which valid solution
the Gaussian scan selects. -/
theorem rawCoefficientFit_no_zeroScalar_solution {s R d : Nat}
    (candidate : RawFieldCandidate s)
    (hfield : rawFieldCandidateCheck candidate = true)
    (forward inverse : RawCoordinateMatrix)
    (hcoordinates : rawCoordinateMatrixCheck (n := 3 * s) forward inverse = true)
    (supportMatrix : RawBinaryArray) (raw residual : RawCoefficientArray)
    (hmodel : RawCoefficientFitModelDecomposition raw candidate hfield forward inverse
      hcoordinates residual supportMatrix)
    (hd : d ≤ R) (hs : 2 * R + 5 ≤ s)
    (coefficients : RawCoefficientFitColumnIndex s d → ZMod 2)
    (hfit : RawCoefficientFitAffineSolution candidate hfield inverse supportMatrix raw)
    (hzero : ∀ j : Fin s, coefficients (Sum.inl j) = 0) : False := by
  classical
  have hsupported := rawCoefficientFit_zeroScalar_implies_supported candidate hfield
    inverse supportMatrix raw coefficients hfit hzero
  letI : Fact (Irreducible (rawCandidateModulus candidate)) :=
    ⟨accepted_rawCandidateModulus_irreducible candidate hfield⟩
  let K := AdjoinRoot (rawCandidateModulus candidate)
  have hvalid := accepted_rawFieldCandidateCheck candidate hfield
  have hmod := rawFieldCandidateValid_modulus_polynomial candidate hvalid
  letI : Module.Finite BinaryField K := by
    simpa [rawCandidateModulus] using hmod.1.finite_adjoinRoot
  let coords := accepted_rawCandidatePhysicalCoordinates candidate hfield
    forward inverse hcoordinates
  let c : K := AdjoinRoot.mk (rawCandidateModulus candidate)
    (rawCandidateScalar candidate)
  have hc : c ≠ 0 := by
    simpa [c] using accepted_rawCandidate_scalar_residue_ne_zero candidate hfield
  have hrank : Module.finrank BinaryField (modeImage
      (rawTraceDetTensor candidate hfield forward inverse hcoordinates)) = 3 * s := by
    have h := traceDeterminantTensor_modeImage_finrank coords c hc
    simpa [rawTraceDetTensor, K, coords, c] using h
  have hresidueModel :
      rawTraceDetTensor candidate hfield forward inverse hcoordinates =
        pullback
          (decodeDenseInput (fun e : IncreasingTriple d => coefficients (Sum.inr e)) +
            decodeRawArray (n := d) residual)
          (rawSupportMap (n := 3 * s) (d := d) supportMatrix) := by
    have hsum := congrArg (fun tensor : BinaryTensor (3 * s) => tensor) hmodel
    rw [hsupported] at hsum
    have hcancel :
        rawTraceDetTensor candidate hfield forward inverse hcoordinates +
          pullback (decodeRawArray (n := d) residual)
            (rawSupportMap (n := 3 * s) (d := d) supportMatrix) =
        pullback
          (decodeDenseInput (fun e : IncreasingTriple d => coefficients (Sum.inr e)))
          (rawSupportMap (n := 3 * s) (d := d) supportMatrix) := hsum.symm
    calc
      rawTraceDetTensor candidate hfield forward inverse hcoordinates =
          rawTraceDetTensor candidate hfield forward inverse hcoordinates +
            (pullback (decodeRawArray (n := d) residual)
              (rawSupportMap (n := 3 * s) (d := d) supportMatrix) +
             pullback (decodeRawArray (n := d) residual)
              (rawSupportMap (n := 3 * s) (d := d) supportMatrix)) := by
                simp
      _ = _ := by
        rw [← add_assoc, hcancel]
        simp [pullback_apply]
  have hsmall : Module.finrank BinaryField (modeImage
      (pullback
        (decodeDenseInput (fun e : IncreasingTriple d => coefficients (Sum.inr e)) +
          decodeRawArray (n := d) residual)
        (rawSupportMap (n := 3 * s) (d := d) supportMatrix))) ≤ R :=
    modeImage_pullback_finrank_le_supportDimension _ _ hd
  have heqrank := congrArg (fun tensor : BinaryTensor (3 * s) =>
      Module.finrank BinaryField (modeImage tensor)) hresidueModel
  rw [hrank] at heqrank
  omega

end CorruptedFieldRecovery
