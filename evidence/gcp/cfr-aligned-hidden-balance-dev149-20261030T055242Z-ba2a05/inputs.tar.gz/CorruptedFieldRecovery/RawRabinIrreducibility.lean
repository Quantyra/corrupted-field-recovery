import CorruptedFieldRecovery.RawExecutableTraceCertificate

/-! A finite-mask Rabin-style irreducibility route. Polynomial remainder and
Euclidean gcd are computed on Nat masks; Frobenius powers are formed by
repeated quotient squaring. -/

namespace CorruptedFieldRecovery

/-- Nat-mask polynomial remainder by a nonzero mask. The fuel is bounded by
the dividend bit width; the quotient proof is available for every fuel. -/
def rawPolynomialRemainder (dividend divisor : Nat) : Nat :=
  if divisor = 0 then dividend else
    rawReduceFuel divisor (Nat.log2 divisor) (Nat.log2 dividend + 1) dividend

theorem rawPolynomialRemainder_lt {a b : Nat} (hb : b ≠ 0) :
    rawPolynomialRemainder a b < b := by
  have hlow : 2 ^ Nat.log2 b ≤ b := Nat.log2_self_le (Nat.pos_of_ne_zero hb)
  have hupp : b < 2 ^ (Nat.log2 b + 1) := Nat.lt_log2_self
  have hfuel : Nat.log2 a - Nat.log2 b + 1 ≤ Nat.log2 a + 1 := by omega
  have hrem := rawReduceFuel_lt_of_modulus_band_logFuel
    (s := Nat.log2 b) (modulus := b) (a := a) (fuel := Nat.log2 a + 1)
    hlow hupp hfuel
  have hpow := Nat.log2_self_le (Nat.pos_of_ne_zero hb)
  unfold rawPolynomialRemainder
  simp only [if_neg hb]
  exact lt_of_lt_of_le hrem hpow

/-- Mask remainder preserves the polynomial quotient class modulo the divisor
mask, by the actual bounded Nat reduction. -/
theorem rawPolynomialRemainder_quotient_sound {a b : Nat} (hb : b ≠ 0) :
    AdjoinRoot.mk (rawMaskPolynomial b)
        (rawMaskPolynomial (rawPolynomialRemainder a b)) =
      AdjoinRoot.mk (rawMaskPolynomial b) (rawMaskPolynomial a) := by
  unfold rawPolynomialRemainder
  simp only [if_neg hb]
  exact rawReduceFuel_quotient_sound b (Nat.log2 b) (Nat.log2 a + 1) a

/-- Euclidean gcd on Nat masks. Each recursive divisor is the canonical
remainder, so the second argument strictly decreases. -/
def rawPolynomialGcd : Nat → Nat → Nat
  | a, 0 => a
  | a, b + 1 => rawPolynomialGcd (b + 1) (rawPolynomialRemainder a (b + 1))
termination_by _ b => b
decreasing_by
  exact rawPolynomialRemainder_lt (by omega)

/-- Repeated quotient squaring computes the `d`th Frobenius power of a mask. -/
def rawCandidateFrobeniusAux {s : Nat} (candidate : RawFieldCandidate s)
    (hfield : rawFieldCandidateCheck candidate = true) : Nat → Nat → Nat
  | 0, x => x
  | d + 1, x => rawCandidateFrobeniusAux candidate hfield d
      (rawFieldMulBits candidate hfield x x)

def rawCandidateFrobenius {s : Nat} (candidate : RawFieldCandidate s)
    (hfield : rawFieldCandidateCheck candidate = true) (d : Nat) : Nat :=
  rawCandidateFrobeniusAux candidate hfield d 2

/-- The executable low-degree Frobenius gcd checks: every possible proper
irreducible factor degree is tested against `X^(2^d)-X`. -/
def rawCandidateRabinCheck {s : Nat} (candidate : RawFieldCandidate s)
    (hfield : rawFieldCandidateCheck candidate = true) : Bool :=
  decide (∀ d ∈ Finset.Icc 1 (s / 2),
    rawPolynomialGcd (rawFieldBitsToNat candidate.modulus)
      (Nat.xor (rawCandidateFrobenius candidate hfield d) 2) = 1)

end CorruptedFieldRecovery
