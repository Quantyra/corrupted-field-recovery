import CorruptedFieldRecovery.S010BalanceGaussianAffineArrayOutputRefinementFixed

open scoped Matrix

namespace CorruptedFieldRecovery

/-! Candidate-specific correctness for the corrected affine output.  The
selected free kernel vector is the one used to compute the returned
coefficients.  The array theorem is obtained only after the exact output
refinement from the preceding draft.  This source remains uncompiled. -/

/-- Corrected matrix-view coefficient projection: a free candidate is a
single vector, and its coefficient at `j` is its `Fin.castSucc j` entry. -/
def actualBalanceGaussianAffineMatrixRecurrenceValueCorrected {s : Nat}
    (T : Module.End BinaryField (BinaryVector (3 * s)))
    (free : balanceGaussianFreeIndex
      (balanceGaussianColumnScan (actualBalanceGaussianAffinePowerMatrix T)
        ∅ (List.ofFn fun j : Fin (s + 1) => j)).2) : Fin s → ZMod 2 :=
  let run := balanceGaussianColumnScan (actualBalanceGaussianAffinePowerMatrix T)
    ∅ (List.ofFn fun j : Fin (s + 1) => j)
  fun j => balanceGaussianFreeCandidateFamily run.1 run.2 free
    (Fin.castSucc j)

/-- Matrix-view option output using the corrected coefficient projection. -/
def actualBalanceGaussianAffineMatrixRecurrenceCorrected? {s : Nat}
    (T : Module.End BinaryField (BinaryVector (3 * s))) :
    Option (Fin s → ZMod 2) :=
  (actualBalanceGaussianAffineSelectFreeIndex
    (actualBalanceGaussianAffinePowerMatrix T)).map
    (actualBalanceGaussianAffineMatrixRecurrenceValueCorrected T)

/-- If the first `s` powers are independent in the `s`-dimensional scalar
range, the exact free candidate selected by the matrix scan has final
coordinate one, lies in the augmented matrix kernel, and its first `s`
coordinates are the coefficients returned by the corrected option output. -/
theorem actualBalanceGaussianAffineMatrixRecurrenceCorrected?_correct
    {K : Type*} [Field K] [Fintype K] [DecidableEq K] [Finite K]
    [CharP K 2] [Algebra BinaryField K]
    [FiniteDimensional BinaryField K]
    {s : Nat}
    (Q : BinaryVector (3 * s) ≃ₗ[BinaryField] FieldTriple K)
    (T : Module.End BinaryField (BinaryVector (3 * s)))
    (hT : T ∈ qScalarConjugateEndRange Q)
    (hK : Module.finrank BinaryField K = s)
    (hpow : LinearIndependent BinaryField (fun i : Fin s => T ^ i.val)) :
    ∃ coefficients,
      actualBalanceGaussianAffineMatrixRecurrenceCorrected? T = some coefficients ∧
      T ^ s = ∑ j : Fin s, coefficients j • T ^ j.val := by
  obtain ⟨witnessCoefficients, hwitness⟩ :=
    actualBalanceGaussianPowerRecurrence_exists_of_independent
      Q T hT hK hpow
  let A := actualBalanceGaussianAffinePowerMatrix T
  have hsolution : ∃ x, A *ᵥ x = 0 ∧ x (Fin.last s) = 1 := by
    refine ⟨actualBalanceGaussianAffinePowerWitness witnessCoefficients,
      (actualBalanceGaussianAffinePowerMatrix_mulVec_witness_iff T
        witnessCoefficients).2 hwitness, ?_⟩
    simp [actualBalanceGaussianAffinePowerWitness]
  obtain ⟨free, hselected, hlast⟩ :=
    actualBalanceGaussianAffineSelectFreeIndex_some_of_witness A hsolution
  let run := balanceGaussianColumnScan A ∅
    (List.ofFn fun j : Fin (s + 1) => j)
  let coefficients := actualBalanceGaussianAffineMatrixRecurrenceValueCorrected T free
  have hker : A *ᵥ balanceGaussianFreeCandidateFamily run.1 run.2 free = 0 := by
    simpa [run, A] using actualBalanceGaussianAffineFreeCandidate_mem_ker A free
  have hdecomp : balanceGaussianFreeCandidateFamily run.1 run.2 free =
      Fin.snoc coefficients 1 := by
    funext i
    refine Fin.lastCases ?_ ?_ i
    · simpa [coefficients, actualBalanceGaussianAffineMatrixRecurrenceValueCorrected,
        run, A] using hlast
    · intro j
      rfl
  have hrecurrence : T ^ s = ∑ j : Fin s, coefficients j • T ^ j.val := by
    apply (actualBalanceGaussianAffinePowerMatrix_mulVec_witness_iff
      T coefficients).mp
    rw [← hdecomp]
    exact hker
  refine ⟨coefficients, ?_, hrecurrence⟩
  simp [actualBalanceGaussianAffineMatrixRecurrenceCorrected?, coefficients,
    actualBalanceGaussianAffineMatrixRecurrenceValueCorrected, hselected, run, A]

/-- The array-derived option output has the same selected coefficient vector,
so its actual output satisfies the recurrence under the same hypotheses. -/
theorem actualBalanceGaussianAffineArrayRecurrenceFixed?_correct
    {K : Type*} [Field K] [Fintype K] [DecidableEq K] [Finite K]
    [CharP K 2] [Algebra BinaryField K]
    [FiniteDimensional BinaryField K]
    {s : Nat}
    (Q : BinaryVector (3 * s) ≃ₗ[BinaryField] FieldTriple K)
    (T : Module.End BinaryField (BinaryVector (3 * s)))
    (hT : T ∈ qScalarConjugateEndRange Q)
    (hK : Module.finrank BinaryField K = s)
    (hpow : LinearIndependent BinaryField (fun i : Fin s => T ^ i.val)) :
    ∃ coefficients,
      actualBalanceGaussianAffineArrayRecurrenceFixed? T = some coefficients ∧
      T ^ s = ∑ j : Fin s, coefficients j • T ^ j.val := by
  obtain ⟨coefficients, houtput, hrecurrence⟩ :=
    actualBalanceGaussianAffineMatrixRecurrenceCorrected?_correct
      Q T hT hK hpow
  refine ⟨coefficients, ?_, hrecurrence⟩
  rw [actualBalanceGaussianAffineArrayRecurrenceFixed?_eq_matrix]
  exact houtput

end CorruptedFieldRecovery
