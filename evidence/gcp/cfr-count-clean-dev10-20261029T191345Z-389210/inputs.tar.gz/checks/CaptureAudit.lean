import CorruptedFieldRecovery
import CorruptedFieldRecovery.S010CleanLossBounds
import CorruptedFieldRecovery.S010CountProduct

set_option pp.universes true
set_option pp.explicit false
set_option pp.fullNames true
set_option pp.piBinderTypes true
set_option pp.piBinderNames true
set_option pp.piBinderNames.hygienic true
set_option pp.proofs true
set_option pp.deepTerms true
set_option pp.maxSteps 1000000
set_option maxRecDepth 10000

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.one_sub_mul_one_sub_lower"
#check @CorruptedFieldRecovery.one_sub_mul_one_sub_lower
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.one_sub_mul_one_sub_lower"
#print axioms CorruptedFieldRecovery.one_sub_mul_one_sub_lower

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.four_one_sub_product_lower"
#check @CorruptedFieldRecovery.four_one_sub_product_lower
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.four_one_sub_product_lower"
#print axioms CorruptedFieldRecovery.four_one_sub_product_lower

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.four_nat_sub_factors_normalized_lower"
#check @CorruptedFieldRecovery.four_nat_sub_factors_normalized_lower
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.four_nat_sub_factors_normalized_lower"
#print axioms CorruptedFieldRecovery.four_nat_sub_factors_normalized_lower

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.four_clean_losses_le_beta"
#check @CorruptedFieldRecovery.four_clean_losses_le_beta
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.four_clean_losses_le_beta"
#print axioms CorruptedFieldRecovery.four_clean_losses_le_beta
