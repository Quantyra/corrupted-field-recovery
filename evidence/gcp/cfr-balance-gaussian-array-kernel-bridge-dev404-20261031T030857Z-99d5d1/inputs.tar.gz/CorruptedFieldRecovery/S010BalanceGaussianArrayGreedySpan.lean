import CorruptedFieldRecovery.S010BalanceGaussianArrayKernelBridge
import CorruptedFieldRecovery.S010BalanceGaussianKernelUniqueness

open scoped Matrix

namespace CorruptedFieldRecovery

/-! # Array-backed greedy span membership

Disjoint proof draft. Given an ordered array of physical columns and a target,
append the target as the final column, run the actual nested-array Gaussian
scan, and inspect its free-variable kernel candidates. A candidate with final
coordinate one is exactly a witness that the target is in the original
column span. This module does not yet prove the quotient-orbit growth or the
three-pass module-basis theorem. -/

/-- The semantic matrix whose columns are the supplied physical vectors,
followed by the target as the last column. -/
def actualGreedyArrayAugmentedMatrix {m : Nat}
    (columns : Array (Fin m → ZMod 2)) (target : Fin m → ZMod 2) :
    Matrix (Fin m) (Fin (columns.size + 1)) (ZMod 2) :=
  fun row col => Fin.lastCases (target row)
    (fun j => columns[j.val]! row) col

/-- Row-major serialization of the augmented matrix consumed by the array
scan. -/
def actualGreedyArrayAugmentedCells {m : Nat}
    (columns : Array (Fin m → ZMod 2)) (target : Fin m → ZMod 2) :
    Array (Array (ZMod 2)) :=
  Array.ofFn fun row : Fin m =>
    Array.ofFn fun col : Fin (columns.size + 1) =>
      actualGreedyArrayAugmentedMatrix columns target row col

/-- Reading the row-major augmented array gives the stated finite matrix. -/
theorem actualGreedyArrayAugmentedCells_view {m : Nat}
    (columns : Array (Fin m → ZMod 2)) (target : Fin m → ZMod 2) :
    actualBalanceGaussianArrayView
        (m := m) (n := columns.size + 1)
        (actualGreedyArrayAugmentedCells columns target) =
      actualGreedyArrayAugmentedMatrix columns target := by
  ext row col
  simp [actualBalanceGaussianArrayView, actualGreedyArrayAugmentedCells]

/-- The actual full-column array scan of the augmented system. -/
def actualGreedyArrayAugmentedScan {m : Nat}
    (columns : Array (Fin m → ZMod 2)) (target : Fin m → ZMod 2) :=
  actualBalanceGaussianArrayColumnScan
    (actualGreedyArrayAugmentedCells columns target) ∅
    (List.ofFn fun col : Fin (columns.size + 1) => col)

/-- The deterministic matrix scan of the same augmented system has exactly
the matrix view and pivot transcript returned by the actual array scan. -/
theorem actualGreedyArrayAugmentedScan_refines {m : Nat}
    (columns : Array (Fin m → ZMod 2)) (target : Fin m → ZMod 2) :
    (actualBalanceGaussianArrayView
        (m := m) (n := columns.size + 1)
        (actualGreedyArrayAugmentedScan columns target).1,
      (actualGreedyArrayAugmentedScan columns target).2) =
      balanceGaussianColumnScan
        (actualGreedyArrayAugmentedMatrix columns target) ∅
        (List.ofFn fun col : Fin (columns.size + 1) => col) := by
  unfold actualGreedyArrayAugmentedScan
  rw [actualBalanceGaussianArrayColumnScan_refines,
    actualGreedyArrayAugmentedCells_view]

/-- Test whether one scanned column is free and its canonical free-kernel
candidate has coefficient one on the appended target coordinate. -/
def actualGreedyArraySpanCandidateTest {m k : Nat}
    (run : Array (Array (ZMod 2)) × List (Fin m × Fin (k + 1)))
    (column : Fin (k + 1)) : Bool :=
  decide (column ∉ run.2.map Prod.snd) &&
    decide (balanceGaussianFreeKernelCandidate
      (actualBalanceGaussianArrayView (m := m) (n := k + 1) run.1)
      run.2 column (Fin.last k) = 1)

/-- Return the first free-variable witness whose augmented target coordinate
is one. This is a deterministic executable finite scan over column indices. -/
def actualGreedyArraySpanWitness? {m : Nat}
    (columns : Array (Fin m → ZMod 2)) (target : Fin m → ZMod 2) :
    Option (Fin (columns.size + 1)) :=
  let run := actualGreedyArrayAugmentedScan columns target
  (List.ofFn fun col : Fin (columns.size + 1) => col).find?
    (actualGreedyArraySpanCandidateTest run)

/-- Semantic column-span membership for an array of vectors. -/
def actualGreedyArrayColumnSpanContains {m : Nat}
    (columns : Array (Fin m → ZMod 2)) (target : Fin m → ZMod 2) : Prop :=
  ∃ coeff : Fin columns.size → ZMod 2,
    (fun row => ∑ j : Fin columns.size, columns[j.val]! row * coeff j) = target

/-- Multiplication by the last-column augmentation on `Fin.snoc` coefficients
is the original column combination plus the target. -/
theorem actualGreedyArrayAugmentedMatrix_mulVec_snoc {m : Nat}
    (columns : Array (Fin m → ZMod 2)) (target : Fin m → ZMod 2)
    (coeff : Fin columns.size → ZMod 2) :
    actualGreedyArrayAugmentedMatrix columns target *ᵥ Fin.snoc coeff 1 =
      (fun row => ∑ j : Fin columns.size, columns[j.val]! row * coeff j) + target := by
  funext row
  simp [actualGreedyArrayAugmentedMatrix, Matrix.mulVec, dotProduct,
    Fin.sum_univ_castSucc, Fin.snoc_castSucc, Fin.snoc_last,
    Fin.val_castSucc, Fin.val_last]
  ring

/-- Exact equivalence between a semantic column-span witness and a kernel
vector of the augmented matrix whose final coordinate is one. -/
theorem actualGreedyArrayColumnSpan_iff_augmentedKernel {m : Nat}
    (columns : Array (Fin m → ZMod 2)) (target : Fin m → ZMod 2) :
    actualGreedyArrayColumnSpanContains columns target ↔
      ∃ z : Fin (columns.size + 1) → ZMod 2,
        actualGreedyArrayAugmentedMatrix columns target *ᵥ z = 0 ∧
          z (Fin.last columns.size) = 1 := by
  constructor
  · rintro ⟨coeff, hcoeff⟩
    refine ⟨Fin.snoc coeff 1, ?_, ?_⟩
    · rw [actualGreedyArrayAugmentedMatrix_mulVec_snoc, hcoeff]
      apply funext
      intro row
      exact ZModModule.add_self (target row)
    · simp
  · rintro ⟨z, hz, hlast⟩
    let coeff : Fin columns.size → ZMod 2 := fun j => z j.castSucc
    have hzdecomp : z = Fin.snoc coeff 1 := by
      funext i
      refine Fin.lastCases ?_ ?_ i
      · simpa [coeff] using hlast
      · intro j
        rfl
    have hsum :
        (fun row => ∑ j : Fin columns.size, columns[j.val]! row * coeff j) +
          target = 0 := by
      rw [hzdecomp, actualGreedyArrayAugmentedMatrix_mulVec_snoc] at hz
      exact hz
    refine ⟨coeff, ?_⟩
    apply funext
    intro row
    have hrow := congrFun hsum row
    calc
      (∑ j : Fin columns.size, columns[j.val]! row * coeff j) =
          (∑ j : Fin columns.size, columns[j.val]! row * coeff j) + 0 := by simp
      _ = (∑ j : Fin columns.size, columns[j.val]! row * coeff j) +
          (target row + target row) := by rw [ZModModule.add_self]; simp
      _ = ((∑ j : Fin columns.size, columns[j.val]! row * coeff j) +
          target row) + target row := by rw [← add_assoc]
      _ = 0 + target row := by rw [hrow]
      _ = target row := by simp

/-- A candidate selected by the array scan is a genuine semantic column-span
witness. -/
theorem actualGreedyArraySpanWitness?_sound {m : Nat}
    (columns : Array (Fin m → ZMod 2)) (target : Fin m → ZMod 2)
    {j : Fin (columns.size + 1)}
    (h : actualGreedyArraySpanWitness? columns target = some j) :
    actualGreedyArrayColumnSpanContains columns target := by
  classical
  let run := actualGreedyArrayAugmentedScan columns target
  have htest : actualGreedyArraySpanCandidateTest run j = true := by
    unfold actualGreedyArraySpanWitness? at h
    simp only [run] at h
    induction (List.ofFn fun col : Fin (columns.size + 1) => col) with
    | nil => simp at h
    | cons a tail ih =>
      by_cases ha : actualGreedyArraySpanCandidateTest run a = true
      · simp [ha] at h
        subst j
        exact ha
      · simp [ha] at h
        exact ih h
  have hparts := Bool.and_eq_true.mp htest
  have hfree : j ∉ run.2.map Prod.snd := of_decide_eq_true hparts.1
  have hlast : balanceGaussianFreeKernelCandidate
      (actualBalanceGaussianArrayView (m := m) (n := columns.size + 1) run.1)
      run.2 j (Fin.last columns.size) = 1 := of_decide_eq_true hparts.2
  have hscan := actualGreedyArrayAugmentedScan_refines columns target
  have hmatrix := congrArg Prod.fst hscan
  have hpivots := congrArg Prod.snd hscan
  let A := actualGreedyArrayAugmentedMatrix columns target
  let pivots := (balanceGaussianColumnScan A ∅
    (List.ofFn fun col : Fin (columns.size + 1) => col)).2
  have hrows : (pivots.map Prod.fst).Nodup := by
    simpa [pivots, A] using balanceGaussianColumnScan_pivotRows_nodup
      (List.ofFn fun col : Fin (columns.size + 1) => col) A ∅
  have hunit : ∀ pivot ∈ pivots, ∀ i,
      (balanceGaussianColumnScan A ∅
        (List.ofFn fun col : Fin (columns.size + 1) => col)).1 i pivot.2 =
          if i = pivot.1 then 1 else 0 := by
    intro pivot hpivot i
    exact balanceGaussianColumnScan_recordedPivots_unit
      (List.ofFn fun col : Fin (columns.size + 1) => col) A ∅ pivot hpivot i
  have hzero : ∀ i, i ∉ pivots.map Prod.fst →
      (balanceGaussianColumnScan A ∅
        (List.ofFn fun col : Fin (columns.size + 1) => col)).1 i = 0 := by
    intro i hi
    funext col
    exact balanceGaussianFullColumnScan_unusedRows_zero A i hi col
  have hcandidateKernel :
      (balanceGaussianColumnScan A ∅
        (List.ofFn fun col : Fin (columns.size + 1) => col)).1 *ᵥ
          balanceGaussianFreeKernelCandidate
            (balanceGaussianColumnScan A ∅
              (List.ofFn fun col : Fin (columns.size + 1) => col)).1
            pivots j = 0 := by
    apply balanceGaussianFreeKernelCandidate_mem_ker
      _ pivots j (by simpa [pivots] using hfree) hrows hunit
    intro i hi
    exact congrFun (hzero i hi) j
  have hkernelArray :
      actualBalanceGaussianArrayView (m := m) (n := columns.size + 1) run.1 *ᵥ
          balanceGaussianFreeKernelCandidate
            (actualBalanceGaussianArrayView (m := m) (n := columns.size + 1) run.1)
            run.2 j = 0 := by
    simpa [run, hmatrix, hpivots, A, pivots] using hcandidateKernel
  have hkernelInput :=
    (actualBalanceGaussianArrayFullColumnScan_kernel_iff
      (actualGreedyArrayAugmentedCells columns target)
      (balanceGaussianFreeKernelCandidate
        (actualBalanceGaussianArrayView (m := m) (n := columns.size + 1) run.1)
        run.2 j)).mp hkernelArray
  have hinputMatrix :
      actualBalanceGaussianArrayView (m := m) (n := columns.size + 1)
          (actualGreedyArrayAugmentedCells columns target) = A :=
    actualGreedyArrayAugmentedCells_view columns target
  have haug : A *ᵥ
      balanceGaussianFreeKernelCandidate
        (actualBalanceGaussianArrayView (m := m) (n := columns.size + 1) run.1)
        run.2 j = 0 := by
    simpa [A, hinputMatrix] using hkernelInput
  have hlast' :
      balanceGaussianFreeKernelCandidate
        (actualBalanceGaussianArrayView (m := m) (n := columns.size + 1) run.1)
        run.2 j (Fin.last columns.size) = 1 := by
    simpa using hlast
  exact (actualGreedyArrayColumnSpan_iff_augmentedKernel columns target).mpr
    ⟨balanceGaussianFreeKernelCandidate
        (actualBalanceGaussianArrayView (m := m) (n := columns.size + 1) run.1)
        run.2 j, haug, hlast'⟩

end CorruptedFieldRecovery
