import CorruptedFieldRecovery
import CorruptedFieldRecovery.RawVerifier

set_option pp.universes true
set_option pp.explicit false
set_option pp.fullNames true
set_option pp.piBinderTypes true
set_option pp.piBinderNames true
set_option pp.piBinderNames.hygienic true
set_option pp.proofs true
set_option pp.deepTerms true
set_option pp.maxSteps 1000000
set_option maxRecDepth 10000

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawSupportOffset"
#check @CorruptedFieldRecovery.rawSupportOffset
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawSupportOffset"
#print axioms CorruptedFieldRecovery.rawSupportOffset

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawSupportMap"
#check @CorruptedFieldRecovery.rawSupportMap
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawSupportMap"
#print axioms CorruptedFieldRecovery.rawSupportMap

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.RawDecomposition"
#check @CorruptedFieldRecovery.RawDecomposition
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.RawDecomposition"
#print axioms CorruptedFieldRecovery.RawDecomposition

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.RawDecomposition.represented"
#check @CorruptedFieldRecovery.RawDecomposition.represented
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.RawDecomposition.represented"
#print axioms CorruptedFieldRecovery.RawDecomposition.represented

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.RawDecomposition.represented_alternating"
#check @CorruptedFieldRecovery.RawDecomposition.represented_alternating
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.RawDecomposition.represented_alternating"
#print axioms CorruptedFieldRecovery.RawDecomposition.represented_alternating

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawIncreasingCoefficientCheck"
#check @CorruptedFieldRecovery.rawIncreasingCoefficientCheck
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawIncreasingCoefficientCheck"
#print axioms CorruptedFieldRecovery.rawIncreasingCoefficientCheck

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawDecompositionCheck"
#check @CorruptedFieldRecovery.rawDecompositionCheck
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawDecompositionCheck"
#print axioms CorruptedFieldRecovery.rawDecompositionCheck

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.accepted_rawDecompositionCheck_support_bound"
#check @CorruptedFieldRecovery.accepted_rawDecompositionCheck_support_bound
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.accepted_rawDecompositionCheck_support_bound"
#print axioms CorruptedFieldRecovery.accepted_rawDecompositionCheck_support_bound

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.accepted_rawDecompositionCheck_sound"
#check @CorruptedFieldRecovery.accepted_rawDecompositionCheck_sound
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.accepted_rawDecompositionCheck_sound"
#print axioms CorruptedFieldRecovery.accepted_rawDecompositionCheck_sound

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawDecomposition_residual_factors"
#check @CorruptedFieldRecovery.rawDecomposition_residual_factors
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawDecomposition_residual_factors"
#print axioms CorruptedFieldRecovery.rawDecomposition_residual_factors

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.modeImage_pullback_le_dualMap_range"
#check @CorruptedFieldRecovery.modeImage_pullback_le_dualMap_range
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.modeImage_pullback_le_dualMap_range"
#print axioms CorruptedFieldRecovery.modeImage_pullback_le_dualMap_range
