import CorruptedFieldRecovery
import CorruptedFieldRecovery.RawFieldTraceBitValue

set_option pp.universes true
set_option pp.explicit false
set_option pp.fullNames true
set_option pp.piBinderTypes true
set_option pp.piBinderNames true
set_option pp.piBinderNames.hygienic true
set_option pp.proofs true
set_option pp.deepTerms true
set_option pp.maxSteps 1000000
set_option maxRecDepth 10000

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawMaskPolynomial_natDegree_lt_pow"
#check @CorruptedFieldRecovery.rawMaskPolynomial_natDegree_lt_pow
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawMaskPolynomial_natDegree_lt_pow"
#print axioms CorruptedFieldRecovery.rawMaskPolynomial_natDegree_lt_pow

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawFieldTraceBits_eq_baseBit"
#check @CorruptedFieldRecovery.rawFieldTraceBits_eq_baseBit
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawFieldTraceBits_eq_baseBit"
#print axioms CorruptedFieldRecovery.rawFieldTraceBits_eq_baseBit
