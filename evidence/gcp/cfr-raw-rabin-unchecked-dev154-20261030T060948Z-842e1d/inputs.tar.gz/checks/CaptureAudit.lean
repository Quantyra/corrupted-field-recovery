import CorruptedFieldRecovery
import CorruptedFieldRecovery.RawRabinIrreducibility

set_option pp.universes true
set_option pp.explicit false
set_option pp.fullNames true
set_option pp.piBinderTypes true
set_option pp.piBinderNames true
set_option pp.piBinderNames.hygienic true
set_option pp.proofs true
set_option pp.deepTerms true
set_option pp.maxSteps 1000000
set_option maxRecDepth 10000

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawPolynomialRemainder"
#check @CorruptedFieldRecovery.rawPolynomialRemainder
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawPolynomialRemainder"
#print axioms CorruptedFieldRecovery.rawPolynomialRemainder

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawPolynomialRemainder_lt"
#check @CorruptedFieldRecovery.rawPolynomialRemainder_lt
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawPolynomialRemainder_lt"
#print axioms CorruptedFieldRecovery.rawPolynomialRemainder_lt

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawPolynomialRemainder_quotient_sound"
#check @CorruptedFieldRecovery.rawPolynomialRemainder_quotient_sound
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawPolynomialRemainder_quotient_sound"
#print axioms CorruptedFieldRecovery.rawPolynomialRemainder_quotient_sound

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawPolynomialGcd"
#check @CorruptedFieldRecovery.rawPolynomialGcd
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawPolynomialGcd"
#print axioms CorruptedFieldRecovery.rawPolynomialGcd

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawCandidateFrobeniusAux"
#check @CorruptedFieldRecovery.rawCandidateFrobeniusAux
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawCandidateFrobeniusAux"
#print axioms CorruptedFieldRecovery.rawCandidateFrobeniusAux

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawCandidateFrobenius"
#check @CorruptedFieldRecovery.rawCandidateFrobenius
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawCandidateFrobenius"
#print axioms CorruptedFieldRecovery.rawCandidateFrobenius

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawCandidateRabinCheck"
#check @CorruptedFieldRecovery.rawCandidateRabinCheck
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawCandidateRabinCheck"
#print axioms CorruptedFieldRecovery.rawCandidateRabinCheck

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawFieldCandidateShapeCheck"
#check @CorruptedFieldRecovery.rawFieldCandidateShapeCheck
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawFieldCandidateShapeCheck"
#print axioms CorruptedFieldRecovery.rawFieldCandidateShapeCheck

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawFieldCandidateFastCheck"
#check @CorruptedFieldRecovery.rawFieldCandidateFastCheck
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawFieldCandidateFastCheck"
#print axioms CorruptedFieldRecovery.rawFieldCandidateFastCheck
