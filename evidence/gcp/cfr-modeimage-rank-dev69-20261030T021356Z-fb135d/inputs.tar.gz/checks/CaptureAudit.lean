import CorruptedFieldRecovery
import CorruptedFieldRecovery.S010ModeImageRank

set_option pp.universes true
set_option pp.explicit false
set_option pp.fullNames true
set_option pp.piBinderTypes true
set_option pp.piBinderNames true
set_option pp.piBinderNames.hygienic true
set_option pp.proofs true
set_option pp.deepTerms true
set_option pp.maxSteps 1000000
set_option maxRecDepth 10000

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.modeImageSemanticSupport_finrank_eq"
#check @CorruptedFieldRecovery.modeImageSemanticSupport_finrank_eq
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.modeImageSemanticSupport_finrank_eq"
#print axioms CorruptedFieldRecovery.modeImageSemanticSupport_finrank_eq
