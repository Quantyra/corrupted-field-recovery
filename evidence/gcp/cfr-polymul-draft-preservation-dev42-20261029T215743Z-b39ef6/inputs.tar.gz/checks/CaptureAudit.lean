import CorruptedFieldRecovery
import CorruptedFieldRecovery.RawPolyMulBounds

set_option pp.universes true
set_option pp.explicit false
set_option pp.fullNames true
set_option pp.piBinderTypes true
set_option pp.piBinderNames true
set_option pp.piBinderNames.hygienic true
set_option pp.proofs true
set_option pp.deepTerms true
set_option pp.maxSteps 1000000
set_option maxRecDepth 10000

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawPolyMul_lt_pow"
#check @CorruptedFieldRecovery.rawPolyMul_lt_pow
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawPolyMul_lt_pow"
#print axioms CorruptedFieldRecovery.rawPolyMul_lt_pow

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawFieldMulFuel_lt_of_accepted_2s"
#check @CorruptedFieldRecovery.rawFieldMulFuel_lt_of_accepted_2s
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawFieldMulFuel_lt_of_accepted_2s"
#print axioms CorruptedFieldRecovery.rawFieldMulFuel_lt_of_accepted_2s
