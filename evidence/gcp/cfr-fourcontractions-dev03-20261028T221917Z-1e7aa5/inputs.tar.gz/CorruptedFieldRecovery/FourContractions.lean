import Mathlib.FieldTheory.Finite.Trace
import Mathlib.Algebra.CharP.Two

/-! Algebraic core for the four-contraction field-identification route.

This file deliberately does not claim M2a coverage: the concrete determinant
contractions, their trace radicals, block extraction, and arbitrary sampled-basis
transport still have to be connected to the algebraic core below.
-/

namespace CorruptedFieldRecovery

/-- The finite-field trace pairing is nondegenerate in either argument. -/
theorem tracePairing_nondegenerate
    (K : Type*) [Field K] [Finite K] [Algebra (ZMod (ringChar K)) K]
    (λ : K) (hλ : λ ≠ 0) (x : K) (hx : x ≠ 0) :
    ∃ y : K, Algebra.trace (ZMod (ringChar K)) K (λ * x * y) ≠ 0 := by
  obtain ⟨y, hy⟩ := FiniteField.trace_to_zmod_nondegenerate K (mul_ne_zero hλ hx)
  exact ⟨y, by simpa [mul_assoc] using hy⟩

/-- The coordinate model for the clean three-dimensional field space. -/
abbrev FieldTriple (K : Type*) := K × K × K

/-- The determinant of three column vectors in the standard coordinates. -/
def fieldDet3 {K : Type*} [CommRing K]
    (x y z : FieldTriple K) : K :=
  x.1 * (y.2.1 * z.2.2 - y.2.2 * z.2.1) -
    y.1 * (x.2.1 * z.2.2 - x.2.2 * z.2.1) +
    z.1 * (x.2.1 * y.2.2 - x.2.2 * y.2.1)

def fieldBasis0 {K : Type*} [Zero K] [One K] : FieldTriple K := (1, 0, 0)
def fieldBasis1 {K : Type*} [Zero K] [One K] : FieldTriple K := (0, 1, 0)
def fieldBasis2 {K : Type*} [Zero K] [One K] : FieldTriple K := (0, 0, 1)

/-- The first clean contraction of the trace-determinant tensor. -/
def fieldContraction0
    (K : Type*) [Field K] [Finite K] [Algebra (ZMod (ringChar K)) K]
    (c : K) (x y : FieldTriple K) : ZMod (ringChar K) :=
  Algebra.trace (ZMod (ringChar K)) K (c * fieldDet3 x y fieldBasis0)

/-- The second clean contraction of the trace-determinant tensor. -/
def fieldContraction1
    (K : Type*) [Field K] [Finite K] [Algebra (ZMod (ringChar K)) K]
    (c : K) (x y : FieldTriple K) : ZMod (ringChar K) :=
  Algebra.trace (ZMod (ringChar K)) K (c * fieldDet3 x y fieldBasis1)

/-- The third clean contraction of the trace-determinant tensor. -/
def fieldContraction2
    (K : Type*) [Field K] [Finite K] [Algebra (ZMod (ringChar K)) K]
    (c : K) (x y : FieldTriple K) : ZMod (ringChar K) :=
  Algebra.trace (ZMod (ringChar K)) K (c * fieldDet3 x y fieldBasis2)

/-- The radical of the first standard contraction is exactly its K-coordinate
axis. This is the first concrete radical derivation needed for M2a. -/
theorem fieldContraction0_radical
    (K : Type*) [Field K] [Finite K] [Algebra (ZMod (ringChar K)) K]
    (c : K) (hc : c ≠ 0) (x : FieldTriple K) :
    (∀ y, fieldContraction0 K c x y = 0) ↔ x.2.1 = 0 ∧ x.2.2 = 0 := by
  constructor
  · intro hx
    constructor
    · by_contra h1
      obtain ⟨t, ht⟩ := tracePairing_nondegenerate K c hc x.2.1 h1
      have hz := hx (0, 0, t)
      have hdet : fieldDet3 x (0, 0, t) fieldBasis0 = x.2.1 * t := by
        simp [fieldDet3, fieldBasis0]
      rw [fieldContraction0, hdet, mul_assoc] at hz
      exact ht hz
    · by_contra h2
      obtain ⟨t, ht⟩ := tracePairing_nondegenerate K c hc (-x.2.2) (by simpa using h2)
      have hz := hx (0, t, 0)
      have hdet : fieldDet3 x (0, t, 0) fieldBasis0 = -x.2.2 * t := by
        simp [fieldDet3, fieldBasis0]
      rw [fieldContraction0, hdet, mul_assoc] at hz
      exact ht hz
  · rintro ⟨h1, h2⟩ y
    simp [fieldContraction0, fieldDet3, fieldBasis0, h1, h2]

/-- An F-linear map on a finite field that commutes with multiplication by an
algebra generator is multiplication by its value at one. This is the scalar
recognition step used after the first three contractions identify one common
self-adjoint block map. -/
theorem linearMap_scalar_of_commutes_generator
    (F K : Type*) [CommSemiring F] [Field K] [Algebra F K]
    (A : K →ₗ[F] K) (α : K)
    (hgen : Algebra.adjoin F {α} = ⊤)
    (hcomm : ∀ x : K, A (α * x) = α * A x) :
    ∀ x : K, A x = A 1 * x := by
  have hmul : ∀ r : K, r ∈ Algebra.adjoin F {α} → ∀ x : K,
      A (r * x) = r * A x := by
    intro r hr
    rw [Algebra.mem_adjoin_iff] at hr
    induction hr using Subring.closure_induction with
    | mem r hr =>
        rcases hr with ⟨t, rfl⟩ | hr
        · intro x
          rw [Algebra.smul_def, map_smul]
          simp [Algebra.smul_def]
        · have hr : r = α := by simpa using hr
          subst r
          exact hcomm
    | zero =>
        intro x
        simp
    | one =>
        intro x
        simp
    | add r s hr hs ihr ihs =>
        intro x
        rw [add_mul, map_add, ihr x, ihs x, add_mul]
    | neg r hr ihr =>
        intro x
        rw [neg_mul, map_neg, ihr x, neg_mul]
    | mul r s hr hs ihr ihs =>
        intro x
        rw [mul_assoc, ihr (s * x), ihs x, mul_assoc]
  have htop : ∀ r : K, ∀ x : K, A (r * x) = r * A x := by
    intro r x
    apply hmul r
    rw [hgen]
    trivial
  intro x
  simpa [mul_comm] using (htop x 1)

end CorruptedFieldRecovery
