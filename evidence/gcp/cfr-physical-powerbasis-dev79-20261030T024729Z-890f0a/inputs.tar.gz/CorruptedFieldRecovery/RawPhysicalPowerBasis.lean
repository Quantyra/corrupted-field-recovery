import CorruptedFieldRecovery.RawPhysicalTraceBits
import CorruptedFieldRecovery.RawFieldCoordinateBridge

/-! Relate the little-endian block masks read from physical vectors to the
monomial expansion used by the accepted quotient-field power basis. -/

namespace CorruptedFieldRecovery

open Polynomial AdjoinRoot

/-- `ZMod 2` coefficients have exactly their expected Boolean encoding. -/
theorem rawZModTwo_boolValue (a : ZMod 2) :
    (if decide (a = 1) then (1 : ZMod 2) else 0) = a := by
  fin_cases a <;> decide

/-- A finite little-endian Bool vector expands to its coefficient monomials. -/
theorem rawBoolListPolynomial_ofFn {s : Nat} (bits : Fin s → Bool) :
    rawBoolListPolynomial (List.ofFn bits) =
      ∑ i : Fin s, Polynomial.monomial i (if bits i then (1 : ZMod 2) else 0) := by
  induction s generalizing bits with
  | zero => simp [List.ofFn, rawBoolListPolynomial]
  | succ s ih =>
      rw [List.ofFn_succ]
      simp only [rawBoolListPolynomial, ih, Fin.sum_univ_succ]
      simp only [Polynomial.monomial_zero_left, Polynomial.X_mul_monomial,
        Fin.val_succ]
      ac_rfl

/-- Polynomial interpretation of a physical coordinate block equals the
finite monomial sum of the corresponding vector entries. -/
theorem rawPhysicalBlockMask_polynomial {s : Nat}
    (v : BinaryVector (3 * s)) (block : Fin 3) :
    rawMaskPolynomial (rawPhysicalBlockMask v block) =
      ∑ i : Fin s,
        Polynomial.monomial i (v (finProdFinEquiv (block, i))) := by
  rw [← rawBoolListPolynomial_eq_mask]
  rw [rawPhysicalBlockMask, rawBoolListPolynomial_ofFn]
  apply Finset.sum_congr rfl
  intro i hi
  exact congrArg (Polynomial.monomial i)
    (rawZModTwo_boolValue (v (finProdFinEquiv (block, i))))

/-- The quotient class of an extracted block mask is the quotient class of
its corresponding coefficient polynomial. -/
theorem rawPhysicalBlockMask_quotient {s : Nat}
    (candidate : RawFieldCandidate s) (v : BinaryVector (3 * s)) (block : Fin 3) :
    rawCandidateQuotientClass candidate (rawPhysicalBlockMask v block) =
      AdjoinRoot.mk (rawCandidateModulus candidate)
        (∑ i : Fin s,
          Polynomial.monomial i (v (finProdFinEquiv (block, i)))) := by
  rw [rawCandidateQuotientClass, rawPhysicalBlockMask_polynomial]

/-- The decoded component is the power-basis inverse of its exact physical
coefficient block. -/
theorem rawPhysicalBlockMask_eq_powerCoordinates {s : Nat}
    (candidate : RawFieldCandidate s)
    (hcheck : rawFieldCandidateCheck candidate = true)
    (v : BinaryVector (3 * s)) (block : Fin 3) :
    rawCandidateQuotientClass candidate (rawPhysicalBlockMask v block) =
      (rawQuotientPowerCoordinates (rawCandidateModulus candidate)
        (accepted_rawCandidateModulus_monic candidate hcheck)
        (by
          have hv := accepted_rawFieldCandidateCheck candidate hcheck
          have hm := rawFieldCandidateValid_modulus_polynomial candidate hv
          simpa [rawCandidateModulus] using hm.2)).symm
        (fun i => v (finProdFinEquiv (block, i))) := by
  rw [rawPhysicalBlockMask_quotient]
  simp [rawQuotientPowerCoordinates, AdjoinRoot.powerBasisAux',
    Basis.equivFun_symm_apply, Polynomial.monomial]

end CorruptedFieldRecovery
