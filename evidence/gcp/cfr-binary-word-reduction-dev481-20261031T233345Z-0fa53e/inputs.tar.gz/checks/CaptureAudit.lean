import CorruptedFieldRecovery
import CorruptedFieldRecovery.RawBinaryWordReduction

set_option pp.universes true
set_option pp.explicit false
set_option pp.fullNames true
set_option pp.piBinderTypes true
set_option pp.piBinderNames true
set_option pp.piBinderNames.hygienic true
set_option pp.proofs true
set_option pp.deepTerms true
set_option pp.maxSteps 1000000
set_option maxRecDepth 10000

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawBinaryWordBelowPowTwo"
#check @CorruptedFieldRecovery.rawBinaryWordBelowPowTwo
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawBinaryWordBelowPowTwo"
#print axioms CorruptedFieldRecovery.rawBinaryWordBelowPowTwo

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawBinaryWordBelowPowTwo_spec"
#check @CorruptedFieldRecovery.rawBinaryWordBelowPowTwo_spec
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawBinaryWordBelowPowTwo_spec"
#print axioms CorruptedFieldRecovery.rawBinaryWordBelowPowTwo_spec

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawBinaryWordLeadingOne"
#check @CorruptedFieldRecovery.rawBinaryWordLeadingOne
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawBinaryWordLeadingOne"
#print axioms CorruptedFieldRecovery.rawBinaryWordLeadingOne

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawBinaryWordLeadingOne_spec"
#check @CorruptedFieldRecovery.rawBinaryWordLeadingOne_spec
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawBinaryWordLeadingOne_spec"
#print axioms CorruptedFieldRecovery.rawBinaryWordLeadingOne_spec

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawReduceStepWordFromBits"
#check @CorruptedFieldRecovery.rawReduceStepWordFromBits
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawReduceStepWordFromBits"
#print axioms CorruptedFieldRecovery.rawReduceStepWordFromBits

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawReduceStepWordFromBits_refines"
#check @CorruptedFieldRecovery.rawReduceStepWordFromBits_refines
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawReduceStepWordFromBits_refines"
#print axioms CorruptedFieldRecovery.rawReduceStepWordFromBits_refines

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawReduceFuelWordFromBits"
#check @CorruptedFieldRecovery.rawReduceFuelWordFromBits
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawReduceFuelWordFromBits"
#print axioms CorruptedFieldRecovery.rawReduceFuelWordFromBits

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawReduceFuelWordFromBits_refines"
#check @CorruptedFieldRecovery.rawReduceFuelWordFromBits_refines
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawReduceFuelWordFromBits_refines"
#print axioms CorruptedFieldRecovery.rawReduceFuelWordFromBits_refines
