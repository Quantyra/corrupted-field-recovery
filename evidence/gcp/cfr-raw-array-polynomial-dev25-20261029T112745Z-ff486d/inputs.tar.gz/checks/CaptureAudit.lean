import CorruptedFieldRecovery
import CorruptedFieldRecovery.RawFieldArrayPolynomial

set_option pp.universes true
set_option pp.explicit false
set_option pp.fullNames true
set_option pp.piBinderTypes true
set_option pp.piBinderNames true
set_option pp.piBinderNames.hygienic true
set_option pp.proofs true
set_option pp.deepTerms true
set_option pp.maxSteps 1000000
set_option maxRecDepth 10000

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawBitsToNat_cons"
#check @CorruptedFieldRecovery.rawBitsToNat_cons
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawBitsToNat_cons"
#print axioms CorruptedFieldRecovery.rawBitsToNat_cons

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawBoolListPolynomial_eq_mask"
#check @CorruptedFieldRecovery.rawBoolListPolynomial_eq_mask
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawBoolListPolynomial_eq_mask"
#print axioms CorruptedFieldRecovery.rawBoolListPolynomial_eq_mask

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawFieldArrayPolynomial_eq_mask"
#check @CorruptedFieldRecovery.rawFieldArrayPolynomial_eq_mask
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawFieldArrayPolynomial_eq_mask"
#print axioms CorruptedFieldRecovery.rawFieldArrayPolynomial_eq_mask
