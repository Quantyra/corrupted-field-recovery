import CorruptedFieldRecovery
import CorruptedFieldRecovery.RawRabinGcdCorrectness

set_option pp.universes true
set_option pp.explicit false
set_option pp.fullNames true
set_option pp.piBinderTypes true
set_option pp.piBinderNames true
set_option pp.piBinderNames.hygienic true
set_option pp.proofs true
set_option pp.deepTerms true
set_option pp.maxSteps 1000000
set_option maxRecDepth 10000

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawPolynomialGcd_one_iff_coprime"
#check @CorruptedFieldRecovery.rawPolynomialGcd_one_iff_coprime
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawPolynomialGcd_one_iff_coprime"
#print axioms CorruptedFieldRecovery.rawPolynomialGcd_one_iff_coprime
