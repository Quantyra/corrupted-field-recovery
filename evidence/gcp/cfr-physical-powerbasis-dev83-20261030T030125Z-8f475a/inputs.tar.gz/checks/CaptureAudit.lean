import CorruptedFieldRecovery
import CorruptedFieldRecovery.RawPhysicalPowerBasis

set_option pp.universes true
set_option pp.explicit false
set_option pp.fullNames true
set_option pp.piBinderTypes true
set_option pp.piBinderNames true
set_option pp.piBinderNames.hygienic true
set_option pp.proofs true
set_option pp.deepTerms true
set_option pp.maxSteps 1000000
set_option maxRecDepth 10000

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawZModTwo_boolValue"
#check @CorruptedFieldRecovery.rawZModTwo_boolValue
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawZModTwo_boolValue"
#print axioms CorruptedFieldRecovery.rawZModTwo_boolValue

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawBoolListPolynomial_ofFn"
#check @CorruptedFieldRecovery.rawBoolListPolynomial_ofFn
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawBoolListPolynomial_ofFn"
#print axioms CorruptedFieldRecovery.rawBoolListPolynomial_ofFn

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawPhysicalBlockMask_polynomial"
#check @CorruptedFieldRecovery.rawPhysicalBlockMask_polynomial
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawPhysicalBlockMask_polynomial"
#print axioms CorruptedFieldRecovery.rawPhysicalBlockMask_polynomial

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawPhysicalBlockMask_quotient"
#check @CorruptedFieldRecovery.rawPhysicalBlockMask_quotient
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawPhysicalBlockMask_quotient"
#print axioms CorruptedFieldRecovery.rawPhysicalBlockMask_quotient

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawPhysicalBlockMask_eq_powerCoordinates"
#check @CorruptedFieldRecovery.rawPhysicalBlockMask_eq_powerCoordinates
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawPhysicalBlockMask_eq_powerCoordinates"
#print axioms CorruptedFieldRecovery.rawPhysicalBlockMask_eq_powerCoordinates
