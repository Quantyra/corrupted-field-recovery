import CorruptedFieldRecovery
import CorruptedFieldRecovery.FourContractions

set_option pp.universes true
set_option pp.explicit false
set_option pp.fullNames true
set_option pp.piBinderTypes true
set_option pp.piBinderNames true
set_option pp.piBinderNames.hygienic true
set_option pp.proofs true
set_option pp.deepTerms true
set_option pp.maxSteps 1000000
set_option maxRecDepth 10000

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.tracePairing_nondegenerate"
#check @CorruptedFieldRecovery.tracePairing_nondegenerate
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.tracePairing_nondegenerate"
#print axioms CorruptedFieldRecovery.tracePairing_nondegenerate

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.fieldContraction0_radical"
#check @CorruptedFieldRecovery.fieldContraction0_radical
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.fieldContraction0_radical"
#print axioms CorruptedFieldRecovery.fieldContraction0_radical

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.fieldContraction1_radical"
#check @CorruptedFieldRecovery.fieldContraction1_radical
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.fieldContraction1_radical"
#print axioms CorruptedFieldRecovery.fieldContraction1_radical

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.fieldContraction2_radical"
#check @CorruptedFieldRecovery.fieldContraction2_radical
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.fieldContraction2_radical"
#print axioms CorruptedFieldRecovery.fieldContraction2_radical

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.balanced_first_three_preserves_axes"
#check @CorruptedFieldRecovery.balanced_first_three_preserves_axes
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.balanced_first_three_preserves_axes"
#print axioms CorruptedFieldRecovery.balanced_first_three_preserves_axes

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.linearMap_scalar_of_commutes_generator"
#check @CorruptedFieldRecovery.linearMap_scalar_of_commutes_generator
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.linearMap_scalar_of_commutes_generator"
#print axioms CorruptedFieldRecovery.linearMap_scalar_of_commutes_generator
