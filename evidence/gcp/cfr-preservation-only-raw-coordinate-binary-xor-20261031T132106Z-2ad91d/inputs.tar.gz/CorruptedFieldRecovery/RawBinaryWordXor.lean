import CorruptedFieldRecovery.RawFieldArrayPolynomial
import CorruptedFieldRecovery.RawExecutableQuotient
import Mathlib.Data.Nat.Bits
import Mathlib.Data.Nat.Bitwise

/-! A concrete little-endian bit-list implementation of word XOR and its
semantic connection to `Nat.xor`. The recursive program charges one Boolean
XOR gate for each output bit. The gate count does not include list traversal,
addressing, allocation, conversion between Nat and words, or evaluator stack;
it refines the XOR primitive only. -/

namespace CorruptedFieldRecovery

/-- One Boolean XOR gate. -/
def rawBinaryWordXorBit (a b : Bool) : Bool := decide (a ≠ b)

/-- Little-endian word XOR, padding the shorter input with zero bits. -/
def rawBinaryWordXor : List Bool → List Bool → List Bool
  | [], [] => []
  | a :: as, [] => rawBinaryWordXorBit a false :: rawBinaryWordXor as []
  | [], b :: bs => rawBinaryWordXorBit false b :: rawBinaryWordXor [] bs
  | a :: as, b :: bs =>
      rawBinaryWordXorBit a b :: rawBinaryWordXor as bs

/-- The list routine produces one output cell, and hence one Boolean XOR
gate, per bit position up to the longer input width. -/
theorem rawBinaryWordXor_length (left right : List Bool) :
    (rawBinaryWordXor left right).length = max left.length right.length := by
  induction left generalizing right with
  | nil =>
      induction right with
      | nil => rfl
      | cons b bs ih => simp [rawBinaryWordXor, ih]
  | cons a as ih =>
      cases right with
      | nil => simp [rawBinaryWordXor, ih]
      | cons b bs => simp [rawBinaryWordXor, ih]

/-- The represented bit-list computation decodes to the core `Nat.xor`
operation, for inputs of unequal as well as equal width. -/
theorem rawBinaryWordXor_refines_natXor (left right : List Bool) :
    rawBitsToNat (rawBinaryWordXor left right) =
      Nat.xor (rawBitsToNat left) (rawBitsToNat right) := by
  induction left generalizing right with
  | nil =>
      cases right with
      | nil => simp [rawBinaryWordXor, rawBitsToNat]
      | cons b bs =>
          simp [rawBinaryWordXor, rawBitsToNat_cons,
            rawBinaryWordXorBit, Nat.xor_bit, ih]
  | cons a as ih =>
      cases right with
      | nil =>
          simp [rawBinaryWordXor, rawBitsToNat_cons,
            rawBinaryWordXorBit, Nat.xor_bit, ih]
      | cons b bs =>
          simp [rawBinaryWordXor, rawBitsToNat_cons,
            rawBinaryWordXorBit, Nat.xor_bit, ih]

/-- The repository's little-endian decoder maps Mathlib's canonical Nat bit
list back to the represented natural number. -/
theorem rawBitsToNat_natBits (value : Nat) :
    rawBitsToNat value.bits = value := by
  induction value using Nat.binaryRec' with
  | zero => simp [rawBitsToNat]
  | bit b n h ih =>
      rw [Nat.bits_append_bit n b h]
      simp [rawBitsToNat_cons, Nat.bit, ih]

/-- On canonical Nat bit representations, the concrete list algorithm
decodes to the core natural-number XOR. -/
theorem rawNatBitsXor_refines_natXor (left right : Nat) :
    rawBitsToNat (rawBinaryWordXor left.bits right.bits) =
      Nat.xor left right := by
  rw [rawBinaryWordXor_refines_natXor,
    rawBitsToNat_natBits, rawBitsToNat_natBits]

/-- A word-based implementation of the reducer's cancellation result. Only
the XOR is run over Boolean words here; logarithm, shift, multiplication and
the Nat-to-word boundary remain explicit unrefined primitives. -/
def rawReduceStepWord (modulus degree current : Nat) : List Bool :=
  rawBinaryWordXor current.bits
    (modulus * 2 ^ (Nat.log2 current - degree)).bits

theorem rawReduceStepWord_refines (modulus degree current : Nat) :
    rawBitsToNat (rawReduceStepWord modulus degree current) =
      rawReduceStep modulus degree current := by
  rw [rawReduceStepWord, rawBinaryWordXor_refines_natXor,
    rawBitsToNat_natBits, rawBitsToNat_natBits]
  rfl

/-- Gate count for this Boolean-word implementation: one Boolean XOR gate
per output bit, excluding traversal, addressing, and storage operations. -/
def rawBinaryWordXorGateCount (left right : List Bool) : Nat :=
  (rawBinaryWordXor left right).length

theorem rawBinaryWordXorGateCount_eq_width (left right : List Bool) :
    rawBinaryWordXorGateCount left right = max left.length right.length :=
  rawBinaryWordXor_length left right

/-- Exact Boolean XOR-gate count for a reducer cancellation when the operands
are supplied as canonical bit words. This is not a total reducer charge. -/
theorem rawReduceStepWord_gateCount (modulus degree current : Nat) :
    rawBinaryWordXorGateCount current.bits
      (modulus * 2 ^ (Nat.log2 current - degree)).bits =
    max current.bits.length
      (modulus * 2 ^ (Nat.log2 current - degree)).bits.length :=
  rawBinaryWordXorGateCount_eq_width _ _

end CorruptedFieldRecovery
