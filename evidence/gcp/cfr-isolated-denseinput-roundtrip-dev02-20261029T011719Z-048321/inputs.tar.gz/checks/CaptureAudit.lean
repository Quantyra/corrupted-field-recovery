import CorruptedFieldRecovery
import CorruptedFieldRecovery.DenseInput

set_option pp.universes true
set_option pp.explicit false
set_option pp.fullNames true
set_option pp.piBinderTypes true
set_option pp.piBinderNames true
set_option pp.piBinderNames.hygienic true
set_option pp.proofs true
set_option pp.deepTerms true
set_option pp.maxSteps 1000000
set_option maxRecDepth 10000

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.IncreasingTriple"
#check @CorruptedFieldRecovery.IncreasingTriple
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.IncreasingTriple"
#print axioms CorruptedFieldRecovery.IncreasingTriple

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.DenseInputPayload"
#check @CorruptedFieldRecovery.DenseInputPayload
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.DenseInputPayload"
#print axioms CorruptedFieldRecovery.DenseInputPayload

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.increasingTripleI"
#check @CorruptedFieldRecovery.increasingTripleI
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.increasingTripleI"
#print axioms CorruptedFieldRecovery.increasingTripleI

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.increasingTripleJ"
#check @CorruptedFieldRecovery.increasingTripleJ
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.increasingTripleJ"
#print axioms CorruptedFieldRecovery.increasingTripleJ

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.increasingTripleK"
#check @CorruptedFieldRecovery.increasingTripleK
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.increasingTripleK"
#print axioms CorruptedFieldRecovery.increasingTripleK

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.coordinateVectorCode"
#check @CorruptedFieldRecovery.coordinateVectorCode
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.coordinateVectorCode"
#print axioms CorruptedFieldRecovery.coordinateVectorCode

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.coordinateVectorCode_eq_coordinateVector"
#check @CorruptedFieldRecovery.coordinateVectorCode_eq_coordinateVector
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.coordinateVectorCode_eq_coordinateVector"
#print axioms CorruptedFieldRecovery.coordinateVectorCode_eq_coordinateVector

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.coordinateMonomial"
#check @CorruptedFieldRecovery.coordinateMonomial
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.coordinateMonomial"
#print axioms CorruptedFieldRecovery.coordinateMonomial

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.coordinateMonomial_apply"
#check @CorruptedFieldRecovery.coordinateMonomial_apply
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.coordinateMonomial_apply"
#print axioms CorruptedFieldRecovery.coordinateMonomial_apply

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.minorTensor"
#check @CorruptedFieldRecovery.minorTensor
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.minorTensor"
#print axioms CorruptedFieldRecovery.minorTensor

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.minorTensor_apply"
#check @CorruptedFieldRecovery.minorTensor_apply
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.minorTensor_apply"
#print axioms CorruptedFieldRecovery.minorTensor_apply

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.minorTensor_isAlternating"
#check @CorruptedFieldRecovery.minorTensor_isAlternating
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.minorTensor_isAlternating"
#print axioms CorruptedFieldRecovery.minorTensor_isAlternating

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.encodeDenseInput"
#check @CorruptedFieldRecovery.encodeDenseInput
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.encodeDenseInput"
#print axioms CorruptedFieldRecovery.encodeDenseInput

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.encodeDenseInput_eq_semanticCoefficient"
#check @CorruptedFieldRecovery.encodeDenseInput_eq_semanticCoefficient
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.encodeDenseInput_eq_semanticCoefficient"
#print axioms CorruptedFieldRecovery.encodeDenseInput_eq_semanticCoefficient

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.decodeDenseInput"
#check @CorruptedFieldRecovery.decodeDenseInput
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.decodeDenseInput"
#print axioms CorruptedFieldRecovery.decodeDenseInput

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.minorTensor_code_basis_eval"
#check @CorruptedFieldRecovery.minorTensor_code_basis_eval
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.minorTensor_code_basis_eval"
#print axioms CorruptedFieldRecovery.minorTensor_code_basis_eval

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.minorTensor_increasing_code_eval"
#check @CorruptedFieldRecovery.minorTensor_increasing_code_eval
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.minorTensor_increasing_code_eval"
#print axioms CorruptedFieldRecovery.minorTensor_increasing_code_eval

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.decodeDenseInput_code_coordinate"
#check @CorruptedFieldRecovery.decodeDenseInput_code_coordinate
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.decodeDenseInput_code_coordinate"
#print axioms CorruptedFieldRecovery.decodeDenseInput_code_coordinate

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.decodeDenseInput_isAlternating"
#check @CorruptedFieldRecovery.decodeDenseInput_isAlternating
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.decodeDenseInput_isAlternating"
#print axioms CorruptedFieldRecovery.decodeDenseInput_isAlternating

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.encode_decodeDenseInput"
#check @CorruptedFieldRecovery.encode_decodeDenseInput
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.encode_decodeDenseInput"
#print axioms CorruptedFieldRecovery.encode_decodeDenseInput

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.decode_encodeDenseInput"
#check @CorruptedFieldRecovery.decode_encodeDenseInput
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.decode_encodeDenseInput"
#print axioms CorruptedFieldRecovery.decode_encodeDenseInput
