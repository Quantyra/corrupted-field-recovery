import CorruptedFieldRecovery.S010ObservedCleanTensor
import CorruptedFieldRecovery.S010ModeImageAlignedHiddenBalance
import Mathlib.Tactic

namespace CorruptedFieldRecovery

noncomputable section

/-- The coordinate cast induced by a free equality `p = 2` is linear over
`ZMod p`. Keeping `p` free avoids dependent elimination on `ringChar K`. -/
private def physicalCoordinateEquiv_of_index_eq_two
    {p n : Nat} (hp : p = 2) :
    (Fin n → ZMod p) ≃ₗ[ZMod p] BinaryVector n := by
  cases hp
  exact LinearEquiv.refl (ZMod 2) (BinaryVector n)

private theorem physicalCoordinateEquiv_apply
    {p n : Nat} (hp : p = 2) (x : Fin n → ZMod p) :
    physicalCoordinateEquiv_of_index_eq_two hp x =
      Equiv.cast (congrArg (fun q => Fin n → ZMod q) hp) x := by
  cases hp
  rfl

/-- Transport a physical binary-linear endomorphism to the manuscript's input
space over `ZMod p`, using the derived `p = 2` coordinate equivalence. -/
private def physicalEndomorphismToInput
    {p n : Nat} (hp : p = 2)
    (T : Module.End (ZMod 2) (BinaryVector n)) :
    Module.End (ZMod p) (Fin n → ZMod p) := by
  let e := physicalCoordinateEquiv_of_index_eq_two hp
  have hT : Module.End (ZMod p) (BinaryVector n) := by
    cases hp
    exact T
  exact e.symm.conj hT

private theorem physicalEndomorphismToInput_apply
    {p n : Nat} (hp : p = 2)
    (T : Module.End (ZMod 2) (BinaryVector n)) (x : Fin n → ZMod p) :
    physicalEndomorphismToInput hp T x =
      (physicalCoordinateEquiv_of_index_eq_two hp).symm
        (T (physicalCoordinateEquiv_of_index_eq_two hp x)) := by
  simp [physicalEndomorphismToInput, LinearEquiv.conj_apply_apply]

/-- Pointwise, the Q-derived input equivalence sends a transported physical
endomorphism to Q applied to the original physical endomorphism. This derives
the scalar-ring and input-map correspondence from `ringChar K = 2`. -/
theorem modeImage_inputEquiv_from_Q_transport_endomorphism
    {K : Type*} [Field K] [CharP K 2]
    [Algebra BinaryField K] [Algebra (ZMod (ringChar K)) K]
    {n : Nat} (Q : BinaryVector n ≃ₗ[BinaryField] FieldTriple K)
    (T : Module.End (ZMod 2) (BinaryVector n)) (x : BinaryInput K n) :
    modeImage_inputEquiv_from_Q Q (physicalEndomorphismToInput
      (ringChar.eq K 2) T x) =
      Q (T (modeImage_inputVectorToBinary (K := K) x)) := by
  let e := physicalCoordinateEquiv_of_index_eq_two (ringChar.eq K 2)
  have hcast (y : BinaryInput K n) :
      Equiv.cast (congrArg (fun p => Fin n → ZMod p) (ringChar.eq K 2)) y =
        modeImage_inputVectorToBinary (K := K) y := rfl
  have hcancel (y : BinaryVector n) :
      modeImage_inputVectorToBinary (K := K) (e.symm y) = y := by
    rw [← hcast, ← physicalCoordinateEquiv_apply]
    exact e.apply_symm_apply y
  rw [modeImage_inputEquiv_from_Q_apply]
  rw [physicalEndomorphismToInput_apply, hcast]
  have hcoord : modeImage_inputVectorToBinary (K := K) (e.symm (T (e x))) =
      T (modeImage_inputVectorToBinary (K := K) x) := by
    rw [hcancel, physicalCoordinateEquiv_apply, hcast]
  rw [hcoord]

/-- On vectors in `Q` coordinates, the clean physical tensor is precisely the
trace-determinant contraction used by the hidden sampled-basis equations. -/
theorem qTraceDeterminantTensor_apply
    {K : Type*} [Field K] [Finite K] [Algebra BinaryField K]
    {n : Nat} (Q : BinaryVector n ≃ₗ[BinaryField] FieldTriple K) (c : K)
    (x y z : BinaryVector n) :
    qTraceDeterminantTensor Q c x y z =
      Algebra.trace BinaryField K (c * fieldDet3 (Q x) (Q y) (Q z)) := rfl

end

end CorruptedFieldRecovery
