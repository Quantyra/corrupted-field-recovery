import Mathlib.FieldTheory.Finiteness
import Mathlib.LinearAlgebra.FiniteDimensional.Lemmas
import Mathlib.Data.ZMod.Basic

/-! Finite counting for the actual clean F₂-subspace used by recovery.

The intended instantiation is `V = K × K × K`, viewed as an F₂-space through
the manuscript's hidden linear isomorphism, and `u` is the promised support
map. Nothing here assumes that `ker u` is K-linear.
-/

namespace CorruptedFieldRecovery

open Module LinearMap

/- The kernel of a surjective support map of codimension `r` has the expected
number of physical binary vectors. `V` may be the hidden-coordinate copy of
`K³`; the only input about its dimension is stated explicitly. -/
theorem card_ker_support_f2
    {V W : Type*}
    [AddCommGroup V] [Module (ZMod 2) V] [FiniteDimensional (ZMod 2) V]
    [AddCommGroup W] [Module (ZMod 2) W] [FiniteDimensional (ZMod 2) W]
    [Fintype V] [Fintype W]
    (u : V →ₗ[ZMod 2] W) (hu : Function.Surjective u)
    (n r : ℕ) (hV : finrank (ZMod 2) V = n)
    (hW : finrank (ZMod 2) W = r) :
    Fintype.card (LinearMap.ker u) = 2 ^ (n - r) := by
  have hrange : LinearMap.range u = ⊤ := LinearMap.range_eq_top.mpr hu
  have hdim := u.finrank_range_add_finrank_ker
  rw [hrange, finrank_top, hW, hV] at hdim
  have hrle : r ≤ n := by omega
  have hker : finrank (ZMod 2) (LinearMap.ker u) = n - r := by omega
  rw [Module.card_eq_pow_finrank, hker]
  norm_num

/- Four independent uniform physical words are clean exactly when each lies
in the support kernel. This counts the finite sample space directly instead
of postulating a cleanliness probability. -/
theorem card_four_clean_words
    {V : Type*} [Fintype V]
    (A : Finset V) :
    Fintype.card {x : Fin 4 → V // ∀ i, x i ∈ A} = (A.card : ℕ) ^ 4 := by
  let e : {x : Fin 4 → V // ∀ i, x i ∈ A} ≃ (Fin 4 → {v // v ∈ A}) where
    toFun x i := ⟨x.1 i, x.2 i⟩
    invFun x := ⟨fun i => (x i).1, fun i => (x i).2⟩
    left_inv x := by cases x; rfl
    right_inv x := by funext i; apply Subtype.ext; rfl
  rw [Fintype.card_congr e, Fintype.card_fun, Fintype.card_fin,
    Fintype.card_coe]
  simp

end CorruptedFieldRecovery
