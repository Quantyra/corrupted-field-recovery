import CorruptedFieldRecovery
import CorruptedFieldRecovery.ExecutableCertificate

set_option pp.universes true
set_option pp.explicit false
set_option pp.fullNames true
set_option pp.piBinderTypes true
set_option pp.piBinderNames true
set_option pp.piBinderNames.hygienic true
set_option pp.proofs true
set_option pp.deepTerms true
set_option pp.maxSteps 1000000
set_option maxRecDepth 10000

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.CoefficientArray"
#check @CorruptedFieldRecovery.CoefficientArray
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.CoefficientArray"
#print axioms CorruptedFieldRecovery.CoefficientArray

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.coefficientOffset"
#check @CorruptedFieldRecovery.coefficientOffset
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.coefficientOffset"
#print axioms CorruptedFieldRecovery.coefficientOffset

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.ExecutableCertificate"
#check @CorruptedFieldRecovery.ExecutableCertificate
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.ExecutableCertificate"
#print axioms CorruptedFieldRecovery.ExecutableCertificate

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.ExecutableInput"
#check @CorruptedFieldRecovery.ExecutableInput
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.ExecutableInput"
#print axioms CorruptedFieldRecovery.ExecutableInput

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.executableCoefficientCheck"
#check @CorruptedFieldRecovery.executableCoefficientCheck
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.executableCoefficientCheck"
#print axioms CorruptedFieldRecovery.executableCoefficientCheck

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.accepted_executable_coefficients"
#check @CorruptedFieldRecovery.accepted_executable_coefficients
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.accepted_executable_coefficients"
#print axioms CorruptedFieldRecovery.accepted_executable_coefficients

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.accepted_executable_certificate_sound"
#check @CorruptedFieldRecovery.accepted_executable_certificate_sound
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.accepted_executable_certificate_sound"
#print axioms CorruptedFieldRecovery.accepted_executable_certificate_sound
