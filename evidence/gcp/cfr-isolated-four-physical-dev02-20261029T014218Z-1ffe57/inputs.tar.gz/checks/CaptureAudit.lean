import CorruptedFieldRecovery
import CorruptedFieldRecovery.FourContractions

set_option pp.universes true
set_option pp.explicit false
set_option pp.fullNames true
set_option pp.piBinderTypes true
set_option pp.piBinderNames true
set_option pp.piBinderNames.hygienic true
set_option pp.proofs true
set_option pp.deepTerms true
set_option pp.maxSteps 1000000
set_option maxRecDepth 10000

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.tracePairing_nondegenerate"
#check @CorruptedFieldRecovery.tracePairing_nondegenerate
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.tracePairing_nondegenerate"
#print axioms CorruptedFieldRecovery.tracePairing_nondegenerate

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.fieldDet3"
#check @CorruptedFieldRecovery.fieldDet3
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.fieldDet3"
#print axioms CorruptedFieldRecovery.fieldDet3

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.fieldBasis0"
#check @CorruptedFieldRecovery.fieldBasis0
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.fieldBasis0"
#print axioms CorruptedFieldRecovery.fieldBasis0

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.fieldBasis1"
#check @CorruptedFieldRecovery.fieldBasis1
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.fieldBasis1"
#print axioms CorruptedFieldRecovery.fieldBasis1

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.fieldBasis2"
#check @CorruptedFieldRecovery.fieldBasis2
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.fieldBasis2"
#print axioms CorruptedFieldRecovery.fieldBasis2

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.fieldContraction0"
#check @CorruptedFieldRecovery.fieldContraction0
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.fieldContraction0"
#print axioms CorruptedFieldRecovery.fieldContraction0

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.fieldContraction1"
#check @CorruptedFieldRecovery.fieldContraction1
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.fieldContraction1"
#print axioms CorruptedFieldRecovery.fieldContraction1

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.fieldContraction2"
#check @CorruptedFieldRecovery.fieldContraction2
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.fieldContraction2"
#print axioms CorruptedFieldRecovery.fieldContraction2

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.fieldContraction4"
#check @CorruptedFieldRecovery.fieldContraction4
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.fieldContraction4"
#print axioms CorruptedFieldRecovery.fieldContraction4

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.fieldScalarTriple"
#check @CorruptedFieldRecovery.fieldScalarTriple
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.fieldScalarTriple"
#print axioms CorruptedFieldRecovery.fieldScalarTriple

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.fieldScalarTriple_eq_smul"
#check @CorruptedFieldRecovery.fieldScalarTriple_eq_smul
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.fieldScalarTriple_eq_smul"
#print axioms CorruptedFieldRecovery.fieldScalarTriple_eq_smul

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.fieldDet3_smul_left"
#check @CorruptedFieldRecovery.fieldDet3_smul_left
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.fieldDet3_smul_left"
#print axioms CorruptedFieldRecovery.fieldDet3_smul_left

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.fieldDet3_smul_right"
#check @CorruptedFieldRecovery.fieldDet3_smul_right
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.fieldDet3_smul_right"
#print axioms CorruptedFieldRecovery.fieldDet3_smul_right

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.fieldContraction0_radical"
#check @CorruptedFieldRecovery.fieldContraction0_radical
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.fieldContraction0_radical"
#print axioms CorruptedFieldRecovery.fieldContraction0_radical

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.fieldContraction1_radical"
#check @CorruptedFieldRecovery.fieldContraction1_radical
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.fieldContraction1_radical"
#print axioms CorruptedFieldRecovery.fieldContraction1_radical

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.fieldContraction2_radical"
#check @CorruptedFieldRecovery.fieldContraction2_radical
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.fieldContraction2_radical"
#print axioms CorruptedFieldRecovery.fieldContraction2_radical

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.balanced_first_three_preserves_axes"
#check @CorruptedFieldRecovery.balanced_first_three_preserves_axes
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.balanced_first_three_preserves_axes"
#print axioms CorruptedFieldRecovery.balanced_first_three_preserves_axes

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.fieldAxis0"
#check @CorruptedFieldRecovery.fieldAxis0
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.fieldAxis0"
#print axioms CorruptedFieldRecovery.fieldAxis0

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.fieldAxis1"
#check @CorruptedFieldRecovery.fieldAxis1
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.fieldAxis1"
#print axioms CorruptedFieldRecovery.fieldAxis1

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.fieldAxis2"
#check @CorruptedFieldRecovery.fieldAxis2
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.fieldAxis2"
#print axioms CorruptedFieldRecovery.fieldAxis2

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.fieldCoordinate0"
#check @CorruptedFieldRecovery.fieldCoordinate0
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.fieldCoordinate0"
#print axioms CorruptedFieldRecovery.fieldCoordinate0

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.fieldCoordinate1"
#check @CorruptedFieldRecovery.fieldCoordinate1
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.fieldCoordinate1"
#print axioms CorruptedFieldRecovery.fieldCoordinate1

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.fieldCoordinate2"
#check @CorruptedFieldRecovery.fieldCoordinate2
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.fieldCoordinate2"
#print axioms CorruptedFieldRecovery.fieldCoordinate2

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.fieldBlock0"
#check @CorruptedFieldRecovery.fieldBlock0
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.fieldBlock0"
#print axioms CorruptedFieldRecovery.fieldBlock0

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.fieldBlock1"
#check @CorruptedFieldRecovery.fieldBlock1
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.fieldBlock1"
#print axioms CorruptedFieldRecovery.fieldBlock1

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.fieldBlock2"
#check @CorruptedFieldRecovery.fieldBlock2
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.fieldBlock2"
#print axioms CorruptedFieldRecovery.fieldBlock2

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.balanced_first_three_block_form"
#check @CorruptedFieldRecovery.balanced_first_three_block_form
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.balanced_first_three_block_form"
#print axioms CorruptedFieldRecovery.balanced_first_three_block_form

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.fieldTracePair"
#check @CorruptedFieldRecovery.fieldTracePair
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.fieldTracePair"
#print axioms CorruptedFieldRecovery.fieldTracePair

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.balanced_first_three_pair_relations"
#check @CorruptedFieldRecovery.balanced_first_three_pair_relations
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.balanced_first_three_pair_relations"
#print axioms CorruptedFieldRecovery.balanced_first_three_pair_relations

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.fieldTracePair_right_injective"
#check @CorruptedFieldRecovery.fieldTracePair_right_injective
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.fieldTracePair_right_injective"
#print axioms CorruptedFieldRecovery.fieldTracePair_right_injective

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.three_pair_relations_common_selfadjoint"
#check @CorruptedFieldRecovery.three_pair_relations_common_selfadjoint
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.three_pair_relations_common_selfadjoint"
#print axioms CorruptedFieldRecovery.three_pair_relations_common_selfadjoint

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.first_three_common_block"
#check @CorruptedFieldRecovery.first_three_common_block
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.first_three_common_block"
#print axioms CorruptedFieldRecovery.first_three_common_block

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.fourth_balance_weighted_pairs"
#check @CorruptedFieldRecovery.fourth_balance_weighted_pairs
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.fourth_balance_weighted_pairs"
#print axioms CorruptedFieldRecovery.fourth_balance_weighted_pairs

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.fieldFourBalanced"
#check @CorruptedFieldRecovery.fieldFourBalanced
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.fieldFourBalanced"
#print axioms CorruptedFieldRecovery.fieldFourBalanced

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.standard_four_contractions_iff_scalar"
#check @CorruptedFieldRecovery.standard_four_contractions_iff_scalar
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.standard_four_contractions_iff_scalar"
#print axioms CorruptedFieldRecovery.standard_four_contractions_iff_scalar

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.linearMap_scalar_of_commutes_generator"
#check @CorruptedFieldRecovery.linearMap_scalar_of_commutes_generator
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.linearMap_scalar_of_commutes_generator"
#print axioms CorruptedFieldRecovery.linearMap_scalar_of_commutes_generator

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.FieldTriple"
#check @CorruptedFieldRecovery.FieldTriple
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.FieldTriple"
#print axioms CorruptedFieldRecovery.FieldTriple

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.fourContractionsBalancedVia"
#check @CorruptedFieldRecovery.fourContractionsBalancedVia
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.fourContractionsBalancedVia"
#print axioms CorruptedFieldRecovery.fourContractionsBalancedVia

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.four_contractions_via_iff_scalar"
#check @CorruptedFieldRecovery.four_contractions_via_iff_scalar
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.four_contractions_via_iff_scalar"
#print axioms CorruptedFieldRecovery.four_contractions_via_iff_scalar

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.has"
#check @CorruptedFieldRecovery.has
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.has"
#print axioms CorruptedFieldRecovery.has

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.scalarTripleEndLinearMap"
#check @CorruptedFieldRecovery.scalarTripleEndLinearMap
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.scalarTripleEndLinearMap"
#print axioms CorruptedFieldRecovery.scalarTripleEndLinearMap

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.scalarTripleEndRange"
#check @CorruptedFieldRecovery.scalarTripleEndRange
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.scalarTripleEndRange"
#print axioms CorruptedFieldRecovery.scalarTripleEndRange

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.scalarTripleEndLinearMap_injective"
#check @CorruptedFieldRecovery.scalarTripleEndLinearMap_injective
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.scalarTripleEndLinearMap_injective"
#print axioms CorruptedFieldRecovery.scalarTripleEndLinearMap_injective

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.scalarTripleEndRange_finrank"
#check @CorruptedFieldRecovery.scalarTripleEndRange_finrank
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.scalarTripleEndRange_finrank"
#print axioms CorruptedFieldRecovery.scalarTripleEndRange_finrank

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.standard_four_balance_iff_mem_scalarTripleEndRange"
#check @CorruptedFieldRecovery.standard_four_balance_iff_mem_scalarTripleEndRange
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.standard_four_balance_iff_mem_scalarTripleEndRange"
#print axioms CorruptedFieldRecovery.standard_four_balance_iff_mem_scalarTripleEndRange

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.standard_four_contractions_balance_finrank"
#check @CorruptedFieldRecovery.standard_four_contractions_balance_finrank
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.standard_four_contractions_balance_finrank"
#print axioms CorruptedFieldRecovery.standard_four_contractions_balance_finrank

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.fieldTripleEquivPi"
#check @CorruptedFieldRecovery.fieldTripleEquivPi
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.fieldTripleEquivPi"
#print axioms CorruptedFieldRecovery.fieldTripleEquivPi

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.fieldTripleStandardBasis"
#check @CorruptedFieldRecovery.fieldTripleStandardBasis
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.fieldTripleStandardBasis"
#print axioms CorruptedFieldRecovery.fieldTripleStandardBasis

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.sampledBasisCoordinateEquiv"
#check @CorruptedFieldRecovery.sampledBasisCoordinateEquiv
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.sampledBasisCoordinateEquiv"
#print axioms CorruptedFieldRecovery.sampledBasisCoordinateEquiv

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.sampledBasisDeterminant"
#check @CorruptedFieldRecovery.sampledBasisDeterminant
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.sampledBasisDeterminant"
#print axioms CorruptedFieldRecovery.sampledBasisDeterminant

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.sampledBasisDeterminant_ne_zero"
#check @CorruptedFieldRecovery.sampledBasisDeterminant_ne_zero
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.sampledBasisDeterminant_ne_zero"
#print axioms CorruptedFieldRecovery.sampledBasisDeterminant_ne_zero

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.fieldDet3_eq_standardBasis_det"
#check @CorruptedFieldRecovery.fieldDet3_eq_standardBasis_det
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.fieldDet3_eq_standardBasis_det"
#print axioms CorruptedFieldRecovery.fieldDet3_eq_standardBasis_det

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.fieldDet3_sampledBasis_change"
#check @CorruptedFieldRecovery.fieldDet3_sampledBasis_change
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.fieldDet3_sampledBasis_change"
#print axioms CorruptedFieldRecovery.fieldDet3_sampledBasis_change

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.sampledContraction0"
#check @CorruptedFieldRecovery.sampledContraction0
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.sampledContraction0"
#print axioms CorruptedFieldRecovery.sampledContraction0

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.sampledContraction1"
#check @CorruptedFieldRecovery.sampledContraction1
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.sampledContraction1"
#print axioms CorruptedFieldRecovery.sampledContraction1

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.sampledContraction2"
#check @CorruptedFieldRecovery.sampledContraction2
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.sampledContraction2"
#print axioms CorruptedFieldRecovery.sampledContraction2

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.sampledContraction4"
#check @CorruptedFieldRecovery.sampledContraction4
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.sampledContraction4"
#print axioms CorruptedFieldRecovery.sampledContraction4

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.sampledFourBalanced"
#check @CorruptedFieldRecovery.sampledFourBalanced
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.sampledFourBalanced"
#print axioms CorruptedFieldRecovery.sampledFourBalanced

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.sampledContraction0_eq_coordinate"
#check @CorruptedFieldRecovery.sampledContraction0_eq_coordinate
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.sampledContraction0_eq_coordinate"
#print axioms CorruptedFieldRecovery.sampledContraction0_eq_coordinate

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.sampledContraction1_eq_coordinate"
#check @CorruptedFieldRecovery.sampledContraction1_eq_coordinate
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.sampledContraction1_eq_coordinate"
#print axioms CorruptedFieldRecovery.sampledContraction1_eq_coordinate

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.sampledContraction2_eq_coordinate"
#check @CorruptedFieldRecovery.sampledContraction2_eq_coordinate
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.sampledContraction2_eq_coordinate"
#print axioms CorruptedFieldRecovery.sampledContraction2_eq_coordinate

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.sampledContraction4_eq_coordinate"
#check @CorruptedFieldRecovery.sampledContraction4_eq_coordinate
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.sampledContraction4_eq_coordinate"
#print axioms CorruptedFieldRecovery.sampledContraction4_eq_coordinate

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.sampled_four_contractions_iff_via"
#check @CorruptedFieldRecovery.sampled_four_contractions_iff_via
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.sampled_four_contractions_iff_via"
#print axioms CorruptedFieldRecovery.sampled_four_contractions_iff_via
