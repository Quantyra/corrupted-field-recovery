import CorruptedFieldRecovery
import CorruptedFieldRecovery.RawFieldTraceBits

set_option pp.universes true
set_option pp.explicit false
set_option pp.fullNames true
set_option pp.piBinderTypes true
set_option pp.piBinderNames true
set_option pp.piBinderNames.hygienic true
set_option pp.proofs true
set_option pp.deepTerms true
set_option pp.maxSteps 1000000
set_option maxRecDepth 10000

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawCandidateQuotientClass"
#check @CorruptedFieldRecovery.rawCandidateQuotientClass
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawCandidateQuotientClass"
#print axioms CorruptedFieldRecovery.rawCandidateQuotientClass

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawFieldMulBits"
#check @CorruptedFieldRecovery.rawFieldMulBits
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawFieldMulBits"
#print axioms CorruptedFieldRecovery.rawFieldMulBits

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawFieldMulBits_quotient_sound"
#check @CorruptedFieldRecovery.rawFieldMulBits_quotient_sound
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawFieldMulBits_quotient_sound"
#print axioms CorruptedFieldRecovery.rawFieldMulBits_quotient_sound

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawFieldAddBits_quotient_sound"
#check @CorruptedFieldRecovery.rawFieldAddBits_quotient_sound
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawFieldAddBits_quotient_sound"
#print axioms CorruptedFieldRecovery.rawFieldAddBits_quotient_sound

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawFieldTraceAux"
#check @CorruptedFieldRecovery.rawFieldTraceAux
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawFieldTraceAux"
#print axioms CorruptedFieldRecovery.rawFieldTraceAux

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawFieldTraceBits"
#check @CorruptedFieldRecovery.rawFieldTraceBits
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawFieldTraceBits"
#print axioms CorruptedFieldRecovery.rawFieldTraceBits

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawFieldTraceAux_quotient_eq_frobenius_sum"
#check @CorruptedFieldRecovery.rawFieldTraceAux_quotient_eq_frobenius_sum
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawFieldTraceAux_quotient_eq_frobenius_sum"
#print axioms CorruptedFieldRecovery.rawFieldTraceAux_quotient_eq_frobenius_sum

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawFieldTraceBits_lt_pow"
#check @CorruptedFieldRecovery.rawFieldTraceBits_lt_pow
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawFieldTraceBits_lt_pow"
#print axioms CorruptedFieldRecovery.rawFieldTraceBits_lt_pow
