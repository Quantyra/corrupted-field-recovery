import CorruptedFieldRecovery.RawFieldQuotient

/-! Finite array checker for a square binary coordinate transform and a
serialized two-sided inverse. -/

namespace CorruptedFieldRecovery

abbrev RawCoordinateMatrix := Array (ZMod 2)

def rawCoordinateMatrixOffset (n : Nat) (i j : Fin n) : Nat := i.val * n + j.val

/-- Interpret a row-major binary matrix as a linear map on `Fin n` vectors. -/
def rawCoordinateMatrixMap {n : Nat} (matrix : RawCoordinateMatrix) :
    BinaryVector n →ₗ[ZMod 2] BinaryVector n where
  toFun x i := ∑ j : Fin n, matrix[rawCoordinateMatrixOffset n i j]! * x j
  map_add' x y := by
    ext i
    simp [Finset.sum_add_distrib, mul_add]
  map_smul' c x := by
    ext i
    simp [Finset.mul_sum, mul_assoc, mul_comm]

/-- The checker validates both finite matrix products on the standard basis.
Together with the two dense-size checks, this is the actual serialized
invertibility gate. -/
def rawCoordinateMatrixCheck {n : Nat}
    (forward inverse : RawCoordinateMatrix) : Bool :=
  decide (forward.size = n * n) &&
    decide (inverse.size = n * n) &&
    decide (∀ i : Fin n,
      rawCoordinateMatrixMap inverse
        (rawCoordinateMatrixMap forward ((Pi.basisFun (ZMod 2) (Fin n)) i)) =
        (Pi.basisFun (ZMod 2) (Fin n)) i) &&
    decide (∀ i : Fin n,
      rawCoordinateMatrixMap forward
        (rawCoordinateMatrixMap inverse ((Pi.basisFun (ZMod 2) (Fin n)) i)) =
        (Pi.basisFun (ZMod 2) (Fin n)) i)

theorem accepted_rawCoordinateMatrixCheck_compositions {n : Nat}
    (forward inverse : RawCoordinateMatrix)
    (hcheck : rawCoordinateMatrixCheck forward inverse = true) :
    (rawCoordinateMatrixMap inverse).comp (rawCoordinateMatrixMap forward) =
        LinearMap.id ∧
      (rawCoordinateMatrixMap forward).comp (rawCoordinateMatrixMap inverse) =
        LinearMap.id := by
  classical
  simp only [rawCoordinateMatrixCheck, Bool.and_eq_true] at hcheck
  have hleft : ∀ i : Fin n,
      rawCoordinateMatrixMap inverse
        (rawCoordinateMatrixMap forward ((Pi.basisFun (ZMod 2) (Fin n)) i)) =
        (Pi.basisFun (ZMod 2) (Fin n)) i := of_decide_eq_true hcheck.2.2.1
  have hright : ∀ i : Fin n,
      rawCoordinateMatrixMap forward
        (rawCoordinateMatrixMap inverse ((Pi.basisFun (ZMod 2) (Fin n)) i)) =
        (Pi.basisFun (ZMod 2) (Fin n)) i := of_decide_eq_true hcheck.2.2.2
  constructor
  · apply (Pi.basisFun (ZMod 2) (Fin n)).ext
    intro i
    simpa [LinearMap.comp_apply] using hleft i
  · apply (Pi.basisFun (ZMod 2) (Fin n)).ext
    intro i
    simpa [LinearMap.comp_apply] using hright i

noncomputable def accepted_rawCoordinateMatrixEquiv {n : Nat}
    (forward inverse : RawCoordinateMatrix)
    (hcheck : rawCoordinateMatrixCheck forward inverse = true) :
    BinaryVector n ≃ₗ[ZMod 2] BinaryVector n :=
  LinearEquiv.ofBijective (rawCoordinateMatrixMap forward) (by
    have hcomp := accepted_rawCoordinateMatrixCheck_compositions forward inverse hcheck
    refine ⟨?_, ?_⟩
    · intro x y hxy
      have hleft := congrArg (rawCoordinateMatrixMap inverse) hxy
      have hx := congrArg (fun f : BinaryVector n →ₗ[ZMod 2] BinaryVector n => f x) hcomp.1
      have hy := congrArg (fun f : BinaryVector n →ₗ[ZMod 2] BinaryVector n => f y) hcomp.1
      simpa [LinearMap.comp_apply] using hleft.trans (by rw [hy, hx])
    · intro y
      refine ⟨rawCoordinateMatrixMap inverse y, ?_⟩
      have hright := congrArg
        (fun f : BinaryVector n →ₗ[ZMod 2] BinaryVector n => f y) hcomp.2
      simpa [LinearMap.comp_apply] using hright.symm)

end CorruptedFieldRecovery
