import CorruptedFieldRecovery
import CorruptedFieldRecovery.RawPolynomialIrreducibility

set_option pp.universes true
set_option pp.explicit false
set_option pp.fullNames true
set_option pp.piBinderTypes true
set_option pp.piBinderNames true
set_option pp.piBinderNames.hygienic true
set_option pp.proofs true
set_option pp.deepTerms true
set_option pp.maxSteps 1000000
set_option maxRecDepth 10000

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawMaskPolynomial_step"
#check @CorruptedFieldRecovery.rawMaskPolynomial_step
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawMaskPolynomial_step"
#print axioms CorruptedFieldRecovery.rawMaskPolynomial_step

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawMaskPolynomial_eval_zero"
#check @CorruptedFieldRecovery.rawMaskPolynomial_eval_zero
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawMaskPolynomial_eval_zero"
#print axioms CorruptedFieldRecovery.rawMaskPolynomial_eval_zero

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawDivX_X_mul"
#check @CorruptedFieldRecovery.rawDivX_X_mul
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawDivX_X_mul"
#print axioms CorruptedFieldRecovery.rawDivX_X_mul

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawMaskPolynomial_injective"
#check @CorruptedFieldRecovery.rawMaskPolynomial_injective
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawMaskPolynomial_injective"
#print axioms CorruptedFieldRecovery.rawMaskPolynomial_injective

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawBitsToNat_lt_pow_length"
#check @CorruptedFieldRecovery.rawBitsToNat_lt_pow_length
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawBitsToNat_lt_pow_length"
#print axioms CorruptedFieldRecovery.rawBitsToNat_lt_pow_length

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawPolynomialBits_mask_decode"
#check @CorruptedFieldRecovery.rawPolynomialBits_mask_decode
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawPolynomialBits_mask_decode"
#print axioms CorruptedFieldRecovery.rawPolynomialBits_mask_decode
