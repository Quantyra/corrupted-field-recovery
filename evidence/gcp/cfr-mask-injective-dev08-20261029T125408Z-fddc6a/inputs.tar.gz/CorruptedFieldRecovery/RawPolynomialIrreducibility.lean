import CorruptedFieldRecovery.RawPolynomialMaskCompleteness

/-! Ordinary bridge work for the finite raw factor search.  The initial
lemmas pin down the boundedness of its coefficient-mask representation; the
remaining theorem will connect the predicate to `Polynomial.Irreducible`.
No theorem here changes the executable candidate checker.
-/

namespace CorruptedFieldRecovery

open Polynomial

theorem rawMaskPolynomial_step (n : Nat) :
    rawMaskPolynomial n = C (if n.bodd then 1 else 0) +
      X * rawMaskPolynomial n.div2 := by
  cases n with
  | zero => simp [rawMaskPolynomial_zero]
  | succ n =>
      have hn : n + 1 ≠ 0 := by omega
      rw [rawMaskPolynomial_eq_of_ne_zero _ hn]

theorem rawMaskPolynomial_eval_zero (n : Nat) :
    (rawMaskPolynomial n).eval 0 = if n.bodd then 1 else 0 := by
  rw [rawMaskPolynomial_step]
  cases n.bodd <;> simp [eval_add, eval_mul]

theorem rawDivX_X_mul (p : Polynomial (ZMod 2)) :
    Polynomial.divX (X * p) = p := by
  apply Polynomial.ext
  intro i
  simp [Polynomial.coeff_divX]

/-- The mask decoder is injective: its constant coefficient records the low
bit and division by `X` exposes the remaining mask. -/
theorem rawMaskPolynomial_injective {a b : Nat}
    (h : rawMaskPolynomial a = rawMaskPolynomial b) : a = b := by
  suffices hmain : ∀ n a b, a + b = n →
      rawMaskPolynomial a = rawMaskPolynomial b → a = b by
    exact hmain (a + b) a b rfl h
  intro n
  induction n using Nat.strong_induction_on with
  | h n ih =>
      intro a b hab heq
      by_cases hn : n = 0
      · subst n
        have ha : a = 0 := by omega
        have hb : b = 0 := by omega
        subst a
        subst b
        rfl
      have hlowEval := congrArg (fun f : Polynomial (ZMod 2) => f.eval 0) heq
      change (rawMaskPolynomial a).eval 0 = (rawMaskPolynomial b).eval 0 at hlowEval
      rw [rawMaskPolynomial_eval_zero, rawMaskPolynomial_eval_zero] at hlowEval
      have hlow : a.bodd = b.bodd := by
        cases ha : a.bodd <;> cases hb : b.bodd <;>
          simp [ha, hb] at hlowEval ⊢
      have hdivPoly : rawMaskPolynomial a.div2 = rawMaskPolynomial b.div2 := by
        have hdiv := congrArg Polynomial.divX heq
        rw [rawMaskPolynomial_step a, rawMaskPolynomial_step b] at hdiv
        cases ha : a.bodd <;> cases hb : b.bodd <;>
          simpa [ha, hb, Nat.div2_val, Polynomial.divX_add, Polynomial.divX_C,
            rawDivX_X_mul] using hdiv
      have hlt : a.div2 + b.div2 < n := by
        rw [Nat.div2_val, Nat.div2_val]
        omega
      have hdiv := ih (a.div2 + b.div2) hlt a.div2 b.div2 rfl hdivPoly
      have hdivQuot : a / 2 = b / 2 := by
        simpa [Nat.div2_val] using hdiv
      have hbits : a % 2 = b % 2 := by
        cases ha : a.bodd <;> cases hb : b.bodd <;>
          simp_all [Nat.mod_two_of_bodd]
      omega

/-- A little-endian list of `n` bits represents a natural below `2^n`.
This is the upper half of the range argument for the finite mask encoding. -/
theorem rawBitsToNat_lt_pow_length (bits : List Bool) :
    rawBitsToNat bits < 2 ^ bits.length := by
  induction bits with
  | nil => simp [rawBitsToNat]
  | cons b bs ih =>
      cases b <;> simp [rawBitsToNat] at * <;> omega

/-- The existing mask decoder agrees with the proof-defined finite
coefficient encoding, so arbitrary polynomial factors can be represented by
finite masks without truncation. -/
theorem rawPolynomialBits_mask_decode (p : Polynomial (ZMod 2)) :
    rawMaskPolynomial (rawBitsToNat (rawPolynomialBits p)) = p := by
  rw [← rawBoolListPolynomial_eq_mask]
  exact rawPolynomialBits_decode p

end CorruptedFieldRecovery
