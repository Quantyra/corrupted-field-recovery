import CorruptedFieldRecovery.S010ActualScalarBounds
import CorruptedFieldRecovery.S010BetaArithmetic

namespace CorruptedFieldRecovery

/-- Fully instantiate beta arithmetic with the actual proper-degree Finset
bound for a finite binary extension field. -/
theorem beta_lt_half_actual
    (K : Type*) [Field K] [Finite K] [Algebra BinaryField K]
    [FiniteDimensional BinaryField K] (s R : Nat)
    (hsdim : Module.finrank BinaryField K = s)
    (hsize : 2 * R + 5 ≤ s) :
    ((2 ^ R : ℚ) * (1 + (2 ^ s : ℚ) + (2 ^ s : ℚ) ^ 2) /
      (2 ^ s : ℚ) ^ 3) +
      ((2 ^ R : ℚ) * (∑ d ∈ properDegrees K, 2 ^ d)) /
        (2 ^ s : ℚ) < 1 / 2 := by
  apply beta_lt_half_from_size hsize
  exact actual_proper_degree_scaled_bound K s R hsdim hsize

end CorruptedFieldRecovery
