import CorruptedFieldRecovery
import CorruptedFieldRecovery.RawFieldPolynomialBridge

set_option pp.universes true
set_option pp.explicit false
set_option pp.fullNames true
set_option pp.piBinderTypes true
set_option pp.piBinderNames true
set_option pp.piBinderNames.hygienic true
set_option pp.proofs true
set_option pp.deepTerms true
set_option pp.maxSteps 1000000
set_option maxRecDepth 10000

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawMaskPolynomial_bit"
#check @CorruptedFieldRecovery.rawMaskPolynomial_bit
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawMaskPolynomial_bit"
#print axioms CorruptedFieldRecovery.rawMaskPolynomial_bit

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawMaskPolynomial_shift"
#check @CorruptedFieldRecovery.rawMaskPolynomial_shift
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawMaskPolynomial_shift"
#print axioms CorruptedFieldRecovery.rawMaskPolynomial_shift

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawMaskPolynomial_xor"
#check @CorruptedFieldRecovery.rawMaskPolynomial_xor
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawMaskPolynomial_xor"
#print axioms CorruptedFieldRecovery.rawMaskPolynomial_xor

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawPolyMul_polynomial"
#check @CorruptedFieldRecovery.rawPolyMul_polynomial
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawPolyMul_polynomial"
#print axioms CorruptedFieldRecovery.rawPolyMul_polynomial
