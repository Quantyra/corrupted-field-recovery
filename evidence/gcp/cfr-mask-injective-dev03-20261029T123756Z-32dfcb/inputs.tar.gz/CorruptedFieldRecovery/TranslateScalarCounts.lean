import Mathlib.Data.Finset.Card
import Mathlib.Tactic

/-! Finite root counts for the fifth-word translate scalar.

The support is represented here by its actual finite set of K³ coordinates.
No K-linearity of this set is used: its binary-subspace structure enters only
through its cardinality in the caller. -/

namespace CorruptedFieldRecovery

noncomputable section

variable (K : Type*) [Field K] [Fintype K] [DecidableEq K]

abbrev KTriple := Fin 3 → K

def translateScalarRoots (u₀ u₁ : KTriple K) : Finset K :=
  Finset.univ.filter fun t => u₀ + t • u₁ = 0

theorem card_translateScalarRoots_le_one (u₀ u₁ : KTriple K)
    (hu₁ : u₁ ≠ 0) : (translateScalarRoots K u₀ u₁).card ≤ 1 := by
  classical
  apply Finset.card_le_one.mpr
  intro t ht u hu
  simp only [translateScalarRoots, Finset.mem_filter, Finset.mem_univ,
    true_and] at ht hu
  have hmul : (t - u) • u₁ = 0 := by
    have heq : t • u₁ = u • u₁ := by
      rw [eq_neg_of_add_eq_zero_left ht, eq_neg_of_add_eq_zero_left hu]
    rw [sub_smul, heq, sub_self]
  have hj : ∃ j : Fin 3, u₁ j ≠ 0 := by
    by_contra h
    apply hu₁
    funext j
    exact not_not.mp (by simpa using h j)
  obtain ⟨j, hj⟩ := hj
  have hcoord := congrFun hmul j
  simp only [Pi.smul_apply, smul_eq_mul] at hcoord
  have htu : t - u = 0 := (mul_eq_zero.mp hcoord).resolve_right hj
  exact sub_eq_zero.mp htu

abbrev TranslatePair (U : Finset (KTriple K)) :=
  {x // x ∈ U} × {x // x ∈ U}

def nonzeroTranslatePairs (U : Finset (KTriple K)) : Finset (TranslatePair K U) :=
  Finset.univ.filter fun p => p.1.1 ≠ 0 ∨ p.2.1 ≠ 0

def badTranslateScalars (U : Finset (KTriple K)) : Finset K :=
  (nonzeroTranslatePairs K U).biUnion fun p =>
    translateScalarRoots K p.1.1 p.2.1

theorem card_nonzeroTranslatePairs_le (U : Finset (KTriple K))
    (hzero : (0 : KTriple K) ∈ U) :
    (nonzeroTranslatePairs K U).card ≤ U.card ^ 2 - 1 := by
  classical
  let p : TranslatePair K U → Prop := fun x => x.1.1 ≠ 0 ∨ x.2.1 ≠ 0
  letI : DecidablePred p := Classical.decPred p
  have hsplit := Finset.card_filter_add_card_filter_not
    (s := (Finset.univ : Finset (TranslatePair K U))) p
  have hzeroCard : (Finset.univ.filter fun x : TranslatePair K U => ¬ p x).card = 1 := by
    have hsingleton : (Finset.univ.filter fun x : TranslatePair K U => ¬ p x) =
        {⟨⟨0, hzero⟩, ⟨0, hzero⟩⟩} := by
      ext x
      constructor
      · intro hx
        simp only [Finset.mem_filter, Finset.mem_univ, true_and, p,
          not_or, not_not] at hx
        rcases hx with ⟨hx₁, hx₂⟩
        apply Prod.ext
        · apply Subtype.ext
          exact hx₁
        · apply Subtype.ext
          exact hx₂
      · intro hx
        subst x
        simp [p]
    rw [hsingleton]
    simp
  have hprod : Fintype.card (TranslatePair K U) = U.card ^ 2 := by
    simp [TranslatePair, Fintype.card_prod]
  have hsplit' : (nonzeroTranslatePairs K U).card + 1 = U.card ^ 2 := by
    simpa [nonzeroTranslatePairs, p, hzeroCard, hprod] using hsplit
  omega

theorem card_badTranslateScalars_le (U : Finset (KTriple K))
    (hzero : (0 : KTriple K) ∈ U) :
    (badTranslateScalars K U).card ≤ U.card ^ 2 - 1 := by
  classical
  calc
    (badTranslateScalars K U).card ≤
        ∑ p ∈ nonzeroTranslatePairs K U,
          (translateScalarRoots K p.1.1 p.2.1).card := Finset.card_biUnion_le
    _ ≤ (nonzeroTranslatePairs K U).card := by
      apply Finset.sum_le_sum
      intro p hp
      have hne : p.1.1 ≠ 0 ∨ p.2.1 ≠ 0 := (Finset.mem_filter.mp hp).2
      by_cases hu₁ : p.2.1 ≠ 0
      · exact card_translateScalarRoots_le_one K p.1.1 p.2.1 hu₁
      · have hu₀ : p.1.1 ≠ 0 := hne.resolve_right hu₁
        have hempty : translateScalarRoots K p.1.1 p.2.1 = ∅ := by
          ext t
          simp [translateScalarRoots, hu₁, hu₀]
        simp [hempty]
    _ ≤ U.card ^ 2 - 1 := by
      simpa [nonzeroTranslatePairs] using card_nonzeroTranslatePairs_le K U hzero

theorem card_badTranslateScalars_le_pow (U : Finset (KTriple K))
    (hzero : (0 : KTriple K) ∈ U) (r : Nat) (hcard : U.card = 2 ^ r) :
    (badTranslateScalars K U).card ≤ 2 ^ (2 * r) - 1 := by
  have h := card_badTranslateScalars_le K U hzero
  rw [hcard] at h
  simpa [pow_mul, Nat.mul_comm] using h

end

end CorruptedFieldRecovery
