import CorruptedFieldRecovery.RawRabinGcdBitCost

/-! A logarithmic-depth envelope for the declared charge of the actual
Euclidean recursion used by the raw Rabin gate. -/

namespace CorruptedFieldRecovery

private theorem rawRabinBitWidth_le_of_lt_pow {n k : Nat}
    (hn : n < 2 ^ k) : rawNatBitWidth n ≤ k + 1 := by
  unfold rawNatBitWidth
  by_cases hn0 : n = 0
  · simp [hn0]
  · have hk : 0 < k := by
      cases k with
      | zero => simp at hn; omega
      | succ k => omega
    have hlog := rawLog2_lt_of_lt_pow hk hn
    omega

private theorem rawRabin_lt_pow_of_log_lt {n k : Nat}
    (h : Nat.log2 n < k) : n < 2 ^ k := by
  by_cases hn0 : n = 0
  · simp [hn0]
  · have hn : 0 < n := Nat.pos_of_ne_zero hn0
    have hlog : n < 2 ^ (Nat.log2 n + 1) := Nat.lt_log2_self
    have hp : 2 ^ (Nat.log2 n + 1) ≤ 2 ^ k := by
      exact Nat.pow_le_pow_right (by decide : 0 < 2)
        (Nat.succ_le_of_lt h)
    exact lt_of_lt_of_le hlog hp

/-- The exact costed Euclidean recursion has logarithmic depth. Under a common
`A`-bit envelope for its two inputs, its declared charge is bounded by a
polynomial in `A` times `log₂(divisor)+2`. This is a theorem about the explicit
charge recurrence, not a claim about Lean's machine execution time. -/
theorem rawPolynomialGcdBitCosted_cost_le {a b A : Nat}
    (hA : 0 < A) (ha : a < 2 ^ A) (hb : b < 2 ^ A) :
    (rawPolynomialGcdBitCosted a b).2 ≤
      (Nat.log2 b + 2) * (40 * (3 * A + 6) ^ 2 * (A + 1)) := by
  have hmain : ∀ k a b, Nat.log2 b = k → ∀ A,
      0 < A → a < 2 ^ A → b < 2 ^ A →
      (rawPolynomialGcdBitCosted a b).2 ≤
        (Nat.log2 b + 2) * (40 * (3 * A + 6) ^ 2 * (A + 1)) := by
    intro k
    induction k using Nat.strong_induction_on with
    | h k ih =>
      intro a b hk A hA ha hb
      have hPpos : 1 ≤ 40 * (3 * A + 6) ^ 2 * (A + 1) := by
        nlinarith [hA]
      by_cases hb0 : b = 0
      · simp [rawPolynomialGcdBitCosted, hb0]
        unfold rawNatBitWidth
        nlinarith [hPpos]
      · by_cases hb1 : b = 1
        · simp [rawPolynomialGcdBitCosted, hb1, rawNatBitWidth]
          nlinarith [hPpos]
        · have hbtwo : 1 < b := by omega
          obtain ⟨d, rfl⟩ : ∃ d, b = d + 2 := by omega
          have hlogbA : Nat.log2 b < A := rawLog2_lt_of_lt_pow hA hb
          let rem := rawPolynomialRemainderBitCosted a b
          have hrem : rem.1 < 2 ^ Nat.log2 b := by
            rw [show rem.1 = rawPolynomialRemainder a b by
              dsimp [rem]
              exact rawPolynomialRemainderBitCosted_fst a b]
            exact rawPolynomialRemainder_lt_pow_log hbtwo
          have hremLog : Nat.log2 rem.1 < Nat.log2 b :=
            rawLog2_lt_of_lt_pow (by omega) hrem
          rw [hk] at hremLog
          have hlogbK : k < A := by simpa [hk] using hlogbA
          have hremA : rem.1 < 2 ^ A := by
            apply rawRabin_lt_pow_of_log_lt
            exact lt_of_lt_of_le hremLog (Nat.le_of_lt hlogbK)
          have hremCost := rawPolynomialRemainderBitCosted_cost_le
            hA ha hbtwo
          have hwidthB : rawNatBitWidth b ≤ A := by
            unfold rawNatBitWidth
            omega
          have hwidthLog : rawNatBitWidth (Nat.log2 b) ≤ A := by
            have hloglog : Nat.log2 (Nat.log2 b) ≤ Nat.log2 b :=
              Nat.log2_le_self _
            unfold rawNatBitWidth
            omega
          have hlocal : rawNatBitWidth b + rem.2 ≤
              40 * (3 * A + 6) ^ 2 * (A + 1) := by
            have hterm : A + Nat.log2 b + rawNatBitWidth (Nat.log2 b) + 4 ≤
                3 * A + 6 := by omega
            have hquad : 40 * (A + Nat.log2 b +
                rawNatBitWidth (Nat.log2 b) + 4) ^ 2 ≤
                40 * (3 * A + 6) ^ 2 := by
              gcongr
            have hremCost' : rem.2 ≤
                A * (40 * (A + Nat.log2 b +
                  rawNatBitWidth (Nat.log2 b) + 4) ^ 2) := by
              simpa [rem] using hremCost
            have hcost : rem.2 ≤ A * (40 * (3 * A + 6) ^ 2) := by
              exact le_trans hremCost'
                (Nat.mul_le_mul_left A hquad)
            have hfactor : A * (40 * (3 * A + 6) ^ 2) + A ≤
                40 * (3 * A + 6) ^ 2 * (A + 1) := by
              nlinarith [hA]
            calc
              _ ≤ A + A * (40 * (3 * A + 6) ^ 2) := by
                exact Nat.add_le_add hwidthB hcost
              _ ≤ 40 * (3 * A + 6) ^ 2 * (A + 1) := hfactor
          have hrest := ih (Nat.log2 rem.1) hremLog b rem.1 rfl A hA hb hremA
          have hrec : (rawPolynomialGcdBitCosted b rem.1).2 ≤
              (Nat.log2 rem.1 + 2) * (40 * (3 * A + 6) ^ 2 * (A + 1)) := hrest
          simp only [rawPolynomialGcdBitCosted]
          dsimp [rem]
          have hdepth : Nat.log2 rem.1 + 2 ≤ Nat.log2 b + 1 := by omega
          have hdepthMul := Nat.mul_le_mul_right
            (40 * (3 * A + 6) ^ 2 * (A + 1)) hdepth
          calc
            _ ≤ (40 * (3 * A + 6) ^ 2 * (A + 1)) +
                (Nat.log2 rem.1 + 2) *
                  (40 * (3 * A + 6) ^ 2 * (A + 1)) := by
                    exact Nat.add_le_add hlocal hrec
            _ ≤ (Nat.log2 b + 2) *
                  (40 * (3 * A + 6) ^ 2 * (A + 1)) := by
                    nlinarith [hdepthMul]
  exact hmain (Nat.log2 b) a b rfl A hA ha hb

end CorruptedFieldRecovery
