import CorruptedFieldRecovery.S010BalanceGaussianAffinePowerSolve

open scoped Matrix

namespace CorruptedFieldRecovery

/-! A disjoint, uncompiled bridge for the affine selector.  The Gaussian
column scan is run on the nested array.  Its exact matrix view and pivot
transcript then feed the same ordered free-column list and first-passing
predicate as the matrix specification.  This file does not claim a separate
array implementation of candidate-vector arithmetic or a resource bound. -/

/-- Search the free coordinates of an explicit final matrix/pivot output in
the same order used by the matrix affine selector. -/
def actualBalanceGaussianAffineSelectFromOutput {s : Nat}
    (output : Matrix (Fin ((3 * s) * (3 * s))) (Fin (s + 1)) (ZMod 2) ×
      List (Fin ((3 * s) * (3 * s)) × Fin (s + 1))) :
    Option (balanceGaussianFreeIndex output.2) :=
  actualBalanceGaussianFirstPassing
    (fun free => decide
      (balanceGaussianFreeCandidateFamily output.1 output.2 free
        (Fin.last s) = 1))
    (actualBalanceGaussianAffineFreeIndexList output.2)

/-- Affine selection driven by the final output of the nested-array run. -/
def actualBalanceGaussianAffineArraySelectFreeIndex {s : Nat}
    (T : Module.End (ZMod 2) (BinaryVector (3 * s))) :
    Option (balanceGaussianFreeIndex
      (actualBalanceGaussianAffineArrayOutput
        (actualBalanceGaussianAffinePowerMatrix T)).2) :=
  actualBalanceGaussianAffineSelectFromOutput
    (actualBalanceGaussianAffineArrayOutput
      (actualBalanceGaussianAffinePowerMatrix T))

/-- The array-driven selector refines the existing matrix selector exactly:
the same pivot output determines the ordered free list, the same Boolean test
is run from left to right, and the selected subtype witness is preserved. -/
theorem actualBalanceGaussianAffineArraySelectFreeIndex_refines
    {s : Nat} (T : Module.End (ZMod 2) (BinaryVector (3 * s))) :
    actualBalanceGaussianAffineArraySelectFreeIndex T =
      actualBalanceGaussianAffineSelectFreeIndex
        (actualBalanceGaussianAffinePowerMatrix T) := by
  let A := actualBalanceGaussianAffinePowerMatrix T
  change actualBalanceGaussianAffineSelectFromOutput
      (actualBalanceGaussianAffineArrayOutput A) =
    actualBalanceGaussianAffineSelectFreeIndex A
  rw [actualBalanceGaussianAffineArrayOutput_eq_scan]
  rfl

/-- Coefficients extracted from the array-selected free kernel vector. -/
def actualBalanceGaussianAffineArrayRecurrenceValue {s : Nat}
    (T : Module.End (ZMod 2) (BinaryVector (3 * s)))
    (free : balanceGaussianFreeIndex
      (actualBalanceGaussianAffineArrayOutput
        (actualBalanceGaussianAffinePowerMatrix T)).2) : Fin s → ZMod 2 :=
  let output := actualBalanceGaussianAffineArrayOutput
    (actualBalanceGaussianAffinePowerMatrix T)
  fun j => balanceGaussianFreeCandidateFamily output.1 output.2 free
    (Fin.last s) (Fin.castSucc j)

/-- Option-valued coefficients produced using the array run's selected free
candidate, with no independently chosen witness. -/
def actualBalanceGaussianAffineArrayRecurrence? {s : Nat}
    (T : Module.End (ZMod 2) (BinaryVector (3 * s))) :
    Option (Fin s → ZMod 2) :=
  (actualBalanceGaussianAffineArraySelectFreeIndex T).map
    (actualBalanceGaussianAffineArrayRecurrenceValue T)

/-- The coefficient output is extensionally identical to the current matrix
selector output, including the exact ordered first-passing free vector. -/
theorem actualBalanceGaussianAffineArrayRecurrence?_eq_matrixOutput
    {s : Nat} (T : Module.End (ZMod 2) (BinaryVector (3 * s))) :
    actualBalanceGaussianAffineArrayRecurrence? T =
      actualBalanceGaussianAffineRecurrence? T := by
  let A := actualBalanceGaussianAffinePowerMatrix T
  have houtput := actualBalanceGaussianAffineArrayOutput_eq_scan A
  cases houtput
  rfl

end CorruptedFieldRecovery
