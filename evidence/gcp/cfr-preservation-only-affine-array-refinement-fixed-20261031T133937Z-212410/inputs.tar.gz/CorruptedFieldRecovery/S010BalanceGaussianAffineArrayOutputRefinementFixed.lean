import CorruptedFieldRecovery.S010BalanceGaussianAffinePowerSolve

open scoped Matrix

namespace CorruptedFieldRecovery

/-! Focused successor to the uncompiled affine array-output refinement draft.
The free candidate is a vector `Fin (s+1) → ZMod 2`, so coefficient `j`
is its single coordinate at `Fin.castSucc j`.  The selected free-index proof
depends on the pivot list; the refinement theorem therefore compares erased
column indices, while the coefficient-output theorem compares values in a
fixed function type. -/

def actualBalanceGaussianAffineSelectFromOutputFixed {s : Nat}
    (output : Matrix (Fin ((3 * s) * (3 * s))) (Fin (s + 1)) (ZMod 2) ×
      List (Fin ((3 * s) * (3 * s)) × Fin (s + 1))) :
    Option (balanceGaussianFreeIndex output.2) :=
  actualBalanceGaussianFirstPassing
    (fun free => decide
      (balanceGaussianFreeCandidateFamily output.1 output.2 free
        (Fin.last s) = 1))
    (actualBalanceGaussianAffineFreeIndexList output.2)

def actualBalanceGaussianAffineArraySelectFreeIndexFixed {s : Nat}
    (T : Module.End (ZMod 2) (BinaryVector (3 * s))) :
    Option (balanceGaussianFreeIndex
      (actualBalanceGaussianAffineArrayOutput
        (actualBalanceGaussianAffinePowerMatrix T)).2) :=
  actualBalanceGaussianAffineSelectFromOutputFixed
    (actualBalanceGaussianAffineArrayOutput
      (actualBalanceGaussianAffinePowerMatrix T))

/-- The subtype proof varies with the pivot transcript, so state exact
selector refinement after erasing only that proof component. -/
theorem actualBalanceGaussianAffineArraySelectFreeIndexFixed_erased_refines
    {s : Nat} (T : Module.End (ZMod 2) (BinaryVector (3 * s))) :
    (actualBalanceGaussianAffineArraySelectFreeIndexFixed T).map Subtype.val =
      (actualBalanceGaussianAffineSelectFreeIndex
        (actualBalanceGaussianAffinePowerMatrix T)).map Subtype.val := by
  let A := actualBalanceGaussianAffinePowerMatrix T
  change (actualBalanceGaussianAffineSelectFromOutputFixed
      (actualBalanceGaussianAffineArrayOutput A)).map Subtype.val =
    (actualBalanceGaussianAffineSelectFreeIndex A).map Subtype.val
  rw [actualBalanceGaussianAffineArrayOutput_eq_scan]
  rfl

def actualBalanceGaussianAffineArrayRecurrenceValueFixed {s : Nat}
    (T : Module.End (ZMod 2) (BinaryVector (3 * s)))
    (free : balanceGaussianFreeIndex
      (actualBalanceGaussianAffineArrayOutput
        (actualBalanceGaussianAffinePowerMatrix T)).2) : Fin s → ZMod 2 :=
  let output := actualBalanceGaussianAffineArrayOutput
    (actualBalanceGaussianAffinePowerMatrix T)
  fun j => balanceGaussianFreeCandidateFamily output.1 output.2 free
    (Fin.castSucc j)

def actualBalanceGaussianAffineArrayRecurrenceFixed? {s : Nat}
    (T : Module.End (ZMod 2) (BinaryVector (3 * s))) :
    Option (Fin s → ZMod 2) :=
  (actualBalanceGaussianAffineArraySelectFreeIndexFixed T).map
    (actualBalanceGaussianAffineArrayRecurrenceValueFixed T)

/-- Matrix-view output using the same coefficient-coordinate convention. -/
def actualBalanceGaussianAffineMatrixRecurrenceValueFixed {s : Nat}
    (T : Module.End (ZMod 2) (BinaryVector (3 * s)))
    (free : balanceGaussianFreeIndex
      (balanceGaussianColumnScan (actualBalanceGaussianAffinePowerMatrix T)
        ∅ (List.ofFn fun j : Fin (s + 1) => j)).2) : Fin s → ZMod 2 :=
  let run := balanceGaussianColumnScan (actualBalanceGaussianAffinePowerMatrix T)
    ∅ (List.ofFn fun j : Fin (s + 1) => j)
  fun j => balanceGaussianFreeCandidateFamily run.1 run.2 free
    (Fin.castSucc j)

def actualBalanceGaussianAffineMatrixRecurrenceFixed? {s : Nat}
    (T : Module.End (ZMod 2) (BinaryVector (3 * s))) :
    Option (Fin s → ZMod 2) :=
  (actualBalanceGaussianAffineSelectFreeIndex
    (actualBalanceGaussianAffinePowerMatrix T)).map
    (actualBalanceGaussianAffineMatrixRecurrenceValueFixed T)

/-- Array scan, free-list order, first-passing test, and extracted coefficients
agree exactly with the matrix-view specification. -/
theorem actualBalanceGaussianAffineArrayRecurrenceFixed?_eq_matrix :
    ∀ {s : Nat} (T : Module.End (ZMod 2) (BinaryVector (3 * s))),
      actualBalanceGaussianAffineArrayRecurrenceFixed? T =
        actualBalanceGaussianAffineMatrixRecurrenceFixed? T := by
  intro s T
  let A := actualBalanceGaussianAffinePowerMatrix T
  have houtput := actualBalanceGaussianAffineArrayOutput_eq_scan A
  cases houtput
  rfl

end CorruptedFieldRecovery
