import CorruptedFieldRecovery
import CorruptedFieldRecovery.RawGcdOperationalMachine

set_option pp.universes true
set_option pp.explicit false
set_option pp.fullNames true
set_option pp.piBinderTypes true
set_option pp.piBinderNames true
set_option pp.piBinderNames.hygienic true
set_option pp.proofs true
set_option pp.deepTerms true
set_option pp.maxSteps 1000000
set_option maxRecDepth 10000

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.RawGcdMachineStep"
#check @CorruptedFieldRecovery.RawGcdMachineStep
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.RawGcdMachineStep"
#print axioms CorruptedFieldRecovery.RawGcdMachineStep

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.RawGcdMachineExec"
#check @CorruptedFieldRecovery.RawGcdMachineExec
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.RawGcdMachineExec"
#print axioms CorruptedFieldRecovery.RawGcdMachineExec

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawGcdMachineExec_sound"
#check @CorruptedFieldRecovery.rawGcdMachineExec_sound
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawGcdMachineExec_sound"
#print axioms CorruptedFieldRecovery.rawGcdMachineExec_sound

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawGcdMachineExec_exists"
#check @CorruptedFieldRecovery.rawGcdMachineExec_exists
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawGcdMachineExec_exists"
#print axioms CorruptedFieldRecovery.rawGcdMachineExec_exists

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawGcdMachineExec_refines_rawPolynomialGcd"
#check @CorruptedFieldRecovery.rawGcdMachineExec_refines_rawPolynomialGcd
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawGcdMachineExec_refines_rawPolynomialGcd"
#print axioms CorruptedFieldRecovery.rawGcdMachineExec_refines_rawPolynomialGcd

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawGcdMachineExec_charge_le"
#check @CorruptedFieldRecovery.rawGcdMachineExec_charge_le
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawGcdMachineExec_charge_le"
#print axioms CorruptedFieldRecovery.rawGcdMachineExec_charge_le
