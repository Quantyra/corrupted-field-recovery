import CorruptedFieldRecovery.Defect
import Mathlib.LinearAlgebra.StdBasis
import Mathlib.Data.ZMod.Basic

/-! Dense binary trilinear input semantics for the manuscript. -/

namespace CorruptedFieldRecovery

/-- A physical input vector in the manuscript's binary coordinate model. -/
abbrev BinaryVector (n : ℕ) := Fin n → ZMod 2

/-- An explicitly represented trilinear tensor on `F₂^n`. -/
abbrev BinaryTensor (n : ℕ) := Trilinear (ZMod 2) (BinaryVector n)

/-- The standard coordinate vector indexed by `i`. -/
noncomputable def coordinateVector {n : ℕ} (i : Fin n) : BinaryVector n :=
  Pi.basisFun (ZMod 2) (Fin n) i

/-- The ordered coefficient table of a dense tensor. -/
def coefficient {n : ℕ} (C : BinaryTensor n) (i j k : Fin n) : ZMod 2 :=
  C (coordinateVector i) (coordinateVector j) (coordinateVector k)

/-- Vanishing whenever any two arguments agree. -/
def IsAlternating {n : ℕ} (C : BinaryTensor n) : Prop :=
  (∀ x y, C x x y = 0) ∧ (∀ x y, C x y x = 0) ∧ (∀ x y, C x y y = 0)

/-- Equality of every ordered basis coefficient implies equality on all vectors.
The proof expands each of the three vector arguments in the standard basis. -/
theorem binaryTensor_ext_of_coefficients {n : ℕ} {C D : BinaryTensor n}
    (h : ∀ i j k, coefficient C i j k = coefficient D i j k) : C = D := by
  apply (Pi.basisFun (ZMod 2) (Fin n)).ext
  intro i
  apply (Pi.basisFun (ZMod 2) (Fin n)).ext
  intro j
  apply (Pi.basisFun (ZMod 2) (Fin n)).ext
  intro k
  exact h i j k

/-- Alternation in the first two arguments implies symmetry there over `F₂`. -/
theorem alternating_swap12 {n : ℕ} {C : BinaryTensor n}
    (h : IsAlternating C) (x y z : BinaryVector n) :
    C y x z = C x y z := by
  have hdiag := h.1 (x + y) z
  have hcross : C x y z + C y x z = 0 := by
    simpa only [LinearMap.map_add, LinearMap.add_apply, h.1 x z, h.1 y z,
      zero_add, add_zero] using hdiag
  have heq := eq_neg_of_add_eq_zero_left hcross
  simpa using heq.symm

/-- Alternation in the last two arguments implies symmetry there over `F₂`. -/
theorem alternating_swap23 {n : ℕ} {C : BinaryTensor n}
    (h : IsAlternating C) (x y z : BinaryVector n) :
    C x z y = C x y z := by
  have hdiag := h.2.2 x (y + z)
  have hcross : C x y z + C x z y = 0 := by
    simpa only [LinearMap.map_add, LinearMap.add_apply, h.2.2 x y, h.2.2 x z,
      zero_add, add_zero] using hdiag
  have heq := eq_neg_of_add_eq_zero_left hcross
  simpa using heq.symm

/-- Alternation gives symmetry under exchanging the first and third arguments. -/
theorem alternating_swap13 {n : ℕ} {C : BinaryTensor n}
    (h : IsAlternating C) (x y z : BinaryVector n) :
    C z y x = C x y z := by
  calc
    C z y x = C y z x := alternating_swap12 h z y x
    _ = C y x z := (alternating_swap23 h y z x).symm
    _ = C x y z := alternating_swap12 h y x z

end CorruptedFieldRecovery
