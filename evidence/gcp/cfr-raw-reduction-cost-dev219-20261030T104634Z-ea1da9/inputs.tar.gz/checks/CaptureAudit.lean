import CorruptedFieldRecovery
import CorruptedFieldRecovery.RawReductionBitCost

set_option pp.universes true
set_option pp.explicit false
set_option pp.fullNames true
set_option pp.piBinderTypes true
set_option pp.piBinderNames true
set_option pp.piBinderNames.hygienic true
set_option pp.proofs true
set_option pp.deepTerms true
set_option pp.maxSteps 1000000
set_option maxRecDepth 10000

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawNatMulBitCharge"
#check @CorruptedFieldRecovery.rawNatMulBitCharge
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawNatMulBitCharge"
#print axioms CorruptedFieldRecovery.rawNatMulBitCharge

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawReduceStepBitCosted"
#check @CorruptedFieldRecovery.rawReduceStepBitCosted
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawReduceStepBitCosted"
#print axioms CorruptedFieldRecovery.rawReduceStepBitCosted

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawReduceStepBitCosted_fst"
#check @CorruptedFieldRecovery.rawReduceStepBitCosted_fst
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawReduceStepBitCosted_fst"
#print axioms CorruptedFieldRecovery.rawReduceStepBitCosted_fst

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawReduceFuelBitCosted"
#check @CorruptedFieldRecovery.rawReduceFuelBitCosted
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawReduceFuelBitCosted"
#print axioms CorruptedFieldRecovery.rawReduceFuelBitCosted

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawReduceFuelBitCosted_fst"
#check @CorruptedFieldRecovery.rawReduceFuelBitCosted_fst
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawReduceFuelBitCosted_fst"
#print axioms CorruptedFieldRecovery.rawReduceFuelBitCosted_fst

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawReduceFuelBitCosted_cost_eq"
#check @CorruptedFieldRecovery.rawReduceFuelBitCosted_cost_eq
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawReduceFuelBitCosted_cost_eq"
#print axioms CorruptedFieldRecovery.rawReduceFuelBitCosted_cost_eq
