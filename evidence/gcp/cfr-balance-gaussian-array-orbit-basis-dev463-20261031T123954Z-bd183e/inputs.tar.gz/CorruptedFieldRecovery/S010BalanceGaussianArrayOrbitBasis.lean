import CorruptedFieldRecovery.S010BalanceGaussianArrayOrbitRun
import Mathlib.LinearAlgebra.Basis.Basic
import Mathlib.LinearAlgebra.Matrix.ToLin

namespace CorruptedFieldRecovery

/-! # Basis facts for actual orbit arrays

This module proves a finite-dimensional consequence of the executable array
run interface. It does not compute an inverse matrix: the array matrix below
is computable, while the `Basis` object is a proof-level witness assembled
from linear independence and spanning.
-/

/-- A full-span ordered array with exactly as many columns as ambient
coordinates is linearly independent. -/
theorem actualGreedyArrayColumnFamily_linearIndependent_of_top
    {m : Nat} (columns : Array (BinaryVector m))
    (hsize : columns.size = m)
    (hspan : actualGreedyArrayColumnSubmodule columns = \u22a4) :
    LinearIndependent (ZMod 2) (actualGreedyArrayColumnFamily columns) := by
  rw [actualGreedyArrayColumnSubmodule_eq_span] at hspan
  exact linearIndependent_of_top_le_span_of_card_eq_finrank hspan.ge (by
    simp [BinaryVector, hsize])

/-- A basis indexed by the actual array positions, derived from its exact
length and full-span proof. This is a proof-level basis witness, not an
algorithmic basis constructor. -/
noncomputable def actualGreedyArrayColumnBasis {m : Nat}
    (columns : Array (BinaryVector m))
    (hsize : columns.size = m)
    (hspan : actualGreedyArrayColumnSubmodule columns = \u22a4) :
    Basis (Fin columns.size) (ZMod 2) (BinaryVector m) := by
  have hli := actualGreedyArrayColumnFamily_linearIndependent_of_top
    columns hsize hspan
  have hspan' : Submodule.span (ZMod 2)
      (Set.range (actualGreedyArrayColumnFamily columns)) = \u22a4 := by
    exact hspan
  exact Basis.mk hli hspan'.ge

/-- The matrix whose columns are the actual entries of an ordered vector
array. This definition is executable and uses the array's stored entries. -/
def actualGreedyArrayOrbitBasisMatrix {m : Nat}
    (columns : Array (BinaryVector m)) :
    Matrix (Fin m) (Fin columns.size) (ZMod 2) :=
  fun row column => columns[column.val]![row]

/-- The matrix column family agrees pointwise with the actual array family. -/
theorem actualGreedyArrayOrbitBasisMatrix_col {m : Nat}
    (columns : Array (BinaryVector m)) :
    (actualGreedyArrayOrbitBasisMatrix columns).col =
      actualGreedyArrayColumnFamily columns := by
  funext column row
  rfl

end CorruptedFieldRecovery
