import CorruptedFieldRecovery.S010BalanceGaussianGreedyCoordinateInverse
import CorruptedFieldRecovery.RawCoordinateEquivalence

namespace CorruptedFieldRecovery

/-! # Serialize the computed greedy coordinate matrices

Disjoint uncompiled draft.  It flattens the actual forward matrix and the
Gaussian-computed inverse into the row-major `RawCoordinateMatrix` format read
by the certificate checker.  The entry theorem is intended to pin the
`Fin.prodFinEquiv` order to the checker's `i*n+j` offset.  Under the two
matrix identities from the previous draft, it proves the actual Boolean
`rawCoordinateMatrixCheck` succeeds.  No serialized inverse is supplied. -/

/-- Row-major finite-array serialization of a square `Fin` matrix. -/
def rawCoordinateMatrixSerialize {n : Nat}
    (A : Matrix (Fin n) (Fin n) (ZMod 2)) : RawCoordinateMatrix :=
  Array.ofFn fun k : Fin (n * n) =>
    let ij := finProdFinEquiv.symm k
    A ij.1 ij.2

/-- The serialized array has exactly `n^2` entries. -/
theorem rawCoordinateMatrixSerialize_size {n : Nat}
    (A : Matrix (Fin n) (Fin n) (ZMod 2)) :
    (rawCoordinateMatrixSerialize A).size = n * n := by
  simp [rawCoordinateMatrixSerialize]

/-- Entrywise correspondence between the row-major array and the matrix. -/
theorem rawCoordinateMatrixSerialize_entry {n : Nat}
    (A : Matrix (Fin n) (Fin n) (ZMod 2)) (i j : Fin n) :
    (rawCoordinateMatrixSerialize A)[rawCoordinateMatrixOffset n i j]! = A i j := by
  classical
  have hoff : rawCoordinateMatrixOffset n i j < n * n := by
    simp [rawCoordinateMatrixOffset]
    nlinarith [i.isLt, j.isLt]
  have hval : (finProdFinEquiv (i, j)).val =
      rawCoordinateMatrixOffset n i j := by
    simp [rawCoordinateMatrixOffset, finProdFinEquiv]
  let k : Fin (n * n) := ⟨rawCoordinateMatrixOffset n i j, hoff⟩
  have hk : k = finProdFinEquiv (i, j) := Fin.ext hval.symm
  rw [Array.getElem!_pos hoff]
  simp [rawCoordinateMatrixSerialize, k, hk]

/-- The raw checker interpretation of the serialized matrix is exactly its
matrix-vector multiplication, for every vector. -/
theorem rawCoordinateMatrixMap_serialize_eq_mulVec {n : Nat}
    (A : Matrix (Fin n) (Fin n) (ZMod 2)) (x : BinaryVector n) :
    rawCoordinateMatrixMap (rawCoordinateMatrixSerialize A) x = A *ᵥ x := by
  ext i
  simp [rawCoordinateMatrixMap, Matrix.mulVec, dotProduct,
    rawCoordinateMatrixSerialize_entry]

/-- Any two-sided matrix inverse serializes to arrays that pass the exact
finite checker, including its length checks. -/
theorem rawCoordinateMatrixCheck_true_of_two_sided {n : Nat}
    (A B : Matrix (Fin n) (Fin n) (ZMod 2))
    (hAB : A * B = 1) (hBA : B * A = 1) :
    rawCoordinateMatrixCheck
      (rawCoordinateMatrixSerialize A) (rawCoordinateMatrixSerialize B) = true := by
  have hleft : ∀ i : Fin n,
      rawCoordinateMatrixMap (rawCoordinateMatrixSerialize B)
        (rawCoordinateMatrixMap (rawCoordinateMatrixSerialize A)
          (rawCoordinateUnitVector i)) = rawCoordinateUnitVector i := by
    intro i
    rw [rawCoordinateMatrixMap_serialize_eq_mulVec,
      rawCoordinateMatrixMap_serialize_eq_mulVec]
    have h := congrFun (show (B * A) *ᵥ rawCoordinateUnitVector i =
        (1 : Matrix (Fin n) (Fin n) (ZMod 2)) *ᵥ rawCoordinateUnitVector i from by
          rw [hBA])
    simpa [Matrix.mulVec, dotProduct, rawCoordinateUnitVector] using h
  have hright : ∀ i : Fin n,
      rawCoordinateMatrixMap (rawCoordinateMatrixSerialize A)
        (rawCoordinateMatrixMap (rawCoordinateMatrixSerialize B)
          (rawCoordinateUnitVector i)) = rawCoordinateUnitVector i := by
    intro i
    rw [rawCoordinateMatrixMap_serialize_eq_mulVec,
      rawCoordinateMatrixMap_serialize_eq_mulVec]
    have h := congrFun (show (A * B) *ᵥ rawCoordinateUnitVector i =
        (1 : Matrix (Fin n) (Fin n) (ZMod 2)) *ᵥ rawCoordinateUnitVector i from by
          rw [hAB])
    simpa [Matrix.mulVec, dotProduct, rawCoordinateUnitVector] using h
  simp [rawCoordinateMatrixCheck, rawCoordinateMatrixSerialize_size, hleft, hright]

/-- The actual greedy output serializes to a checker-accepted forward/inverse
pair whenever the orbit span is full. The inverse side is constructed by the
deterministic repeated Gaussian solves from the preceding file. -/
theorem rawGreedyCoordinateSerialization_check
    {s : Nat} (state : RawGreedyOrbitState (3 * s))
    (hspan : Submodule.span (ZMod 2)
      (Set.range (rawGreedyOrbitColumnFamily state.columns)) = ⊤) :
    rawCoordinateMatrixCheck
      (rawCoordinateMatrixSerialize (rawGreedyOrbitBasisMatrix state))
      (rawCoordinateMatrixSerialize
        (actualGaussianInverseMatrix (rawGreedyOrbitBasisMatrix state))) = true := by
  have htwoSided := rawGreedyOrbitBasisMatrix_computed_coordinates state hspan
  exact rawCoordinateMatrixCheck_true_of_two_sided
    (rawGreedyOrbitBasisMatrix state)
    (actualGaussianInverseMatrix (rawGreedyOrbitBasisMatrix state))
    htwoSided.1 htwoSided.2

/-- Under the explicit irreducible-annihilator hypotheses, the actual
three-pass physical-unit/orbit output has a serialized forward matrix and a
Gaussian-constructed inverse accepted by the raw matrix checker. -/
theorem rawGreedyModuleBasis_serialized_coordinate_check
    {s : Nat} (hs : 1 ≤ s)
    (T : Module.End (ZMod 2) (BinaryVector (3 * s)))
    (p : Polynomial (ZMod 2)) (hp : Irreducible p) (hmonic : p.Monic)
    (hdeg : p.natDegree = s) (hroot : Polynomial.aeval T p = 0) :
    rawCoordinateMatrixCheck
      (rawCoordinateMatrixSerialize
        (rawGreedyOrbitBasisMatrix (rawGreedyModuleBasisColumns T)))
      (rawCoordinateMatrixSerialize
        (actualGaussianInverseMatrix
          (rawGreedyOrbitBasisMatrix (rawGreedyModuleBasisColumns T)))) = true := by
  obtain ⟨_, _, hdim, _⟩ := rawGreedyModuleBasisColumns_threePass_dimension
    hs T p hp hmonic hdeg hroot
  have hspan := rawGreedyOrbitArraySpan_eq_top_of_full_finrank
    (rawGreedyModuleBasisColumns T) hdim
  exact rawGreedyCoordinateSerialization_check _ hspan

end CorruptedFieldRecovery
