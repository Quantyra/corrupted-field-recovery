import CorruptedFieldRecovery.S010BalanceGaussianQuotientOrbitIndependence
import Mathlib.Algebra.Polynomial.AlgebraMap

namespace CorruptedFieldRecovery

/-! Polynomial-stability and Bezout core for the quotient-orbit lemma.
This source is an uncompiled proof draft.  It does not yet package a linear
relation as a degree-`< s` polynomial, or derive coprimality from irreducibility
and the degree bound. -/

/-- A subspace invariant under T is invariant under every polynomial in T.
This is proved directly by polynomial induction; no field action on the
quotient is assumed. -/
theorem rawTInvariant_submodule_aeval_mem {n : Nat}
    (T : Module.End (ZMod 2) (BinaryVector n))
    (M : Submodule (ZMod 2) (BinaryVector n))
    (hT : ∀ x, x ∈ M → T x ∈ M)
    (x : BinaryVector n) (hx : x ∈ M) (q : Polynomial (ZMod 2)) :
    (Polynomial.aeval T q) x ∈ M := by
  have hpow : ∀ k y, y ∈ M → (T ^ k) y ∈ M := by
    intro k
    induction k with
    | zero =>
        intro y hy
        simpa using hy
    | succ k ih =>
        intro y hy
        rw [pow_succ, Module.End.mul_apply]
        exact ih (T y) (hT y hy)
  induction q using Polynomial.induction_on' with
  | add p q hp hq =>
      rw [map_add, Module.End.add_apply]
      exact M.add_mem hp hq
  | monomial k a =>
      rw [Polynomial.aeval_monomial, Module.End.mul_apply,
        Algebra.algebraMap_end_apply]
      exact M.smul_mem a (hpow k x hx)

/-- Bezout identity contradiction: if q(T)v already lies in an invariant
subspace M and a*q+b*p=1 with p(T)=0, then v lies in M. -/
theorem rawPolynomialBezout_forces_mem_submodule {n : Nat}
    (T : Module.End (ZMod 2) (BinaryVector n))
    (M : Submodule (ZMod 2) (BinaryVector n))
    (hpoly : ∀ r y, y ∈ M → (Polynomial.aeval T r) y ∈ M)
    (v : BinaryVector n)
    (a b q p : Polynomial (ZMod 2))
    (hbezout : a * q + b * p = 1)
    (hroot : Polynomial.aeval T p = 0)
    (hqv : (Polynomial.aeval T q) v ∈ M) :
    v ∈ M := by
  have hidentity :
      Polynomial.aeval T a * Polynomial.aeval T q +
        Polynomial.aeval T b * Polynomial.aeval T p = 1 := by
    calc
      _ = Polynomial.aeval T (a * q + b * p) := by simp
      _ = Polynomial.aeval T 1 := congrArg (Polynomial.aeval T) hbezout
      _ = 1 := by simp
  have hfirst :
      (Polynomial.aeval T a) ((Polynomial.aeval T q) v) ∈ M :=
    hpoly a _ hqv
  have hrootv : (Polynomial.aeval T p) v = 0 := by
    rw [hroot]
    simp
  have happly := congrArg (fun f : Module.End (ZMod 2) (BinaryVector n) => f v)
    hidentity
  have hresult :
      (Polynomial.aeval T a) ((Polynomial.aeval T q) v) = v := by
    simpa [Module.End.add_apply, Module.End.mul_apply, hrootv] using happly
  exact hresult ▸ hfirst

/-- The central contradiction in the orbit proof, with the coprime/Bezout
fact exposed as an explicit witness.  In the final theorem this witness is
obtained from `Irreducible p`, `p.natDegree = s`, and `q.natDegree < s`. -/
theorem rawLowDegreeRelation_contradiction_of_bezout {n : Nat}
    (T : Module.End (ZMod 2) (BinaryVector n))
    (M : Submodule (ZMod 2) (BinaryVector n))
    (hT : ∀ x, x ∈ M → T x ∈ M)
    (v : BinaryVector n) (hv : v ∉ M)
    (a b q p : Polynomial (ZMod 2))
    (hbezout : a * q + b * p = 1)
    (hroot : Polynomial.aeval T p = 0)
    (hqv : (Polynomial.aeval T q) v ∈ M) : False := by
  have hpoly := fun r y hy => rawTInvariant_submodule_aeval_mem T M hT y hy r
  exact hv (rawPolynomialBezout_forces_mem_submodule T M hpoly v a b q p
    hbezout hroot hqv)

end CorruptedFieldRecovery
