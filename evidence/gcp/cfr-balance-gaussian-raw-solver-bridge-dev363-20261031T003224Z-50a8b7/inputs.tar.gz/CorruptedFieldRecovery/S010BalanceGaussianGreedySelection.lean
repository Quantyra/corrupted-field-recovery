import CorruptedFieldRecovery.RawGreedyModuleBasis
import CorruptedFieldRecovery.S010BalanceGaussianOrbitGrowth

namespace CorruptedFieldRecovery

/-! # Completeness of the physical-unit selector

Disjoint uncompiled draft.  It proves that a proper span of the current
array's columns has a standard unit outside it, and that the dynamic augmented
Gaussian Boolean selector returns such a unit.  A selected unit can then be
fed into the orbit-growth theorem.  This does not yet prove the Array-append
span refinement needed to induct over `rawGreedyOrbitRun`; that remaining
obligation is stated explicitly at the end. -/

/-- Semantic column span of the current array. -/
def rawGreedyOrbitArraySpan {n : Nat} (columns : RawGreedyOrbitColumns n) :
    Submodule (ZMod 2) (BinaryVector n) :=
  Submodule.span (ZMod 2) (Set.range (rawGreedyOrbitColumnFamily columns))

/-- The matrix coefficient predicate used by the augmented Gaussian scan is
exactly membership in the semantic span of its columns. -/
theorem balanceGaussianColumnSpanContains_iff_mem_span
    {m n : Nat} (columns : Fin n → Fin m → ZMod 2) (target : Fin m → ZMod 2) :
    balanceGaussianColumnSpanContains columns target ↔
      target ∈ Submodule.span (ZMod 2) (Set.range columns) := by
  rw [balanceGaussianColumnSpanContains, ← Matrix.range_mulVecLin]
  simp only [LinearMap.mem_range, Matrix.mulVecLin_apply]
  constructor
  · rintro ⟨coeff, hcoeff⟩
    exact ⟨coeff, hcoeff⟩
  · rintro ⟨coeff, hcoeff⟩
    exact ⟨coeff, hcoeff⟩

/-- The dynamic Boolean predicate reports `true` exactly for vectors in the
current array's column span. -/
theorem rawGreedyOrbitMemSpan_true_iff
    {n : Nat} (columns : RawGreedyOrbitColumns n) (v : BinaryVector n) :
    rawGreedyOrbitMemSpan? columns v = true ↔
      v ∈ rawGreedyOrbitArraySpan columns := by
  unfold rawGreedyOrbitMemSpan? rawGreedyOrbitArraySpan
  rw [balanceGaussianSpanWitness?_nonempty_iff,
    balanceGaussianColumnSpanContains_iff_mem_span]
  simp only [Option.isSome_iff_exists]

/-- A list selector returns some element whenever its Boolean predicate holds
on at least one list entry. -/
private theorem list_find?_some_of_exists {α : Type*} (test : α → Bool)
    (xs : List α) (hex : ∃ a, a ∈ xs ∧ test a = true) :
    ∃ a, xs.find? test = some a ∧ test a = true := by
  induction xs with
  | nil => simp at hex
  | cons x xs ih =>
      by_cases hx : test x = true
      · refine ⟨x, ?_, hx⟩
        simp [List.find?, hx]
      · rcases hex with ⟨a, ha, htest⟩
        rcases List.mem_cons.mp ha with hax | htail
        · subst a
          exact False.elim (hx htest)
        · obtain ⟨b, hb, hbt⟩ := ih ⟨a, htail, htest⟩
          refine ⟨b, ?_, hbt⟩
          simp [List.find?, hx, hb]

/-- Every proper submodule of the physical binary vector space misses one of
the standard coordinate vectors.  Otherwise it contains the range of the
coordinate basis and is therefore the top submodule. -/
theorem rawGreedyOrbit_exists_unit_outside
    {n : Nat} (M : Submodule (ZMod 2) (BinaryVector n))
    (hproper : M ≠ ⊤) :
    ∃ i : Fin n, rawGreedyOrbitUnitVector i ∉ M := by
  classical
  have hbasis :
      (fun i : Fin n => rawGreedyOrbitUnitVector i) =
        (Pi.basisFun (ZMod 2) (Fin n) : Basis (Fin n) (ZMod 2) (BinaryVector n)) := by
    funext i j
    simp [rawGreedyOrbitUnitVector, Pi.basisFun]
  have hspan :
      Submodule.span (ZMod 2)
        (Set.range fun i : Fin n => rawGreedyOrbitUnitVector i) = ⊤ := by
    rw [hbasis]
    exact (Pi.basisFun (ZMod 2) (Fin n)).span_eq
  by_contra h
  push_neg at h
  have hle :
      Submodule.span (ZMod 2)
        (Set.range fun i : Fin n => rawGreedyOrbitUnitVector i) ≤ M :=
    Submodule.span_le.mpr (Set.range_subset_iff.mpr h)
  rw [hspan] at hle
  exact hproper (eq_top_iff.mpr hle)

/-- If any physical unit is outside the current semantic span, the actual
left-to-right `find?` selector returns some unit outside that span.  The
Boolean-to-span equivalence is supplied by the augmented-kernel witness
iff, not by an assumed search result. -/
theorem rawGreedyOrbitFirstOutside?_some_of_exists
    {n : Nat} (columns : RawGreedyOrbitColumns n)
    (hex : ∃ i : Fin n, rawGreedyOrbitUnitVector i ∉
      rawGreedyOrbitArraySpan columns) :
    ∃ i : Fin n, rawGreedyOrbitFirstOutside? columns = some i ∧
      rawGreedyOrbitUnitVector i ∉ rawGreedyOrbitArraySpan columns := by
  classical
  let test : Fin n → Bool := fun i =>
    !(rawGreedyOrbitMemSpan? columns (rawGreedyOrbitUnitVector i))
  have hexTest : ∃ i, i ∈ List.ofFn (fun j : Fin n => j) ∧ test i = true := by
    rcases hex with ⟨i, hi⟩
    refine ⟨i, List.mem_ofFn.mpr ⟨i, rfl⟩, ?_⟩
    have hnot : rawGreedyOrbitMemSpan? columns (rawGreedyOrbitUnitVector i) ≠ true := by
      intro ht
      exact hi ((rawGreedyOrbitMemSpan_true_iff columns _).mp ht)
    cases hm : rawGreedyOrbitMemSpan? columns (rawGreedyOrbitUnitVector i) <;>
      simp [test, hm] at *
  obtain ⟨i, hfind, htest⟩ :=
    list_find?_some_of_exists test (List.ofFn fun j : Fin n => j) hexTest
  refine ⟨i, ?_, ?_⟩
  · simpa [rawGreedyOrbitFirstOutside?, test] using hfind
  · have hfalse : rawGreedyOrbitMemSpan? columns (rawGreedyOrbitUnitVector i) = false := by
      cases hmem : rawGreedyOrbitMemSpan? columns (rawGreedyOrbitUnitVector i) <;>
        simp [test, hmem] at htest ⊢
    intro hi
    have := (rawGreedyOrbitMemSpan_true_iff columns _).mpr hi
    simp [hfalse] at this

/-- A proper current span therefore never causes the actual selector to stop
early: there is a first outside unit.  This theorem uses only the fact that
the current submodule is proper; it assumes neither a desired greedy outcome
nor a predetermined generator. -/
theorem rawGreedyOrbitFirstOutside?_exists_of_proper
    {n : Nat} (columns : RawGreedyOrbitColumns n)
    (hproper : rawGreedyOrbitArraySpan columns ≠ ⊤) :
    ∃ i : Fin n, rawGreedyOrbitFirstOutside? columns = some i ∧
      rawGreedyOrbitUnitVector i ∉ rawGreedyOrbitArraySpan columns := by
  exact rawGreedyOrbitFirstOutside?_some_of_exists columns
    (rawGreedyOrbit_exists_unit_outside _ hproper)

/-- Theorem-sized bridge from one actual scan step to the module-level
dimension/invariance increment.  `some i` is obtained by the previous proper
span theorem; the annihilator hypotheses then provide exact growth.  The
separate array theorem equating the span of `columns ++ orbit` with
`M ⊔ rawTOrbitSpan T unit` is still required before this can be iterated over
the concrete three-pass state. -/
theorem rawGreedyOrbitSelectedUnit_growth
    {n s : Nat} (T : Module.End (ZMod 2) (BinaryVector n))
    (columns : RawGreedyOrbitColumns n) (M : Submodule (ZMod 2) (BinaryVector n))
    (hspan : rawGreedyOrbitArraySpan columns = M)
    (hproper : M ≠ ⊤)
    (p : Polynomial (ZMod 2)) (hp : Irreducible p) (hmonic : p.Monic)
    (hs : 1 ≤ s) (hdeg : p.natDegree = s)
    (hroot : Polynomial.aeval T p = 0)
    (hM : ∀ x, x ∈ M → T x ∈ M) :
    ∃ i : Fin n,
      rawGreedyOrbitFirstOutside? columns = some i ∧
      rawGreedyOrbitUnitVector i ∉ M ∧
      Module.finrank (ZMod 2)
          (M ⊔ rawTOrbitSpan T (rawGreedyOrbitUnitVector i)) =
        Module.finrank (ZMod 2) M + s ∧
      (∀ x, x ∈ M ⊔ rawTOrbitSpan T (rawGreedyOrbitUnitVector i) →
        T x ∈ M ⊔ rawTOrbitSpan T (rawGreedyOrbitUnitVector i)) := by
  obtain ⟨i, hfind, hout⟩ :=
    rawGreedyOrbitFirstOutside?_exists_of_proper columns (by simpa [hspan] using hproper)
  have houtM : rawGreedyOrbitUnitVector i ∉ M := by simpa [hspan] using hout
  have hconsequence := rawGreedySelectedOrbit_step_consequences
    T M (rawGreedyOrbitUnitVector i) p hp hmonic hs hdeg hroot hM houtM
  exact ⟨i, hfind, houtM, hconsequence.1, hconsequence.2⟩

/-- Exact structural obligation for iterating the step theorem over the real
array state.  It is stated as a target, not asserted as a proved result: the
index/slice proof must identify the span of `Array.append` with the supremum
of the two semantic spans. -/
def RawGreedyArrayAppendSpanRefinementTarget {n s : Nat}
    (columns : RawGreedyOrbitColumns n)
    (orbit : RawGreedyOrbitColumns n) : Prop :=
  rawGreedyOrbitArraySpan (columns ++ orbit) =
    rawGreedyOrbitArraySpan columns ⊔
      Submodule.span (ZMod 2)
        (Set.range (rawGreedyOrbitColumnFamily orbit))

end CorruptedFieldRecovery
