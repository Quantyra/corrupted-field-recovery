import CorruptedFieldRecovery.S010BalanceGaussianGreedySelection

namespace CorruptedFieldRecovery

/-! # Array append refinement and three-pass growth

Disjoint uncompiled draft.  This file closes the representation step needed
to apply the one-orbit theorem to the actual array state: the span of an
appended orbit array is the supremum of the old column span and orbit span.
It then gives a strong-induction invariant for the concrete recursive run.
The proof assumes only the fixed irreducible monic annihilator and `s > 0`;
each selector success is derived from properness of the current span.  This
still depends on uncompiled dynamic-span and quotient-orbit dependencies. -/

/-- The semantic span of an array append is the sum of the spans of its two
parts.  `Fin.addCases` gives the exact finite reindexing; the two cases reduce
to the left/right `Array.append` lookup equations. -/
theorem rawGreedyArrayAppendSpanRefinement
    {n : Nat} (left right : RawGreedyOrbitColumns n) :
    rawGreedyOrbitArraySpan (left ++ right) =
      rawGreedyOrbitArraySpan left ⊔ rawGreedyOrbitArraySpan right := by
  classical
  let f := rawGreedyOrbitColumnFamily left
  let g := rawGreedyOrbitColumnFamily right
  simp only [Array.size_append]
  have hfamily : rawGreedyOrbitColumnFamily (left ++ right) =
      Fin.addCases f g := by
    funext i
    induction i using Fin.addCases with
    | left j => simp [f, rawGreedyOrbitColumnFamily]
    | right j => simp [g, rawGreedyOrbitColumnFamily]
  have hrange : Set.range (Fin.addCases f g) =
      Set.range f ∪ Set.range g := by
    ext x
    simp only [Set.mem_range, Set.mem_union]
    constructor
    · rintro ⟨i, rfl⟩
      induction i using Fin.addCases with
      | left j => exact Or.inl ⟨j, rfl⟩
      | right j => exact Or.inr ⟨j, rfl⟩
    · rintro (⟨j, rfl⟩ | ⟨j, rfl⟩)
      · exact ⟨Fin.castAdd right.size j, by simp [f]
      · exact ⟨Fin.natAdd left.size j, by simp [g]
  rw [rawGreedyOrbitArraySpan, hfamily, hrange,
    Submodule.span_union, rawGreedyOrbitArraySpan, rawGreedyOrbitArraySpan]

/-- The span represented by `Array.ofFn` of the first `s` iterates is the
semantic orbit span used by the quotient argument. -/
theorem rawGreedyTOrbit_arraySpan_eq
    {n s : Nat} (T : Module.End (ZMod 2) (BinaryVector n))
    (v : BinaryVector n) :
    rawGreedyOrbitArraySpan (rawGreedyTOrbit T v) = rawTOrbitSpan T v := by
  simp [rawGreedyOrbitArraySpan, rawGreedyOrbitColumnFamily,
    rawGreedyTOrbit, rawTOrbitFamily]

/-- A state/run summary, parameterized by the number of remaining passes and
the current semantic dimension. -/
def RawGreedyOrbitRunSummary {s k : Nat}
    (T : Module.End (ZMod 2) (BinaryVector (3 * s)))
    (state : RawGreedyOrbitState (3 * s)) (M : Submodule (ZMod 2) (BinaryVector (3 * s)))
    (d : Nat) : Prop :=
  let out := rawGreedyOrbitRun T k state
  rawGreedyOrbitArraySpan out.columns = M ∧
    Module.finrank (ZMod 2) M = d + k * s ∧
    (∀ x, x ∈ M → T x ∈ M) ∧
    out.selectedUnits.size = state.selectedUnits.size + k ∧
    out.columns.size = state.columns.size + k * s

/-- Every requested pass succeeds while the current dimension plus the
remaining orbit blocks fits strictly below the ambient dimension.  The proof
does not posit a selected index: properness yields an outside unit, and the
actual `find?` scan is proved complete for that witness. -/
theorem rawGreedyOrbitRun_summary
    {s k d : Nat} (T : Module.End (ZMod 2) (BinaryVector (3 * s)))
    (state : RawGreedyOrbitState (3 * s))
    (M : Submodule (ZMod 2) (BinaryVector (3 * s)))
    (hs : 1 ≤ s)
    (p : Polynomial (ZMod 2)) (hp : Irreducible p) (hmonic : p.Monic)
    (hdeg : p.natDegree = s) (hroot : Polynomial.aeval T p = 0)
    (hspan : rawGreedyOrbitArraySpan state.columns = M)
    (hdim : Module.finrank (ZMod 2) M = d)
    (hT : ∀ x, x ∈ M → T x ∈ M)
    (hbudget : d + k * s ≤ 3 * s) :
    RawGreedyOrbitRunSummary T state M d := by
  induction k generalizing state M d hspan hdim hT hbudget with
  | zero =>
      simp only [RawGreedyOrbitRunSummary, rawGreedyOrbitRun,
        Nat.zero_mul, Nat.add_zero]
      exact ⟨hspan, hdim, hT, by simp, by simp⟩
  | succ k ih =>
      have hremaining : d + (k + 1) * s ≤ 3 * s := by simpa using hbudget
      have hproper : M ≠ ⊤ := by
        have hlt : d < 3 * s := by omega
        intro htop
        have htopdim : Module.finrank (ZMod 2)
            (⊤ : Submodule (ZMod 2) (BinaryVector (3 * s))) = 3 * s := by
          simp [BinaryVector, finrank_pi]
        rw [htop, htopdim] at hdim
        omega
      obtain ⟨i, hfind, houtM, hgrowth, hnextT⟩ :=
        rawGreedyOrbitSelectedUnit_growth T state.columns M hspan hproper
          p hp hmonic hs hdeg hroot hT
      let next := rawGreedyOrbitStep T state
      let Mnext := M ⊔ rawTOrbitSpan T (rawGreedyOrbitUnitVector i)
      have hnextSpan : rawGreedyOrbitArraySpan next.columns = Mnext := by
        simp [next, Mnext, rawGreedyOrbitStep, hfind,
          rawGreedyArrayAppendSpanRefinement, rawGreedyTOrbit_arraySpan_eq, hspan]
      have hnextDim : Module.finrank (ZMod 2) Mnext = d + s := by
        change Module.finrank (ZMod 2)
          (M ⊔ rawTOrbitSpan T (rawGreedyOrbitUnitVector i)) = d + s
        rw [hgrowth, hdim]
      have hbudgetNext : (d + s) + k * s ≤ 3 * s := by
        nlinarith [hremaining]
      have htail := ih next Mnext (d + s) hnextSpan hnextDim hnextT hbudgetNext
      have hselectedSize : next.selectedUnits.size = state.selectedUnits.size + 1 := by
        simp [next, rawGreedyOrbitStep, hfind]
      have hcolumnSize : next.columns.size = state.columns.size + s := by
        simp [next, rawGreedyOrbitStep, hfind, rawGreedyTOrbit]
      refine ?_
      simpa [RawGreedyOrbitRunSummary, rawGreedyOrbitRun, next, Mnext,
        hselectedSize, hcolumnSize, Nat.add_assoc, Nat.add_left_comm,
        Nat.add_comm, Nat.mul_add, add_mul] using htail

/-- With `n = 3s`, the concrete three-pass loop reaches a full-dimensional
column span, emits exactly three physical unit generators and exactly `3s`
orbit columns, provided the supplied endomorphism has the stated irreducible
monic degree-`s` annihilator. -/
theorem rawGreedyModuleBasisColumns_threePass_dimension
    {s : Nat} (hs : 1 ≤ s)
    (T : Module.End (ZMod 2) (BinaryVector (3 * s)))
    (p : Polynomial (ZMod 2)) (hp : Irreducible p) (hmonic : p.Monic)
    (hdeg : p.natDegree = s) (hroot : Polynomial.aeval T p = 0) :
    (rawGreedyModuleBasisColumns T).selectedUnits.size = 3 ∧
    (rawGreedyModuleBasisColumns T).columns.size = 3 * s ∧
    Module.finrank (ZMod 2)
      (rawGreedyOrbitArraySpan (rawGreedyModuleBasisColumns T).columns) = 3 * s ∧
    (∀ x, x ∈ rawGreedyOrbitArraySpan (rawGreedyModuleBasisColumns T).columns →
      T x ∈ rawGreedyOrbitArraySpan (rawGreedyModuleBasisColumns T).columns) := by
  have hinitial : rawGreedyOrbitArraySpan (rawGreedyOrbitInitial (3 * s)).columns = ⊥ := by
    simp [rawGreedyOrbitArraySpan, rawGreedyOrbitInitial,
      rawGreedyOrbitColumnFamily]
  have hbottom : Module.finrank (ZMod 2)
      (⊥ : Submodule (ZMod 2) (BinaryVector (3 * s))) = 0 := finrank_bot
  have hzeroT : ∀ x, x ∈ (⊥ : Submodule (ZMod 2) (BinaryVector (3 * s))) → T x ∈ ⊥ := by
    simp
  have hrun := rawGreedyOrbitRun_summary (k := 3) (d := 0) T
    (rawGreedyOrbitInitial (3 * s))
    (⊥ : Submodule (ZMod 2) (BinaryVector (3 * s))) hs p hp hmonic hdeg hroot
    hinitial hbottom hzeroT (by omega)
  rcases hrun with ⟨hspanFinal, hdimFinal, hTFinal, hselectedFinal, hcolumnsFinal⟩
  refine ⟨?_, ?_, ?_, ?_⟩
  · simpa [rawGreedyModuleBasisColumns] using hselectedFinal
  · simpa [rawGreedyModuleBasisColumns] using hcolumnsFinal
  · simpa [rawGreedyModuleBasisColumns] using hdimFinal
  · simpa [rawGreedyModuleBasisColumns, hspanFinal] using hTFinal

end CorruptedFieldRecovery
