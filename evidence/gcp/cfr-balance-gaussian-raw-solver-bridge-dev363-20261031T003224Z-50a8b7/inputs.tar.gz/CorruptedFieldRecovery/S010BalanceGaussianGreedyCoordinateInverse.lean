import CorruptedFieldRecovery.S010BalanceGaussianGreedyRun
import CorruptedFieldRecovery.RawCoefficientFitAffineExtraction
import Mathlib.LinearAlgebra.Matrix.ToLin

open scoped Matrix

namespace CorruptedFieldRecovery

/-! # Computed coordinates from the greedy orbit columns

Disjoint uncompiled draft.  It constructs the inverse matrix by solving, in
increasing physical-coordinate order, the systems `A x = e_j` with the actual
deterministic augmented Gaussian span selector.  No inverse matrix or
noncomputable basis representation is an input.  Under the full-span result
for the greedy columns, each selector call has a witness; soundness gives
`A * B = 1`, and injectivity from full rank gives `B * A = 1`.

All imported greedy, selector, and quotient-orbit sources are uncompiled
preservation drafts.  The source-level proof still needs GCP checking; this is
not a certification claim. -/

/-- The augmented Gaussian selector's chosen kernel vector, restricted to the
original coefficient coordinates, is the actual solution returned for one
right-hand side. -/
def actualGaussianSpanSolution? {n : Nat}
    (A : Matrix (Fin n) (Fin n) (ZMod 2)) (rhs : Fin n → ZMod 2) :
    Option (Fin n → ZMod 2) :=
  let run := balanceGaussianSpanScan A.col rhs
  match balanceGaussianSpanWitness? A.col rhs with
  | none => none
  | some free =>
      some (fun j => balanceGaussianFreeCandidateFamily run.1 run.2 free j.castSucc)

/-- The first `n` coordinates of a selected augmented witness really solve
the corresponding finite system. -/
theorem actualGaussianSpanSolutionOfFree_correct {n : Nat}
    (A : Matrix (Fin n) (Fin n) (ZMod 2)) (rhs : Fin n → ZMod 2)
    (free : balanceGaussianFreeIndex (balanceGaussianSpanScan A.col rhs).2)
    (hfree : balanceGaussianSpanWitness? A.col rhs = some free) :
    A *ᵥ (fun j => balanceGaussianFreeCandidateFamily
      (balanceGaussianSpanScan A.col rhs).1
      (balanceGaussianSpanScan A.col rhs).2 free j.castSucc) = rhs := by
  let run := balanceGaussianSpanScan A.col rhs
  let z := balanceGaussianFreeCandidateFamily run.1 run.2 free
  have hselected := balanceGaussianSpanWitness?_sound A.col rhs hfree
  have hker : balanceGaussianSpanAugmentedMatrix A.col rhs *ᵥ z = 0 := hselected.1
  have hlast : z (Fin.last n) = 1 := hselected.2
  let x : Fin n → ZMod 2 := fun j => z j.castSucc
  have hz : z = Fin.snoc x 1 := by
    funext j
    refine Fin.lastCases ?_ ?_ j
    · simpa [x] using hlast
    · intro i
      rfl
  have hraw : rawLastColumnAugmentedMatrix (balanceGaussianSpanMatrix A.col) rhs *ᵥ
      Fin.snoc x 1 = 0 := by
    rw [← balanceGaussianSpanAugmentedMatrix_eq_rawLastColumn]
    simpa [run, z] using hker
  rw [rawLastColumnAugmentedMatrix_mulVec_snoc] at hraw
  have hzero : balanceGaussianSpanMatrix A.col *ᵥ x + rhs = 0 := hraw
  have hsolve : balanceGaussianSpanMatrix A.col *ᵥ x = rhs := by
    apply funext
    intro i
    have hi := congrFun hzero i
    calc
      (balanceGaussianSpanMatrix A.col *ᵥ x) i =
          (balanceGaussianSpanMatrix A.col *ᵥ x) i + 0 := by simp
      _ = (balanceGaussianSpanMatrix A.col *ᵥ x) i + (rhs i + rhs i) := by
        rw [ZModModule.add_self]
        simp
      _ = ((balanceGaussianSpanMatrix A.col *ᵥ x) i + rhs i) + rhs i := by
        rw [← add_assoc]
      _ = 0 + rhs i := by rw [hi]
      _ = rhs i := by simp
  simpa [balanceGaussianSpanMatrix, x, z, run] using hsolve

/-- Soundness of the returned Option result, including the selected-candidate
equation needed by the inverse constructor. -/
theorem actualGaussianSpanSolution?_sound {n : Nat}
    (A : Matrix (Fin n) (Fin n) (ZMod 2)) (rhs : Fin n → ZMod 2)
    {x : Fin n → ZMod 2} (hout : actualGaussianSpanSolution? A rhs = some x) :
    A *ᵥ x = rhs := by
  classical
  unfold actualGaussianSpanSolution? at hout
  split at hout
  · simp_all
  · rename_i free hfree
    have hx : x = fun j => balanceGaussianFreeCandidateFamily
        (balanceGaussianSpanScan A.col rhs).1
        (balanceGaussianSpanScan A.col rhs).2 free j.castSucc := by
      simpa [hfree] using hout
    subst x
    -- The selector equation is precisely the branch equation exposed above.
    exact actualGaussianSpanSolutionOfFree_correct A rhs free hfree

/-- A full column span makes the deterministic selector return a solution for
every right-hand side. -/
theorem actualGaussianSpanSolution?_complete_of_span_eq_top {n : Nat}
    (A : Matrix (Fin n) (Fin n) (ZMod 2))
    (hspan : Submodule.span (ZMod 2) (Set.range A.col) = ⊤)
    (rhs : Fin n → ZMod 2) :
    ∃ x, actualGaussianSpanSolution? A rhs = some x := by
  have hrhs : rhs ∈ Submodule.span (ZMod 2) (Set.range A.col) := by
    rw [hspan]
    exact Submodule.mem_top
  have hcontains : balanceGaussianColumnSpanContains A.col rhs := by
    exact (balanceGaussianColumnSpanContains_iff_mem_span A.col rhs).2 hrhs
  obtain ⟨free, hfree⟩ :=
    (balanceGaussianSpanWitness?_nonempty_iff A.col rhs).2 hcontains
  refine ⟨fun j => balanceGaussianFreeCandidateFamily
    (balanceGaussianSpanScan A.col rhs).1
    (balanceGaussianSpanScan A.col rhs).2 free j.castSucc, ?_⟩
  simp [actualGaussianSpanSolution?, hfree]

/-- Deterministic Gaussian inverse construction.  Column `j` is the solution
selected for the physical unit vector `e_j`; the zero default only makes the
definition total on singular matrices. Under the full-span hypothesis the
default branch is never taken. -/
def actualGaussianInverseMatrix {n : Nat}
    (A : Matrix (Fin n) (Fin n) (ZMod 2)) : Matrix (Fin n) (Fin n) (ZMod 2) :=
  fun i j => ((actualGaussianSpanSolution? A (Pi.single j 1)).getD 0) i

/-- The computed right inverse is a left inverse of the original matrix. -/
theorem actualGaussianInverse_left_identity {n : Nat}
    (A : Matrix (Fin n) (Fin n) (ZMod 2))
    (hspan : Submodule.span (ZMod 2) (Set.range A.col) = ⊤) :
    A * actualGaussianInverseMatrix A = 1 := by
  ext i j
  obtain ⟨x, hx⟩ := actualGaussianSpanSolution?_complete_of_span_eq_top A hspan
    (Pi.single j 1)
  have hsolve := actualGaussianSpanSolution?_sound A (Pi.single j 1) hx
  calc
    (A * actualGaussianInverseMatrix A) i j = (A *ᵥ x) i := by
      simp [actualGaussianInverseMatrix, hx, Matrix.mul_apply, Matrix.mulVec,
        dotProduct]
    _ = (Pi.single j 1) i := congrFun hsolve i
    _ = (1 : Matrix (Fin n) (Fin n) (ZMod 2)) i j := by simp [Pi.single]

/-- Full column span for a square matrix gives injectivity of its vector action.
This follows by identifying its `n` columns as a basis of the `n`-dimensional
ambient space. -/
theorem actualGaussianMatrix_mulVec_injective_of_span_eq_top {n : Nat}
    (A : Matrix (Fin n) (Fin n) (ZMod 2))
    (hspan : Submodule.span (ZMod 2) (Set.range A.col) = ⊤) :
    Function.Injective (A *ᵥ ·) := by
  have hLI : LinearIndependent (ZMod 2) A.col :=
    linearIndependent_of_top_le_span_of_card_eq_finrank hspan.ge (by simp [BinaryVector])
  exact (Matrix.mulVec_injective_iff).2 hLI

/-- The computed right inverse is also a right inverse whenever the greedy
columns have full rank; no inverse is postulated or supplied. -/
theorem actualGaussianInverse_right_identity {n : Nat}
    (A : Matrix (Fin n) (Fin n) (ZMod 2))
    (hspan : Submodule.span (ZMod 2) (Set.range A.col) = ⊤) :
    actualGaussianInverseMatrix A * A = 1 := by
  have hinj := actualGaussianMatrix_mulVec_injective_of_span_eq_top A hspan
  have hBA : ∀ x, actualGaussianInverseMatrix A *ᵥ (A *ᵥ x) = x := by
    intro x
    apply hinj
    calc
      A *ᵥ (actualGaussianInverseMatrix A *ᵥ (A *ᵥ x)) =
          (A * actualGaussianInverseMatrix A) *ᵥ (A *ᵥ x) := by
        rw [← Matrix.mulVec_mulVec]
      _ = (1 : Matrix (Fin n) (Fin n) (ZMod 2)) *ᵥ (A *ᵥ x) := by
        rw [actualGaussianInverse_left_identity A hspan]
      _ = A *ᵥ x := by simp
  ext i j
  have hij := congrFun (hBA (Pi.single j 1)) i
  simpa [Matrix.mulVec, Matrix.mul_apply, dotProduct, Pi.single] using hij

/-- Both multiplication checks pass for the deterministically constructed
matrix inverse, on the same exact full-rank premise. -/
theorem actualGaussianInverse_two_sided {n : Nat}
    (A : Matrix (Fin n) (Fin n) (ZMod 2))
    (hspan : Submodule.span (ZMod 2) (Set.range A.col) = ⊤) :
    A * actualGaussianInverseMatrix A = 1 ∧
      actualGaussianInverseMatrix A * A = 1 :=
  ⟨actualGaussianInverse_left_identity A hspan,
    actualGaussianInverse_right_identity A hspan⟩

/-- Matrix read from the actual ordered greedy orbit array. -/
def rawGreedyOrbitBasisMatrix {s : Nat}
    (state : RawGreedyOrbitState (3 * s)) :
    Matrix (Fin (3 * s)) (Fin (3 * s)) (ZMod 2) :=
  fun row column => state.columns[column.val]![row]

/-- If the actual greedy orbit columns span the full physical space, the
forward and inverse coordinate matrices are computed and satisfy the explicit
two-sided check. The size premise ensures array lookup reads exactly the
three-pass output rather than its total default. -/
theorem rawGreedyOrbitBasisMatrix_computed_coordinates
    {s : Nat} (state : RawGreedyOrbitState (3 * s))
    (hspan : Submodule.span (ZMod 2)
      (Set.range (rawGreedyOrbitColumnFamily state.columns)) = ⊤) :
    rawGreedyOrbitBasisMatrix state *
        actualGaussianInverseMatrix (rawGreedyOrbitBasisMatrix state) = 1 ∧
      actualGaussianInverseMatrix (rawGreedyOrbitBasisMatrix state) *
        rawGreedyOrbitBasisMatrix state = 1 := by
  have hcol : Set.range (rawGreedyOrbitBasisMatrix state).col =
      Set.range (rawGreedyOrbitColumnFamily state.columns) := by
    ext x
    simp [rawGreedyOrbitBasisMatrix, rawGreedyOrbitColumnFamily]
  apply actualGaussianInverse_two_sided
  simpa [hcol] using hspan

/-- Full dimension of the greedy orbit-column span makes it the whole
physical vector space. This is the bridge from the three-pass growth result
to the surjectivity premise used by each inverse-column Gaussian solve. -/
theorem rawGreedyOrbitArraySpan_eq_top_of_full_finrank {s : Nat}
    (state : RawGreedyOrbitState (3 * s))
    (hdim : Module.finrank (ZMod 2)
      (rawGreedyOrbitArraySpan state.columns) = 3 * s) :
    rawGreedyOrbitArraySpan state.columns = ⊤ := by
  apply Submodule.eq_top_of_finrank_eq
  simpa [BinaryVector, finrank_pi] using hdim

/-- End-to-end matrix constructor from the actual three-pass greedy output.
The inverse is computed by Gaussian span solves against each physical unit
vector; the successful greedy full-dimension theorem supplies full span, not
an inverse as data. -/
theorem rawGreedyModuleBasis_computed_inverse
    {s : Nat} (hs : 1 ≤ s)
    (T : Module.End (ZMod 2) (BinaryVector (3 * s)))
    (p : Polynomial (ZMod 2)) (hp : Irreducible p) (hmonic : p.Monic)
    (hdeg : p.natDegree = s) (hroot : Polynomial.aeval T p = 0) :
    rawGreedyOrbitBasisMatrix (rawGreedyModuleBasisColumns T) *
        actualGaussianInverseMatrix (rawGreedyOrbitBasisMatrix
          (rawGreedyModuleBasisColumns T)) = 1 ∧
      actualGaussianInverseMatrix (rawGreedyOrbitBasisMatrix
          (rawGreedyModuleBasisColumns T)) *
        rawGreedyOrbitBasisMatrix (rawGreedyModuleBasisColumns T) = 1 := by
  obtain ⟨_, _, hdim, _⟩ := rawGreedyModuleBasisColumns_threePass_dimension
    hs T p hp hmonic hdeg hroot
  have hspan : rawGreedyOrbitArraySpan (rawGreedyModuleBasisColumns T).columns = ⊤ :=
    rawGreedyOrbitArraySpan_eq_top_of_full_finrank _ hdim
  exact rawGreedyOrbitBasisMatrix_computed_coordinates
    (rawGreedyModuleBasisColumns T) hspan

/-- Forward coordinate decoding and its deterministically computed inverse
encoding, both as executable matrix-vector products. -/
def rawGreedyOrbitDecode {s : Nat}
    (T : Module.End (ZMod 2) (BinaryVector (3 * s))) :
    (Fin (3 * s) → ZMod 2) → BinaryVector (3 * s) :=
  rawGreedyOrbitBasisMatrix (rawGreedyModuleBasisColumns T) *ᵥ ·

def rawGreedyOrbitEncode {s : Nat}
    (T : Module.End (ZMod 2) (BinaryVector (3 * s))) :
    BinaryVector (3 * s) → (Fin (3 * s) → ZMod 2) :=
  actualGaussianInverseMatrix (rawGreedyOrbitBasisMatrix
    (rawGreedyModuleBasisColumns T)) *ᵥ ·

/-- The constructed coordinate maps are mutual inverses; these are the exact
two-sided checks used to accept the computed basis matrix. -/
theorem rawGreedyOrbitCoordinateMaps_inverse
    {s : Nat} (hs : 1 ≤ s)
    (T : Module.End (ZMod 2) (BinaryVector (3 * s)))
    (p : Polynomial (ZMod 2)) (hp : Irreducible p) (hmonic : p.Monic)
    (hdeg : p.natDegree = s) (hroot : Polynomial.aeval T p = 0) :
    (∀ x, rawGreedyOrbitEncode T (rawGreedyOrbitDecode T x) = x) ∧
      (∀ v, rawGreedyOrbitDecode T (rawGreedyOrbitEncode T v) = v) := by
  obtain ⟨hinv, hforward⟩ := rawGreedyModuleBasis_computed_inverse
    hs T p hp hmonic hdeg hroot
  constructor
  · intro x
    simp [rawGreedyOrbitEncode, rawGreedyOrbitDecode, ← Matrix.mulVec_mulVec,
      hforward]
  · intro v
    simp [rawGreedyOrbitEncode, rawGreedyOrbitDecode, ← Matrix.mulVec_mulVec,
      hinv]

end CorruptedFieldRecovery
