import CorruptedFieldRecovery.S010BalanceGaussianQuotientOrbitBezout
import Mathlib.Algebra.Polynomial.OfFn

namespace CorruptedFieldRecovery

/-! Attempted full proof of quotient-orbit independence from the raw
irreducible-annihilator hypotheses.  No quotient field action is assumed.
This file is an uncompiled proof draft and depends on the uncompiled
Gaussian/orbit chain. -/

/-- A nonzero polynomial of degree below an irreducible polynomial is
coprime to it; extract the Bezout coefficients needed by the orbit argument.
-/
theorem rawLowerDegree_polynomials_have_bezout
    {p q : Polynomial (ZMod 2)} {s : Nat}
    (hirr : Irreducible p) (hpdeg : p.natDegree = s)
    (hqne : q ≠ 0) (hqdeg : q.natDegree < s) :
    ∃ a b, a * q + b * p = 1 := by
  have hnotdvd : ¬ p ∣ q := by
    intro hdiv
    have hle := Polynomial.natDegree_le_of_dvd hdiv hqne
    rw [hpdeg] at hle
    omega
  have hcoprime : p.Coprime q := hirr.coprime_iff_not_dvd.mpr hnotdvd
  rcases hcoprime.isCoprime with ⟨a, b, hab⟩
  refine ⟨b, a, ?_⟩
  simpa [add_comm, mul_comm] using hab

/-- The first `s` orbit classes are linearly independent, and hence span an
`s`-dimensional subspace of the quotient by an invariant subspace.  The only
operator hypotheses are an irreducible degree-s annihilator, invariance of M,
and a vector outside M. -/
theorem rawQuotientOrbit_independent_of_irreducible_annihilator
    {n s : Nat}
    (T : Module.End (ZMod 2) (BinaryVector n))
    (M : Submodule (ZMod 2) (BinaryVector n))
    (v : BinaryVector n) (p : Polynomial (ZMod 2))
    (hs : 1 ≤ s) (hpdeg : p.natDegree = s)
    (hirr : Irreducible p)
    (hroot : Polynomial.aeval T p = 0)
    (hT : ∀ x, x ∈ M → T x ∈ M)
    (hv : v ∉ M) :
    LinearIndependent (ZMod 2) (rawQuotientOrbitFamily T M v) ∧
      Module.finrank (ZMod 2)
        (Submodule.span (ZMod 2) (Set.range (rawQuotientOrbitFamily T M v))) = s := by
  classical
  have hLI : LinearIndependent (ZMod 2) (rawQuotientOrbitFamily T M v) := by
    rw [Fintype.linearIndependent_iff]
    intro coeff hrel
    by_contra hnotzero
    push_neg at hnotzero
    obtain ⟨j, hj⟩ := hnotzero
    let q : Polynomial (ZMod 2) := Polynomial.ofFn s coeff
    have hqEval : (Polynomial.aeval T q) v =
        ∑ i : Fin s, coeff i • ((T ^ i.val) v) := by
      rw [q, Polynomial.ofFn_eq_sum_monomial]
      simp [Polynomial.aeval_sum, Polynomial.aeval_monomial,
        Module.End.mul_apply, Algebra.algebraMap_end_apply]
    have hsum : ∑ i : Fin s, coeff i • ((T ^ i.val) v) ∈ M := by
      have hmk : M.mkQ (∑ i : Fin s, coeff i • ((T ^ i.val) v)) = 0 := by
        simpa [rawQuotientOrbitFamily, map_sum, map_smul] using hrel
      exact (Submodule.Quotient.mk_eq_zero M).1 hmk
    have hqv : (Polynomial.aeval T q) v ∈ M := by
      rw [hqEval]
      exact hsum
    have hqne : q ≠ 0 := by
      intro hqzero
      have hcoeffzero : coeff = 0 :=
        Polynomial.injective_ofFn s (by simpa [q] using hqzero)
      exact hj (congrFun hcoeffzero j)
    have hqdeg : q.natDegree < s := by
      simpa [q] using Polynomial.ofFn_natDegree_lt hs coeff
    obtain ⟨a, b, hbezout⟩ :=
      rawLowerDegree_polynomials_have_bezout hirr hpdeg hqne hqdeg
    exact False.elim
      (rawLowDegree_relation_contradiction_of_bezout T M hT v hv a b q p
        hbezout hroot hqv)
  refine ⟨hLI, ?_⟩
  rw [finrank_span_eq_card hLI]
  simp

end CorruptedFieldRecovery
