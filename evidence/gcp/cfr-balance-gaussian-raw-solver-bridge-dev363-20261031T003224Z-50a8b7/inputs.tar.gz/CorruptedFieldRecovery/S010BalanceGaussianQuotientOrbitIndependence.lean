import CorruptedFieldRecovery.RawGreedyModuleBasis

namespace CorruptedFieldRecovery

/-! # Exact quotient-orbit lemma target (proof not yet formalized)

The target below deliberately assumes only an irreducible polynomial
annihilating the operator, invariance of the old subspace, and that the new
vector is outside it.  It does not assume a field-module structure on the
quotient.  The intended proof is the polynomial Bezout argument recorded in
`rawQuotientOrbitIndependenceProofPlan`.

This file is an uncompiled specification draft, not a Lean theorem proof.
The imported Gaussian/orbit drafts are also uncompiled. -/

/-- Orbit classes in the quotient by the already constructed invariant
subspace. -/
def rawQuotientOrbitFamily {n s : Nat}
    (T : Module.End (ZMod 2) (BinaryVector n))
    (M : Submodule (ZMod 2) (BinaryVector n))
    (v : BinaryVector n) (i : Fin s) : BinaryVector n ⧸ M :=
  Submodule.Quotient.mk M ((T ^ i.val) v)

/-- Exact hypotheses for the orbit-independence claim. -/
def RawQuotientOrbitIndependenceHypotheses {n s : Nat}
    (T : Module.End (ZMod 2) (BinaryVector n))
    (M : Submodule (ZMod 2) (BinaryVector n))
    (v : BinaryVector n) (p : Polynomial (ZMod 2)) : Prop :=
  Irreducible p ∧ p.natDegree = s ∧
    Polynomial.aeval T p = 0 ∧
    (∀ x, x ∈ M → T x ∈ M) ∧ v ∉ M

/-- The precise conclusion needed by one greedy module-basis step. -/
def RawQuotientOrbitIndependenceConclusion {n s : Nat}
    (T : Module.End (ZMod 2) (BinaryVector n))
    (M : Submodule (ZMod 2) (BinaryVector n))
    (v : BinaryVector n) : Prop :=
  LinearIndependent (ZMod 2) (rawQuotientOrbitFamily T M v) ∧
    Module.finrank (ZMod 2)
      (Submodule.span (ZMod 2) (Set.range (rawQuotientOrbitFamily T M v))) = s

/-- The unsolved theorem target, stated without an assumed quotient field
action.  This is a proposition definition, not an axiom or proved theorem. -/
def RawQuotientOrbitIndependenceTarget {n s : Nat}
    (T : Module.End (ZMod 2) (BinaryVector n))
    (M : Submodule (ZMod 2) (BinaryVector n))
    (v : BinaryVector n) (p : Polynomial (ZMod 2)) : Prop :=
  RawQuotientOrbitIndependenceHypotheses T M v p →
    RawQuotientOrbitIndependenceConclusion T M v

/-- Proof plan: a nonzero linear relation among the quotient classes is a
polynomial q of degree `< s` for which q(T)v lies in M.  Irreducibility of p
and the degree bound imply IsCoprime q p, so choose a,b with a*q+b*p=1.
Polynomial evaluation at T preserves this identity; p(T)=0.  T-invariance of M
implies invariance under a(T), proved by induction on polynomial degree.
Applying the evaluated identity to v therefore puts v in M, contradiction.
This proves linear independence.  The span dimension s then follows from
finite-dimensional linear independence of the s-element family.  Remaining
formal work: construct q from Fin-indexed coefficients, prove its degree bound
when nonzero, prove polynomial invariance of M, and formalize the Bezout/eval
step and finite-span dimension lemma. -/
def rawQuotientOrbitIndependenceProofPlan : String :=
  "relation -> q(T)v in M; gcd(q,p)=1; Bezout gives v in M; contradiction"

end CorruptedFieldRecovery
