import CorruptedFieldRecovery.RawExecutableTraceVerifier

/-! Semantic correspondence between the executable inverse-matrix route and
the accepted coordinate equivalence used by the trace tensor. -/

namespace CorruptedFieldRecovery

/-- The accepted matrix equivalence decodes vectors by the serialized inverse
matrix. This uses both checked matrix products, not an assumed inverse law. -/
theorem accepted_rawCoordinateMatrixEquiv_symm_apply {n : Nat}
    (forward inverse : RawCoordinateMatrix)
    (hcheck : rawCoordinateMatrixCheck (n := n) forward inverse = true)
    (v : BinaryVector n) :
    (accepted_rawCoordinateMatrixEquiv forward inverse hcheck).symm v =
      rawCoordinateMatrixMap inverse v := by
  let e := accepted_rawCoordinateMatrixEquiv forward inverse hcheck
  have hcomp := accepted_rawCoordinateMatrixCheck_compositions forward inverse hcheck
  have hleft : rawCoordinateMatrixMap forward (rawCoordinateMatrixMap inverse v) = v := by
    have h := congrArg (fun f : BinaryVector n →ₗ[ZMod 2] BinaryVector n => f v) hcomp.2
    simpa [LinearMap.comp_apply] using h
  apply e.injective
  rw [e.apply_symm_apply]
  change v = rawCoordinateMatrixMap forward (rawCoordinateMatrixMap inverse v)
  exact hleft.symm

/-- Decoding the checked physical coordinate isomorphism agrees exactly with
first applying the raw inverse matrix and then decoding the canonical power
basis. -/
theorem accepted_rawCandidatePhysicalCoordinates_symm_eq_canonical
    {s : Nat} (candidate : RawFieldCandidate s)
    (hfield : rawFieldCandidateCheck candidate = true)
    (forward inverse : RawCoordinateMatrix)
    (hcoordinates : rawCoordinateMatrixCheck (n := 3 * s) forward inverse = true)
    (v : BinaryVector (3 * s)) :
    (accepted_rawCandidatePhysicalCoordinates candidate hfield forward inverse
      hcoordinates).symm v = rawPhysicalCanonicalTriple candidate hfield inverse v := by
  have hv := accepted_rawFieldCandidateCheck candidate hfield
  have hm := rawFieldCandidateValid_modulus_polynomial candidate hv
  letI : Fact (Irreducible (rawCandidateModulus candidate)) :=
    ⟨accepted_rawCandidateModulus_irreducible candidate hfield⟩
  change (rawFieldTripleToBinaryVector (rawCandidateModulus candidate)
      (accepted_rawCandidateModulus_monic candidate hfield)
      (by
        have hp := rawFieldCandidateValid_modulus_polynomial candidate hv
        simpa [rawCandidateModulus] using hp.2)).symm
      ((accepted_rawCoordinateMatrixEquiv forward inverse hcoordinates).symm v) =
    (rawFieldTripleToBinaryVector (rawCandidateModulus candidate)
      (accepted_rawCandidateModulus_monic candidate hfield)
      (by
        have hp := rawFieldCandidateValid_modulus_polynomial candidate hv
        simpa [rawCandidateModulus] using hp.2)).symm
      (rawCoordinateMatrixMap inverse v)
  rw [accepted_rawCoordinateMatrixEquiv_symm_apply]

end CorruptedFieldRecovery
