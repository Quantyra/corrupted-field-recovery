import CorruptedFieldRecovery
import CorruptedFieldRecovery.RawRabinGcdBitCost

set_option pp.universes true
set_option pp.explicit false
set_option pp.fullNames true
set_option pp.piBinderTypes true
set_option pp.piBinderNames true
set_option pp.piBinderNames.hygienic true
set_option pp.proofs true
set_option pp.deepTerms true
set_option pp.maxSteps 1000000
set_option maxRecDepth 10000

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawPolynomialRemainder_lt_pow_log"
#check @CorruptedFieldRecovery.rawPolynomialRemainder_lt_pow_log
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawPolynomialRemainder_lt_pow_log"
#print axioms CorruptedFieldRecovery.rawPolynomialRemainder_lt_pow_log

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawPolynomialGcdBitCosted"
#check @CorruptedFieldRecovery.rawPolynomialGcdBitCosted
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawPolynomialGcdBitCosted"
#print axioms CorruptedFieldRecovery.rawPolynomialGcdBitCosted

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawPolynomialGcdBitCosted_fst"
#check @CorruptedFieldRecovery.rawPolynomialGcdBitCosted_fst
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawPolynomialGcdBitCosted_fst"
#print axioms CorruptedFieldRecovery.rawPolynomialGcdBitCosted_fst
