import CorruptedFieldRecovery.S010ActualScalarBounds
import CorruptedFieldRecovery.S010BetaArithmetic

namespace CorruptedFieldRecovery

theorem beta_lt_half_actual
    (K : Type*) [Field K] [Finite K] [Algebra BinaryField K]
    [FiniteDimensional BinaryField K] (s R : Nat)
    (hsdim : Module.finrank BinaryField K = s)
    (hsize : 2 * R + 5 ≤ s) :
    ((2 ^ R : ℚ) * (1 + (2 ^ s : ℚ) + (2 ^ s : ℚ) ^ 2) /
      (2 ^ s : ℚ) ^ 3) +
      ((2 ^ R : ℚ) * ((∑ d ∈ properDegrees K, (2 ^ d : Nat)) : ℚ)) /
        (2 ^ s : ℚ) < 1 / 2 := by
  have htau := actual_proper_degree_scaled_bound K s R hsdim hsize
  exact beta_lt_half_from_size
    (T := ∑ d ∈ properDegrees K, (2 ^ d : Nat)) hsize htau

end CorruptedFieldRecovery
