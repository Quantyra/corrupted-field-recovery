import CorruptedFieldRecovery
import CorruptedFieldRecovery.RawExecutableQuotient

set_option pp.universes true
set_option pp.explicit false
set_option pp.fullNames true
set_option pp.piBinderTypes true
set_option pp.piBinderNames true
set_option pp.piBinderNames.hygienic true
set_option pp.proofs true
set_option pp.deepTerms true
set_option pp.maxSteps 1000000
set_option maxRecDepth 10000

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawReduceStep"
#check @CorruptedFieldRecovery.rawReduceStep
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawReduceStep"
#print axioms CorruptedFieldRecovery.rawReduceStep

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawReduceFuel"
#check @CorruptedFieldRecovery.rawReduceFuel
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawReduceFuel"
#print axioms CorruptedFieldRecovery.rawReduceFuel

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawFieldMulFuel"
#check @CorruptedFieldRecovery.rawFieldMulFuel
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawFieldMulFuel"
#print axioms CorruptedFieldRecovery.rawFieldMulFuel

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawMaskPolynomial_mul_pow_two"
#check @CorruptedFieldRecovery.rawMaskPolynomial_mul_pow_two
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawMaskPolynomial_mul_pow_two"
#print axioms CorruptedFieldRecovery.rawMaskPolynomial_mul_pow_two

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawReduceStep_quotient_sound"
#check @CorruptedFieldRecovery.rawReduceStep_quotient_sound
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawReduceStep_quotient_sound"
#print axioms CorruptedFieldRecovery.rawReduceStep_quotient_sound

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawReduceFuel_quotient_sound"
#check @CorruptedFieldRecovery.rawReduceFuel_quotient_sound
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawReduceFuel_quotient_sound"
#print axioms CorruptedFieldRecovery.rawReduceFuel_quotient_sound

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawFieldMulFuel_quotient_sound"
#check @CorruptedFieldRecovery.rawFieldMulFuel_quotient_sound
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawFieldMulFuel_quotient_sound"
#print axioms CorruptedFieldRecovery.rawFieldMulFuel_quotient_sound
