import CorruptedFieldRecovery
import CorruptedFieldRecovery.S010QInputEquivalence

set_option pp.universes true
set_option pp.explicit false
set_option pp.fullNames true
set_option pp.piBinderTypes true
set_option pp.piBinderNames true
set_option pp.piBinderNames.hygienic true
set_option pp.proofs true
set_option pp.deepTerms true
set_option pp.maxSteps 1000000
set_option maxRecDepth 10000

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.modeImage_inputEquiv_from_Q"
#check @CorruptedFieldRecovery.modeImage_inputEquiv_from_Q
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.modeImage_inputEquiv_from_Q"
#print axioms CorruptedFieldRecovery.modeImage_inputEquiv_from_Q
