import Mathlib.Tactic

namespace CorruptedFieldRecovery

/-- The proper-degree geometric estimate, after the selected field-size
condition, is strong enough for the nongenerator part of beta/gamma. -/
theorem scaled_tau_lt_field_size {s R tau : Nat}
    (hs : 2 * R + 5 ≤ s)
    (htau : tau < 2 ^ (s / 2 + 1)) :
    4 * (2 ^ R * tau) < 2 ^ s := by
  have hmul : 2 ^ R * tau < 2 ^ (R + (s / 2 + 1)) := by
    calc
      2 ^ R * tau < 2 ^ R * 2 ^ (s / 2 + 1) := Nat.mul_lt_mul_left _ htau
      _ = 2 ^ (R + (s / 2 + 1)) := by rw [← Nat.pow_add]
  have hexp : R + (s / 2 + 1) + 2 ≤ s := by omega
  have hpow : 2 ^ (R + (s / 2 + 1) + 2) ≤ 2 ^ s :=
    Nat.pow_le_pow_right (by decide : 1 ≤ 2) hexp
  calc
    4 * (2 ^ R * tau) < 2 ^ 2 * 2 ^ (R + (s / 2 + 1)) := by
      norm_num
      exact Nat.mul_lt_mul_left (2 ^ 2) hmul
    _ = 2 ^ (R + (s / 2 + 1) + 2) := by
      rw [← Nat.pow_add]
      congr 1
      omega
    _ ≤ 2 ^ s := hpow

/-- The translate-support loss is below one thirty-second of the field for
all supported dimensions r≤R. -/
theorem scaled_support_lt_field_size {s R : Nat}
    (hs : 2 * R + 5 ≤ s) :
    32 * 2 ^ (2 * R) ≤ 2 ^ s := by
  have hexp : 5 + 2 * R ≤ s := by omega
  have hpow : 2 ^ (5 + 2 * R) ≤ 2 ^ s :=
    Nat.pow_le_pow_right (by decide : 1 ≤ 2) hexp
  calc
    32 * 2 ^ (2 * R) = 2 ^ (5 + 2 * R) := by norm_num [Nat.pow_add]
    _ ≤ 2 ^ s := hpow

end CorruptedFieldRecovery
