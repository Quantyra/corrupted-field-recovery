import CorruptedFieldRecovery
import CorruptedFieldRecovery.RawFieldDeterminantBits

set_option pp.universes true
set_option pp.explicit false
set_option pp.fullNames true
set_option pp.piBinderTypes true
set_option pp.piBinderNames true
set_option pp.piBinderNames.hygienic true
set_option pp.proofs true
set_option pp.deepTerms true
set_option pp.maxSteps 1000000
set_option maxRecDepth 10000

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawFieldMul3Bits"
#check @CorruptedFieldRecovery.rawFieldMul3Bits
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawFieldMul3Bits"
#print axioms CorruptedFieldRecovery.rawFieldMul3Bits

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawFieldDet3Bits"
#check @CorruptedFieldRecovery.rawFieldDet3Bits
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawFieldDet3Bits"
#print axioms CorruptedFieldRecovery.rawFieldDet3Bits

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawFieldTraceDet3Bits"
#check @CorruptedFieldRecovery.rawFieldTraceDet3Bits
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawFieldTraceDet3Bits"
#print axioms CorruptedFieldRecovery.rawFieldTraceDet3Bits

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawFieldDet3Bits_quotient_sound"
#check @CorruptedFieldRecovery.rawFieldDet3Bits_quotient_sound
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawFieldDet3Bits_quotient_sound"
#print axioms CorruptedFieldRecovery.rawFieldDet3Bits_quotient_sound

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawFieldTraceDet3Bits_eq_baseTrace"
#check @CorruptedFieldRecovery.rawFieldTraceDet3Bits_eq_baseTrace
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawFieldTraceDet3Bits_eq_baseTrace"
#print axioms CorruptedFieldRecovery.rawFieldTraceDet3Bits_eq_baseTrace
