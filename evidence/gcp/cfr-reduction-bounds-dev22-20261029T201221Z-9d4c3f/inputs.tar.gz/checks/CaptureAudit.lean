import CorruptedFieldRecovery
import CorruptedFieldRecovery.RawReductionBounds

set_option pp.universes true
set_option pp.explicit false
set_option pp.fullNames true
set_option pp.piBinderTypes true
set_option pp.piBinderNames true
set_option pp.piBinderNames.hygienic true
set_option pp.proofs true
set_option pp.deepTerms true
set_option pp.maxSteps 1000000
set_option maxRecDepth 10000

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawXor_lt_two_pow_of_top_bit"
#check @CorruptedFieldRecovery.rawXor_lt_two_pow_of_top_bit
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawXor_lt_two_pow_of_top_bit"
#print axioms CorruptedFieldRecovery.rawXor_lt_two_pow_of_top_bit

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawReduceStep_lt_pow_of_top_bit"
#check @CorruptedFieldRecovery.rawReduceStep_lt_pow_of_top_bit
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawReduceStep_lt_pow_of_top_bit"
#print axioms CorruptedFieldRecovery.rawReduceStep_lt_pow_of_top_bit
