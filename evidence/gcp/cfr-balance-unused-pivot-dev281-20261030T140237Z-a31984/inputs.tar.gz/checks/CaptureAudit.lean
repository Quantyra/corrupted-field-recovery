import CorruptedFieldRecovery
import CorruptedFieldRecovery.S010BalanceGaussianUnusedPivot

set_option pp.universes true
set_option pp.explicit false
set_option pp.fullNames true
set_option pp.piBinderTypes true
set_option pp.piBinderNames true
set_option pp.piBinderNames.hygienic true
set_option pp.proofs true
set_option pp.deepTerms true
set_option pp.maxSteps 1000000
set_option maxRecDepth 10000

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.balanceMaskUsedRows"
#check @CorruptedFieldRecovery.balanceMaskUsedRows
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.balanceMaskUsedRows"
#print axioms CorruptedFieldRecovery.balanceMaskUsedRows

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.balanceFirstUnusedPivotRow"
#check @CorruptedFieldRecovery.balanceFirstUnusedPivotRow
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.balanceFirstUnusedPivotRow"
#print axioms CorruptedFieldRecovery.balanceFirstUnusedPivotRow

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.balanceFirstUnusedPivotRow_sound"
#check @CorruptedFieldRecovery.balanceFirstUnusedPivotRow_sound
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.balanceFirstUnusedPivotRow_sound"
#print axioms CorruptedFieldRecovery.balanceFirstUnusedPivotRow_sound

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.balanceFirstUnusedPivotRow_complete"
#check @CorruptedFieldRecovery.balanceFirstUnusedPivotRow_complete
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.balanceFirstUnusedPivotRow_complete"
#print axioms CorruptedFieldRecovery.balanceFirstUnusedPivotRow_complete
