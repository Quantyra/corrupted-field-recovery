import CorruptedFieldRecovery
import CorruptedFieldRecovery.SamplingCounts

set_option pp.universes true
set_option pp.explicit false
set_option pp.fullNames true
set_option pp.piBinderTypes true
set_option pp.piBinderNames true
set_option pp.piBinderNames.hygienic true
set_option pp.proofs true
set_option pp.deepTerms true
set_option pp.maxSteps 1000000
set_option maxRecDepth 10000

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.card_ker_support_f2"
#check @CorruptedFieldRecovery.card_ker_support_f2
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.card_ker_support_f2"
#print axioms CorruptedFieldRecovery.card_ker_support_f2

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.card_four_clean_words"
#check @CorruptedFieldRecovery.card_four_clean_words
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.card_four_clean_words"
#print axioms CorruptedFieldRecovery.card_four_clean_words
