import CorruptedFieldRecovery.DenseInput

/-! Raw array boundary for alternating dense tensors.

The array is indexed by the row-major ordered coefficient offset used by
`ExecutableCertificate`. Decoding selects only increasing triples and expands
them in the six-term minor basis. Thus the output is alternating by
construction. This file certifies the array comparison boundary; it does not
certify that the compatible array encodes a field determinant or that the
residual has bounded support.
-/

namespace CorruptedFieldRecovery

abbrev RawCoefficientArray := Array (ZMod 2)

def rawCoefficientOffset (n : Nat) (i j k : Fin n) : Nat :=
  (i.val * n + j.val) * n + k.val

/-- The raw dense array decodes to the finite sum of its selected minor
coefficients. This is a computable finite sum through `decodeDenseInput`. -/
def decodeRawArray {n : Nat} (raw : RawCoefficientArray) : BinaryTensor n :=
  decodeDenseInput (fun t =>
    raw[rawCoefficientOffset n (increasingTripleI t)
      (increasingTripleJ t) (increasingTripleK t)]!)

/-- Decoder identity at every serialized increasing-triple coordinate. -/
theorem encode_decodeRawArray {n : Nat} (raw : RawCoefficientArray)
    (t : IncreasingTriple n) :
    encodeDenseInput (decodeRawArray raw) t =
      raw[rawCoefficientOffset n (increasingTripleI t)
        (increasingTripleJ t) (increasingTripleK t)]! := by
  exact encode_decodeDenseInput (n := n) _ t

theorem decodeRawArray_isAlternating {n : Nat} (raw : RawCoefficientArray) :
    IsAlternating (decodeRawArray raw) :=
  decodeDenseInput_isAlternating _

/-- Agreement of raw arrays implies equality of the decoded alternating
tensors. This theorem needs no semantic tensor field attached to either input. -/
theorem decodeRawArray_congr {n : Nat} {left right : RawCoefficientArray}
    (h : left = right) : decodeRawArray left = decodeRawArray right := by
  subst right
  rfl

/-- Accepted raw comparison: both serialized arrays have exactly `n^3`
entries and all bits agree. -/
def rawArrayCheck {n : Nat} (input represented : RawCoefficientArray) : Bool :=
  decide (input.size = n * n * n) &&
    decide (represented.size = n * n * n) && input == represented

theorem accepted_raw_array_decoders_equal {n : Nat}
    (input represented : RawCoefficientArray)
    (accepted : rawArrayCheck (n := n) input represented = true) :
    decodeRawArray input = decodeRawArray represented := by
  simp only [rawArrayCheck, Bool.and_eq_true] at accepted
  have hEq : (input == represented) = true := accepted.2
  exact decodeRawArray_congr (eq_of_beq hEq)

end CorruptedFieldRecovery
