import CorruptedFieldRecovery.Support
import CorruptedFieldRecovery.S010PhysicalSupportTransport
import Mathlib.Tactic

namespace CorruptedFieldRecovery

noncomputable section

/-- The field-coordinate support transported all the way to the actual
physical dual. -/
def fieldToPhysicalDualEquiv {K : Type*} [Field K] [Finite K]
    [Algebra BinaryField K] [FiniteDimensional BinaryField K]
    {s : Nat}
    (Q : BinaryVector (3 * s) ≃ₗ[BinaryField] FieldTriple K) :
    KTriple K ≃ₗ[BinaryField]
      Module.Dual BinaryField (BinaryVector (3 * s)) :=
  ((fieldTripleEquivPi K).restrictScalars BinaryField).symm.trans
    ((binaryFieldTripleTraceDualEquiv K).trans Q.dualMap)

/-- The semantic support subspace is the preimage of the actual physical
support module under the binary-linear coordinate/trace dual equivalence. -/
def semanticSupportFromPhysical {K : Type*} [Field K] [Finite K]
    [Algebra BinaryField K] [FiniteDimensional BinaryField K]
    {s : Nat}
    (Q : BinaryVector (3 * s) ≃ₗ[BinaryField] FieldTriple K)
    (P : Submodule BinaryField
      (Module.Dual BinaryField (BinaryVector (3 * s)))) :
    Submodule BinaryField (KTriple K) :=
  Submodule.map (fieldToPhysicalDualEquiv Q).symm.toLinearMap P

/-- Pushing the semantic U back through the coordinate trace map recovers
exactly the physical support module in field-dual coordinates. -/
theorem actualTraceSupportSubmodule_eq_physicalPullback
    {K : Type*} [Field K] [Finite K]
    [Algebra BinaryField K] [FiniteDimensional BinaryField K]
    {s : Nat}
    (Q : BinaryVector (3 * s) ≃ₗ[BinaryField] FieldTriple K)
    (P : Submodule BinaryField
      (Module.Dual BinaryField (BinaryVector (3 * s)))) :
    actualTraceSupportSubmodule K (semanticSupportFromPhysical Q P) =
      Submodule.map Q.dualMap.symm.toLinearMap P := by
  rw [actualTraceSupportSubmodule, semanticSupportFromPhysical]
  rw [← Submodule.map_comp, ← Submodule.map_comp]
  congr 1
  apply LinearMap.ext
  intro p
  simp [fieldToPhysicalDualEquiv, LinearEquiv.trans_apply]

/-- For the manuscript's actual tensor support, the physical observation
kernel is its dual coannihilator, transported by Q. -/
theorem modeImage_clean_iff_observation_zero
    {K : Type*} [Field K] [Finite K]
    [Algebra BinaryField K] [FiniteDimensional BinaryField K]
    {s : Nat}
    (Q : BinaryVector (3 * s) ≃ₗ[BinaryField] FieldTriple K)
    (E : BinaryTensor (3 * s))
    (x : BinaryVector (3 * s)) :
    physicalSupportObservation Q
        (actualTraceSupportSubmodule K
          (semanticSupportFromPhysical Q (modeImage E))) x = 0 ↔
      x ∈ (modeImage E).dualCoannihilator := by
  rw [physicalSupportObservation_kernel_iff]
  rw [actualTraceSupportSubmodule_eq_physicalPullback]
  constructor
  · intro hx
    rw [Submodule.mem_dualCoannihilator] at hx ⊢
    intro g hg
    have hmem : Q.dualMap.symm g ∈
        Submodule.map Q.dualMap.symm.toLinearMap (modeImage E) :=
      ⟨g, hg, rfl⟩
    have hzero := hx (Q.dualMap.symm g) hmem
    simpa [LinearEquiv.dualMap_apply] using hzero
  · intro hx
    rw [Submodule.mem_dualCoannihilator] at hx ⊢
    intro f hf
    obtain ⟨g, hg, hfg⟩ := Submodule.mem_map.mp hf
    have hzero := hx g hg
    have heq : f = Q.dualMap.symm g := hfg
    rw [heq]
    simpa [LinearEquiv.dualMap_apply] using hzero

end

end CorruptedFieldRecovery
