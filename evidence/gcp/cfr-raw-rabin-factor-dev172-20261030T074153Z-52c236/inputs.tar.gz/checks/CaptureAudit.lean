import CorruptedFieldRecovery
import CorruptedFieldRecovery.RawRabinFactorFrobenius

set_option pp.universes true
set_option pp.explicit false
set_option pp.fullNames true
set_option pp.piBinderTypes true
set_option pp.piBinderNames true
set_option pp.piBinderNames.hygienic true
set_option pp.proofs true
set_option pp.deepTerms true
set_option pp.maxSteps 1000000
set_option maxRecDepth 10000

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.irreducible_dvd_X_pow_two_pow_natDegree"
#check @CorruptedFieldRecovery.irreducible_dvd_X_pow_two_pow_natDegree
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.irreducible_dvd_X_pow_two_pow_natDegree"
#print axioms CorruptedFieldRecovery.irreducible_dvd_X_pow_two_pow_natDegree
