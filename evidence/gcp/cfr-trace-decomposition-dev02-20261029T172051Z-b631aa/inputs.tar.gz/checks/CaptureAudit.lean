import CorruptedFieldRecovery
import CorruptedFieldRecovery.RawTraceDecomposition

set_option pp.universes true
set_option pp.explicit false
set_option pp.fullNames true
set_option pp.piBinderTypes true
set_option pp.piBinderNames true
set_option pp.piBinderNames.hygienic true
set_option pp.proofs true
set_option pp.deepTerms true
set_option pp.maxSteps 1000000
set_option maxRecDepth 10000

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawTraceDetPayload"
#check @CorruptedFieldRecovery.rawTraceDetPayload
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawTraceDetPayload"
#print axioms CorruptedFieldRecovery.rawTraceDetPayload

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawTraceDetTensor"
#check @CorruptedFieldRecovery.rawTraceDetTensor
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawTraceDetTensor"
#print axioms CorruptedFieldRecovery.rawTraceDetTensor

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawTraceDetTensor_alternating"
#check @CorruptedFieldRecovery.rawTraceDetTensor_alternating
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawTraceDetTensor_alternating"
#print axioms CorruptedFieldRecovery.rawTraceDetTensor_alternating

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawTraceCompatibleCheck"
#check @CorruptedFieldRecovery.rawTraceCompatibleCheck
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawTraceCompatibleCheck"
#print axioms CorruptedFieldRecovery.rawTraceCompatibleCheck

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.accepted_rawTraceCompatibleCheck"
#check @CorruptedFieldRecovery.accepted_rawTraceCompatibleCheck
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.accepted_rawTraceCompatibleCheck"
#print axioms CorruptedFieldRecovery.accepted_rawTraceCompatibleCheck

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawTraceDecompositionCheck"
#check @CorruptedFieldRecovery.rawTraceDecompositionCheck
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawTraceDecompositionCheck"
#print axioms CorruptedFieldRecovery.rawTraceDecompositionCheck

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.accepted_rawTraceDecompositionCheck_sound"
#check @CorruptedFieldRecovery.accepted_rawTraceDecompositionCheck_sound
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.accepted_rawTraceDecompositionCheck_sound"
#print axioms CorruptedFieldRecovery.accepted_rawTraceDecompositionCheck_sound
