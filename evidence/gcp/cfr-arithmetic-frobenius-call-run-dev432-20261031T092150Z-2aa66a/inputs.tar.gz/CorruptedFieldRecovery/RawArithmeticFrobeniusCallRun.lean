import CorruptedFieldRecovery.RawArithmeticFrobeniusCallMachine

/-! An ordered, phase-labelled schedule for the abstract Frobenius call tree.
The schedule orders parent, multiplier-prefix, reducer-prefix, and recursive
child events. These are source-level call snapshots, not individual bit
operations or a Lean runtime trace. -/

namespace CorruptedFieldRecovery

/-- Ordered phase events for the source-level abstract recursive call run. -/
def rawCandidateFrobeniusCallRun (modulus : Nat) : Nat → Nat →
    List RawArithmeticCallState
  | 0, x =>
      [⟨.frobenius, [rawArithmeticFrobeniusFrame modulus 0 x x 0]⟩]
  | d + 1, x =>
      let square := rawPolyMulBitCosted x x
      let rem := rawPolynomialRemainderBitCosted square.1 modulus
      let parent := rawArithmeticFrobeniusFrame modulus (d + 1) x
        square.1 rem.1
      [⟨.frobenius, [parent]⟩] ++
        (rawArithmeticPrefixStackTrace (rawPolyMulActivationTrace x x)).map
          (fun stack => ⟨.multiply, parent :: stack⟩) ++
        (rawArithmeticPrefixStackTrace
          (rawReduceFuelActivationTrace modulus (Nat.log2 modulus)
            (Nat.log2 square.1 + 1) square.1)).map
          (fun stack => ⟨.reduce, parent :: stack⟩) ++
        (rawCandidateFrobeniusCallRun modulus d rem.1).map
          (fun state => ⟨state.phase, parent :: state.stack⟩)
termination_by d _ => d
decreasing_by omega

/-- Erasing phase labels from the ordered event schedule gives exactly the
previously audited composed snapshot list. -/
theorem rawCandidateFrobeniusCallRun_map_stack_eq_nestedTrace
    (modulus d x : Nat) :
    (rawCandidateFrobeniusCallRun modulus d x).map
      RawArithmeticCallState.stack =
        rawCandidateFrobeniusNestedStackTrace modulus d x := by
  induction d generalizing x with
  | zero => simp [rawCandidateFrobeniusCallRun,
      rawCandidateFrobeniusNestedStackTrace]
  | succ d ih =>
      simp only [rawCandidateFrobeniusCallRun,
        rawCandidateFrobeniusNestedStackTrace, List.map_append,
        List.map_map, Function.comp_def]
      rw [ih]

/-- Each event in the ordered schedule refines to a state in the accepted
abstract call-tree reachability relation. -/
theorem rawCandidateFrobeniusCallRun_mem_reachable
    (modulus d x : Nat) {state : RawArithmeticCallState}
    (hstate : state ∈ rawCandidateFrobeniusCallRun modulus d x) :
    ∃ phase, RawCandidateFrobeniusCallReachable modulus d x
      ⟨phase, state.stack⟩ := by
  have hstack : state.stack ∈
      rawCandidateFrobeniusNestedStackTrace modulus d x := by
    have hmap : state.stack ∈
        (rawCandidateFrobeniusCallRun modulus d x).map
          RawArithmeticCallState.stack :=
      List.mem_map.mpr ⟨state, hstate, rfl⟩
    rw [rawCandidateFrobeniusCallRun_map_stack_eq_nestedTrace] at hmap
    exact hmap
  exact (rawCandidateFrobeniusCallReachable_iff_trace modulus d x state.stack).2 hstack

/-- Ordered abstract run events inherit the declared-cost stack-depth bound.
This is call-event depth, not machine instruction count. -/
theorem rawCandidateFrobeniusCallRun_depth_le_declared_cost
    {modulus d x : Nat} (hmod : 1 < modulus)
    {state : RawArithmeticCallState}
    (hstate : state ∈ rawCandidateFrobeniusCallRun modulus d x) :
    state.stack.length ≤ (rawCandidateFrobeniusAuxBitCosted modulus d x).2 + 1 := by
  obtain ⟨phase, hreachable⟩ :=
    rawCandidateFrobeniusCallRun_mem_reachable modulus d x hstate
  exact rawCandidateFrobeniusCallReachable_depth_le_declared_cost hmod
    hreachable

end CorruptedFieldRecovery
