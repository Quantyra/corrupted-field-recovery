import CorruptedFieldRecovery.S010BalanceGaussianArrayOrbitStep
import Mathlib.LinearAlgebra.Matrix.ToLin

namespace CorruptedFieldRecovery

/-! # Array append refinement for an actual operator orbit

This module connects the accepted one-orbit span from
`S010BalanceGaussianArrayOrbitStep` to the concrete `Array.append` used by the
greedy run. It proves the exact column-submodule equality; it does not yet
prove the recursive three-pass success theorem. -/

/-- The ordered family of columns represented by an array. -/
def actualGreedyArrayColumnFamily {m : Nat}
    (columns : Array (Fin m → ZMod 2)) : Fin columns.size → Fin m → ZMod 2 :=
  fun j => columns[j.val]!

/-- The range of a matrix's column map is the span represented by the array. -/
theorem actualGreedyArrayColumnSubmodule_eq_span {m : Nat}
    (columns : Array (Fin m → ZMod 2)) :
    actualGreedyArrayColumnSubmodule columns =
      Submodule.span (ZMod 2)
        (Set.range (actualGreedyArrayColumnFamily columns)) := by
  rw [actualGreedyArrayColumnSubmodule, Matrix.range_mulVecLin]
  rfl

/-- Appending arrays takes the supremum of their represented column spans. -/
theorem actualGreedyArrayAppendColumnSubmodule {m : Nat}
    (left right : Array (Fin m → ZMod 2)) :
    actualGreedyArrayColumnSubmodule (left ++ right) =
      actualGreedyArrayColumnSubmodule left ⊔
        actualGreedyArrayColumnSubmodule right := by
  classical
  let f := actualGreedyArrayColumnFamily left
  let g := actualGreedyArrayColumnFamily right
  simp only [Array.size_append]
  have hfamily : actualGreedyArrayColumnFamily (left ++ right) =
      Fin.addCases f g := by
    simp only [Array.size_append]
    funext i
    induction i using Fin.addCases with
    | left j => simp [f, actualGreedyArrayColumnFamily]
    | right j => simp [g, actualGreedyArrayColumnFamily]
  have hrange : Set.range (Fin.addCases f g) =
      Set.range f ∪ Set.range g := by
    ext x
    simp only [Set.mem_range, Set.mem_union]
    constructor
    · rintro ⟨i, rfl⟩
      induction i using Fin.addCases with
      | left j => exact Or.inl ⟨j, rfl⟩
      | right j => exact Or.inr ⟨j, rfl⟩
    · rintro (⟨j, rfl⟩ | ⟨j, rfl⟩)
      · exact ⟨Fin.castAdd right.size j, by simp [f]⟩
      · exact ⟨Fin.natAdd left.size j, by simp [g]⟩
  rw [actualGreedyArrayColumnSubmodule_eq_span,
    actualGreedyArrayColumnSubmodule_eq_span,
    actualGreedyArrayColumnSubmodule_eq_span,
    hfamily, hrange, Submodule.span_union]

/-- The actual finite array of the first `s` iterates of `T v`. -/
def actualGreedyArrayOrbitColumns {n s : Nat}
    (T : Module.End (ZMod 2) (BinaryVector n)) (v : BinaryVector n) :
    Array (BinaryVector n) :=
  Array.ofFn (actualGreedyOrbitFamily (s := s) T v)

/-- The column family of the orbit array is exactly the specified orbit. -/
theorem actualGreedyArrayOrbitColumns_family {n s : Nat}
    (T : Module.End (ZMod 2) (BinaryVector n)) (v : BinaryVector n) :
    actualGreedyArrayColumnFamily (actualGreedyArrayOrbitColumns T v) =
      actualGreedyOrbitFamily (s := s) T v := by
  funext i
  simp [actualGreedyArrayOrbitColumns, actualGreedyArrayColumnFamily]

/-- The actual orbit array represents the same submodule as the abstract
finite orbit span. -/
theorem actualGreedyArrayOrbitColumns_span {n s : Nat}
    (T : Module.End (ZMod 2) (BinaryVector n)) (v : BinaryVector n) :
    actualGreedyArrayColumnSubmodule (actualGreedyArrayOrbitColumns T v) =
      actualGreedyOrbitSpan (s := s) T v := by
  rw [actualGreedyArrayColumnSubmodule_eq_span,
    actualGreedyArrayOrbitColumns_family, actualGreedyOrbitSpan]

/-- Appending the concrete orbit array has exactly the abstract sup used by
the selected-orbit dimension and invariance theorem. -/
theorem actualGreedyArrayAppendOrbit_span {s : Nat}
    (T : Module.End (ZMod 2) (BinaryVector (3 * s)))
    (columns : Array (BinaryVector (3 * s))) (v : BinaryVector (3 * s)) :
    actualGreedyArrayColumnSubmodule
        (columns ++ actualGreedyArrayOrbitColumns T v) =
      actualGreedyArrayColumnSubmodule columns ⊔
        actualGreedyOrbitSpan (s := s) T v := by
  rw [actualGreedyArrayAppendColumnSubmodule,
    actualGreedyArrayOrbitColumns_span]

end CorruptedFieldRecovery
