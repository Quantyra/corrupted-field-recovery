import CorruptedFieldRecovery
import CorruptedFieldRecovery.RawRabinScanBitCost

set_option pp.universes true
set_option pp.explicit false
set_option pp.fullNames true
set_option pp.piBinderTypes true
set_option pp.piBinderNames true
set_option pp.piBinderNames.hygienic true
set_option pp.proofs true
set_option pp.deepTerms true
set_option pp.maxSteps 1000000
set_option maxRecDepth 10000

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawRabinCheckIndexBitCosted"
#check @CorruptedFieldRecovery.rawRabinCheckIndexBitCosted
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawRabinCheckIndexBitCosted"
#print axioms CorruptedFieldRecovery.rawRabinCheckIndexBitCosted

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawRabinCheckIndexBitCosted_fst"
#check @CorruptedFieldRecovery.rawRabinCheckIndexBitCosted_fst
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawRabinCheckIndexBitCosted_fst"
#print axioms CorruptedFieldRecovery.rawRabinCheckIndexBitCosted_fst

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawRabinScanBitCosted"
#check @CorruptedFieldRecovery.rawRabinScanBitCosted
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawRabinScanBitCosted"
#print axioms CorruptedFieldRecovery.rawRabinScanBitCosted

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawRabinCheckIndexCharge"
#check @CorruptedFieldRecovery.rawRabinCheckIndexCharge
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawRabinCheckIndexCharge"
#print axioms CorruptedFieldRecovery.rawRabinCheckIndexCharge

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawRabinCheckIndexBitCosted_cost_le"
#check @CorruptedFieldRecovery.rawRabinCheckIndexBitCosted_cost_le
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawRabinCheckIndexBitCosted_cost_le"
#print axioms CorruptedFieldRecovery.rawRabinCheckIndexBitCosted_cost_le

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawRabinScanBitCosted_cost_le"
#check @CorruptedFieldRecovery.rawRabinScanBitCosted_cost_le
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawRabinScanBitCosted_cost_le"
#print axioms CorruptedFieldRecovery.rawRabinScanBitCosted_cost_le
