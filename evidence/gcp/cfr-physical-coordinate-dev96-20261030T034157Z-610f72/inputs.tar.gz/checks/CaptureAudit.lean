import CorruptedFieldRecovery
import CorruptedFieldRecovery.RawPhysicalCoordinateCorrespondence

set_option pp.universes true
set_option pp.explicit false
set_option pp.fullNames true
set_option pp.piBinderTypes true
set_option pp.piBinderNames true
set_option pp.piBinderNames.hygienic true
set_option pp.proofs true
set_option pp.deepTerms true
set_option pp.maxSteps 1000000
set_option maxRecDepth 10000

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawFieldTripleComponent"
#check @CorruptedFieldRecovery.rawFieldTripleComponent
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawFieldTripleComponent"
#print axioms CorruptedFieldRecovery.rawFieldTripleComponent

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawPhysicalBlockMask_eq_canonicalComponent"
#check @CorruptedFieldRecovery.rawPhysicalBlockMask_eq_canonicalComponent
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawPhysicalBlockMask_eq_canonicalComponent"
#print axioms CorruptedFieldRecovery.rawPhysicalBlockMask_eq_canonicalComponent
