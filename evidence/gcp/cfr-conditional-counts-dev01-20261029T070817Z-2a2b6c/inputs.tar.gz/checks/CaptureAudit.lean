import CorruptedFieldRecovery
import CorruptedFieldRecovery.ConditionalCounts

set_option pp.universes true
set_option pp.explicit false
set_option pp.fullNames true
set_option pp.piBinderTypes true
set_option pp.piBinderNames true
set_option pp.piBinderNames.hygienic true
set_option pp.proofs true
set_option pp.deepTerms true
set_option pp.maxSteps 1000000
set_option maxRecDepth 10000

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.card_first_coordinate_fiber"
#check @CorruptedFieldRecovery.card_first_coordinate_fiber
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.card_first_coordinate_fiber"
#print axioms CorruptedFieldRecovery.card_first_coordinate_fiber

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.card_subset_first_coordinate_fiber_le"
#check @CorruptedFieldRecovery.card_subset_first_coordinate_fiber_le
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.card_subset_first_coordinate_fiber_le"
#print axioms CorruptedFieldRecovery.card_subset_first_coordinate_fiber_le
