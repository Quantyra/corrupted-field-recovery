import CorruptedFieldRecovery.S010QInputEquivalence
import CorruptedFieldRecovery.S010GoodTapeBilinearBalance
import CorruptedFieldRecovery.FourContractions

namespace CorruptedFieldRecovery

noncomputable section

/-- The clean trace-determinant tensor specified by the manuscript's field
coordinates `Q` and coefficient `c`. Its three input slots are the original
physical binary input vectors. -/
def qTraceDeterminantTensor
    {K : Type*} [Field K] [Finite K] [Algebra BinaryField K]
    {n : Nat} (Q : BinaryVector n ≃ₗ[BinaryField] FieldTriple K) (c : K) :
    BinaryTensor n :=
  { toFun := fun x =>
      { toFun := fun y =>
          { toFun := fun z =>
              Algebra.trace BinaryField K (c * fieldDet3 (Q x) (Q y) (Q z))
            map_add' := by
              intro z z'
              simp only [map_add, fieldDet3]
              ring
            map_smul' := by
              intro a z
              rw [map_smul]
              simp only [fieldDet3_smul_right, smul_eq_mul]
              rw [Algebra.trace_smul]
              simp [Algebra.smul_def, mul_assoc] }
        map_add' := by
          intro y y'
          ext z
          simp only [map_add, fieldDet3]
          rw [Algebra.trace_add]
          ring
        map_smul' := by
          intro a y
          ext z
          rw [map_smul]
          simp only [fieldDet3_smul_right, smul_eq_mul]
          rw [Algebra.trace_smul]
          simp [Algebra.smul_def, mul_assoc] }
    map_add' := by
      intro x x'
      ext y
      ext z
      simp only [map_add, fieldDet3]
      rw [Algebra.trace_add]
      ring
    map_smul' := by
      intro a x
      ext y
      ext z
      rw [map_smul]
      simp only [fieldDet3_smul_left, smul_eq_mul]
      rw [Algebra.trace_smul]
      simp [Algebra.smul_def, mul_assoc] }

/-- The input promise for the observed model: its tensor is the canonical
Q-derived clean trace determinant plus the observed pullback of the hidden
defect tensor. This records the manuscript's model data explicitly; it makes
no claim that an algorithm constructs or verifies that promise. -/
def HasObservedTraceDeterminantDecomposition
    {K : Type*} [Field K] [Finite K] [Algebra BinaryField K]
    {n m : Nat} (Ctotal : BinaryTensor n) (E : BinaryTensor m)
    (u : BinaryVector n →ₗ[ZMod 2] BinaryVector m)
    (Q : BinaryVector n ≃ₗ[BinaryField] FieldTriple K) (c : K) : Prop :=
  Ctotal = physicalPerturbedTensor (qTraceDeterminantTensor Q c) E u

/-- The observed tensor equals its canonical clean model plus the supplied
hidden defect pullback, directly from the explicit input decomposition
promise. -/
theorem originalObservedTensor_eq_clean_plus_defect
    {K : Type*} [Field K] [Finite K] [Algebra BinaryField K]
    {n m : Nat} (Ctotal : BinaryTensor n) (E : BinaryTensor m)
    (u : BinaryVector n →ₗ[ZMod 2] BinaryVector m)
    (Q : BinaryVector n ≃ₗ[BinaryField] FieldTriple K) (c : K)
    (hmodel : HasObservedTraceDeterminantDecomposition Ctotal E u Q c) :
    Ctotal = qTraceDeterminantTensor Q c + pullback E u := by
  exact hmodel

/-- On a clean third slot, the complete observed contraction bilinear form is
the canonical Q-derived trace-determinant form. The only model premise is the
explicit clean-plus-defect decomposition above. -/
theorem originalObserved_bilinForm_eq_clean_on_coannihilator
    {K : Type*} [Field K] [Finite K] [Algebra BinaryField K]
    {n m : Nat} (Ctotal : BinaryTensor n) (E : BinaryTensor m)
    (u : BinaryVector n →ₗ[ZMod 2] BinaryVector m)
    (Q : BinaryVector n ≃ₗ[BinaryField] FieldTriple K) (c : K)
    (hmodel : HasObservedTraceDeterminantDecomposition Ctotal E u Q c)
    (z : BinaryVector n)
    (hz : u z ∈ (modeImage E).dualCoannihilator) :
    physicalThirdSlotBilinForm Ctotal z =
      physicalThirdSlotBilinForm (qTraceDeterminantTensor Q c) z := by
  rw [originalObservedTensor_eq_clean_plus_defect Ctotal E u Q c hmodel]
  exact physicalPerturbed_bilinForm_eq_clean_of_modeImage_coannihilator
    (qTraceDeterminantTensor Q c) E u z hz

end

end CorruptedFieldRecovery
