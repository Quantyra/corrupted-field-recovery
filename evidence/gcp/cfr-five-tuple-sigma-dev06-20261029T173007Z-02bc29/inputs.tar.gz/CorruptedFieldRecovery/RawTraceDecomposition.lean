import CorruptedFieldRecovery.RawVerifier
import CorruptedFieldRecovery.RawFieldCoordinateBridge
import CorruptedFieldRecovery.FourContractions

/-! S011 trace-compatible coefficient validation.

The supplied compatible array is checked against coefficients computed from
the accepted quotient-field scalar and the checked physical coordinates.  The
expected tensor is decoded from those computed alternating coefficients; no
identity is stored in the certificate.  The construction is noncomputable at
the current quotient-field boundary, so this is a formal finite coefficient
checker, not yet a serialized bit-level implementation of quotient arithmetic.
-/

namespace CorruptedFieldRecovery

open AdjoinRoot

/-- Pointwise trace of a scaled field determinant, transported along a binary
linear coordinate map. -/
noncomputable def traceDeterminantTensor {n : Nat}
    (K : Type*) [Field K] [Finite K] [Algebra (ZMod 2) K]
    (c : K) (coords : BinaryVector n →ₗ[ZMod 2] FieldTriple K) : BinaryTensor n :=
  { toFun := fun x =>
      { toFun := fun y =>
          { toFun := fun z =>
              Algebra.trace (ZMod 2) K (c * fieldDet3 (coords x) (coords y) (coords z))
            map_add' := by
              intro z w
              simp only [LinearMap.map_add]
              simp [fieldDet3, sub_mul, mul_add, add_mul]
              ring
            map_smul' := by
              intro a z
              simp only [LinearMap.map_smul]
              simp [fieldDet3, smul_eq_mul, sub_mul, mul_add, add_mul]
              ring }
        map_add' := by
          intro y w
          ext z
          simp only [LinearMap.map_add]
          simp [fieldDet3, sub_mul, mul_add, add_mul]
          ring
        map_smul' := by
          intro a y
          ext z
          simp only [LinearMap.map_smul]
          simp [fieldDet3, smul_eq_mul, sub_mul, mul_add, add_mul]
          ring }
    map_add' := by
      intro x y
      ext z w
      simp only [LinearMap.map_add]
      simp [fieldDet3, sub_mul, mul_add, add_mul]
      ring
    map_smul' := by
      intro a x
      ext z w
      simp only [LinearMap.map_smul]
      simp [fieldDet3, smul_eq_mul, sub_mul, mul_add, add_mul]
      ring }

/-- Repeated arguments make the determinant zero, so the transported trace
form is alternating. -/
theorem traceDeterminantTensor_alternating {n : Nat}
    (K : Type*) [Field K] [Finite K] [Algebra (ZMod 2) K]
    (c : K) (coords : BinaryVector n →ₗ[ZMod 2] FieldTriple K) :
    IsAlternating (traceDeterminantTensor K c coords) := by
  refine ⟨?_, ?_, ?_⟩
  · intro x z
    change Algebra.trace _ _ (_ * fieldDet3 _ _ _) = 0
    have hdet : fieldDet3 (coords x) (coords x) (coords z) = 0 := by
      simp [fieldDet3]
      ring
    rw [hdet]
    simp
  · intro x y
    change Algebra.trace _ _ (_ * fieldDet3 _ _ _) = 0
    have hdet : fieldDet3 (coords x) (coords y) (coords x) = 0 := by
      simp [fieldDet3]
      ring
    rw [hdet]
    simp
  · intro x y
    change Algebra.trace _ _ (_ * fieldDet3 _ _ _) = 0
    have hdet : fieldDet3 (coords x) (coords y) (coords y) = 0 := by
      simp [fieldDet3]
      ring
    rw [hdet]
    simp

/-- The expected increasing coefficients, evaluated from the actual
candidate field, nonzero scalar, and accepted physical coordinate map. -/
noncomputable def rawTraceDetPayload {s : Nat}
    (candidate : RawFieldCandidate s)
    (hfield : rawFieldCandidateCheck candidate = true)
    (forward inverse : RawCoordinateMatrix)
    (hcoordinates : rawCoordinateMatrixCheck (n := 3 * s) forward inverse = true) :
    DenseInputPayload (3 * s) := by
  letI : Fact (Irreducible (rawCandidateModulus candidate)) :=
    ⟨accepted_rawCandidateModulus_irreducible candidate hfield⟩
  let K := AdjoinRoot (rawCandidateModulus candidate)
  let coords := accepted_rawCandidatePhysicalCoordinates candidate hfield
    forward inverse hcoordinates
  let c : K := AdjoinRoot.mk (rawCandidateModulus candidate)
    (rawCandidateScalar candidate)
  intro t
  exact Algebra.trace (ZMod 2) K
    (c * fieldDet3 (coords.symm (coordinateVectorCode (increasingTripleI t)))
      (coords.symm (coordinateVectorCode (increasingTripleJ t)))
      (coords.symm (coordinateVectorCode (increasingTripleK t))))

/-- The pointwise trace-determinant tensor computed from the accepted field
candidate and physical coordinates. -/
noncomputable def rawTraceDetTensor {s : Nat}
    (candidate : RawFieldCandidate s)
    (hfield : rawFieldCandidateCheck candidate = true)
    (forward inverse : RawCoordinateMatrix)
    (hcoordinates : rawCoordinateMatrixCheck (n := 3 * s) forward inverse = true) :
    BinaryTensor (3 * s) := by
  letI : Fact (Irreducible (rawCandidateModulus candidate)) :=
    ⟨accepted_rawCandidateModulus_irreducible candidate hfield⟩
  let K := AdjoinRoot (rawCandidateModulus candidate)
  let coords := accepted_rawCandidatePhysicalCoordinates candidate hfield
    forward inverse hcoordinates
  let c : K := AdjoinRoot.mk (rawCandidateModulus candidate)
    (rawCandidateScalar candidate)
  exact traceDeterminantTensor K c coords.symm.toLinearMap

theorem rawTraceDetTensor_alternating {s : Nat}
    (candidate : RawFieldCandidate s)
    (hfield : rawFieldCandidateCheck candidate = true)
    (forward inverse : RawCoordinateMatrix)
    (hcoordinates : rawCoordinateMatrixCheck (n := 3 * s) forward inverse = true) :
    IsAlternating (rawTraceDetTensor candidate hfield forward inverse hcoordinates) := by
  letI : Fact (Irreducible (rawCandidateModulus candidate)) :=
    ⟨accepted_rawCandidateModulus_irreducible candidate hfield⟩
  let K := AdjoinRoot (rawCandidateModulus candidate)
  let coords := accepted_rawCandidatePhysicalCoordinates candidate hfield
    forward inverse hcoordinates
  let c : K := AdjoinRoot.mk (rawCandidateModulus candidate)
    (rawCandidateScalar candidate)
  simpa [rawTraceDetTensor, K, coords, c] using
    traceDeterminantTensor_alternating K c coords.symm.toLinearMap

/-- The payload is exactly the increasing coefficient table of the literal
pointwise trace-determinant tensor. -/
theorem rawTraceDetPayload_eq_encode {s : Nat}
    (candidate : RawFieldCandidate s)
    (hfield : rawFieldCandidateCheck candidate = true)
    (forward inverse : RawCoordinateMatrix)
    (hcoordinates : rawCoordinateMatrixCheck (n := 3 * s) forward inverse = true) :
    rawTraceDetPayload candidate hfield forward inverse hcoordinates =
      encodeDenseInput (rawTraceDetTensor candidate hfield forward inverse hcoordinates) := by
  funext t
  simp [rawTraceDetPayload, rawTraceDetTensor, encodeDenseInput,
    coordinateVectorCode_eq_coordinateVector]

/-- Finite comparison of the actual compatible array's decoded coefficients
with the coefficients calculated from the accepted field and coordinates. -/
noncomputable def rawTraceCompatibleCheck {s : Nat}
    (compatible : RawBinaryArray)
    (candidate : RawFieldCandidate s)
    (hfield : rawFieldCandidateCheck candidate = true)
    (forward inverse : RawCoordinateMatrix)
    (hcoordinates : rawCoordinateMatrixCheck (n := 3 * s) forward inverse = true) : Bool :=
  decide (∀ t : IncreasingTriple (3 * s),
    encodeDenseInput (decodeRawArray (n := 3 * s) compatible) t =
      rawTraceDetPayload candidate hfield forward inverse hcoordinates t)

theorem accepted_rawTraceCompatibleCheck {s : Nat}
    (compatible : RawBinaryArray)
    (candidate : RawFieldCandidate s)
    (hfield : rawFieldCandidateCheck candidate = true)
    (forward inverse : RawCoordinateMatrix)
    (hcoordinates : rawCoordinateMatrixCheck (n := 3 * s) forward inverse = true)
    (hcheck : rawTraceCompatibleCheck compatible candidate hfield forward inverse
      hcoordinates = true) :
    decodeRawArray (n := 3 * s) compatible =
      rawTraceDetTensor candidate hfield forward inverse hcoordinates := by
  apply binaryTensor_ext_of_increasing_coefficients
  · exact decodeRawArray_isAlternating (n := 3 * s) compatible
  · exact rawTraceDetTensor_alternating candidate hfield forward inverse hcoordinates
  · intro i j k hij hjk
    let t : IncreasingTriple (3 * s) := ⟨((i, j), k), ⟨hij, hjk⟩⟩
    have heq : ∀ t : IncreasingTriple (3 * s),
        encodeDenseInput (decodeRawArray (n := 3 * s) compatible) t =
          rawTraceDetPayload candidate hfield forward inverse hcoordinates t :=
      of_decide_eq_true (by simpa [rawTraceCompatibleCheck] using hcheck)
    have hc := heq t
    have hd := encode_decodeRawArray (n := 3 * s) compatible t
    have hp := congrFun (rawTraceDetPayload_eq_encode candidate hfield forward inverse
      hcoordinates) t
    change coefficient (decodeRawArray (n := 3 * s) compatible) i j k =
      coefficient (rawTraceDetTensor candidate hfield forward inverse hcoordinates) i j k
    rw [← encodeDenseInput_eq_semanticCoefficient, hd, hc, hp]
    rfl

/-- S011 combined gate: the original raw decomposition verifier must accept,
and the compatible array must independently match the computed trace-field
coefficients. -/
noncomputable def rawTraceDecompositionCheck {s R : Nat}
    (p : RawDecomposition (3 * s) R)
    (candidate : RawFieldCandidate s)
    (hfield : rawFieldCandidateCheck candidate = true)
    (forward inverse : RawCoordinateMatrix)
    (hcoordinates : rawCoordinateMatrixCheck (n := 3 * s) forward inverse = true) : Bool :=
  rawDecompositionCheck p &&
    rawTraceCompatibleCheck p.compatible candidate hfield forward inverse hcoordinates

/-- An accepted combined gate proves the complete input identity with the
computed trace-determinant-compatible tensor and the explicitly factored
residual. It proves compatibility, not uniqueness or recovery completeness. -/
theorem accepted_rawTraceDecompositionCheck_sound {s R : Nat}
    (p : RawDecomposition (3 * s) R)
    (candidate : RawFieldCandidate s)
    (hfield : rawFieldCandidateCheck candidate = true)
    (forward inverse : RawCoordinateMatrix)
    (hcoordinates : rawCoordinateMatrixCheck (n := 3 * s) forward inverse = true)
    (hcheck : rawTraceDecompositionCheck p candidate hfield forward inverse
      hcoordinates = true) :
    ∀ x y z,
      decodeRawArray (n := 3 * s) p.input x y z =
        (rawTraceDetTensor candidate hfield forward inverse hcoordinates +
          pullback (decodeRawArray (n := p.supportDimension) p.residual)
            (rawSupportMap p.supportMatrix)) x y z := by
  simp only [rawTraceDecompositionCheck, Bool.and_eq_true] at hcheck
  have hdecomp := accepted_rawDecompositionCheck_sound p hcheck.1
  have hclean := accepted_rawTraceCompatibleCheck p.compatible candidate hfield
    forward inverse hcoordinates hcheck.2
  have hsum : p.represented =
      rawTraceDetTensor candidate hfield forward inverse hcoordinates +
        pullback (decodeRawArray (n := p.supportDimension) p.residual)
          (rawSupportMap p.supportMatrix) := by
    rw [RawDecomposition.represented, hclean]
  intro x y z
  rw [hdecomp]
  exact congrArg (fun T : BinaryTensor (3 * s) => T x y z) hsum

end CorruptedFieldRecovery
