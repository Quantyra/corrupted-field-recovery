import CorruptedFieldRecovery
import CorruptedFieldRecovery.TranslateScalarCounts

set_option pp.universes true
set_option pp.explicit false
set_option pp.fullNames true
set_option pp.piBinderTypes true
set_option pp.piBinderNames true
set_option pp.piBinderNames.hygienic true
set_option pp.proofs true
set_option pp.deepTerms true
set_option pp.maxSteps 1000000
set_option maxRecDepth 10000

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.card_translateScalarRoots_le_one"
#check @CorruptedFieldRecovery.card_translateScalarRoots_le_one
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.card_translateScalarRoots_le_one"
#print axioms CorruptedFieldRecovery.card_translateScalarRoots_le_one

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.card_nonzeroTranslatePairs_le"
#check @CorruptedFieldRecovery.card_nonzeroTranslatePairs_le
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.card_nonzeroTranslatePairs_le"
#print axioms CorruptedFieldRecovery.card_nonzeroTranslatePairs_le

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.card_badTranslateScalars_le"
#check @CorruptedFieldRecovery.card_badTranslateScalars_le
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.card_badTranslateScalars_le"
#print axioms CorruptedFieldRecovery.card_badTranslateScalars_le

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.card_badTranslateScalars_le_pow"
#check @CorruptedFieldRecovery.card_badTranslateScalars_le_pow
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.card_badTranslateScalars_le_pow"
#print axioms CorruptedFieldRecovery.card_badTranslateScalars_le_pow
