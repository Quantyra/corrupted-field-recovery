import CorruptedFieldRecovery
import CorruptedFieldRecovery.RawArithmeticRegisterSpaceModel

set_option pp.universes true
set_option pp.explicit false
set_option pp.fullNames true
set_option pp.piBinderTypes true
set_option pp.piBinderNames true
set_option pp.piBinderNames.hygienic true
set_option pp.proofs true
set_option pp.deepTerms true
set_option pp.maxSteps 1000000
set_option maxRecDepth 10000

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.RawArithmeticFrameKind"
#check @CorruptedFieldRecovery.RawArithmeticFrameKind
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.RawArithmeticFrameKind"
#print axioms CorruptedFieldRecovery.RawArithmeticFrameKind

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.RawArithmeticFrame"
#check @CorruptedFieldRecovery.RawArithmeticFrame
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.RawArithmeticFrame"
#print axioms CorruptedFieldRecovery.RawArithmeticFrame

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawArithmeticMultiplyFrame"
#check @CorruptedFieldRecovery.rawArithmeticMultiplyFrame
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawArithmeticMultiplyFrame"
#print axioms CorruptedFieldRecovery.rawArithmeticMultiplyFrame

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawArithmeticReduceFrame"
#check @CorruptedFieldRecovery.rawArithmeticReduceFrame
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawArithmeticReduceFrame"
#print axioms CorruptedFieldRecovery.rawArithmeticReduceFrame

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawArithmeticGcdFrame"
#check @CorruptedFieldRecovery.rawArithmeticGcdFrame
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawArithmeticGcdFrame"
#print axioms CorruptedFieldRecovery.rawArithmeticGcdFrame

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawArithmeticFrobeniusFrame"
#check @CorruptedFieldRecovery.rawArithmeticFrobeniusFrame
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawArithmeticFrobeniusFrame"
#print axioms CorruptedFieldRecovery.rawArithmeticFrobeniusFrame

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawArithmeticFrameLiveBits"
#check @CorruptedFieldRecovery.rawArithmeticFrameLiveBits
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawArithmeticFrameLiveBits"
#print axioms CorruptedFieldRecovery.rawArithmeticFrameLiveBits

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawArithmeticStackLiveBits"
#check @CorruptedFieldRecovery.rawArithmeticStackLiveBits
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawArithmeticStackLiveBits"
#print axioms CorruptedFieldRecovery.rawArithmeticStackLiveBits

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawArithmeticFrameLiveBits_le"
#check @CorruptedFieldRecovery.rawArithmeticFrameLiveBits_le
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawArithmeticFrameLiveBits_le"
#print axioms CorruptedFieldRecovery.rawArithmeticFrameLiveBits_le

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawArithmeticStackLiveBits_le"
#check @CorruptedFieldRecovery.rawArithmeticStackLiveBits_le
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawArithmeticStackLiveBits_le"
#print axioms CorruptedFieldRecovery.rawArithmeticStackLiveBits_le

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawArithmeticStackLiveBits_le_of_charge"
#check @CorruptedFieldRecovery.rawArithmeticStackLiveBits_le_of_charge
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawArithmeticStackLiveBits_le_of_charge"
#print axioms CorruptedFieldRecovery.rawArithmeticStackLiveBits_le_of_charge
