import Mathlib.Algebra.Polynomial.FieldDivision
import Mathlib.Algebra.Field.ZMod

/-! A small raw-data gate for candidate binary quotient fields.

This validates the polynomial and scalar portion of a serialized field
candidate. It deliberately does not claim to validate the tensor-coordinate
map or its trace/determinant coefficients.
-/

namespace CorruptedFieldRecovery

abbrev RawFieldBits := Array (ZMod 2)

/-- Convert little-endian coefficient bits into a polynomial over `F₂`.
The array itself is the certificate data; out-of-range lookup is never used. -/
def rawBinaryPolynomial (bits : RawFieldBits) : Polynomial (ZMod 2) :=
  ∑ i ∈ Finset.range bits.size, C (bits[i]!) * X ^ i

/-- A serialized polynomial/scalar candidate for a degree-`s` quotient field.
Both arrays use little-endian binary coefficients. -/
structure RawFieldCandidate (s : Nat) where
  modulus : RawFieldBits
  scalar : RawFieldBits

/-- Deterministic recognition gate: exact coefficient-array lengths, a monic
degree-`s` irreducible modulus, and a nonzero scalar residue. The polynomial
predicate is decidable because it is over the finite field `F₂`. -/
def rawFieldCandidateCheck {s : Nat} (p : RawFieldCandidate s) : Bool :=
  decide (p.modulus.size = s + 1) &&
  decide (p.scalar.size = s) &&
  decide ((rawBinaryPolynomial p.modulus).natDegree = s) &&
  decide ((rawBinaryPolynomial p.modulus).Monic) &&
  decide ((rawBinaryPolynomial p.modulus).IsIrreducible) &&
  decide (∃ i ∈ Finset.range p.scalar.size, p.scalar[i]! ≠ 0)

/-- Acceptance gives the exact irreducibility and nonzero claims needed before
interpreting the arrays in a quotient. -/
theorem accepted_rawFieldCandidateCheck {s : Nat} (p : RawFieldCandidate s)
    (h : rawFieldCandidateCheck p = true) :
    p.modulus.size = s + 1 ∧
    p.scalar.size = s ∧
    (rawBinaryPolynomial p.modulus).natDegree = s ∧
    (rawBinaryPolynomial p.modulus).Monic ∧
    (rawBinaryPolynomial p.modulus).IsIrreducible ∧
    (∃ i ∈ Finset.range p.scalar.size, p.scalar[i]! ≠ 0) := by
  simp only [rawFieldCandidateCheck, Bool.and_eq_true] at h
  rcases h with ⟨h₁, h₂, h₃, h₄, h₅, h₆⟩
  exact ⟨of_decide_eq_true h₁, of_decide_eq_true h₂,
    of_decide_eq_true h₃, of_decide_eq_true h₄,
    of_decide_eq_true h₅, of_decide_eq_true h₆⟩

end CorruptedFieldRecovery
