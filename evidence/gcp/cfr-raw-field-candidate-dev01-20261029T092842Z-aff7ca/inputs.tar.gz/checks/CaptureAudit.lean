import CorruptedFieldRecovery
import CorruptedFieldRecovery.RawFieldCandidate

set_option pp.universes true
set_option pp.explicit false
set_option pp.fullNames true
set_option pp.piBinderTypes true
set_option pp.piBinderNames true
set_option pp.piBinderNames.hygienic true
set_option pp.proofs true
set_option pp.deepTerms true
set_option pp.maxSteps 1000000
set_option maxRecDepth 10000

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.RawFieldCandidate"
#check @CorruptedFieldRecovery.RawFieldCandidate
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.RawFieldCandidate"
#print axioms CorruptedFieldRecovery.RawFieldCandidate

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawBinaryPolynomial"
#check @CorruptedFieldRecovery.rawBinaryPolynomial
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawBinaryPolynomial"
#print axioms CorruptedFieldRecovery.rawBinaryPolynomial

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawFieldCandidateCheck"
#check @CorruptedFieldRecovery.rawFieldCandidateCheck
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawFieldCandidateCheck"
#print axioms CorruptedFieldRecovery.rawFieldCandidateCheck

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.accepted_rawFieldCandidateCheck"
#check @CorruptedFieldRecovery.accepted_rawFieldCandidateCheck
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.accepted_rawFieldCandidateCheck"
#print axioms CorruptedFieldRecovery.accepted_rawFieldCandidateCheck
