import CorruptedFieldRecovery.S010BalanceRawInputMatrix
import Mathlib.Tactic

namespace CorruptedFieldRecovery

theorem actualBalanceCoordinateList_length (n : Nat) :
    (actualBalanceCoordinateList n).length = n := by
  simp [actualBalanceCoordinateList]

theorem actualBalanceColumnList_length (s : Nat) :
    (actualBalanceColumnList s).length = (3 * s) * (3 * s) := by
  simp [actualBalanceColumnList, actualBalanceCoordinateList,
    List.length_flatMap, List.length_map]

theorem actualBalanceRowList_length (s : Nat) :
    (actualBalanceRowList s).length = 4 * (3 * s) * (3 * s) := by
  simp [actualBalanceRowList, actualBalanceCoordinateList,
    List.length_flatMap, List.length_map]

theorem actualBalanceSerializedRow_width {s : Nat}
    (A : BinaryTensor (3 * s)) (tape : FiveWordTape s)
    (row : ActualBalanceBasisRow s) :
    (((actualBalanceColumnList s).map fun col =>
      actualBalanceComputableCoefficientMatrix A tape row col).toArray).size =
        (3 * s) * (3 * s) := by
  simp [actualBalanceColumnList_length]

theorem actualBalanceSerializedCoefficientMatrix_exact_outer_size {s : Nat}
    (A : BinaryTensor (3 * s)) (tape : FiveWordTape s) :
    (actualBalanceSerializedCoefficientMatrix A tape).size =
      4 * (3 * s) * (3 * s) := by
  rw [actualBalanceSerializedCoefficientMatrix_outer_size,
    actualBalanceRowList_length]

end CorruptedFieldRecovery