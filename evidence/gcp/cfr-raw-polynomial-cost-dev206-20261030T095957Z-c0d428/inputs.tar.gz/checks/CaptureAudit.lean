import CorruptedFieldRecovery
import CorruptedFieldRecovery.RawPolynomialBitCost

set_option pp.universes true
set_option pp.explicit false
set_option pp.fullNames true
set_option pp.piBinderTypes true
set_option pp.piBinderNames true
set_option pp.piBinderNames.hygienic true
set_option pp.proofs true
set_option pp.deepTerms true
set_option pp.maxSteps 1000000
set_option maxRecDepth 10000

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawNatBitWidth"
#check @CorruptedFieldRecovery.rawNatBitWidth
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawNatBitWidth"
#print axioms CorruptedFieldRecovery.rawNatBitWidth

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawPolyMulBitCosted"
#check @CorruptedFieldRecovery.rawPolyMulBitCosted
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawPolyMulBitCosted"
#print axioms CorruptedFieldRecovery.rawPolyMulBitCosted

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawPolyMulBitCosted_fst"
#check @CorruptedFieldRecovery.rawPolyMulBitCosted_fst
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawPolyMulBitCosted_fst"
#print axioms CorruptedFieldRecovery.rawPolyMulBitCosted_fst

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawPolyMulBitCosted_cost_le"
#check @CorruptedFieldRecovery.rawPolyMulBitCosted_cost_le
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawPolyMulBitCosted_cost_le"
#print axioms CorruptedFieldRecovery.rawPolyMulBitCosted_cost_le
