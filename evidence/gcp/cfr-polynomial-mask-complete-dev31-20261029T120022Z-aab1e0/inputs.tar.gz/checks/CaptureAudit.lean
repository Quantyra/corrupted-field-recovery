import CorruptedFieldRecovery
import CorruptedFieldRecovery.RawPolynomialMaskCompleteness

set_option pp.universes true
set_option pp.explicit false
set_option pp.fullNames true
set_option pp.piBinderTypes true
set_option pp.piBinderNames true
set_option pp.piBinderNames.hygienic true
set_option pp.proofs true
set_option pp.deepTerms true
set_option pp.maxSteps 1000000
set_option maxRecDepth 10000

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.zmodTwo_eq_zero_or_one"
#check @CorruptedFieldRecovery.zmodTwo_eq_zero_or_one
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.zmodTwo_eq_zero_or_one"
#print axioms CorruptedFieldRecovery.zmodTwo_eq_zero_or_one

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawPolynomialBitsFuel_decode"
#check @CorruptedFieldRecovery.rawPolynomialBitsFuel_decode
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawPolynomialBitsFuel_decode"
#print axioms CorruptedFieldRecovery.rawPolynomialBitsFuel_decode

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawPolynomialBits_decode"
#check @CorruptedFieldRecovery.rawPolynomialBits_decode
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawPolynomialBits_decode"
#print axioms CorruptedFieldRecovery.rawPolynomialBits_decode
