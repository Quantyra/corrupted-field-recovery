import CorruptedFieldRecovery.RawCoefficientFitAugmentedSolverBridge
import CorruptedFieldRecovery.S010BalanceGaussianKernelUniqueness

/-! # Affine fit, augmented kernel, and deterministic free-vector extraction

This draft proves the generic algebraic bridge needed by the raw fit system:
`A x = b` is equivalent over `ZMod 2` to a null vector of the matrix with `b`
as its last column and final coordinate one. It then specifies a deterministic
first-passing scan over the actual free-kernel candidates, and proves that a
consistent system has such a candidate. The compact increasing-triple fit
still needs a proved equivalence to its zero-padded finite system, and the
manuscript-specific consistency premise is not established here.
-/

namespace CorruptedFieldRecovery

/-- Append a vector as the last matrix column, so `Fin.snoc x 1` tests the
affine equation. -/
def rawLastColumnAugmentedMatrix {m n : Nat}
    (A : Matrix (Fin m) (Fin n) (ZMod 2)) (rhs : Fin m → ZMod 2) :
    Matrix (Fin m) (Fin (n + 1)) (ZMod 2) := fun row column =>
  Fin.lastCases (rhs row) (fun j => A row j) column

/-- Finite affine system represented by a rectangular matrix and RHS. -/
def RawFiniteAffineSolution {m n : Nat}
    (A : Matrix (Fin m) (Fin n) (ZMod 2)) (rhs : Fin m → ZMod 2) : Prop :=
  ∃ x : Fin n → ZMod 2, A *ᵥ x = rhs

/-- Multiplying a last-column augmented matrix by `Fin.snoc x 1` produces the
original matrix product plus the appended RHS. -/
theorem rawLastColumnAugmentedMatrix_mulVec_snoc {m n : Nat}
    (A : Matrix (Fin m) (Fin n) (ZMod 2)) (rhs : Fin m → ZMod 2)
    (x : Fin n → ZMod 2) :
    rawLastColumnAugmentedMatrix A rhs *ᵥ Fin.snoc x 1 = A *ᵥ x + rhs := by
  funext row
  simp [rawLastColumnAugmentedMatrix, Matrix.mulVec, dotProduct,
    Fin.sum_univ_castSucc, Fin.snoc_castSucc, Fin.snoc_last,
    Fin.val_castSucc, Fin.val_last]
  ring

/-- Exact augmented-kernel characterization. This statement is independent
of the matrix's origin; it applies to the flattened fit matrix once its compact
source-indexed correspondence is proved. -/
theorem rawLastColumnAugmentedMatrix_affine_iff {m n : Nat}
    (A : Matrix (Fin m) (Fin n) (ZMod 2)) (rhs : Fin m → ZMod 2) :
    RawFiniteAffineSolution A rhs ↔
      ∃ z : Fin (n + 1) → ZMod 2,
        rawLastColumnAugmentedMatrix A rhs *ᵥ z = 0 ∧ z (Fin.last n) = 1 := by
  constructor
  · rintro ⟨x, hx⟩
    refine ⟨Fin.snoc x 1, ?_, ?_⟩
    · rw [rawLastColumnAugmentedMatrix_mulVec_snoc, hx]
      apply funext
      intro row
      exact ZModModule.add_self (rhs row)
    · simp
  · rintro ⟨z, hz, hlast⟩
    let x : Fin n → ZMod 2 := fun j => z j.castSucc
    have hzdecomp : z = Fin.snoc x 1 := by
      funext j
      refine Fin.lastCases ?_ ?_ j
      · simpa [x] using hlast
      · intro i
        rfl
    refine ⟨x, ?_⟩
    have hsum : A *ᵥ x + rhs = 0 := by
      rw [hzdecomp, rawLastColumnAugmentedMatrix_mulVec_snoc] at hz
      exact hz
    apply funext
    intro row
    have hrow := congrFun hsum row
    calc
      (A *ᵥ x) row = (A *ᵥ x) row + 0 := by simp
      _ = (A *ᵥ x) row + (rhs row + rhs row) := by
        rw [ZModModule.add_self]
        simp
      _ = ((A *ᵥ x) row + rhs row) + rhs row := by
        rw [← add_assoc]
      _ = 0 + rhs row := by rw [hrow]
      _ = rhs row := by simp

/-- The compact raw fit's zero-padded rectangular system. -/
def rawCoefficientFitFiniteRhsVector {s : Nat} :
    RawCoefficientArray → Fin (((3 * s) * (3 * s)) * (3 * s)) → ZMod 2 :=
  fun raw row => rawCoefficientFitFiniteRhs raw row

def RawCoefficientFitFiniteSystemSolution {s d : Nat}
    (candidate : RawFieldCandidate s)
    (hcheck : rawFieldCandidateCheck candidate = true)
    (inverse : RawCoordinateMatrix) (supportMatrix : RawBinaryArray)
    (raw : RawCoefficientArray) : Prop :=
  RawFiniteAffineSolution
    (rawCoefficientFitFiniteMatrix candidate hcheck inverse supportMatrix)
    (rawCoefficientFitFiniteRhsVector raw)

/-- Serialization/coordinate conditions required to interpret the finite
matrix entries as the manuscript's raw input and supplied physical
coordinates. These conditions do not assert that the affine fit is
consistent. -/
def RawCoefficientFitExecutionShape {s d : Nat}
    (forward inverse : RawCoordinateMatrix) (supportMatrix : RawBinaryArray)
    (raw : RawCoefficientArray) : Prop :=
  raw.size = ((3 * s) * (3 * s)) * (3 * s) ∧
  supportMatrix.size = (3 * s) * d ∧
  rawCoordinateMatrixCheck (n := 3 * s) forward inverse = true

/-- The exact bridge still needed between the compact fit sum and its
zero-padded all-triples finite equation. Its proof must extend coefficients
by zero on invalid support triples and use the one-hot row enumeration; it is
not supplied as a premise to the extraction theorem below. -/
def RawCoefficientFitCompactFiniteEquivalenceTarget {s d : Nat}
    (candidate : RawFieldCandidate s)
    (hcheck : rawFieldCandidateCheck candidate = true)
    (inverse : RawCoordinateMatrix) (supportMatrix : RawBinaryArray)
    (raw : RawCoefficientArray) : Prop :=
  RawCoefficientFitAffineSolution candidate hcheck inverse supportMatrix raw ↔
    RawCoefficientFitFiniteSystemSolution candidate hcheck inverse
      supportMatrix raw

/-- Last-column augmented version of the finite raw fit. This uses `Fin.last`
directly, matching the affine extraction theorem and avoiding an implicit
permutation of the RHS coordinate. -/
def rawCoefficientFitLastAugmentedMatrix {s d : Nat}
    (candidate : RawFieldCandidate s)
    (hcheck : rawFieldCandidateCheck candidate = true)
    (inverse : RawCoordinateMatrix) (supportMatrix : RawBinaryArray)
    (raw : RawCoefficientArray) :
    Matrix (Fin (((3 * s) * (3 * s)) * (3 * s)))
      (Fin ((s + (d * d) * d) + 1)) (ZMod 2) :=
  rawLastColumnAugmentedMatrix
    (rawCoefficientFitFiniteMatrix candidate hcheck inverse supportMatrix)
    (rawCoefficientFitFiniteRhsVector raw)

/-- The deterministic full-column matrix scan used for affine extraction. -/
def rawCoefficientFitLastAugmentedMatrixScan {s d : Nat}
    (candidate : RawFieldCandidate s)
    (hcheck : rawFieldCandidateCheck candidate = true)
    (inverse : RawCoordinateMatrix) (supportMatrix : RawBinaryArray)
    (raw : RawCoefficientArray) :=
  balanceGaussianColumnScan
    (rawCoefficientFitLastAugmentedMatrix candidate hcheck inverse
      supportMatrix raw)
    ∅ (List.ofFn fun column : Fin ((s + (d * d) * d) + 1) => column)

/-- Actual free columns in deterministic scan order. -/
def rawCoefficientFitFreeIndices {m n : Nat}
    (pivots : List (Fin m × Fin n)) : List (balanceGaussianFreeIndex pivots) :=
  (List.ofFn fun column : Fin n => column).filterMap fun column =>
    if hfree : column ∉ pivots.map Prod.snd then some ⟨column, hfree⟩ else none

/-- Deterministic left-to-right Boolean selection. -/
def rawFitFirstPassing {α : Type} (test : α → Bool) : List α → Option α
  | [] => none
  | x :: xs => if test x then some x else rawFitFirstPassing test xs

private theorem rawFitFirstPassing_complete {α : Type}
    (test : α → Bool) (xs : List α)
    (hex : ∃ x, x ∈ xs ∧ test x = true) :
    ∃ x, rawFitFirstPassing test xs = some x ∧ test x = true := by
  induction xs with
  | nil => simpa using hex
  | cons a xs ih =>
      by_cases ha : test a = true
      · exact ⟨a, by simp [rawFitFirstPassing, ha], ha⟩
      · rcases hex with ⟨x, hx, htest⟩
        rcases List.mem_cons.mp hx with hxa | hxtail
        · subst x
          simp [ha] at htest
        · obtain ⟨found, hfound, hfoundTest⟩ := ih ⟨x, hxtail, htest⟩
          exact ⟨found, by simp [rawFitFirstPassing, ha, hfound], hfoundTest⟩

/-- A free-column candidate has the expected identity coefficient on its
own free coordinate, so the ordered filtered list includes every subtype
free index. -/
theorem rawCoefficientFitFreeIndices_complete {m n : Nat}
    (pivots : List (Fin m × Fin n)) (free : balanceGaussianFreeIndex pivots) :
    free ∈ rawCoefficientFitFreeIndices pivots := by
  simp [rawCoefficientFitFreeIndices, free.property]

/-- Every candidate produced by a full deterministic scan is a kernel vector.
This is the generic row-operation/kernel bridge already proved for the
accepted Gaussian chain. -/
theorem rawFullScanFreeCandidate_mem_kernel {m n : Nat}
    (A : Matrix (Fin m) (Fin n) (ZMod 2))
    (free : balanceGaussianFreeIndex
      (balanceGaussianColumnScan A ∅ (List.ofFn fun j : Fin n => j)).2) :
    A *ᵥ balanceGaussianFreeCandidateFamily
      (balanceGaussianColumnScan A ∅ (List.ofFn fun j : Fin n => j)).1
      (balanceGaussianColumnScan A ∅ (List.ofFn fun j : Fin n => j)).2 free = 0 := by
  let columns := List.ofFn (fun j : Fin n => j)
  let run := balanceGaussianColumnScan A ∅ columns
  have hrows : (run.2.map Prod.fst).Nodup := by
    simpa [run, columns] using balanceGaussianColumnScan_pivotRows_nodup columns A ∅
  have hunit : ∀ pivot ∈ run.2, ∀ i,
      run.1 i pivot.2 = if i = pivot.1 then 1 else 0 := by
    intro pivot hpivot i
    exact balanceGaussianColumnScan_recordedPivots_unit columns A ∅ pivot hpivot i
  have hzero : ∀ i, i ∉ run.2.map Prod.fst → run.1 i = 0 := by
    intro i hi
    funext column
    exact balanceGaussianFullColumnScan_unusedRows_zero A i hi column
  have hred := balanceGaussianFreeKernelCandidate_mem_ker
    run.1 run.2 free.1 free.2 hrows hunit (by
      intro i hi
      exact congrFun (hzero i hi) free.1)
  exact (balanceGaussianColumnScan_kernel_iff columns A ∅
    (balanceGaussianFreeCandidateFamily run.1 run.2 free)).mp
      (by simpa [run] using hred)

/-- If the augmented fit system is consistent, some explicit free-kernel
candidate has affine coordinate one. This follows by expanding a witness in
the full scan's free-candidate family; it does not assume that the scan has
already returned a solution. -/
theorem rawFullScanAffineCandidate_exists {m n : Nat}
    (A : Matrix (Fin m) (Fin (n + 1)) (ZMod 2))
    (hwitness : ∃ x, A *ᵥ x = 0 ∧ x (Fin.last n) = 1) :
    ∃ free : balanceGaussianFreeIndex
        (balanceGaussianColumnScan A ∅
          (List.ofFn fun j : Fin (n + 1) => j)).2,
      balanceGaussianFreeCandidateFamily
        (balanceGaussianColumnScan A ∅
          (List.ofFn fun j : Fin (n + 1) => j)).1
        (balanceGaussianColumnScan A ∅
          (List.ofFn fun j : Fin (n + 1) => j)).2 free (Fin.last n) = 1 := by
  classical
  rcases hwitness with ⟨x, hxker, hlast⟩
  let run := balanceGaussianColumnScan A ∅
    (List.ofFn fun j : Fin (n + 1) => j)
  have hrepr := balanceGaussianFullColumnScan_candidates_reconstruct A x hxker
  by_contra hnone
  have hzeros : ∀ free : balanceGaussianFreeIndex run.2,
      balanceGaussianFreeCandidateFamily run.1 run.2 free (Fin.last n) = 0 := by
    intro free
    have hval : balanceGaussianFreeCandidateFamily run.1 run.2 free (Fin.last n) = 0 ∨
        balanceGaussianFreeCandidateFamily run.1 run.2 free (Fin.last n) = 1 := by
      fin_cases balanceGaussianFreeCandidateFamily run.1 run.2 free (Fin.last n) <;> simp
    rcases hval with hzero | hone
    · exact hzero
    · exact False.elim (hnone ⟨free, by simpa [run] using hone⟩)
  have hlastEq := congrFun hrepr (Fin.last n)
  rw [hlast] at hlastEq
  simp [run, Finset.sum_apply, hzeros] at hlastEq

/-- Scan-order selection of a free candidate whose final affine coordinate is
one. The function returns `none` when no such candidate exists; no failure
case is silently replaced by a fabricated fit. -/
def rawCoefficientFitSelectAffineFreeIndex {m n : Nat}
    (A : Matrix (Fin m) (Fin (n + 1)) (ZMod 2)) :
    Option (balanceGaussianFreeIndex
      (balanceGaussianColumnScan A ∅
        (List.ofFn fun j : Fin (n + 1) => j)).2) :=
  let run := balanceGaussianColumnScan A ∅
    (List.ofFn fun j : Fin (n + 1) => j)
  rawFitFirstPassing
    (fun free => decide (balanceGaussianFreeCandidateFamily run.1 run.2 free
      (Fin.last n) = 1))
    (rawCoefficientFitFreeIndices run.2)

/-- A consistent augmented fit has a deterministically selected free vector
with final coordinate one. -/
theorem rawCoefficientFitSelectAffineFreeIndex_some {m n : Nat}
    (A : Matrix (Fin m) (Fin (n + 1)) (ZMod 2))
    (hwitness : ∃ x, A *ᵥ x = 0 ∧ x (Fin.last n) = 1) :
    ∃ free, rawCoefficientFitSelectAffineFreeIndex A = some free ∧
      balanceGaussianFreeCandidateFamily
        (balanceGaussianColumnScan A ∅
          (List.ofFn fun j : Fin (n + 1) => j)).1
        (balanceGaussianColumnScan A ∅
          (List.ofFn fun j : Fin (n + 1) => j)).2 free (Fin.last n) = 1 := by
  let run := balanceGaussianColumnScan A ∅
    (List.ofFn fun j : Fin (n + 1) => j)
  obtain ⟨free, hfree⟩ := rawFullScanAffineCandidate_exists A hwitness
  have hmem := rawCoefficientFitFreeIndices_complete run.2 free
  have htest : decide
      (balanceGaussianFreeCandidateFamily run.1 run.2 free (Fin.last n) = 1) = true :=
    of_decide_eq_true hfree
  obtain ⟨found, hfound, hfoundTest⟩ := rawFitFirstPassing_complete
    (fun free => decide (balanceGaussianFreeCandidateFamily run.1 run.2 free
      (Fin.last n) = 1))
    (rawCoefficientFitFreeIndices run.2) ⟨free, hmem, htest⟩
  refine ⟨found, ?_, of_decide_eq_true hfoundTest⟩
  simpa [rawCoefficientFitSelectAffineFreeIndex, run] using hfound

/-- Concrete affine output for the flattened fit. The coefficients occupy
the first `s+d^3` entries; the final entry is fixed to one. -/
def rawCoefficientFitDeterministicOutput {s d : Nat}
    (candidate : RawFieldCandidate s)
    (hcheck : rawFieldCandidateCheck candidate = true)
    (inverse : RawCoordinateMatrix) (supportMatrix : RawBinaryArray)
    (raw : RawCoefficientArray) :
    Option (Fin (s + (d * d) * d) → ZMod 2) :=
  let A := rawCoefficientFitLastAugmentedMatrix candidate hcheck inverse
    supportMatrix raw
  let run := balanceGaussianColumnScan A ∅
    (List.ofFn fun j : Fin ((s + (d * d) * d) + 1) => j)
  match rawCoefficientFitSelectAffineFreeIndex A with
  | none => none
  | some free =>
      let witness := balanceGaussianFreeCandidateFamily run.1 run.2 free
      some (fun j => witness j.castSucc)

/-- Conditional correctness of the deterministic output. The sole premise is
consistency of the padded finite affine fit. The conclusion is about that
finite system; compact-column projection and manuscript fit consistency are
separate remaining bridges. -/
theorem rawCoefficientFitDeterministicOutput_spec {s d : Nat}
    (candidate : RawFieldCandidate s)
    (hcheck : rawFieldCandidateCheck candidate = true)
    (forward inverse : RawCoordinateMatrix) (supportMatrix : RawBinaryArray)
    (raw : RawCoefficientArray)
    (hinputShape : RawCoefficientFitExecutionShape forward inverse supportMatrix raw)
    (hconsistent : RawCoefficientFitFiniteSystemSolution candidate hcheck
      inverse supportMatrix raw) :
    ∃ coefficients,
      rawCoefficientFitDeterministicOutput candidate hcheck inverse
        supportMatrix raw = some coefficients ∧
      rawCoefficientFitFiniteMatrix candidate hcheck inverse supportMatrix
          *ᵥ coefficients = rawCoefficientFitFiniteRhsVector raw ∧
      RawCoefficientFitExecutionShape forward inverse supportMatrix raw := by
  classical
  let A := rawCoefficientFitLastAugmentedMatrix candidate hcheck inverse
    supportMatrix raw
  obtain ⟨x, hx⟩ := hconsistent
  have hwitness : ∃ z, A *ᵥ z = 0 ∧
      z (Fin.last (s + (d * d) * d)) = 1 :=
    (rawLastColumnAugmentedMatrix_affine_iff
      (rawCoefficientFitFiniteMatrix candidate hcheck inverse supportMatrix)
      (rawCoefficientFitFiniteRhsVector raw)).mp ⟨x, hx⟩
  obtain ⟨free, hselected, hlast⟩ := rawCoefficientFitSelectAffineFreeIndex_some A hwitness
  let run := balanceGaussianColumnScan A ∅
    (List.ofFn fun j : Fin ((s + (d * d) * d) + 1) => j)
  let witness := balanceGaussianFreeCandidateFamily run.1 run.2 free
  let coefficients : Fin (s + (d * d) * d) → ZMod 2 := fun j => witness j.castSucc
  have hker : A *ᵥ witness = 0 := by
    exact rawFullScanFreeCandidate_mem_kernel A free
  have hfit : rawCoefficientFitFiniteMatrix candidate hcheck inverse supportMatrix
      *ᵥ coefficients = rawCoefficientFitFiniteRhsVector raw := by
    have hfinite := (rawLastColumnAugmentedMatrix_affine_iff
      (rawCoefficientFitFiniteMatrix candidate hcheck inverse supportMatrix)
      (rawCoefficientFitFiniteRhsVector raw)).mpr
        ⟨witness, by simpa [A] using hker, by simpa [witness] using hlast⟩
    rcases hfinite with ⟨x, hx⟩
    have hxeq : x = coefficients := by
      funext j
      rfl
    simpa [hxeq] using hx
  refine ⟨coefficients, ?_, hfit, hinputShape⟩
  simp [rawCoefficientFitDeterministicOutput, A, run, witness, coefficients,
    hselected]

end CorruptedFieldRecovery
