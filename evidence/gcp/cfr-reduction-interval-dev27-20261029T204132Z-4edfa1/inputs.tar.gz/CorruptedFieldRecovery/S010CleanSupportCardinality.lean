import CorruptedFieldRecovery.TraceDualTranslateBridge
import CorruptedFieldRecovery.ProperSubfieldCounts
import Mathlib.LinearAlgebra.Dual.Lemmas
import Mathlib.LinearAlgebra.FiniteDimensional.Lemmas
import Mathlib.Data.Finset.Card
import Mathlib.Tactic

namespace CorruptedFieldRecovery

noncomputable section

/-- Transport the binary covector support coordinates to the semantic dual
using the trace pairing. The characteristic-two identification is explicit. -/
def traceSupportDual {K : Type*} [Field K] [Finite K] [CharP K 2]
    [Algebra BinaryField K] [Algebra (ZMod (ringChar K)) K]
    (U : Submodule BinaryField (FieldTriple K)) :
    Submodule BinaryField (Module.Dual BinaryField (FieldTriple K)) := by
  have hchar : ringChar K = 2 := ringChar.eq K 2
  let e₀ := fieldTripleTraceDualEquiv K
  have e : FieldTriple K ≃ₗ[BinaryField]
      Module.Dual BinaryField (FieldTriple K) := by
    simpa [BinaryField, hchar] using e₀
  exact Submodule.map e.toLinearMap U

/-- Semantic clean vectors are the common kernel of the support covectors. -/
def cleanSupportSet {K : Type*} [Field K] [Finite K] [CharP K 2]
    [Algebra BinaryField K] [Algebra (ZMod (ringChar K)) K]
    [Fintype (FieldTriple K)] [DecidableEq (FieldTriple K)]
    (U : Submodule BinaryField (FieldTriple K)) : Finset (FieldTriple K) :=
  Finset.univ.filter fun x =>
    x ∈ (traceSupportDual U).dualCoannihilator

/-- The clean-set cardinality follows from the trace-dual equivalence and the
codimension formula for a dual coannihilator; no desired probability bound is
assumed. -/
theorem cleanSupportSet_card
    (K : Type*) [Field K] [Finite K] [CharP K 2]
    [Algebra BinaryField K] [Algebra (ZMod (ringChar K)) K]
    [Fintype K] [DecidableEq K]
    (s r : Nat) (hs : Module.finrank BinaryField K = s)
    (U : Submodule BinaryField (FieldTriple K))
    (hU : Module.finrank BinaryField U = r) :
    (cleanSupportSet K U).card = 2 ^ (3 * s - r) := by
  classical
  let W := traceSupportDual U
  let A := cleanSupportSet K U
  have hW : Module.finrank BinaryField W = r := by
    rw [W, traceSupportDual]
    have hchar : ringChar K = 2 := ringChar.eq K 2
    let e₀ := fieldTripleTraceDualEquiv K
    have e : FieldTriple K ≃ₗ[BinaryField]
        Module.Dual BinaryField (FieldTriple K) := by
      simpa [BinaryField, hchar] using e₀
    rw [e.finrank_map_eq]
    exact hU
  have hV : Module.finrank BinaryField (FieldTriple K) = 3 * s := by
    rw [FieldTriple, Module.finrank_prod, Module.finrank_prod, hs]
    omega
  have hcoann : Module.finrank BinaryField W.dualCoannihilator = 3 * s - r := by
    have hsum := Subspace.finrank_add_finrank_dualCoannihilator_eq W
    rw [hW, hV] at hsum
    omega
  have hcardV : Fintype.card W.dualCoannihilator = 2 ^ (3 * s - r) := by
    rw [Module.card_eq_pow_finrank, hcoann]
    norm_num
  have hcardA : A.card = Fintype.card W.dualCoannihilator := by
    dsimp [A, cleanSupportSet, W]
    rw [Fintype.card_subtype]
  rw [hcardA, hcardV]

end

end CorruptedFieldRecovery