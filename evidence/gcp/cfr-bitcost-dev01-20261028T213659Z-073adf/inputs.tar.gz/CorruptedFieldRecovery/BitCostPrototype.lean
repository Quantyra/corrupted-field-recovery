import Lean.Elab.Tactic.Omega

/-!
An executable, scoped bit-cost prototype for little-endian ripple addition.

This file gives an explicit *RAM-state interpretation* and charges every
modeled read, write/allocation, Boolean gate, index-bit operation, and program
fetch.  The Lean implementation below uses lists and structural recursion;
this file does not prove a refinement from Lean's runtime representation (or
its recursion stack and list allocation) to the declared RAM storage measure.
In particular, no implementation-space or manuscript-level asymptotic claim
is made here.
-/

namespace CorruptedFieldRecovery.BitCostPrototype

abbrev Word := List Bool

def bitVal (b : Bool) : Nat := if b then 1 else 0

def xorBit (a b : Bool) : Bool := decide (a ≠ b)

def andBit (a b : Bool) : Bool := a && b

def orBit (a b : Bool) : Bool := a || b

/-- The one-bit full-adder circuit: two XORs, two ANDs and one OR. -/
def fullAdder (x y carry : Bool) : Bool × Bool :=
  let p := xorBit x y
  let sum := xorBit p carry
  let carryOut := orBit (andBit x y) (andBit carry p)
  (sum, carryOut)

/-- The exact integer equation for the represented five-gate full adder. -/
theorem fullAdder_correct (x y carry : Bool) :
    bitVal x + bitVal y + bitVal carry =
      bitVal (fullAdder x y carry).1 + 2 * bitVal (fullAdder x y carry).2 := by
  cases x <;> cases y <;> cases carry <;>
    decide

/-- Interpret a little-endian bit list as a natural number. -/
def value : Word → Nat
  | [] => 0
  | b :: bs => bitVal b + 2 * value bs

/-- Execute one ripple stage.  The two heads are the represented bit reads;
the full-adder gates execute on those bits, and cons writes/allocates the
output bit before continuing with the next address. -/
def ripple : Word → Word → Bool → Word × Bool
  | [], [], carry => ([], carry)
  | x :: xs, y :: ys, carry =>
      let gate := fullAdder x y carry
      let rest := ripple xs ys gate.2
      (gate.1 :: rest.1, rest.2)
  | _, _, carry => ([], carry)
termination_by xs ys carry => xs.length
decreasing_by all_goals simp_wf

theorem ripple_correct (xs ys : Word) (carry : Bool)
    (hLen : xs.length = ys.length) :
    value xs + value ys + bitVal carry =
      value (ripple xs ys carry).1 +
        2 ^ xs.length * bitVal (ripple xs ys carry).2 := by
  induction xs generalizing ys carry with
  | nil =>
      cases ys with
      | nil => simp [ripple, value]
      | cons y ys => simp at hLen
  | cons x xs ih =>
      cases ys with
      | nil => simp at hLen
      | cons y ys =>
          have hTail : xs.length = ys.length := by
            simpa using hLen
          let gate := fullAdder x y carry
          have hGate := fullAdder_correct x y carry
          have hRest := ih ys gate.2 hTail
          simp only [ripple, value, gate]
          dsimp [gate] at hGate hRest ⊢
          omega

/-- Number of bits needed to name any address in a length-k word. -/
def addressWidth (k : Nat) : Nat := Nat.log2 (k + 1) + 1

/-- A visible counter for the six primitive families in this prototype.
`reads` counts two input-bit reads per stage; `writes` counts one output-bit
allocation/write; `gates` counts the five Boolean gates; `controlBits` charges
address, loop-counter and instruction-fetch work at their represented bit
width. -/
structure Charge where
  reads : Nat
  writes : Nat
  gates : Nat
  controlBits : Nat
  deriving Repr, DecidableEq

def Charge.total (c : Charge) : Nat :=
  c.reads + c.writes + c.gates + c.controlBits

def Charge.add (a b : Charge) : Charge :=
  ⟨a.reads + b.reads, a.writes + b.writes, a.gates + b.gates,
    a.controlBits + b.controlBits⟩

/-- Cost of the represented instruction sequence at one address. Four
address-width passes account for two reads, the output write, and loop/index
plus instruction-fetch manipulation. -/
def stageCharge (k : Nat) : Charge :=
  ⟨2, 1, 5, 4 * addressWidth k⟩

/-- The program is run over equal-length inputs. Its result contains only the
output word, final carry, and the accumulated primitive charge. -/
structure RunResult where
  output : Word
  finalCarry : Bool
  charge : Charge
  deriving Repr, DecidableEq

def run : Word → Word → Bool → RunResult
  | [], [], carry => ⟨[], carry, ⟨0, 0, 0, 0⟩⟩
  | x :: xs, y :: ys, carry =>
      let gate := fullAdder x y carry
      let rest := run xs ys gate.2
      ⟨gate.1 :: rest.output, rest.finalCarry,
        Charge.add (stageCharge (xs.length + 1)) rest.charge⟩
  | _, _, carry => ⟨[], carry, ⟨0, 0, 0, 0⟩⟩
termination_by xs ys carry => xs.length
decreasing_by all_goals simp_wf

theorem run_correct (xs ys : Word) (carry : Bool)
    (hLen : xs.length = ys.length) :
    value xs + value ys + bitVal carry =
      value (run xs ys carry).output +
        2 ^ xs.length * bitVal (run xs ys carry).finalCarry := by
  simpa [run] using ripple_correct xs ys carry hLen

/-- Inductively executable charge accumulation for the actual `run` program. -/
theorem run_charge_counts (xs ys : Word) (carry : Bool)
    (hLen : xs.length = ys.length) :
    (run xs ys carry).charge.reads = 2 * xs.length ∧
    (run xs ys carry).charge.writes = xs.length ∧
    (run xs ys carry).charge.gates = 5 * xs.length ∧
    (run xs ys carry).charge.controlBits =
      4 * addressWidth xs.length * xs.length := by
  induction xs generalizing ys carry with
  | nil =>
      cases ys with
      | nil => simp [run]
      | cons y ys => simp at hLen
  | cons x xs ih =>
      cases ys with
      | nil => simp at hLen
      | cons y ys =>
          have hTail : xs.length = ys.length := by simpa using hLen
          have h := ih ys (fullAdder x y carry).2 hTail
          simp only [run, Charge.add] at h ⊢
          rcases h with ⟨hr, hw, hg, hc⟩
          simp [stageCharge, addressWidth, hr, hw, hg, hc]
          omega

/-- Explicit RAM live bits for the current represented state: the two retained
input words, the output prefix, carry, binary loop index and fixed instruction
representation. The finite control code is charged as an explicit constant. -/
def currentLiveBits (inputWidth outputPrefix programBits : Nat) : Nat :=
  2 * inputWidth + outputPrefix + 1 + addressWidth inputWidth + programBits

/-- A conservative peak for this append-only output program. -/
def peakLiveBits (k programBits : Nat) : Nat :=
  currentLiveBits k k programBits

theorem currentLiveBits_le_peak (k outLen programBits : Nat)
    (hOut : outLen ≤ k) :
    currentLiveBits k outLen programBits ≤ peakLiveBits k programBits := by
  simp [currentLiveBits, peakLiveBits]
  omega

theorem run_charge_total_bound (xs ys : Word) (carry : Bool)
    (hLen : xs.length = ys.length) :
    (run xs ys carry).charge.total ≤
      xs.length * (8 + 4 * addressWidth xs.length) := by
  have h := run_charge_counts xs ys carry hLen
  rcases h with ⟨hr, hw, hg, hc⟩
  simp [Charge.total, hr, hw, hg, hc]
  omega

/-! ### Representation boundary

`run_charge_counts` proves the exact charge of this executable source-level
program and `currentLiveBits_le_peak` proves the bound for the declared RAM
state interpretation.  The following obligations remain open: a refinement
from this list/recursive Lean implementation to finite mutable arrays; the
cost of Lean list allocation, closure sharing, and recursion stack; and a
proof that those runtime objects fit the declared `currentLiveBits` measure.
Therefore this prototype supplies neither an implementation-space bound nor a
general finite-array machine theorem.  It only validates the arithmetic and
charge interface for the represented ripple program.
-/

end CorruptedFieldRecovery.BitCostPrototype
