import CorruptedFieldRecovery
import CorruptedFieldRecovery.BitCostPrototype

set_option pp.universes true
set_option pp.explicit true
set_option pp.fullNames true

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.BitCostPrototype.fullAdder_correct"
#check @CorruptedFieldRecovery.BitCostPrototype.fullAdder_correct
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.BitCostPrototype.fullAdder_correct"
#print axioms CorruptedFieldRecovery.BitCostPrototype.fullAdder_correct

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.BitCostPrototype.ripple_correct"
#check @CorruptedFieldRecovery.BitCostPrototype.ripple_correct
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.BitCostPrototype.ripple_correct"
#print axioms CorruptedFieldRecovery.BitCostPrototype.ripple_correct

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.BitCostPrototype.run_correct"
#check @CorruptedFieldRecovery.BitCostPrototype.run_correct
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.BitCostPrototype.run_correct"
#print axioms CorruptedFieldRecovery.BitCostPrototype.run_correct

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.BitCostPrototype.run_charge_counts"
#check @CorruptedFieldRecovery.BitCostPrototype.run_charge_counts
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.BitCostPrototype.run_charge_counts"
#print axioms CorruptedFieldRecovery.BitCostPrototype.run_charge_counts

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.BitCostPrototype.currentLiveBits_le_peak"
#check @CorruptedFieldRecovery.BitCostPrototype.currentLiveBits_le_peak
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.BitCostPrototype.currentLiveBits_le_peak"
#print axioms CorruptedFieldRecovery.BitCostPrototype.currentLiveBits_le_peak

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.BitCostPrototype.run_charge_total_bound"
#check @CorruptedFieldRecovery.BitCostPrototype.run_charge_total_bound
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.BitCostPrototype.run_charge_total_bound"
#print axioms CorruptedFieldRecovery.BitCostPrototype.run_charge_total_bound
