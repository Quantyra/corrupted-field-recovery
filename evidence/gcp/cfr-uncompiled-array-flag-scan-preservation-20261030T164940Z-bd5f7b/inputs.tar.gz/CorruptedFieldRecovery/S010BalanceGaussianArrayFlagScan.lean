import CorruptedFieldRecovery.S010BalanceGaussianArrayDeterministicScan

open scoped Matrix

namespace CorruptedFieldRecovery

/-- Read one used-row bit. Missing positions default to `false`; the
algorithm's initializer and update preserve an array of exactly `m` bits. -/
def actualBalanceGaussianUsedFlagView {m : Nat}
    (flags : Array Bool) (row : Fin m) : Bool :=
  (flags[row.val]?.getD false)

/-- Set one used-row bit by rebuilding a fixed-length Boolean array. This
avoids the opaque `Finset` membership and insertion operations in the
computational path, at the cost of `m` bit tests/writes per successful pivot. -/
def actualBalanceGaussianSetUsedFlag {m : Nat}
    (flags : Array Bool) (row : Fin m) : Array Bool :=
  Array.ofFn fun i : Fin m =>
    if i = row then true else actualBalanceGaussianUsedFlagView flags i

theorem actualBalanceGaussianSetUsedFlag_view {m : Nat}
    (flags : Array Bool) (row i : Fin m) :
    actualBalanceGaussianUsedFlagView
      (actualBalanceGaussianSetUsedFlag flags row) i =
        if i = row then true else actualBalanceGaussianUsedFlagView flags i := by
  simp [actualBalanceGaussianSetUsedFlag, actualBalanceGaussianUsedFlagView]

/-- Deterministic first-unused-pivot search using a Boolean flag array and
the nested coefficient-array view. The row order is the standard `Fin` order. -/
def actualBalanceGaussianFlagFirstUnusedPivotRow {m n : Nat}
    (cells : Array (Array (ZMod 2))) (flags : Array Bool)
    (column : Fin n) : Option (Fin m) :=
  (List.ofFn fun row : Fin m => row).find? fun row =>
    decide ((if actualBalanceGaussianUsedFlagView flags row then
      (0 : ZMod 2) else actualBalanceGaussianArrayView cells row column) = 1)

/-- If the flag array represents a used-row set, its pivot search is exactly
the accepted deterministic matrix selector. -/
theorem actualBalanceGaussianFlagFirstUnusedPivotRow_eq
    {m n : Nat} (cells : Array (Array (ZMod 2))) (flags : Array Bool)
    (column : Fin n) (used : Finset (Fin m))
    (hflags : ∀ row, actualBalanceGaussianUsedFlagView flags row =
      decide (row ∈ used)) :
    actualBalanceGaussianFlagFirstUnusedPivotRow cells flags column =
      balanceFirstUnusedPivotRow (actualBalanceGaussianArrayView cells)
        column used := by
  unfold actualBalanceGaussianFlagFirstUnusedPivotRow
    balanceFirstUnusedPivotRow balanceFirstPivotRow
  congr 1
  funext row
  by_cases hu : row ∈ used
  · simp [hflags row, hu, balanceMaskUsedRows]
  · simp [hflags row, hu, balanceMaskUsedRows]

/-- Initialize all used-row flags to false. -/
def actualBalanceGaussianEmptyUsedFlags (m : Nat) : Array Bool :=
  Array.ofFn fun _ : Fin m => false

theorem actualBalanceGaussianEmptyUsedFlags_correct {m : Nat} :
    ∀ row : Fin m,
      actualBalanceGaussianUsedFlagView
        (actualBalanceGaussianEmptyUsedFlags m) row = decide (row ∈ (∅ : Finset (Fin m))) := by
  intro row
  simp [actualBalanceGaussianEmptyUsedFlags,
    actualBalanceGaussianUsedFlagView]

/-- Updating flags preserves the correspondence with `insert`, given that the
new pivot row was fresh. -/
theorem actualBalanceGaussianSetUsedFlag_correct {m : Nat}
    (flags : Array Bool) (row : Fin m) (used : Finset (Fin m))
    (hflags : ∀ i, actualBalanceGaussianUsedFlagView flags i = decide (i ∈ used))
    (hfresh : row ∉ used) :
    ∀ i, actualBalanceGaussianUsedFlagView
      (actualBalanceGaussianSetUsedFlag flags row) i =
        decide (i ∈ insert row used) := by
  intro i
  rw [actualBalanceGaussianSetUsedFlag_view]
  by_cases hi : i = row
  · subst i
    simp [hfresh]
  · simp [hi, hflags i]

/-- Run the deterministic column scan using only an array of used-row flags
for selection state. The returned transcript records exactly the row updates
performed on the nested coefficient array. -/
def actualBalanceGaussianFlagColumnScan {m n : Nat}
    (cells : Array (Array (ZMod 2))) :
    Array Bool → List (Fin n) →
      (Array (Array (ZMod 2)) × Array Bool) × List (Fin m × Fin n)
  | flags, [] => ((cells, flags), [])
  | flags, column :: columns =>
      match actualBalanceGaussianFlagFirstUnusedPivotRow cells flags column with
      | none => actualBalanceGaussianFlagColumnScan cells flags columns
      | some row =>
          let rest := actualBalanceGaussianFlagColumnScan
            (actualBalanceGaussianArrayPivotRow cells row column)
            (actualBalanceGaussianSetUsedFlag flags row) columns
          ((rest.1.1, rest.1.2), (row, column) :: rest.2)

/-- The flag-array implementation refines the accepted matrix scan whenever
its flags represent the matrix scan's `used` set. -/
theorem actualBalanceGaussianFlagColumnScan_refines
    {m n : Nat} (cells : Array (Array (ZMod 2))) (flags : Array Bool)
    (used : Finset (Fin m)) (columns : List (Fin n))
    (hflags : ∀ row, actualBalanceGaussianUsedFlagView flags row =
      decide (row ∈ used)) :
    (actualBalanceGaussianArrayView
        (actualBalanceGaussianFlagColumnScan cells flags columns).1.1,
      (actualBalanceGaussianFlagColumnScan cells flags columns).2) =
      balanceGaussianColumnScan (actualBalanceGaussianArrayView cells)
        used columns := by
  induction columns generalizing cells flags used hflags with
  | nil => rfl
  | cons column columns ih =>
      have hsearch := actualBalanceGaussianFlagFirstUnusedPivotRow_eq
        cells flags column used hflags
      cases hpivot : actualBalanceGaussianFlagFirstUnusedPivotRow
          cells flags column with
      | none =>
          have hpivot' : balanceFirstUnusedPivotRow
              (actualBalanceGaussianArrayView cells) column used = none := by
            rw [← hsearch, hpivot]
          simpa [actualBalanceGaussianFlagColumnScan, hpivot, hpivot'] using
            ih cells flags used hflags
      | some row =>
          have hpivot' : balanceFirstUnusedPivotRow
              (actualBalanceGaussianArrayView cells) column used = some row := by
            rw [← hsearch, hpivot]
          have hfresh := balanceFirstUnusedPivotRow_sound
            (actualBalanceGaussianArrayView cells) column hpivot'
          have hflags' := actualBalanceGaussianSetUsedFlag_correct
            flags row used hflags hfresh.1
          simpa [actualBalanceGaussianFlagColumnScan, hpivot, hpivot',
            actualBalanceGaussianArrayPivotRow_view_eq] using
            ih (actualBalanceGaussianArrayPivotRow cells row column)
              (actualBalanceGaussianSetUsedFlag flags row) (insert row used)
              hflags'

/-- Serialized raw balance scan using Boolean flags. No `Finset` is used in
the executable selector/update loop; the initial flags are all false. -/
def actualBalanceGaussianSerializedArrayFlagScan {s : Nat}
    (raw : RawCoefficientArray) (tape : FiveWordTape s) :=
  actualBalanceGaussianFlagColumnScan
    (actualBalanceSerializedCoefficientMatrix
      (decodeRawArray (n := 3 * s) raw) tape)
    (actualBalanceGaussianEmptyUsedFlags (4 * ((3 * s) * (3 * s))))
    (List.ofFn fun column : Fin ((3 * s) * (3 * s)) => column)

theorem actualBalanceGaussianSerializedArrayFlagScan_refines
    {s : Nat} (raw : RawCoefficientArray) (tape : FiveWordTape s) :
    (actualBalanceGaussianArrayView
        (actualBalanceGaussianSerializedArrayFlagScan raw tape).1.1,
      (actualBalanceGaussianSerializedArrayFlagScan raw tape).2) =
      actualBalanceGaussianRawScan raw tape := by
  have hrefine := actualBalanceGaussianFlagColumnScan_refines
    (actualBalanceSerializedCoefficientMatrix
      (decodeRawArray (n := 3 * s) raw) tape)
    (actualBalanceGaussianEmptyUsedFlags (4 * ((3 * s) * (3 * s))))
    ∅ (List.ofFn fun column : Fin ((3 * s) * (3 * s)) => column)
    (actualBalanceGaussianEmptyUsedFlags_correct)
  simpa [actualBalanceGaussianSerializedArrayFlagScan,
    actualBalanceGaussianRawScan,
    actualBalanceGaussianSerializedArrayView_eq_rawMatrix] using hrefine

/-- Source-level unit-cost model for the flag-array scan. The model explicitly
charges row-list construction/traversal, one Boolean flag read per tested row,
coefficient array views, per-cell pivot work, flag-array rebuilding, and the
pivot transcript. It does not model compiled Lean runtime behavior. -/
structure ActualBalanceGaussianFlagScanCost where
  rowListNodes : Nat
  rowPredicateTests : Nat
  booleanFlagReads : Nat
  selectorCoefficientViewsUpper : Nat
  pivotCoefficientViewsUpper : Nat
  rowComparisons : Nat
  fieldMultiplicationsUpper : Nat
  fieldAdditionsUpper : Nat
  matrixCellWrites : Nat
  matrixRowArrayWrites : Nat
  flagCellComparisons : Nat
  flagCellWrites : Nat
  newMatrixArraySlots : Nat
  newFlagArraySlots : Nat
  liveMatrixArraySlotsUpper : Nat
  liveFlagArraySlotsUpper : Nat
  liveArrayAndListSlotsUpper : Nat
  transcriptNodes : Nat
  pivotBranchSteps : Nat
  columnListNodes : Nat
  deriving DecidableEq, Repr

def actualBalanceGaussianFlagScanCostModel (m n k p : Nat) :
    ActualBalanceGaussianFlagScanCost :=
  { rowListNodes := k * m
    rowPredicateTests := k * m
    booleanFlagReads := k * m
    selectorCoefficientViewsUpper := k * m
    pivotCoefficientViewsUpper := 3 * p * m * n
    rowComparisons := p * m * n
    fieldMultiplicationsUpper := p * m * n
    fieldAdditionsUpper := p * m * n
    matrixCellWrites := p * m * n
    matrixRowArrayWrites := p * m
    flagCellComparisons := p * m
    flagCellWrites := p * m
    newMatrixArraySlots := p * m * (n + 1)
    newFlagArraySlots := p * m
    liveMatrixArraySlotsUpper := (p + 2) * m * (n + 1)
    liveFlagArraySlotsUpper := (p + 2) * m
    liveArrayAndListSlotsUpper :=
      (p + 2) * m * (n + 2) + m + p + k
    transcriptNodes := p
    pivotBranchSteps := p
    columnListNodes := k }

def actualBalanceGaussianFlagScanCost.sourceOperations
    (cost : ActualBalanceGaussianFlagScanCost) : Nat :=
  cost.rowListNodes + cost.rowPredicateTests + cost.booleanFlagReads +
    2 * cost.selectorCoefficientViewsUpper +
    2 * cost.pivotCoefficientViewsUpper + cost.rowComparisons +
    cost.fieldMultiplicationsUpper + cost.fieldAdditionsUpper +
    cost.matrixCellWrites + cost.matrixRowArrayWrites +
    cost.flagCellComparisons + cost.flagCellWrites +
    cost.transcriptNodes + cost.pivotBranchSteps + cost.columnListNodes

theorem actualBalanceGaussianFlagScanCostModel_sourceOperations_eq
    (m n k p : Nat) :
    (actualBalanceGaussianFlagScanCostModel m n k p).sourceOperations =
      5 * k * m + 10 * p * m * n + 3 * p * m + 2 * p + k := by
  simp [actualBalanceGaussianFlagScanCostModel,
    actualBalanceGaussianFlagScanCost.sourceOperations]
  ring

theorem actualBalanceGaussianFlagScanCostModel_sourceOperations_le
    (m n k p : Nat) (hp : p ≤ k) :
    (actualBalanceGaussianFlagScanCostModel m n k p).sourceOperations ≤
      8 * k * m + 10 * k * m * n + 3 * k := by
  rw [actualBalanceGaussianFlagScanCostModel_sourceOperations_eq]
  gcongr

/-- Cumulative array slots are the update output sizes; the live bound keeps
all previous array versions plus one in-progress output conservatively. -/
theorem actualBalanceGaussianFlagScanCostModel_space_bounds
    (m n k p : Nat) (hp : p ≤ k) :
    actualBalanceGaussianFlagScanCostModel m n k p |>.newMatrixArraySlots +
        (actualBalanceGaussianFlagScanCostModel m n k p).newFlagArraySlots ≤
      k * m * (n + 2) ∧
    (actualBalanceGaussianFlagScanCostModel m n k p).liveArrayAndListSlotsUpper ≤
      (k + 2) * m * (n + 2) + m + 2 * k := by
  constructor
  · simp [actualBalanceGaussianFlagScanCostModel]
    gcongr
  · simp [actualBalanceGaussianFlagScanCostModel]
    gcongr

/-- The scan performs at most one pivot update per input column. -/
theorem actualBalanceGaussianFlagColumnScan_pivotCount_le
    {m n : Nat} (cells : Array (Array (ZMod 2))) (flags : Array Bool)
    (columns : List (Fin n)) :
    (actualBalanceGaussianFlagColumnScan cells flags columns).2.length ≤
      columns.length := by
  induction columns generalizing cells flags with
  | nil => simp [actualBalanceGaussianFlagColumnScan]
  | cons column columns ih =>
      cases hpivot : actualBalanceGaussianFlagFirstUnusedPivotRow
          cells flags column with
      | none =>
          simpa [actualBalanceGaussianFlagColumnScan, hpivot] using
            Nat.le_trans (ih cells flags) (Nat.le_succ columns.length)
      | some row =>
          simpa [actualBalanceGaussianFlagColumnScan, hpivot] using
            Nat.succ_le_succ
              (ih (actualBalanceGaussianArrayPivotRow cells row column)
                (actualBalanceGaussianSetUsedFlag flags row))

/-- For a scan with `k` columns, its source-level operation model uses the
actual pivot count from the returned transcript. -/
def actualBalanceGaussianFlagColumnScanCost {m n : Nat}
    (cells : Array (Array (ZMod 2))) (flags : Array Bool)
    (columns : List (Fin n)) : ActualBalanceGaussianFlagScanCost :=
  actualBalanceGaussianFlagScanCostModel m n columns.length
    (actualBalanceGaussianFlagColumnScan cells flags columns).2.length

theorem actualBalanceGaussianFlagColumnScanCost_sourceOperations_le
    {m n : Nat} (cells : Array (Array (ZMod 2))) (flags : Array Bool)
    (columns : List (Fin n)) :
    (actualBalanceGaussianFlagColumnScanCost cells flags columns).sourceOperations ≤
      8 * columns.length * m + 10 * columns.length * m * n +
        3 * columns.length := by
  apply actualBalanceGaussianFlagScanCostModel_sourceOperations_le
  exact actualBalanceGaussianFlagColumnScan_pivotCount_le cells flags columns

/-- The raw balanced system has `m=4*d^2`, `n=k=d^2`, `d=3*s`, so this
source-level flag-array model charges at most `40*d^6 + 28*d^4 + 3*d^2`
operations. Array accesses are unit-cost primitives only in this declared
model; no compiler/runtime bit bound is claimed. -/
theorem actualBalanceGaussianSerializedArrayFlagScan_sourceOperations_le
    {s : Nat} (raw : RawCoefficientArray) (tape : FiveWordTape s) :
    (actualBalanceGaussianFlagColumnScanCost
      (actualBalanceSerializedCoefficientMatrix
        (decodeRawArray (n := 3 * s) raw) tape)
      (actualBalanceGaussianEmptyUsedFlags (4 * ((3 * s) * (3 * s))))
      (List.ofFn fun column : Fin ((3 * s) * (3 * s)) => column)).sourceOperations ≤
        40 * (3 * s) ^ 6 + 32 * (3 * s) ^ 4 + 3 * (3 * s) ^ 2 := by
  calc
    _ ≤ 8 * ((3 * s) * (3 * s)) * (4 * ((3 * s) * (3 * s))) +
        10 * ((3 * s) * (3 * s)) * (4 * ((3 * s) * (3 * s))) *
          ((3 * s) * (3 * s)) + 3 * ((3 * s) * (3 * s)) := by
            simpa using actualBalanceGaussianFlagColumnScanCost_sourceOperations_le
              (actualBalanceSerializedCoefficientMatrix
                (decodeRawArray (n := 3 * s) raw) tape)
              (actualBalanceGaussianEmptyUsedFlags
                (4 * ((3 * s) * (3 * s))))
              (List.ofFn fun column : Fin ((3 * s) * (3 * s)) => column)
    _ = 40 * (3 * s) ^ 6 + 32 * (3 * s) ^ 4 + 3 * (3 * s) ^ 2 := by ring

/-- Raw-system cumulative and peak array/list slots in the declared model.
This omits source tensor construction, call frames, object headers, and GC. -/
theorem actualBalanceGaussianSerializedArrayFlagScan_space_le_polynomial
    {s : Nat} (raw : RawCoefficientArray) (tape : FiveWordTape s) :
    let cost := actualBalanceGaussianFlagColumnScanCost
      (actualBalanceSerializedCoefficientMatrix
        (decodeRawArray (n := 3 * s) raw) tape)
      (actualBalanceGaussianEmptyUsedFlags (4 * ((3 * s) * (3 * s))))
      (List.ofFn fun column : Fin ((3 * s) * (3 * s)) => column)
    cost.newMatrixArraySlots + cost.newFlagArraySlots ≤
        4 * (3 * s) ^ 6 + 8 * (3 * s) ^ 4 ∧
      cost.liveArrayAndListSlotsUpper ≤
        4 * (3 * s) ^ 6 + 16 * (3 * s) ^ 4 + 22 * (3 * s) ^ 2 := by
  let cells := actualBalanceSerializedCoefficientMatrix
    (decodeRawArray (n := 3 * s) raw) tape
  let flags := actualBalanceGaussianEmptyUsedFlags
    (4 * ((3 * s) * (3 * s)))
  let columns := List.ofFn fun column : Fin ((3 * s) * (3 * s)) => column
  let k := (3 * s) * (3 * s)
  let m := 4 * k
  let n := k
  let p := (actualBalanceGaussianFlagColumnScan cells flags columns).2.length
  have hp : p ≤ k := by
    dsimp [p, columns]
    simpa [List.length_ofFn] using
      actualBalanceGaussianFlagColumnScan_pivotCount_le cells flags columns
  have hspace := actualBalanceGaussianFlagScanCostModel_space_bounds
    m n k p hp
  constructor
  · calc
      _ ≤ k * m * (n + 2) := by
        simpa [actualBalanceGaussianFlagColumnScanCost,
          actualBalanceGaussianFlagScanCostModel, cells, flags, columns,
          p, k, m, n, List.length_ofFn] using hspace.1
      _ = 4 * (3 * s) ^ 6 + 8 * (3 * s) ^ 4 := by
        simp [k, m, n]
        ring
  · calc
      _ ≤ (k + 2) * m * (n + 2) + m + 2 * k := by
        simpa [actualBalanceGaussianFlagColumnScanCost,
          actualBalanceGaussianFlagScanCostModel, cells, flags, columns,
          p, k, m, n, List.length_ofFn] using hspace.2
      _ = 4 * (3 * s) ^ 6 + 16 * (3 * s) ^ 4 + 22 * (3 * s) ^ 2 := by
        simp [k, m, n]
        ring

end CorruptedFieldRecovery
