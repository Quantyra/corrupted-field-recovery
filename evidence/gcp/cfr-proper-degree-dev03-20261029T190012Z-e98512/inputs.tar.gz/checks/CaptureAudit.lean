import CorruptedFieldRecovery
import CorruptedFieldRecovery.S010ProperDegreeArithmetic

set_option pp.universes true
set_option pp.explicit false
set_option pp.fullNames true
set_option pp.piBinderTypes true
set_option pp.piBinderNames true
set_option pp.piBinderNames.hygienic true
set_option pp.proofs true
set_option pp.deepTerms true
set_option pp.maxSteps 1000000
set_option maxRecDepth 10000

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.proper_degree_sum_lt_half_power"
#check @CorruptedFieldRecovery.proper_degree_sum_lt_half_power
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.proper_degree_sum_lt_half_power"
#print axioms CorruptedFieldRecovery.proper_degree_sum_lt_half_power

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.sum_pow_two_range_succ"
#check @CorruptedFieldRecovery.sum_pow_two_range_succ
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.sum_pow_two_range_succ"
#print axioms CorruptedFieldRecovery.sum_pow_two_range_succ
