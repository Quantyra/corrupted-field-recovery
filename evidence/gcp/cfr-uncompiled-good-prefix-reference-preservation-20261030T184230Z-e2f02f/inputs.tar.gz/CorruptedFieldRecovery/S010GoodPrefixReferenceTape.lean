import CorruptedFieldRecovery.S010BalanceGaussianPhysicalSuffixSeedBridge
import CorruptedFieldRecovery.S010ActualScalarBounds
import CorruptedFieldRecovery.S010ModeImageFiveCount

namespace CorruptedFieldRecovery

open Module

/-! Given a good first-four semantic prefix, the existing scalar-count bound
provides a genuine good fifth suffix.  This constructs a reference physical
tape without adding randomness.  It also records the exact correspondence
between that physical suffix event and the computed free-column seed.  This
draft depends on the currently uncompiled Gaussian/physical-suffix chain. -/

theorem goodFifthScalars_nonempty_of_size
    {K : Type*} [Field K] [Fintype K] [DecidableEq K] [Finite K]
    [Algebra BinaryField K] [FiniteDimensional BinaryField K]
    (U : Submodule BinaryField (KTriple K)) (s R r : Nat)
    (hsdim : Module.finrank BinaryField K = s)
    (hr : Module.finrank BinaryField U = r)
    (hrR : r ≤ R) (hsize : 2 * R + 5 ≤ s) :
    (goodFifthScalars K U).Nonempty := by
  classical
  let T := ∑ d ∈ properDegrees K, 2 ^ d
  let B := 2 ^ (2 * r) - 1
  have hcount := actual_good_scalar_finite_count_lower K s R r hsdim hrR hsize
  have hgen := card_nonGenerators_le_proper_degree_sum K
  have htranslate := card_badTranslateScalars_submodule_le K U
  have htranslate' :
      (badTranslateScalars K (supportCoordinateFinset K U)).card ≤ B := by
    simpa [B, BinaryField, hr] using htranslate
  have hbad :
      (nonGenerators K ∪
        badTranslateScalars K (supportCoordinateFinset K U)).card ≤ T + B := by
    calc
      _ ≤ (nonGenerators K).card +
          (badTranslateScalars K (supportCoordinateFinset K U)).card :=
        Finset.card_union_le _ _
      _ ≤ T + B := Nat.add_le_add hgen htranslate'
  have hgoodCount : 0 < (goodFifthScalars K U).card := by
    let bad := nonGenerators K ∪
      badTranslateScalars K (supportCoordinateFinset K U)
    have hpartition := Finset.card_filter_add_card_filter_not
      (s := (Finset.univ : Finset K)) (fun x : K => x ∈ bad)
    have hgoodSet : Finset.univ.filter (fun x : K => x ∉ bad) =
        goodFifthScalars K U := by
      ext x
      simp [goodFifthScalars, bad]
    have hbadSet : Finset.univ.filter (fun x : K => x ∈ bad) = bad := by
      ext x
      simp
    rw [hgoodSet, hbadSet, Finset.card_univ] at hpartition
    have hbad' : bad.card ≤ T + B := by simpa [bad] using hbad
    have hfield : Fintype.card K = 2 ^ s := by
      rw [Module.card_eq_pow_finrank (K := BinaryField) (V := K), hsdim]
      simp [BinaryField]
    have hquarter : 0 < 2 ^ s := Nat.pow_pos (by decide)
    have hcount' : 4 * (2 ^ s - (T + B)) ≥ 2 ^ s := by
      simpa [T, B] using hcount
    omega
  exact Finset.card_pos.mp hgoodCount

/-- For every good semantic first-four prefix, there is a suffix whose field
value is both primitive and avoids the support-translate obstruction. -/
theorem goodPrefix_has_good_fifth_index
    {K : Type*} [Field K] [Fintype K] [DecidableEq K] [Finite K]
    [Algebra BinaryField K] [FiniteDimensional BinaryField K]
    {s R r : Nat} (A : Finset (FieldTriple K))
    (U : Submodule BinaryField (KTriple K))
    (b : (Fin 4 → FieldTriple K) → Basis (Fin s) BinaryField K)
    (hsdim : Module.finrank BinaryField K = s)
    (hr : Module.finrank BinaryField U = r)
    (hrR : r ≤ R) (hsize : 2 * R + 5 ≤ s) :
    ∃ index : BinaryVector s, index ∈ goodFifthIndices K (b words) U := by
  classical
  obtain ⟨k, hk⟩ := goodFifthScalars_nonempty_of_size U s R r
    hsdim hr hrR hsize
  refine ⟨(basisFifthIndexEquiv K (b words)).symm k, ?_⟩
  apply Finset.mem_map.mpr
  refine ⟨k, hk, ?_⟩
  simp [goodFifthIndices, basisFifthIndexEquiv]

/-- A good semantic four-prefix has a reference physical tape in the actual
five-word event. Its first four words are the inverse Q-images of the given
prefix. The fifth word is chosen from the positive-count fiber above. -/
theorem goodPrefix_has_actual_reference_tape
    {K : Type*} [Field K] [Fintype K] [DecidableEq K] [Finite K]
    [Algebra BinaryField K] [FiniteDimensional BinaryField K]
    {s R r : Nat}
    (Q : BinaryVector (3 * s) ≃ₗ[BinaryField] FieldTriple K)
    (A : Finset (FieldTriple K)) (U : Submodule BinaryField (KTriple K))
    (b : (Fin 4 → FieldTriple K) → Basis (Fin s) BinaryField K)
    (words : Fin 4 → FieldTriple K)
    (hwords : words ∈ canonicalGoodFourFlatImage K A (nonGenerators K))
    (hsdim : Module.finrank BinaryField K = s)
    (hr : Module.finrank BinaryField U = r)
    (hrR : r ≤ R) (hsize : 2 * R + 5 ≤ s) :
    ∃ tape : FiveWordTape s,
      tape ∈ actualFiveGoodTapeSet K Q A U b ∧
      tape.1 = fun i => Q.symm (words i) := by
  classical
  obtain ⟨index, hindex⟩ := goodPrefix_has_good_fifth_index
    A U b hsdim hr hrR hsize
  refine ⟨(fun i => Q.symm (words i), index), ?_, rfl⟩
  change (fiveTapeSemanticEquiv K Q).symm ⟨words, index⟩ ∈
    (goodFiveTupleSigma K A U b).map
      ⟨(fiveTapeSemanticEquiv K Q).symm,
        (fiveTapeSemanticEquiv K Q).symm.injective⟩
  apply Finset.mem_map.mpr
  refine ⟨⟨words, index⟩, ?_, rfl⟩
  apply Finset.mem_sigma.mpr
  exact ⟨hwords, hindex⟩

/-- On the reference tape, the actual raw scan has exactly `s` free columns;
the accepted span theorem therefore applies to this first-four prefix. -/
theorem goodPrefix_reference_tape_free_dimension
    {K : Type*} [Field K] [Fintype K] [DecidableEq K] [Finite K]
    [CharP K 2] [Algebra BinaryField K] [FiniteDimensional BinaryField K]
    [Algebra (ZMod (ringChar K)) K]
    {s R r : Nat}
    (Q : BinaryVector (3 * s) ≃ₗ[BinaryField] FieldTriple K)
    (E : BinaryTensor (3 * s))
    (U : Submodule BinaryField (KTriple K))
    (b : (Fin 4 → FieldTriple K) → Basis (Fin s) BinaryField K)
    (words : Fin 4 → FieldTriple K)
    (hwords : words ∈ canonicalGoodFourFlatImage K
      (modeImageSemanticCleanFieldSet Q E) (nonGenerators K))
    (hsdim : Module.finrank BinaryField K = s)
    (hr : Module.finrank BinaryField U = r)
    (hrR : r ≤ R) (hsizeField : 2 * R + 5 ≤ s)
    (raw : RawCoefficientArray)
    (c : K) (hc : c ≠ 0)
    (hmodel : HasObservedTraceDeterminantDecomposition
      (decodeRawArray (n := 3 * s) raw) E LinearMap.id Q c)
    (hsizeRaw : raw.size = (3 * s) * (3 * s) * (3 * s)) :
    ∃ tape : FiveWordTape s,
      tape ∈ actualFiveGoodTapeSet K Q
        (modeImageSemanticCleanFieldSet Q E) U b ∧
      Fintype.card (actualBalanceGaussianRawFreeIndex raw tape) = s := by
  obtain ⟨tape, htape, _⟩ := goodPrefix_has_actual_reference_tape
    Q (modeImageSemanticCleanFieldSet Q E) U b words hwords
    hsdim hr hrR hsizeField
  exact ⟨tape, htape,
    actualBalanceGaussianRawFreeIndex_card_eq
      Q E U b raw tape htape c hc hmodel hsizeRaw hsdim⟩

/-- For every suffix on the chosen reference prefix, the model's good-fifth
predicate is equivalent to the predicate on the scalar selected from the
computed Gaussian seed. The selector is evaluated against the reference tape;
its first-four words are fixed, and the suffix-to-seed map is the explicit
bijection in the physical-suffix bridge. This uses no additional random seed. -/
theorem goodPrefix_reference_suffix_event_iff_computed_seed
    {K : Type*} [Field K] [Fintype K] [DecidableEq K] [Finite K]
    [CharP K 2] [Algebra BinaryField K] [FiniteDimensional BinaryField K]
    [Algebra (ZMod (ringChar K)) K]
    {s R r : Nat}
    (Q : BinaryVector (3 * s) ≃ₗ[BinaryField] FieldTriple K)
    (E : BinaryTensor (3 * s))
    (U : Submodule BinaryField (KTriple K))
    (b : (Fin 4 → FieldTriple K) → Basis (Fin s) BinaryField K)
    (words : Fin 4 → FieldTriple K)
    (hwords : words ∈ canonicalGoodFourFlatImage K
      (modeImageSemanticCleanFieldSet Q E) (nonGenerators K))
    (hsdim : Module.finrank BinaryField K = s)
    (hr : Module.finrank BinaryField U = r)
    (hrR : r ≤ R) (hsizeField : 2 * R + 5 ≤ s)
    (raw : RawCoefficientArray)
    (c : K) (hc : c ≠ 0)
    (hmodel : HasObservedTraceDeterminantDecomposition
      (decodeRawArray (n := 3 * s) raw) E LinearMap.id Q c)
    (hsizeRaw : raw.size = (3 * s) * (3 * s) * (3 * s))
    (referenceTape : FiveWordTape s)
    (hreference : referenceTape ∈ actualFiveGoodTapeSet K Q
      (modeImageSemanticCleanFieldSet Q E) U b)
    (hprefix : referenceTape.1 = fun i => Q.symm (words i))
    (suffix : BinaryVector s) :
    actualBalanceGaussianQScalarParameter Q
      (actualBalanceGaussianArrayFlagSelectBySeed raw referenceTape
        (actualBalanceGaussianRawFreeIndex_card_eq
          Q E U b raw referenceTape hreference c hc hmodel hsizeRaw hsdim)
        (actualBalanceGaussianSeedOfPhysicalSuffix Q b raw referenceTape
          (actualBalanceGaussianRawFreeIndex_card_eq
            Q E U b raw referenceTape hreference c hc hmodel hsizeRaw hsdim)
          suffix)) ∈ goodFifthScalars K U ↔
      basisFifthIndexEquiv K (b words) suffix ∈ goodFifthScalars K U := by
  have hwords : (fun i => Q (referenceTape.1 i)) = words := by
    funext i
    rw [hprefix]
    exact Q.apply_symm_apply (words i)
  rw [← hwords]
  exact actualBalanceGaussianSelectedScalar_goodFifth_iff_physicalSuffix
    Q E U b raw referenceTape hreference c hc hmodel hsizeRaw hsdim suffix

/-- A positive good-fifth fiber yields a physical reference tape on which the
actual scan has the correct dimension and whose raw Gaussian basis spans the
Q-conjugated scalar range. The last conjunct is the full span equivalence,
not merely a dimension assertion. -/
theorem goodPrefix_reference_tape_dimension_and_span
    {K : Type*} [Field K] [Fintype K] [DecidableEq K] [Finite K]
    [CharP K 2] [Algebra BinaryField K] [FiniteDimensional BinaryField K]
    [Algebra (ZMod (ringChar K)) K]
    {s R r : Nat}
    (Q : BinaryVector (3 * s) ≃ₗ[BinaryField] FieldTriple K)
    (E : BinaryTensor (3 * s))
    (U : Submodule BinaryField (KTriple K))
    (b : (Fin 4 → FieldTriple K) → Basis (Fin s) BinaryField K)
    (words : Fin 4 → FieldTriple K)
    (hwords : words ∈ canonicalGoodFourFlatImage K
      (modeImageSemanticCleanFieldSet Q E) (nonGenerators K))
    (hsdim : Module.finrank BinaryField K = s)
    (hr : Module.finrank BinaryField U = r)
    (hrR : r ≤ R) (hsizeField : 2 * R + 5 ≤ s)
    (raw : RawCoefficientArray)
    (c : K) (hc : c ≠ 0)
    (hmodel : HasObservedTraceDeterminantDecomposition
      (decodeRawArray (n := 3 * s) raw) E LinearMap.id Q c)
    (hsizeRaw : raw.size = (3 * s) * (3 * s) * (3 * s)) :
    ∃ tape : FiveWordTape s,
      tape ∈ actualFiveGoodTapeSet K Q
        (modeImageSemanticCleanFieldSet Q E) U b ∧
      Fintype.card (actualBalanceGaussianRawFreeIndex raw tape) = s ∧
      ∀ T : Module.End BinaryField (BinaryVector (3 * s)),
        T ∈ qScalarConjugateEndRange Q ↔
          T = ∑ free : balanceGaussianFreeIndex
              (actualBalanceGaussianRawScan raw tape).2,
            actualBalanceGaussianInputCoordinates T free.1 •
              actualBalanceGaussianRawCandidateFamily raw tape free := by
  obtain ⟨tape, htape, hprefix⟩ := goodPrefix_has_actual_reference_tape
    Q (modeImageSemanticCleanFieldSet Q E) U b words hwords
    hsdim hr hrR hsizeField
  refine ⟨tape, htape, ?_, ?_⟩
  · exact actualBalanceGaussianRawFreeIndex_card_eq
      Q E U b raw tape htape c hc hmodel hsizeRaw hsdim
  · intro T
    exact (actualBalanceGaussianRawBasis_spans_QScalarRange
      Q E U b raw tape htape c hc hmodel hsizeRaw T)

/-- Combined prefix theorem: the positive good-fifth count supplies the
reference tape, the scan's computed kernel has dimension `s` and spans the
promised scalar range, and every physical suffix has exactly the same
good-fifth event as the scalar selected from its converted Gaussian seed. -/
theorem goodPrefix_reference_tape_and_suffix_event
    {K : Type*} [Field K] [Fintype K] [DecidableEq K] [Finite K]
    [CharP K 2] [Algebra BinaryField K] [FiniteDimensional BinaryField K]
    [Algebra (ZMod (ringChar K)) K]
    {s R r : Nat}
    (Q : BinaryVector (3 * s) ≃ₗ[BinaryField] FieldTriple K)
    (E : BinaryTensor (3 * s))
    (U : Submodule BinaryField (KTriple K))
    (b : (Fin 4 → FieldTriple K) → Basis (Fin s) BinaryField K)
    (words : Fin 4 → FieldTriple K)
    (hwords : words ∈ canonicalGoodFourFlatImage K
      (modeImageSemanticCleanFieldSet Q E) (nonGenerators K))
    (hsdim : Module.finrank BinaryField K = s)
    (hr : Module.finrank BinaryField U = r)
    (hrR : r ≤ R) (hsizeField : 2 * R + 5 ≤ s)
    (raw : RawCoefficientArray)
    (c : K) (hc : c ≠ 0)
    (hmodel : HasObservedTraceDeterminantDecomposition
      (decodeRawArray (n := 3 * s) raw) E LinearMap.id Q c)
    (hsizeRaw : raw.size = (3 * s) * (3 * s) * (3 * s)) :
    ∃ tape : FiveWordTape s,
      ∃ htape : tape ∈ actualFiveGoodTapeSet K Q
        (modeImageSemanticCleanFieldSet Q E) U b,
        tape.1 = fun i => Q.symm (words i) ∧
        Fintype.card (actualBalanceGaussianRawFreeIndex raw tape) = s ∧
        (∀ T : Module.End BinaryField (BinaryVector (3 * s)),
          T ∈ qScalarConjugateEndRange Q ↔
            T = ∑ free : balanceGaussianFreeIndex
                (actualBalanceGaussianRawScan raw tape).2,
              actualBalanceGaussianInputCoordinates T free.1 •
                actualBalanceGaussianRawCandidateFamily raw tape free) ∧
        ∀ suffix : BinaryVector s,
          actualBalanceGaussianQScalarParameter Q
            (actualBalanceGaussianArrayFlagSelectBySeed raw tape
              (actualBalanceGaussianRawFreeIndex_card_eq
                Q E U b raw tape htape c hc hmodel hsizeRaw hsdim)
              (actualBalanceGaussianSeedOfPhysicalSuffix Q b raw tape
                (actualBalanceGaussianRawFreeIndex_card_eq
                  Q E U b raw tape htape c hc hmodel hsizeRaw hsdim)
                suffix)) ∈ goodFifthScalars K U ↔
            basisFifthIndexEquiv K (b words) suffix ∈ goodFifthScalars K U := by
  obtain ⟨tape, htape, hprefix⟩ := goodPrefix_has_actual_reference_tape
    Q (modeImageSemanticCleanFieldSet Q E) U b words hwords
    hsdim hr hrR hsizeField
  have hcard : Fintype.card (actualBalanceGaussianRawFreeIndex raw tape) = s :=
    actualBalanceGaussianRawFreeIndex_card_eq
      Q E U b raw tape htape c hc hmodel hsizeRaw hsdim
  have hspan : ∀ T : Module.End BinaryField (BinaryVector (3 * s)),
      T ∈ qScalarConjugateEndRange Q ↔
        T = ∑ free : balanceGaussianFreeIndex
            (actualBalanceGaussianRawScan raw tape).2,
          actualBalanceGaussianInputCoordinates T free.1 •
            actualBalanceGaussianRawCandidateFamily raw tape free := by
    intro T
    exact actualBalanceGaussianRawBasis_spans_QScalarRange
      Q E U b raw tape htape c hc hmodel hsizeRaw T
  refine ⟨tape, htape, hprefix, hcard, hspan, ?_⟩
  intro suffix
  exact goodPrefix_reference_suffix_event_iff_computed_seed
    Q E U b words hwords hsdim hr hrR hsizeField raw c hc hmodel
    hsizeRaw tape htape hprefix suffix

end CorruptedFieldRecovery

end CorruptedFieldRecovery
