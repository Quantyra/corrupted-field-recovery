import CorruptedFieldRecovery.S010GoodPrefixReferenceTape
import CorruptedFieldRecovery.S010BalanceGaussianGeneratorFastCheck
import CorruptedFieldRecovery.S010BalanceGaussianPrimitivePowerIndependence

namespace CorruptedFieldRecovery

open Module

/-! Pointwise connection from the original five-word tape to the computed
Gaussian sampler and its serialized generator filter.  The tape remains
`FiveWordTape s`, i.e. exactly four `3*s`-bit words and one `s`-bit suffix.
The suffix is converted bijectively to the computed free-column weights by
the fixed-prefix bridge; no second seed is introduced.  Filter acceptance is
conditional on the explicit fixed scalar-bit shape conditions because those
bits encode the later compatible coefficient, not the random fifth suffix.
This draft depends on the currently uncompiled physical-suffix and
primitive-power bridges. -/

/-- Membership in the actual five-word event supplies the model good-fifth
scalar for the same physical suffix. -/
theorem actualFiveGoodTape_modelSuffix_mem_goodFifthScalars
    {K : Type*} [Field K] [Fintype K] [DecidableEq K] [Finite K]
    [Algebra BinaryField K] [FiniteDimensional BinaryField K]
    {s : Nat}
    (Q : BinaryVector (3 * s) ≃ₗ[BinaryField] FieldTriple K)
    (A : Finset (FieldTriple K)) (U : Submodule BinaryField (KTriple K))
    (b : (Fin 4 → FieldTriple K) → Basis (Fin s) BinaryField K)
    (tape : FiveWordTape s)
    (htape : tape ∈ actualFiveGoodTapeSet K Q A U b) :
    basisFifthIndexEquiv K (b (fun i => Q (tape.1 i))) tape.2 ∈
      goodFifthScalars K U := by
  classical
  have hmap : tape ∈ (goodFiveTupleSigma K A U b).map
      ⟨(fiveTapeSemanticEquiv K Q).symm,
        (fiveTapeSemanticEquiv K Q).symm.injective⟩ := by
    simpa [actualFiveGoodTapeSet] using htape
  obtain ⟨event, hevent, hback⟩ := Finset.mem_map.mp hmap
  have heventEq : event = fiveTapeSemanticEquiv K Q tape := by
    simpa using congrArg (fiveTapeSemanticEquiv K Q) hback
  rw [heventEq] at hevent
  have hsemantic :
      (⟨(fun i => Q (tape.1 i)), tape.2⟩ :
        Σ _e : Fin 4 → FieldTriple K, BinaryVector s) ∈
        goodFiveTupleSigma K A U b := by
    simpa [fiveTapeSemanticEquiv] using hevent
  obtain ⟨_, hindex⟩ := Finset.mem_sigma.mp hsemantic
  obtain ⟨k, hk, hindexEq⟩ := Finset.mem_map.mp hindex
  have hkEq : k =
      basisFifthIndexEquiv K (b (fun i => Q (tape.1 i))) tape.2 := by
    simpa [basisFifthIndexEquiv] using
      congrArg (basisFifthIndexEquiv K (b (fun i => Q (tape.1 i)))) hindexEq
  rw [← hkEq]
  exact hk

/-- On every tape in the true `13*s`-bit event, the suffix-converted Gaussian
sample passes the actual recurrence serialization/shape/Rabin filter, provided
its deterministic coefficient-bit field satisfies the serializer's explicit
size and nonzero requirements.  The first two conjuncts identify the actual
computed recurrence coefficients and serialized candidate.  The final
conjuncts record the mathematical generator and power-independence facts that
make the Rabin acceptance sound; they are derived, not assumed. -/
theorem actualFiveGoodTape_implies_computed_filter_acceptance
    {K : Type*} [Field K] [Fintype K] [DecidableEq K] [Finite K]
    [CharP K 2] [Algebra BinaryField K] [FiniteDimensional BinaryField K]
    [Algebra (ZMod (ringChar K)) K]
    {s : Nat}
    (Q : BinaryVector (3 * s) ≃ₗ[BinaryField] FieldTriple K)
    (E : BinaryTensor (3 * s))
    (U : Submodule BinaryField (KTriple K))
    (b : (Fin 4 → FieldTriple K) → Module.Basis (Fin s) BinaryField K)
    (raw : RawCoefficientArray) (tape : FiveWordTape s)
    (htape : tape ∈ actualFiveGoodTapeSet K Q
      (modeImageSemanticCleanFieldSet Q E) U b)
    (c : K) (hc : c ≠ 0)
    (hmodel : HasObservedTraceDeterminantDecomposition
      (decodeRawArray (n := 3 * s) raw) E LinearMap.id Q c)
    (hsize : raw.size = (3 * s) * (3 * s) * (3 * s))
    (hK : Module.finrank BinaryField K = s)
    (hs : 1 ≤ s)
    (scalarBits : RawFieldBits)
    (hscalarSize : scalarBits.size = s)
    (hscalarNe : rawFieldBitsToNat scalarBits ≠ 0) :
    let hcard : Fintype.card (actualBalanceGaussianRawFreeIndex raw tape) = s :=
      actualBalanceGaussianRawFreeIndex_card_eq
        Q E U b raw tape htape c hc hmodel hsize hK
    let seed := actualBalanceGaussianSeedOfPhysicalSuffix Q b raw tape hcard tape.2
    let T := actualBalanceGaussianArrayFlagSelectBySeed raw tape hcard seed
    ∃ coefficients candidate,
      actualBalanceGaussianAffineRecurrence? T = some coefficients ∧
      actualBalanceGaussianSerializedRecurrenceCandidate? T scalarBits =
        some candidate ∧
      rawFieldCandidateFastCheck candidate = true ∧
      Algebra.adjoin BinaryField
        ({actualBalanceGaussianQScalarParameter Q T} : Set K) = ⊤ ∧
      LinearIndependent BinaryField (fun i : Fin s => T ^ i.val) := by
  let hcard : Fintype.card (actualBalanceGaussianRawFreeIndex raw tape) = s :=
    actualBalanceGaussianRawFreeIndex_card_eq
      Q E U b raw tape htape c hc hmodel hsize hK
  let seed := actualBalanceGaussianSeedOfPhysicalSuffix Q b raw tape hcard tape.2
  let T := actualBalanceGaussianArrayFlagSelectBySeed raw tape hcard seed
  have hT : T ∈ qScalarConjugateEndRange Q := by
    exact actualBalanceGaussianArrayFlagSelectBySeed_mem_qScalarRange
      Q E U b raw tape htape c hc hmodel hsize hK seed
  have hgoodSuffix :
      actualBalanceGaussianQScalarParameter Q T ∈ goodFifthScalars K U := by
    have hiff := actualBalanceGaussianSelectedScalar_goodFifth_iff_physicalSuffix
      Q E U b raw tape htape c hc hmodel hsize hK tape.2
    exact hiff.mpr (actualFiveGoodTape_modelSuffix_mem_goodFifthScalars
      Q (modeImageSemanticCleanFieldSet Q E) U b tape htape)
  have hnotGenerator :
      actualBalanceGaussianQScalarParameter Q T ∉ nonGenerators K := by
    have hnotUnion :
        actualBalanceGaussianQScalarParameter Q T ∉
          nonGenerators K ∪
            badTranslateScalars K (supportCoordinateFinset K U) := by
      simpa [goodFifthScalars] using hgoodSuffix
    exact (Finset.not_mem_union.mp hnotUnion).1
  have hgen : Algebra.adjoin BinaryField
      ({actualBalanceGaussianQScalarParameter Q T} : Set K) = ⊤ := by
    by_contra hne
    have hmem : actualBalanceGaussianQScalarParameter Q T ∈ nonGenerators K := by
      simp [nonGenerators, hne]
    exact hnotGenerator hmem
  have hpow : LinearIndependent BinaryField (fun i : Fin s => T ^ i.val) :=
    actualBalanceGaussian_endPowers_linearIndependent_of_primitive
      Q T hT hgen hK
  obtain ⟨coefficients, hrecOut, _hrecurrence⟩ :=
    actualBalanceGaussianAffineRecurrence?_correct Q T hT hK hpow
  obtain ⟨candidate, hserialized, hfast⟩ :=
    actualBalanceGaussianSerializedRecurrenceCandidate_fastCheck_of_primitive
      Q T hT hK hpow hgen hs scalarBits hscalarSize hscalarNe
  refine ⟨coefficients, candidate, hrecOut, ?_, hfast, hgen, hpow⟩
  have hcand :
      actualBalanceGaussianCandidateOfRecurrence coefficients scalarBits = candidate := by
    simpa [actualBalanceGaussianSerializedRecurrenceCandidate?, hrecOut] using
      hserialized
  simp [actualBalanceGaussianSerializedRecurrenceCandidate?, hrecOut, hcand]

/-- The uniform sample space used above is exactly the manuscript's original
four `3*s`-bit words and one `s`-bit suffix; the bridge changes coordinates
of that suffix but does not append a seed. -/
theorem actualFiveGoodTape_sampler_width {s : Nat} :
    Fintype.card (FiveWordTape s) = 2 ^ (13 * s) :=
  card_fiveWordTape s

end CorruptedFieldRecovery
