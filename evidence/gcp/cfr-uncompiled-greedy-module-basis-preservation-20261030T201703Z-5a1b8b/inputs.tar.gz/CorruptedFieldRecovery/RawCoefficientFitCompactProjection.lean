import CorruptedFieldRecovery.RawCoefficientFitAffineExtraction

/-! # Compact coefficient projection for the padded fit solve

The finite Gaussian system has `s + d^3` coefficient positions, whereas the
manuscript's compact fit has `s + |IncreasingTriple d|` coefficients. Every
compact support coefficient is assigned its explicit `finProdFinEquiv`
position. The remaining ordered support positions are invalid triples; the
finite matrix construction zeroes those columns. This file defines both
directions of the coefficient map and records the exact row/entry obligations
needed to prove that projection preserves a solution.

No fit consistency is assumed. The compact/finite equation equivalence below
is a target, not an asserted theorem in this uncompiled draft.
-/

namespace CorruptedFieldRecovery

/-- Finite position of one compact coefficient. Scalar positions are left
unchanged; an increasing support triple is flattened by the explicit ordered
triple product equivalence. -/
def rawCoefficientFitCompactPosition {s d : Nat} :
    RawCoefficientFitColumnIndex s d → Fin (s + (d * d) * d)
  | Sum.inl j => rawFitColumnFinEquiv s d (Sum.inl j)
  | Sum.inr supportTriple =>
      rawFitColumnFinEquiv s d
        (Sum.inr (rawOrderedTripleFinEquiv d supportTriple.val))

/-- Extend compact coefficients to the padded `Fin (s+d^3)` space. Invalid
ordered support triples receive zero. This is an executable finite map. -/
def rawCoefficientFitExtendCompact {s d : Nat}
    (coefficients : RawCoefficientFitColumnIndex s d → ZMod 2) :
    Fin (s + (d * d) * d) → ZMod 2 := fun position =>
  match (rawFitColumnFinEquiv s d).symm position with
  | Sum.inl j => coefficients (Sum.inl j)
  | Sum.inr supportPosition =>
      let supportTriple := rawOrderedTripleAt supportPosition
      if h : rawOrderedTripleIncreasing supportTriple then
        coefficients (Sum.inr (rawOrderedTripleAsIncreasing supportTriple h))
      else 0

/-- Project an arbitrary padded vector to the compact source coordinates.
The projection reads only the scalar columns and valid increasing support
columns. -/
def rawCoefficientFitProjectCompact {s d : Nat}
    (coefficients : Fin (s + (d * d) * d) → ZMod 2) :
    RawCoefficientFitColumnIndex s d → ZMod 2 := fun compactColumn =>
  coefficients (rawCoefficientFitCompactPosition compactColumn)

/-- Extending a compact coefficient vector and projecting it back preserves
every compact coordinate. -/
theorem rawCoefficientFitProjectExtendCompact {s d : Nat}
    (coefficients : RawCoefficientFitColumnIndex s d → ZMod 2) :
    rawCoefficientFitProjectCompact
      (rawCoefficientFitExtendCompact coefficients) = coefficients := by
  funext compactColumn
  cases compactColumn with
  | inl j => simp [rawCoefficientFitProjectCompact,
      rawCoefficientFitExtendCompact, rawCoefficientFitCompactPosition,
      rawFitColumnFinEquiv]
  | inr supportTriple =>
      simp [rawCoefficientFitProjectCompact,
        rawCoefficientFitExtendCompact, rawCoefficientFitCompactPosition,
        rawFitColumnFinEquiv, rawOrderedTripleAt,
        rawOrderedTripleIncreasing, rawOrderedTripleAsIncreasing,
        rawOrderedTripleFinEquiv]

/-- A padded support column corresponding to a non-increasing ordered triple
is exactly zero. This is the structural reason extra `d^3` columns do not add
new fit directions. -/
theorem rawCoefficientFitFiniteEntry_invalidSupportColumn_zero {s d : Nat}
    (candidate : RawFieldCandidate s)
    (hcheck : rawFieldCandidateCheck candidate = true)
    (inverse : RawCoordinateMatrix) (supportMatrix : RawBinaryArray)
    (physicalRow : IncreasingTriple (3 * s))
    (supportPosition : Fin ((d * d) * d))
    (hinvalid : ¬ rawOrderedTripleIncreasing
      (rawOrderedTripleAt supportPosition)) :
    rawCoefficientFitFiniteEntry candidate hcheck inverse supportMatrix
      (rawOrderedTripleFinEquiv (3 * s) physicalRow.val)
      (rawFitColumnFinEquiv s d (Sum.inr supportPosition)) = 0 := by
  simp [rawCoefficientFitFiniteEntry, rawOrderedTripleAt,
    rawOrderedTripleIncreasing, rawFitColumnFinEquiv,
    rawOrderedTripleFinEquiv, physicalRow.property, hinvalid]

/-- Compact equation at one increasing physical row. -/
def rawCoefficientFitCompactRowEquation {s d : Nat}
    (candidate : RawFieldCandidate s)
    (hcheck : rawFieldCandidateCheck candidate = true)
    (inverse : RawCoordinateMatrix) (supportMatrix : RawBinaryArray)
    (raw : RawCoefficientArray)
    (coefficients : RawCoefficientFitColumnIndex s d → ZMod 2)
    (row : IncreasingTriple (3 * s)) : Prop :=
  (∑ column : RawCoefficientFitColumnIndex s d,
    rawCoefficientFitEntry candidate hcheck inverse supportMatrix row column *
      coefficients column) = rawCoefficientFitRhs raw row

/-- The precise reindexing theorem required to identify the compact row sum
with the padded finite dot product. It decomposes the `Fin(s+d^3)` sum,
transfers the right summand through the subtype of increasing support
triples, and drops the invalid zero terms. -/
def RawCoefficientFitCompactRowReindexTarget {s d : Nat}
    (candidate : RawFieldCandidate s)
    (hcheck : rawFieldCandidateCheck candidate = true)
    (inverse : RawCoordinateMatrix) (supportMatrix : RawBinaryArray)
    (raw : RawCoefficientArray)
    (coefficients : RawCoefficientFitColumnIndex s d → ZMod 2) : Prop :=
  ∀ row : IncreasingTriple (3 * s),
    (rawCoefficientFitFiniteMatrix candidate hcheck inverse supportMatrix *ᵥ
      rawCoefficientFitExtendCompact coefficients)
        (rawOrderedTripleFinEquiv (3 * s) row.val) =
      (∑ column : RawCoefficientFitColumnIndex s d,
        rawCoefficientFitEntry candidate hcheck inverse supportMatrix row column *
          coefficients column)

/-- Compact/finite affine-solution equivalence target. The reverse direction
projects any padded solution; the invalid support-column lemma guarantees
that discarded coordinates do not affect any equation. The proof also needs
the padded-row fact that non-increasing rows are identically zero. -/
def RawCoefficientFitCompactFiniteEquationEquivalenceTarget {s d : Nat}
    (candidate : RawFieldCandidate s)
    (hcheck : rawFieldCandidateCheck candidate = true)
    (inverse : RawCoordinateMatrix) (supportMatrix : RawBinaryArray)
    (raw : RawCoefficientArray) : Prop :=
  RawCoefficientFitAffineSolution candidate hcheck inverse supportMatrix raw ↔
    RawCoefficientFitFiniteSystemSolution candidate hcheck inverse
      supportMatrix raw

/-- Projection correctness target for an arbitrary solution returned by the
augmented finite solver. This is a source-indexed theorem target only; no
solver consistency or manuscript-model hypothesis is hidden here. -/
def RawCoefficientFitProjectionPreservesSolutionTarget {s d : Nat}
    (candidate : RawFieldCandidate s)
    (hcheck : rawFieldCandidateCheck candidate = true)
    (inverse : RawCoordinateMatrix) (supportMatrix : RawBinaryArray)
    (raw : RawCoefficientArray) : Prop :=
  ∀ padded : Fin (s + (d * d) * d) → ZMod 2,
    rawCoefficientFitFiniteMatrix candidate hcheck inverse supportMatrix *ᵥ padded =
      rawCoefficientFitFiniteRhsVector raw →
    ∀ row : IncreasingTriple (3 * s),
      rawCoefficientFitCompactRowEquation candidate hcheck inverse supportMatrix
        raw (rawCoefficientFitProjectCompact padded) row

end CorruptedFieldRecovery
