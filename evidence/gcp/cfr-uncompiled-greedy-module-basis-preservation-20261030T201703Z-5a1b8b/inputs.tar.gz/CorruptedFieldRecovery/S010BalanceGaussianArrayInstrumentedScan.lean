import CorruptedFieldRecovery.S010BalanceGaussianArrayResources

namespace CorruptedFieldRecovery

/-- Event counters carried by the instrumented array scan. Search counters
record events from the executed row predicate. Update counters are explicit
per-pivot upper charges for the current nested `Array.ofFn` implementation. -/
structure ActualBalanceGaussianArrayEventTrace where
  columnsProcessed : Nat
  rowIndexListNodes : Nat
  selectorPredicateTests : Nat
  usedMembershipChecks : Nat
  selectorArrayViewCalls : Nat
  pivotUpdates : Nat
  pivotUpdateArrayViewCallsUpper : Nat
  pivotRowComparisons : Nat
  fieldMultiplicationsUpper : Nat
  fieldAdditionsUpper : Nat
  coefficientCellWrites : Nat
  newArraySlots : Nat
  transcriptCons : Nat
  deriving DecidableEq, Repr

def actualBalanceGaussianArrayEventTrace.zero :
    ActualBalanceGaussianArrayEventTrace :=
  { columnsProcessed := 0
    rowIndexListNodes := 0
    selectorPredicateTests := 0
    usedMembershipChecks := 0
    selectorArrayViewCalls := 0
    pivotUpdates := 0
    pivotUpdateArrayViewCallsUpper := 0
    pivotRowComparisons := 0
    fieldMultiplicationsUpper := 0
    fieldAdditionsUpper := 0
    coefficientCellWrites := 0
    newArraySlots := 0
    transcriptCons := 0 }

def actualBalanceGaussianArrayEventTrace.add
    (left right : ActualBalanceGaussianArrayEventTrace) :
    ActualBalanceGaussianArrayEventTrace :=
  { columnsProcessed := left.columnsProcessed + right.columnsProcessed
    rowIndexListNodes := left.rowIndexListNodes + right.rowIndexListNodes
    selectorPredicateTests := left.selectorPredicateTests + right.selectorPredicateTests
    usedMembershipChecks := left.usedMembershipChecks + right.usedMembershipChecks
    selectorArrayViewCalls := left.selectorArrayViewCalls + right.selectorArrayViewCalls
    pivotUpdates := left.pivotUpdates + right.pivotUpdates
    pivotUpdateArrayViewCallsUpper :=
      left.pivotUpdateArrayViewCallsUpper + right.pivotUpdateArrayViewCallsUpper
    pivotRowComparisons := left.pivotRowComparisons + right.pivotRowComparisons
    fieldMultiplicationsUpper :=
      left.fieldMultiplicationsUpper + right.fieldMultiplicationsUpper
    fieldAdditionsUpper := left.fieldAdditionsUpper + right.fieldAdditionsUpper
    coefficientCellWrites := left.coefficientCellWrites + right.coefficientCellWrites
    newArraySlots := left.newArraySlots + right.newArraySlots
    transcriptCons := left.transcriptCons + right.transcriptCons }

/-- A source-level operation charge read directly from a run's event trace.
Each array-view request is charged for at most two safe indexed reads. The
row-update view/multiplication/addition counters are conservative charges. -/
def actualBalanceGaussianArrayEventTrace.sourceOperationCountUpper
    (trace : ActualBalanceGaussianArrayEventTrace) : Nat :=
  trace.rowIndexListNodes + trace.columnsProcessed +
    trace.selectorPredicateTests + trace.usedMembershipChecks +
    2 * trace.selectorArrayViewCalls +
    2 * trace.pivotUpdateArrayViewCallsUpper +
    trace.pivotRowComparisons + trace.fieldMultiplicationsUpper +
    trace.fieldAdditionsUpper + trace.coefficientCellWrites +
    trace.pivotUpdates + trace.transcriptCons

/-- Charge the one executed selector predicate when a candidate row is used.
The equality test against one still occurs on the masked zero value. -/
def actualBalanceGaussianArrayUsedRowProbe :
    ActualBalanceGaussianArrayEventTrace :=
  { actualBalanceGaussianArrayEventTrace.zero with
    selectorPredicateTests := 1
    usedMembershipChecks := 1 }

/-- Charge the one executed selector predicate when a candidate row is fresh.
This branch performs one nested-array coefficient view. -/
def actualBalanceGaussianArrayFreshRowProbe :
    ActualBalanceGaussianArrayEventTrace :=
  { actualBalanceGaussianArrayEventTrace.zero with
    selectorPredicateTests := 1
    usedMembershipChecks := 1
    selectorArrayViewCalls := 1 }

/-- Recursive first-match selector over the already materialized `Fin` row
list. It returns the found row together with the counters accumulated while
evaluating predicates, stopping at the first match. -/
def actualBalanceGaussianArrayCountedFindUnusedRow {m n : Nat}
    (cells : Array (Array (ZMod 2))) (column : Fin n)
    (used : Finset (Fin m)) : List (Fin m) →
      Option (Fin m) × ActualBalanceGaussianArrayEventTrace
  | [] => (none, actualBalanceGaussianArrayEventTrace.zero)
  | row :: rows =>
      if hused : row ∈ used then
        let rest := actualBalanceGaussianArrayCountedFindUnusedRow
          cells column used rows
        (rest.1, actualBalanceGaussianArrayEventTrace.add
          actualBalanceGaussianArrayUsedRowProbe rest.2)
      else if hvalue : actualBalanceGaussianArrayView cells row column = 1 then
        (some row, actualBalanceGaussianArrayFreshRowProbe)
      else
        let rest := actualBalanceGaussianArrayCountedFindUnusedRow
          cells column used rows
        (rest.1, actualBalanceGaussianArrayEventTrace.add
          actualBalanceGaussianArrayFreshRowProbe rest.2)

private theorem actualBalanceGaussianArrayCountedFindUnusedRow_eq_find?
    {m n : Nat} (cells : Array (Array (ZMod 2))) (column : Fin n)
    (used : Finset (Fin m)) (rows : List (Fin m)) :
    (actualBalanceGaussianArrayCountedFindUnusedRow cells column used rows).1 =
      rows.find? (fun row => decide
        ((if row ∈ used then 0 else
          actualBalanceGaussianArrayView cells row column) = 1)) := by
  induction rows with
  | nil => rfl
  | cons row rows ih =>
      by_cases hused : row ∈ used
      · simp [actualBalanceGaussianArrayCountedFindUnusedRow, hused,
          actualBalanceGaussianArrayEventTrace.add, ih, List.find?]
      · by_cases hvalue : actualBalanceGaussianArrayView cells row column = 1
        · simp [actualBalanceGaussianArrayCountedFindUnusedRow, hused, hvalue,
            actualBalanceGaussianArrayFreshRowProbe, List.find?]
        · simp [actualBalanceGaussianArrayCountedFindUnusedRow, hused, hvalue,
            actualBalanceGaussianArrayEventTrace.add,
            actualBalanceGaussianArrayFreshRowProbe, ih, List.find?]

/-- Execute one array-backed first-unused-row search and record its actual
predicate count. The row-index list is fully materialized before `find`, so
its `m` list cells are charged even when the first row matches. -/
def actualBalanceGaussianArrayCountedFirstUnusedPivotRow {m n : Nat}
    (cells : Array (Array (ZMod 2))) (column : Fin n)
    (used : Finset (Fin m)) :
      Option (Fin m) × ActualBalanceGaussianArrayEventTrace :=
  let rows := List.ofFn fun row : Fin m => row
  let result := actualBalanceGaussianArrayCountedFindUnusedRow
    cells column used rows
  (result.1, actualBalanceGaussianArrayEventTrace.add
    { actualBalanceGaussianArrayEventTrace.zero with rowIndexListNodes := m }
    result.2)

theorem actualBalanceGaussianArrayCountedFirstUnusedPivotRow_eq
    {m n : Nat} (cells : Array (Array (ZMod 2))) (column : Fin n)
    (used : Finset (Fin m)) :
    (actualBalanceGaussianArrayCountedFirstUnusedPivotRow
      cells column used).1 =
      actualBalanceGaussianArrayFirstUnusedPivotRow cells column used := by
  rw [actualBalanceGaussianArrayCountedFirstUnusedPivotRow,
    actualBalanceGaussianArrayCountedFindUnusedRow_eq_find?]
  rfl

/-- Conservative event charges for one call to the current row-update
primitive. It compares each output cell's row index, allows three coefficient
views and one field multiply/add per cell, and charges all nested-array slots
constructed by `Array.ofFn`. -/
def actualBalanceGaussianArrayPivotUpdateCharge (m n : Nat) :
    ActualBalanceGaussianArrayEventTrace :=
  { actualBalanceGaussianArrayEventTrace.zero with
    pivotUpdates := 1
    pivotUpdateArrayViewCallsUpper := 3 * m * n
    pivotRowComparisons := m * n
    fieldMultiplicationsUpper := m * n
    fieldAdditionsUpper := m * n
    coefficientCellWrites := m * n
    newArraySlots := m * (n + 1)
    transcriptCons := 1 }

/-- Instrumented recursive scan. Its value is an array/pivot transcript pair;
the second component is the operation-event record. -/
def actualBalanceGaussianArrayColumnScanInstrumented {m n : Nat}
    (cells : Array (Array (ZMod 2))) : Finset (Fin m) → List (Fin n) →
      (Array (Array (ZMod 2)) × List (Fin m × Fin n)) ×
        ActualBalanceGaussianArrayEventTrace
  | used, [] => ((cells, []), actualBalanceGaussianArrayEventTrace.zero)
  | used, column :: columns =>
      let selected := actualBalanceGaussianArrayCountedFirstUnusedPivotRow
        cells column used
      match selected.1 with
      | none =>
          let rest := actualBalanceGaussianArrayColumnScanInstrumented
            cells used columns
          (rest.1, actualBalanceGaussianArrayEventTrace.add
            (actualBalanceGaussianArrayEventTrace.add selected.2
              { actualBalanceGaussianArrayEventTrace.zero with columnsProcessed := 1 })
            rest.2)
      | some row =>
          let rest := actualBalanceGaussianArrayColumnScanInstrumented
            (actualBalanceGaussianArrayPivotRow cells row column)
            (insert row used) columns
          ((rest.1.1, (row, column) :: rest.1.2),
            actualBalanceGaussianArrayEventTrace.add
              (actualBalanceGaussianArrayEventTrace.add selected.2
                (actualBalanceGaussianArrayEventTrace.add
                  { actualBalanceGaussianArrayEventTrace.zero with columnsProcessed := 1 }
                  (actualBalanceGaussianArrayPivotUpdateCharge m n)))
              rest.2)

/-- The instrumented scan produces exactly the same nested-array output and
pivot transcript as the uninstrumented array scan. Event accumulation does
not change branch selection or row updates. -/
theorem actualBalanceGaussianArrayColumnScanInstrumented_refines
    {m n : Nat} (cells : Array (Array (ZMod 2))) (used : Finset (Fin m))
    (columns : List (Fin n)) :
    (actualBalanceGaussianArrayColumnScanInstrumented cells used columns).1 =
      actualBalanceGaussianArrayColumnScan cells used columns := by
  induction columns generalizing cells used with
  | nil => rfl
  | cons column columns ih =>
      let selected := actualBalanceGaussianArrayCountedFirstUnusedPivotRow
        cells column used
      have hselected := actualBalanceGaussianArrayCountedFirstUnusedPivotRow_eq
        cells column used
      cases h : selected.1 with
      | none =>
          have harraySelector :
              actualBalanceGaussianArrayFirstUnusedPivotRow cells column used = none := by
            rw [← hselected, h]
          simpa [actualBalanceGaussianArrayColumnScanInstrumented,
            actualBalanceGaussianArrayColumnScan, selected, h, harraySelector] using
            ih cells used
      | some row =>
          have harraySelector :
              actualBalanceGaussianArrayFirstUnusedPivotRow cells column used = some row := by
            rw [← hselected, h]
          simpa [actualBalanceGaussianArrayColumnScanInstrumented,
            actualBalanceGaussianArrayColumnScan, selected, h, harraySelector] using
            ih (actualBalanceGaussianArrayPivotRow cells row column)
              (insert row used)

/-- Raw-system specialization of the instrumented execution. Its projected
value refines the deterministic array scan, which in turn refines the accepted
matrix scan in `S010BalanceGaussianArrayDeterministicScan`. -/
def actualBalanceGaussianSerializedArrayScanInstrumented {s : Nat}
    (raw : RawCoefficientArray) (tape : FiveWordTape s) :=
  actualBalanceGaussianArrayColumnScanInstrumented
    (actualBalanceSerializedCoefficientMatrix
      (decodeRawArray (n := 3 * s) raw) tape)
    ∅ (List.ofFn fun column : Fin ((3 * s) * (3 * s)) => column)

/-- The instrumented raw execution projects to the accepted raw matrix scan's
reduced matrix and pivot transcript. -/
theorem actualBalanceGaussianSerializedArrayScanInstrumented_refines
    {s : Nat} (raw : RawCoefficientArray) (tape : FiveWordTape s) :
    (actualBalanceGaussianArrayView
        (actualBalanceGaussianSerializedArrayScanInstrumented raw tape).1.1,
      (actualBalanceGaussianSerializedArrayScanInstrumented raw tape).1.2) =
      actualBalanceGaussianRawScan raw tape := by
  unfold actualBalanceGaussianSerializedArrayScanInstrumented
  rw [actualBalanceGaussianArrayColumnScanInstrumented_refines]
  exact actualBalanceGaussianSerializedArrayDeterministicScan_refines raw tape

end CorruptedFieldRecovery
