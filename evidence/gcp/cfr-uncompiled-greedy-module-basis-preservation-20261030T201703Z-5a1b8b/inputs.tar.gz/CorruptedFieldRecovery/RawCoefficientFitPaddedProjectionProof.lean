import CorruptedFieldRecovery.RawCoefficientFitCompactProjection

/-! # Compact/padded fit equivalence and coefficient projection

This source attempts the finite-sum proof for the original zero-padded
`s+d^3` coefficient system. Invalid support positions have zero matrix
columns; restricting any padded solution to the scalar positions and valid
increasing support positions therefore preserves every row equation. The
compact-to-padded extension assigns zero to invalid positions.

All statements below are uncompiled. Raw input/support sizes and inverse
coordinate validity remain the explicit shape conditions in
`RawCoefficientFitExecutionShape`; no manuscript-specific consistency premise
is added.
-/

namespace CorruptedFieldRecovery

/-- Equivalence between valid ordered support positions in the `d^3` cube and
the source's increasing support triples. -/
def rawFitValidSupportPositionEquiv (d : Nat) :
    {position : Fin ((d * d) * d) //
      rawOrderedTripleIncreasing (rawOrderedTripleAt position)} ≃
      IncreasingTriple d where
  toFun position :=
    rawOrderedTripleAsIncreasing (rawOrderedTripleAt position.1) position.2
  invFun triple :=
    ⟨rawOrderedTripleFinEquiv d triple.1,
      by simpa [rawOrderedTripleAt, rawOrderedTripleIncreasing,
        rawOrderedTripleFinEquiv] using triple.2⟩
  left_inv position := by
    apply Subtype.ext
    simp [rawOrderedTripleAt, rawOrderedTripleFinEquiv]
  right_inv triple := by
    apply Subtype.ext
    rfl

/-- Sum over a full ordered support cube after zeroing invalid triples is
exactly the sum over the source's increasing triples. -/
theorem rawFitSupportZeroPaddedSum {d : Nat}
    (f : IncreasingTriple d → ZMod 2) :
    (∑ position : Fin ((d * d) * d),
      if h : rawOrderedTripleIncreasing (rawOrderedTripleAt position) then
        f (rawOrderedTripleAsIncreasing (rawOrderedTripleAt position) h)
      else 0) = ∑ triple : IncreasingTriple d, f triple := by
  classical
  let valid : Fin ((d * d) * d) → Prop :=
    fun position => rawOrderedTripleIncreasing (rawOrderedTripleAt position)
  let term : Fin ((d * d) * d) → ZMod 2 := fun position =>
    if h : valid position then
      f (rawOrderedTripleAsIncreasing (rawOrderedTripleAt position) h)
    else 0
  have hgood :
      (∑ position : {position : Fin ((d * d) * d) // valid position},
        term position.1) = ∑ triple : IncreasingTriple d, f triple := by
    calc
      _ = ∑ position : {position : Fin ((d * d) * d) // valid position},
          f (rawFitValidSupportPositionEquiv d position) := by
            apply Finset.sum_congr rfl
            intro position hposition
            simp [term, valid]
      _ = ∑ triple : IncreasingTriple d, f triple :=
            Equiv.sum_comp (rawFitValidSupportPositionEquiv d) f
  have hbad :
      (∑ position : {position : Fin ((d * d) * d) // ¬ valid position},
        term position.1) = 0 := by
    apply Finset.sum_eq_zero
    intro position hposition
    simp [term, valid, position.property]
  calc
    (∑ position : Fin ((d * d) * d), term position) =
        (∑ position : {position : Fin ((d * d) * d) // valid position},
          term position.1) +
        (∑ position : {position : Fin ((d * d) * d) // ¬ valid position},
          term position.1) :=
      (Fintype.sum_subtype_add_sum_subtype valid term).symm
    _ = ∑ triple : IncreasingTriple d, f triple := by rw [hgood, hbad]; simp

/-- Compact sum row equality to a padded finite dot product at one increasing
physical row. -/
theorem rawCoefficientFitPaddedRowDotProduct {s d : Nat}
    (candidate : RawFieldCandidate s)
    (hcheck : rawFieldCandidateCheck candidate = true)
    (inverse : RawCoordinateMatrix) (supportMatrix : RawBinaryArray)
    (coefficients : RawCoefficientFitColumnIndex s d → ZMod 2)
    (row : IncreasingTriple (3 * s)) :
    (rawCoefficientFitFiniteMatrix candidate hcheck inverse supportMatrix *ᵥ
      rawCoefficientFitExtendCompact coefficients)
        (rawOrderedTripleFinEquiv (3 * s) row.val) =
      (∑ column : RawCoefficientFitColumnIndex s d,
        rawCoefficientFitEntry candidate hcheck inverse supportMatrix row column *
          coefficients column) := by
  classical
  let rowPosition := rawOrderedTripleFinEquiv (3 * s) row.val
  have hrow : rawOrderedTripleIncreasing (rawOrderedTripleAt rowPosition) := by
    simp [rowPosition, rawOrderedTripleAt, rawOrderedTripleFinEquiv,
      rawOrderedTripleIncreasing, row.property]
  have hsupport (position : Fin ((d * d) * d)) :
      rawCoefficientFitFiniteEntry candidate hcheck inverse supportMatrix rowPosition
          (rawFitColumnFinEquiv s d (Sum.inr position)) *
        rawCoefficientFitExtendCompact coefficients
          (rawFitColumnFinEquiv s d (Sum.inr position)) =
      if h : rawOrderedTripleIncreasing (rawOrderedTripleAt position) then
        rawCoefficientFitEntry candidate hcheck inverse supportMatrix row
          (Sum.inr (rawOrderedTripleAsIncreasing (rawOrderedTripleAt position) h)) *
          coefficients
            (Sum.inr (rawOrderedTripleAsIncreasing (rawOrderedTripleAt position) h))
      else 0 := by
    by_cases hp : rawOrderedTripleIncreasing (rawOrderedTripleAt position)
    · simp [rawCoefficientFitFiniteEntry, rawCoefficientFitExtendCompact,
        rawFitColumnFinEquiv, rowPosition, hrow, hp,
        rawOrderedTripleAt, rawOrderedTripleAsIncreasing]
    · simp [rawCoefficientFitFiniteEntry, rawCoefficientFitExtendCompact,
        rawFitColumnFinEquiv, rowPosition, hrow, hp,
        rawOrderedTripleAt, rawOrderedTripleAsIncreasing]
  simp only [Matrix.mulVec, dotProduct]
  rw [← Equiv.sum_comp (rawFitColumnFinEquiv s d)
    (fun column => rawCoefficientFitFiniteEntry candidate hcheck inverse supportMatrix
      rowPosition column * rawCoefficientFitExtendCompact coefficients column)]
  rw [Fintype.sum_sum_type]
  have hleft :
      (∑ j : Fin s,
        rawCoefficientFitFiniteEntry candidate hcheck inverse supportMatrix rowPosition
          (rawFitColumnFinEquiv s d (Sum.inl j)) *
        rawCoefficientFitExtendCompact coefficients
          (rawFitColumnFinEquiv s d (Sum.inl j))) =
      ∑ j : Fin s,
        rawCoefficientFitEntry candidate hcheck inverse supportMatrix row (Sum.inl j) *
          coefficients (Sum.inl j) := by
    apply Finset.sum_congr rfl
    intro j hj
    simp [rawCoefficientFitFiniteEntry, rawCoefficientFitExtendCompact,
      rawFitColumnFinEquiv, rowPosition, hrow,
      rawOrderedTripleAt, rawOrderedTripleAsIncreasing]
  have hright :
      (∑ position : Fin ((d * d) * d),
        rawCoefficientFitFiniteEntry candidate hcheck inverse supportMatrix rowPosition
            (rawFitColumnFinEquiv s d (Sum.inr position)) *
          rawCoefficientFitExtendCompact coefficients
            (rawFitColumnFinEquiv s d (Sum.inr position))) =
      ∑ triple : IncreasingTriple d,
        rawCoefficientFitEntry candidate hcheck inverse supportMatrix row
          (Sum.inr triple) * coefficients (Sum.inr triple) := by
    calc
      _ = ∑ position : Fin ((d * d) * d),
          if h : rawOrderedTripleIncreasing (rawOrderedTripleAt position) then
            rawCoefficientFitEntry candidate hcheck inverse supportMatrix row
              (Sum.inr (rawOrderedTripleAsIncreasing
                (rawOrderedTripleAt position) h)) *
              coefficients (Sum.inr (rawOrderedTripleAsIncreasing
                (rawOrderedTripleAt position) h))
          else 0 := by
            apply Finset.sum_congr rfl
            intro position hposition
            exact hsupport position
      _ = ∑ triple : IncreasingTriple d,
          rawCoefficientFitEntry candidate hcheck inverse supportMatrix row
            (Sum.inr triple) * coefficients (Sum.inr triple) :=
            rawFitSupportZeroPaddedSum _
  calc
    _ = (∑ j : Fin s,
          rawCoefficientFitEntry candidate hcheck inverse supportMatrix row
            (Sum.inl j) * coefficients (Sum.inl j)) +
        (∑ triple : IncreasingTriple d,
          rawCoefficientFitEntry candidate hcheck inverse supportMatrix row
            (Sum.inr triple) * coefficients (Sum.inr triple)) := by
          rw [hleft, hright]
    _ = ∑ column : RawCoefficientFitColumnIndex s d,
          rawCoefficientFitEntry candidate hcheck inverse supportMatrix row column *
            coefficients column := by
          simp [RawCoefficientFitColumnIndex, Fintype.sum_sum_type]

/-- Padded finite matrix solution implies the compact fit solution by
projecting away the zero invalid-support columns. -/
theorem rawCoefficientFitCompactSolution_of_padded {s d : Nat}
    (candidate : RawFieldCandidate s)
    (hcheck : rawFieldCandidateCheck candidate = true)
    (inverse : RawCoordinateMatrix) (supportMatrix : RawBinaryArray)
    (raw : RawCoefficientArray)
    (padded : Fin (s + (d * d) * d) → ZMod 2)
    (hpadded : rawCoefficientFitFiniteMatrix candidate hcheck inverse supportMatrix *ᵥ
      padded = rawCoefficientFitFiniteRhsVector raw) :
    RawCoefficientFitAffineSolution candidate hcheck inverse supportMatrix raw := by
  classical
  refine ⟨rawCoefficientFitProjectCompact padded, ?_⟩
  intro row
  have hrow := congrFun hpadded (rawOrderedTripleFinEquiv (3 * s) row.val)
  have hproject :
      (rawCoefficientFitFiniteMatrix candidate hcheck inverse supportMatrix *ᵥ padded)
          (rawOrderedTripleFinEquiv (3 * s) row.val) =
      (rawCoefficientFitFiniteMatrix candidate hcheck inverse supportMatrix *ᵥ
        rawCoefficientFitExtendCompact
          (rawCoefficientFitProjectCompact padded))
          (rawOrderedTripleFinEquiv (3 * s) row.val) := by
    simp [Matrix.mulVec, dotProduct, rawCoefficientFitFiniteMatrix,
      rawCoefficientFitFiniteEntry, rawCoefficientFitExtendCompact,
      rawCoefficientFitProjectCompact, rawCoefficientFitCompactPosition,
      rawFitColumnFinEquiv, rawOrderedTripleAt, rawOrderedTripleIncreasing,
      rawOrderedTripleAsIncreasing, rawOrderedTripleFinEquiv]
  have hrowExtended :
      (rawCoefficientFitFiniteMatrix candidate hcheck inverse supportMatrix *ᵥ
        rawCoefficientFitExtendCompact
          (rawCoefficientFitProjectCompact padded))
          (rawOrderedTripleFinEquiv (3 * s) row.val) =
        rawCoefficientFitFiniteRhs raw
          (rawOrderedTripleFinEquiv (3 * s) row.val) := by
    calc
      _ = (rawCoefficientFitFiniteMatrix candidate hcheck inverse supportMatrix *ᵥ
            padded) (rawOrderedTripleFinEquiv (3 * s) row.val) := hproject.symm
      _ = _ := hrow
  rw [rawCoefficientFitPaddedRowDotProduct] at hrowExtended
  simpa [rawCoefficientFitFiniteRhs, rawOrderedTripleAt,
    rawOrderedTripleFinEquiv, rawOrderedTripleIncreasing,
    rawOrderedTripleAsIncreasing] using hrowExtended

/-- A compact solution extends to a solution of the zero-padded finite
system. -/
theorem rawCoefficientFitPaddedSolution_of_compact {s d : Nat}
    (candidate : RawFieldCandidate s)
    (hcheck : rawFieldCandidateCheck candidate = true)
    (inverse : RawCoordinateMatrix) (supportMatrix : RawBinaryArray)
    (raw : RawCoefficientArray)
    (hcompact : RawCoefficientFitAffineSolution candidate hcheck inverse supportMatrix raw) :
    RawCoefficientFitFiniteSystemSolution candidate hcheck inverse supportMatrix raw := by
  classical
  rcases hcompact with ⟨coefficients, hfit⟩
  refine ⟨rawCoefficientFitExtendCompact coefficients, ?_⟩
  apply funext
  intro position
  let triple := rawOrderedTripleAt position
  by_cases hrow : rawOrderedTripleIncreasing triple
  · let row := rawOrderedTripleAsIncreasing triple hrow
    have hpos : rawOrderedTripleFinEquiv (3 * s) row.val = position := by
      simp [row, triple, rawOrderedTripleAt, rawOrderedTripleFinEquiv]
    rw [← hpos, rawCoefficientFitPaddedRowDotProduct]
    simpa [rawCoefficientFitFiniteRhs, row, triple,
      rawOrderedTripleAt, rawOrderedTripleIncreasing,
      rawOrderedTripleAsIncreasing] using hfit row
  · simp [rawCoefficientFitFiniteMatrix, rawCoefficientFitFiniteEntry,
      rawCoefficientFitFiniteRhs, triple, rawOrderedTripleAt, hrow]

/-- Compact and zero-padded finite fit systems have the same consistency
status. No existence of a fit is presumed. -/
theorem rawCoefficientFitCompactPaddedConsistency_iff {s d : Nat}
    (candidate : RawFieldCandidate s)
    (hcheck : rawFieldCandidateCheck candidate = true)
    (inverse : RawCoordinateMatrix) (supportMatrix : RawBinaryArray)
    (raw : RawCoefficientArray) :
    RawCoefficientFitAffineSolution candidate hcheck inverse supportMatrix raw ↔
      RawCoefficientFitFiniteSystemSolution candidate hcheck inverse supportMatrix raw := by
  constructor
  · exact rawCoefficientFitPaddedSolution_of_compact candidate hcheck inverse supportMatrix raw
  · intro h
    rcases h with ⟨padded, hpadded⟩
    exact rawCoefficientFitCompactSolution_of_padded candidate hcheck inverse supportMatrix
      raw padded hpadded

end CorruptedFieldRecovery
