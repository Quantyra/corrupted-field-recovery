import CorruptedFieldRecovery.S010BalanceGaussianAffinePowerSolve

open scoped Matrix

namespace CorruptedFieldRecovery

/-! An executable result wrapper for the augmented power-system Gaussian scan.

The finite-dimensional basis argument is used only in the correctness proof
to establish that the affine system is consistent. The returned coefficient
function itself is extracted from the deterministic finite-matrix scan and
its first free kernel vector with final coordinate one. The existing
nested-array implementation refines this same scan; augmented-run resource
costs are not asserted here. -/

/-- The output coefficient is the first s entries of the selected augmented
kernel vector. -/
def actualBalanceGaussianAffineRecurrenceValue {s : Nat}
    (T : Module.End BinaryField (BinaryVector (3 * s)))
    (free : balanceGaussianFreeIndex
      (balanceGaussianColumnScan (actualBalanceGaussianAffinePowerMatrix T)
        ∅ (List.ofFn fun j : Fin (s + 1) => j)).2) : Fin s → BinaryField :=
  let run := balanceGaussianColumnScan (actualBalanceGaussianAffinePowerMatrix T)
    ∅ (List.ofFn fun j : Fin (s + 1) => j)
  fun j => balanceGaussianFreeCandidateFamily run.1 run.2 free
    (Fin.last s) (Fin.castSucc j)

/-- The coefficient vector returned by the deterministic matrix scan, when
the scan finds an affine kernel candidate. -/
def actualBalanceGaussianAffineRecurrence? {s : Nat}
    (T : Module.End BinaryField (BinaryVector (3 * s))) :
    Option (Fin s → BinaryField) :=
  (actualBalanceGaussianAffineSelectFreeIndex
    (actualBalanceGaussianAffinePowerMatrix T)).map
    (actualBalanceGaussianAffineRecurrenceValue T)

/-- If the first s powers are independent inside the s-dimensional scalar
range, the actual scan returns coefficients and those returned
coefficients satisfy the recurrence. No existence witness is supplied to the
executable function: the witness is derived from the dimension argument. -/
theorem actualBalanceGaussianAffineRecurrence?_correct
    {K : Type*} [Field K] [Fintype K] [DecidableEq K] [Finite K]
    [CharP K 2] [Algebra BinaryField K] [FiniteDimensional BinaryField K]
    {s : Nat}
    (Q : BinaryVector (3 * s) ≃ₗ[BinaryField] FieldTriple K)
    (T : Module.End BinaryField (BinaryVector (3 * s)))
    (hT : T ∈ qScalarConjugateEndRange Q)
    (hK : Module.finrank BinaryField K = s)
    (hpow : LinearIndependent BinaryField (fun i : Fin s => T ^ i.val)) :
    ∃ coefficients,
      actualBalanceGaussianAffineRecurrence? T = some coefficients ∧
      T ^ s = ∑ j : Fin s, coefficients j • T ^ j.val := by
  rcases actualBalanceGaussianPowerRecurrence_exists_of_independent
      Q T hT hK hpow with ⟨witnessCoefficients, hwitness⟩
  let A := actualBalanceGaussianAffinePowerMatrix T
  have hsolution : ∃ x, A *ᵥ x = 0 ∧ x (Fin.last s) = 1 := by
    refine ⟨actualBalanceGaussianAffinePowerWitness witnessCoefficients,
      (actualBalanceGaussianAffinePowerMatrix_mulVec_witness_iff T
        witnessCoefficients).2 hwitness, ?_⟩
    simp [actualBalanceGaussianAffinePowerWitness]
  obtain ⟨free, hselected, hlast⟩ :=
    actualBalanceGaussianAffineSelectFreeIndex_some_of_witness A hsolution
  let coefficients := actualBalanceGaussianAffineRecurrenceValue T free
  have hker : A *ᵥ
      balanceGaussianFreeCandidateFamily
        (balanceGaussianColumnScan A ∅
          (List.ofFn fun j : Fin (s + 1) => j)).1
        (balanceGaussianColumnScan A ∅
          (List.ofFn fun j : Fin (s + 1) => j)).2 free = 0 :=
    actualBalanceGaussianAffineFreeCandidate_mem_ker A free
  have hdecomp :
      balanceGaussianFreeCandidateFamily
        (balanceGaussianColumnScan A ∅
          (List.ofFn fun j : Fin (s + 1) => j)).1
        (balanceGaussianColumnScan A ∅
          (List.ofFn fun j : Fin (s + 1) => j)).2 free =
        Fin.snoc coefficients 1 := by
    funext i
    refine Fin.lastCases ?_ ?_ i
    · simpa [coefficients, actualBalanceGaussianAffineRecurrenceValue,
        A] using hlast
    · intro j
      rfl
  have hrecurrence :
      T ^ s = ∑ j : Fin s, coefficients j • T ^ j.val := by
    apply (actualBalanceGaussianAffinePowerMatrix_mulVec_witness_iff
      T coefficients).mp
    rw [← hdecomp]
    exact hker
  refine ⟨coefficients, ?_, hrecurrence⟩
  simp [actualBalanceGaussianAffineRecurrence?, coefficients, hselected,
    actualBalanceGaussianAffineRecurrenceValue]

/-- The returned coefficients produce a root of the associated recurrence
polynomial at the sampled endomorphism. This is the exact algebraic input
needed by the separate raw modulus serializer/Rabin connection. -/
theorem actualBalanceGaussianAffineRecurrence?_polynomial_root
    {K : Type*} [Field K] [Fintype K] [DecidableEq K] [Finite K]
    [CharP K 2] [Algebra BinaryField K] [FiniteDimensional BinaryField K]
    {s : Nat}
    (Q : BinaryVector (3 * s) ≃ₗ[BinaryField] FieldTriple K)
    (T : Module.End BinaryField (BinaryVector (3 * s)))
    (hT : T ∈ qScalarConjugateEndRange Q)
    (hK : Module.finrank BinaryField K = s)
    (hpow : LinearIndependent BinaryField (fun i : Fin s => T ^ i.val)) :
    ∃ coefficients,
      actualBalanceGaussianAffineRecurrence? T = some coefficients ∧
      Polynomial.aeval T
        (actualBalanceGaussianRecurrencePolynomial coefficients) = 0 := by
  obtain ⟨coefficients, hout, hrecurrence⟩ :=
    actualBalanceGaussianAffineRecurrence?_correct Q T hT hK hpow
  refine ⟨coefficients, hout, ?_⟩
  rw [actualBalanceGaussianRecurrencePolynomial_aeval, hrecurrence]
  simp

/-- Specialize the affine solver to the exact endomorphism selected from the
ordered free-coordinate seed on a good tape. The model promise is retained:
the result does not discover Q, E, U, the basis choices, or the good event. -/
theorem actualBalanceGaussianSelectedSeedRecurrence?_correct
    {K : Type*} [Field K] [Fintype K] [DecidableEq K] [Finite K]
    [CharP K 2] [Algebra BinaryField K] [FiniteDimensional BinaryField K]
    [Algebra (ZMod (ringChar K)) K]
    {s : Nat}
    (Q : BinaryVector (3 * s) ≃ₗ[BinaryField] FieldTriple K)
    (E : BinaryTensor (3 * s))
    (U : Submodule BinaryField (KTriple K))
    (b : (Fin 4 → FieldTriple K) → Module.Basis (Fin s) BinaryField K)
    (raw : RawCoefficientArray) (tape : FiveWordTape s)
    (htape : tape ∈ actualFiveGoodTapeSet K Q
      (modeImageSemanticCleanFieldSet Q E) U b)
    (c : K) (hc : c ≠ 0)
    (hmodel : HasObservedTraceDeterminantDecomposition
      (decodeRawArray (n := 3 * s) raw) E LinearMap.id Q c)
    (hsize : raw.size = (3 * s) * (3 * s) * (3 * s))
    (hK : Module.finrank BinaryField K = s)
    (seed : Fin s → BinaryField)
    (hpow : LinearIndependent BinaryField (fun i : Fin s =>
      (actualBalanceGaussianArrayFlagSelectBySeed raw tape
        (by
          rw [← actualBalanceGaussianRawFreeIndex_card_eq
            Q E U b raw tape htape c hc hmodel hsize hK]
          rfl) seed) ^ i.val)) :
    ∃ coefficients,
      actualBalanceGaussianAffineRecurrence?
        (actualBalanceGaussianArrayFlagSelectBySeed raw tape
          (by
            rw [← actualBalanceGaussianRawFreeIndex_card_eq
              Q E U b raw tape htape c hc hmodel hsize hK]
            rfl) seed) = some coefficients ∧
      (actualBalanceGaussianArrayFlagSelectBySeed raw tape
        (by
          rw [← actualBalanceGaussianRawFreeIndex_card_eq
            Q E U b raw tape htape c hc hmodel hsize hK]
          rfl) seed) ^ s =
        ∑ j : Fin s, coefficients j •
          (actualBalanceGaussianArrayFlagSelectBySeed raw tape
            (by
              rw [← actualBalanceGaussianRawFreeIndex_card_eq
                Q E U b raw tape htape c hc hmodel hsize hK]
              rfl) seed) ^ j.val := by
  let T := actualBalanceGaussianArrayFlagSelectBySeed raw tape
    (by
      rw [← actualBalanceGaussianRawFreeIndex_card_eq
        Q E U b raw tape htape c hc hmodel hsize hK]
      rfl) seed
  have hT : T ∈ qScalarConjugateEndRange Q := by
    exact actualBalanceGaussianArrayFlagSelectBySeed_mem_qScalarRange
      Q E U b raw tape htape c hc hmodel hsize hK seed
  have hcorrect := actualBalanceGaussianAffineRecurrence?_correct
    Q T hT hK (by simpa [T] using hpow)
  exact hcorrect

/-- Full conditional bridge from the actual good-tape sample through the
augmented Gaussian recurrence solve to the sampled primitive-element
conclusion. In addition to the manuscript's good-event/model hypotheses, the
caller must supply the actual power-independence and raw-bit equality checks;
this theorem does not claim that either check always passes. -/
theorem actualBalanceGaussianSelectedSeedFilterPass_of_solverOutput
    {K : Type*} [Field K] [Fintype K] [DecidableEq K] [Finite K]
    [CharP K 2] [Algebra BinaryField K] [FiniteDimensional BinaryField K]
    [Algebra (ZMod (ringChar K)) K]
    {s : Nat}
    (Q : BinaryVector (3 * s) ≃ₗ[BinaryField] FieldTriple K)
    (E : BinaryTensor (3 * s))
    (U : Submodule BinaryField (KTriple K))
    (b : (Fin 4 → FieldTriple K) → Module.Basis (Fin s) BinaryField K)
    (raw : RawCoefficientArray) (tape : FiveWordTape s)
    (htape : tape ∈ actualFiveGoodTapeSet K Q
      (modeImageSemanticCleanFieldSet Q E) U b)
    (c : K) (hc : c ≠ 0)
    (hmodel : HasObservedTraceDeterminantDecomposition
      (decodeRawArray (n := 3 * s) raw) E LinearMap.id Q c)
    (hsize : raw.size = (3 * s) * (3 * s) * (3 * s))
    (hK : Module.finrank BinaryField K = s)
    (seed : Fin s → BinaryField)
    (candidate : RawFieldCandidate s)
    (hpow : LinearIndependent BinaryField (fun i : Fin s =>
      (actualBalanceGaussianArrayFlagSelectBySeed raw tape
        (by
          rw [← actualBalanceGaussianRawFreeIndex_card_eq
            Q E U b raw tape htape c hc hmodel hsize hK]
          rfl) seed) ^ i.val))
    (hencoded : ∃ coefficients,
      actualBalanceGaussianAffineRecurrence?
        (actualBalanceGaussianArrayFlagSelectBySeed raw tape
          (by
            rw [← actualBalanceGaussianRawFreeIndex_card_eq
              Q E U b raw tape htape c hc hmodel hsize hK]
            rfl) seed) = some coefficients ∧
      rawMaskPolynomial (rawFieldBitsToNat candidate.modulus) =
        actualBalanceGaussianRecurrencePolynomial coefficients)
    (hfast : rawFieldCandidateFastCheck candidate = true) :
    let T := actualBalanceGaussianArrayFlagSelectBySeed raw tape
      (by
        rw [← actualBalanceGaussianRawFreeIndex_card_eq
          Q E U b raw tape htape c hc hmodel hsize hK]
        rfl) seed
    let k := actualBalanceGaussianQScalarParameter Q T
    ∃ coefficients,
      actualBalanceGaussianAffineRecurrence? T = some coefficients ∧
      actualBalanceGaussianRecurrencePolynomial coefficients =
        minpoly BinaryField k ∧
      Algebra.adjoin BinaryField ({k} : Set K) = ⊤ := by
  let T := actualBalanceGaussianArrayFlagSelectBySeed raw tape
    (by
      rw [← actualBalanceGaussianRawFreeIndex_card_eq
        Q E U b raw tape htape c hc hmodel hsize hK]
      rfl) seed
  let k := actualBalanceGaussianQScalarParameter Q T
  rcases hencoded with ⟨coefficients, hsolver, hbits⟩
  have hT : T ∈ qScalarConjugateEndRange Q := by
    exact actualBalanceGaussianArrayFlagSelectBySeed_mem_qScalarRange
      Q E U b raw tape htape c hc hmodel hsize hK seed
  have hsolverCorrect := actualBalanceGaussianSelectedSeedRecurrence?_correct
    Q E U b raw tape htape c hc hmodel hsize hK seed (by simpa [T] using hpow)
  have hcoeff : actualBalanceGaussianAffineRecurrence? T = some coefficients := by
    simpa [T] using hsolver
  have hrecurrence : T ^ s = ∑ j : Fin s, coefficients j • T ^ j.val := by
    rcases hsolverCorrect with ⟨found, hfound, hrecurrence⟩
    rw [hcoeff] at hfound
    cases Option.some.inj hfound
    exact hrecurrence
  have hpass : ActualBalanceGaussianGeneratorFilterPass candidate coefficients T := by
    have hfast' : rawFieldCandidateShapeCheck candidate = true ∧
        rawCandidateRabinCheck candidate = true := by
      simpa [rawFieldCandidateFastCheck, Bool.and_eq_true] using hfast
    exact ⟨(by simpa [T] using hpow), hrecurrence, hbits,
      hfast'.1, hfast'.2⟩
  have hprimitive :=
    (actualBalanceGaussianSampledScalar_primitive_of_filterPass
      Q candidate coefficients T hT hpass hK)
  refine ⟨coefficients, ?_, hprimitive.1, hprimitive.2.1⟩
  simpa [T] using hcoeff

end CorruptedFieldRecovery
