import CorruptedFieldRecovery.S010BalanceGaussianArrayDeterministicScan

namespace CorruptedFieldRecovery

/-- Counters for a source-level upper model of the nested-array scan. The
array-slot fields count stored row references and coefficient cells, not Lean
runtime headers, closures, `Finset` tree nodes, or call-stack storage. -/
structure ActualBalanceGaussianArrayResourceModel where
  rowListCons : Nat
  selectorTests : Nat
  usedMembershipTests : Nat
  usedSetInserts : Nat
  arrayOptionReads : Nat
  fieldMultiplications : Nat
  fieldAdditions : Nat
  rowComparisons : Nat
  coefficientCellWrites : Nat
  cumulativeArraySlots : Nat
  transcriptCons : Nat
  columnListCons : Nat
  liveArrayAndListSlotsUpper : Nat
  deriving DecidableEq, Repr

/-- Conservative counters for an `m` by `n` array scan over `k` columns with
`p` successful pivots. Each row search materializes at most `m` row indices
and tests at most `m` predicates. Each pivot update rebuilds all `m*n` cells;
three array-view reads per cell cover the nonpivot branch. -/
def actualBalanceGaussianArrayResourceModel (m n k p : Nat) :
    ActualBalanceGaussianArrayResourceModel :=
  { rowListCons := k * m
    selectorTests := k * m
    usedMembershipTests := k * m
    usedSetInserts := p
    arrayOptionReads := 2 * (k * m + 3 * p * m * n)
    fieldMultiplications := p * m * n
    fieldAdditions := p * m * n
    rowComparisons := p * m * n
    coefficientCellWrites := p * m * n
    cumulativeArraySlots := p * m * (n + 1)
    transcriptCons := p
    columnListCons := k
    liveArrayAndListSlotsUpper := (p + 2) * m * (n + 1) + m + p + k }

/-- The sum of the source operations counted by the model. Array-slot
allocation and the live-slot bound are reported separately as space measures. -/
def actualBalanceGaussianArraySourceOperationCount
    (model : ActualBalanceGaussianArrayResourceModel) : Nat :=
  model.rowListCons + model.selectorTests + model.usedMembershipTests +
    model.arrayOptionReads + model.fieldMultiplications +
    model.fieldAdditions + model.rowComparisons +
    model.coefficientCellWrites + model.usedSetInserts +
    model.transcriptCons + model.columnListCons

/-- The source operation count expands to a simple polynomial in dimensions,
column count, and successful pivot count. -/
theorem actualBalanceGaussianArraySourceOperationCount_eq
    (m n k p : Nat) :
    actualBalanceGaussianArraySourceOperationCount
        (actualBalanceGaussianArrayResourceModel m n k p) =
      5 * k * m + 10 * p * m * n + 2 * p + k := by
  simp [actualBalanceGaussianArraySourceOperationCount,
    actualBalanceGaussianArrayResourceModel]
  ring

/-- If there are at most `k` pivots, the model's counted source work is at
most the expression obtained by charging a pivot at every column. -/
theorem actualBalanceGaussianArraySourceOperationCount_le
    (m n k p : Nat) (hp : p ≤ k) :
    actualBalanceGaussianArraySourceOperationCount
        (actualBalanceGaussianArrayResourceModel m n k p) ≤
      5 * k * m + 10 * k * m * n + 3 * k := by
  rw [actualBalanceGaussianArraySourceOperationCount_eq]
  calc
    5 * k * m + 10 * p * m * n + 2 * p + k ≤
        5 * k * m + 10 * k * m * n + 2 * k + k := by
          gcongr
    _ = 5 * k * m + 10 * k * m * n + 3 * k := by omega

/-- A scan emits no more pivot operations than there are listed columns. -/
theorem actualBalanceGaussianArrayColumnScan_pivotCount_le
    {m n : Nat} (cells : Array (Array (ZMod 2))) (used : Finset (Fin m))
    (columns : List (Fin n)) :
    (actualBalanceGaussianArrayColumnScan cells used columns).2.length ≤
      columns.length := by
  induction columns generalizing cells used with
  | nil => simp [actualBalanceGaussianArrayColumnScan]
  | cons column columns ih =>
      cases hpivot : actualBalanceGaussianArrayFirstUnusedPivotRow
          cells column used with
      | none =>
          have htail := ih cells used
          simpa [actualBalanceGaussianArrayColumnScan, hpivot] using
            Nat.le_trans htail (Nat.le_succ columns.length)
      | some row =>
          have htail := ih
            (actualBalanceGaussianArrayPivotRow cells row column)
            (insert row used)
          simpa [actualBalanceGaussianArrayColumnScan, hpivot] using
            Nat.succ_le_succ htail

/-- Cumulative and peak array/list slot counts grow monotonically with the
number of pivots. The peak bound assumes conservatively that all earlier
matrix versions remain live while a new one is being built. -/
theorem actualBalanceGaussianArrayResourceModel_space_bounds
    (m n k p : Nat) (hp : p ≤ k) :
    (actualBalanceGaussianArrayResourceModel m n k p).cumulativeArraySlots ≤
        k * m * (n + 1) ∧
      (actualBalanceGaussianArrayResourceModel m n k p).liveArrayAndListSlotsUpper ≤
        (k + 2) * m * (n + 1) + m + 2 * k := by
  constructor
  · simp [actualBalanceGaussianArrayResourceModel]
    gcongr
  · simp [actualBalanceGaussianArrayResourceModel]
    have hp2 : p + 2 ≤ k + 2 := Nat.add_le_add_right hp 2
    gcongr

/-- The source-level resource model is parameterized by the actual scan
transcript length, and its work bound follows from the scan's pivot-count
theorem. -/
def actualBalanceGaussianArrayScanResourceModel {m n : Nat}
    (cells : Array (Array (ZMod 2))) (used : Finset (Fin m))
    (columns : List (Fin n)) : ActualBalanceGaussianArrayResourceModel :=
  actualBalanceGaussianArrayResourceModel m n columns.length
    (actualBalanceGaussianArrayColumnScan cells used columns).2.length

theorem actualBalanceGaussianArrayScan_sourceWork_le
    {m n : Nat} (cells : Array (Array (ZMod 2))) (used : Finset (Fin m))
    (columns : List (Fin n)) :
    actualBalanceGaussianArraySourceOperationCount
        (actualBalanceGaussianArrayScanResourceModel cells used columns) ≤
      5 * columns.length * m + 10 * columns.length * m * n +
        3 * columns.length := by
  apply actualBalanceGaussianArraySourceOperationCount_le
  exact actualBalanceGaussianArrayColumnScan_pivotCount_le cells used columns

/-- Space-model bounds tied to the actual scan's number of successful pivot
updates. The model counts only array/list slots; it excludes `Finset` nodes,
headers, closures, and recursive stack frames. -/
theorem actualBalanceGaussianArrayScan_space_bounds
    {m n : Nat} (cells : Array (Array (ZMod 2))) (used : Finset (Fin m))
    (columns : List (Fin n)) :
    (actualBalanceGaussianArrayScanResourceModel cells used columns).cumulativeArraySlots ≤
        columns.length * m * (n + 1) ∧
      (actualBalanceGaussianArrayScanResourceModel cells used columns).liveArrayAndListSlotsUpper ≤
        (columns.length + 2) * m * (n + 1) + m + 2 * columns.length := by
  apply actualBalanceGaussianArrayResourceModel_space_bounds
  exact actualBalanceGaussianArrayColumnScan_pivotCount_le cells used columns

/-- For the raw balance system with `d = 3*s`, there are `4*d^2` equations,
`d^2` unknown coefficients, and `d^2` scanned columns. The source-level
operation model is therefore polynomial in `d` (and hence in `s`). This does
not assert a Lean evaluator, word-RAM, or bit-complexity bound. -/
theorem actualBalanceGaussianSerializedArrayScan_sourceWork_le
    {s : Nat} (raw : RawCoefficientArray) (tape : FiveWordTape s) :
    actualBalanceGaussianArraySourceOperationCount
        (actualBalanceGaussianArrayScanResourceModel
          (actualBalanceSerializedCoefficientMatrix
            (decodeRawArray (n := 3 * s) raw) tape)
          ∅ (List.ofFn fun column : Fin ((3 * s) * (3 * s)) => column)) ≤
      5 * ((3 * s) * (3 * s)) * (4 * ((3 * s) * (3 * s))) +
        10 * ((3 * s) * (3 * s)) * (4 * ((3 * s) * (3 * s))) *
          ((3 * s) * (3 * s)) +
        3 * ((3 * s) * (3 * s)) := by
  simpa using
    (actualBalanceGaussianArrayScan_sourceWork_le
      (actualBalanceSerializedCoefficientMatrix
        (decodeRawArray (n := 3 * s) raw) tape)
      (∅ : Finset (Fin (4 * ((3 * s) * (3 * s)))))
      (List.ofFn fun column : Fin ((3 * s) * (3 * s)) => column))

/-- Explicit polynomial form of the preceding bound, with `d=3*s`. -/
theorem actualBalanceGaussianSerializedArrayScan_sourceWork_le_polynomial
    {s : Nat} (raw : RawCoefficientArray) (tape : FiveWordTape s) :
    actualBalanceGaussianArraySourceOperationCount
        (actualBalanceGaussianArrayScanResourceModel
          (actualBalanceSerializedCoefficientMatrix
            (decodeRawArray (n := 3 * s) raw) tape)
          ∅ (List.ofFn fun column : Fin ((3 * s) * (3 * s)) => column)) ≤
      40 * (3 * s) ^ 6 + 20 * (3 * s) ^ 4 + 3 * (3 * s) ^ 2 := by
  calc
    _ ≤
        5 * ((3 * s) * (3 * s)) * (4 * ((3 * s) * (3 * s))) +
          10 * ((3 * s) * (3 * s)) * (4 * ((3 * s) * (3 * s))) *
            ((3 * s) * (3 * s)) +
          3 * ((3 * s) * (3 * s)) :=
      actualBalanceGaussianSerializedArrayScan_sourceWork_le raw tape
    _ = 40 * (3 * s) ^ 6 + 20 * (3 * s) ^ 4 + 3 * (3 * s) ^ 2 := by ring

/-- Cumulative allocation and peak live array/list slots for the raw balance
scan are also polynomial in `d=3*s`, within the explicitly scoped slot model. -/
theorem actualBalanceGaussianSerializedArrayScan_space_le_polynomial
    {s : Nat} (raw : RawCoefficientArray) (tape : FiveWordTape s) :
    (actualBalanceGaussianArrayScanResourceModel
      (actualBalanceSerializedCoefficientMatrix
        (decodeRawArray (n := 3 * s) raw) tape)
      ∅ (List.ofFn fun column : Fin ((3 * s) * (3 * s)) => column)).cumulativeArraySlots ≤
        4 * (3 * s) ^ 6 + 4 * (3 * s) ^ 4 ∧
      (actualBalanceGaussianArrayScanResourceModel
        (actualBalanceSerializedCoefficientMatrix
          (decodeRawArray (n := 3 * s) raw) tape)
        ∅ (List.ofFn fun column : Fin ((3 * s) * (3 * s)) => column)).liveArrayAndListSlotsUpper ≤
        4 * (3 * s) ^ 6 + 12 * (3 * s) ^ 4 + 14 * (3 * s) ^ 2 := by
  have hspace := actualBalanceGaussianArrayScan_space_bounds
    (actualBalanceSerializedCoefficientMatrix
      (decodeRawArray (n := 3 * s) raw) tape)
    (∅ : Finset (Fin (4 * ((3 * s) * (3 * s)))))
    (List.ofFn fun column : Fin ((3 * s) * (3 * s)) => column)
  constructor
  · calc
      _ ≤ ((3 * s) * (3 * s)) *
          (4 * ((3 * s) * (3 * s))) * (((3 * s) * (3 * s)) + 1) := by
            simpa using hspace.1
      _ = 4 * (3 * s) ^ 6 + 4 * (3 * s) ^ 4 := by ring
  · calc
      _ ≤ (((3 * s) * (3 * s)) + 2) *
          (4 * ((3 * s) * (3 * s))) * (((3 * s) * (3 * s)) + 1) +
          4 * ((3 * s) * (3 * s)) + 2 * ((3 * s) * (3 * s)) := by
            simpa using hspace.2
      _ = 4 * (3 * s) ^ 6 + 12 * (3 * s) ^ 4 + 14 * (3 * s) ^ 2 := by ring

end CorruptedFieldRecovery
