import CorruptedFieldRecovery.S010BalanceGaussianPrimitiveSeedCounting
import CorruptedFieldRecovery.ProperSubfieldCounts

namespace CorruptedFieldRecovery

/-! Convert the existing degree-indexed non-generator union bound into a
lower count for actual ordered coefficient seeds.  The result remains an
uncompiled draft and depends on the preserved, not-yet-audited ordered-seed
bijection chain. -/

/-- On a good tape satisfying the model promise and dense-size hypothesis,
the actual ordered seed sampler has at least `|K| - Σ_{d proper} 2^d`
primitive seeds. The inequality comes from the existing root-count union
bound for non-generators and the exact seed/scalar count bijection. It makes
no claim that this lower bound is positive or asymptotically large. -/
theorem actualBalanceGaussianGoodTape_primitiveSeedCount_lowerBound
    {K : Type*} [Field K] [Fintype K] [DecidableEq K] [Finite K]
    [CharP K 2] [Algebra BinaryField K] [FiniteDimensional BinaryField K]
    [Algebra (ZMod (ringChar K)) K]
    {s : Nat}
    (Q : BinaryVector (3 * s) ≃ₗ[BinaryField] FieldTriple K)
    (E : BinaryTensor (3 * s))
    (U : Submodule BinaryField (KTriple K))
    (b : (Fin 4 → FieldTriple K) → Module.Basis (Fin s) BinaryField K)
    (raw : RawCoefficientArray) (tape : FiveWordTape s)
    (htape : tape ∈ actualFiveGoodTapeSet K Q
      (modeImageSemanticCleanFieldSet Q E) U b)
    (c : K) (hc : c ≠ 0)
    (hmodel : HasObservedTraceDeterminantDecomposition
      (decodeRawArray (n := 3 * s) raw) E LinearMap.id Q c)
    (hsize : raw.size = (3 * s) * (3 * s) * (3 * s))
    (hK : Module.finrank BinaryField K = s) :
    let selected : (Fin s → BinaryField) →
        Module.End BinaryField (BinaryVector (3 * s)) := fun seed =>
      actualBalanceGaussianArrayFlagSelectBySeed raw tape
        (by rw [← actualBalanceGaussianRawFreeIndex_card_eq
          Q E U b raw tape htape c hc hmodel hsize hK]; rfl) seed
    let scalar : (Fin s → BinaryField) → K := fun seed =>
      actualBalanceGaussianQScalarParameter Q (selected seed)
    Fintype.card {seed : Fin s → BinaryField //
      Algebra.adjoin BinaryField ({scalar seed} : Set K) = ⊤} ≥
      Fintype.card K - ∑ d ∈ properDegrees K, 2 ^ d := by
  classical
  let selected : (Fin s → BinaryField) →
      Module.End BinaryField (BinaryVector (3 * s)) := fun seed =>
    actualBalanceGaussianArrayFlagSelectBySeed raw tape
      (by rw [← actualBalanceGaussianRawFreeIndex_card_eq
        Q E U b raw tape htape c hc hmodel hsize hK]; rfl) seed
  let scalar : (Fin s → BinaryField) → K := fun seed =>
    actualBalanceGaussianQScalarParameter Q (selected seed)
  let P : K → Prop := fun k =>
    Algebra.adjoin BinaryField ({k} : Set K) = ⊤
  have hseedCount := actualBalanceGaussianGoodTape_primitiveSeedCount_eq
    Q E U b raw tape htape c hc hmodel hsize hK
  have hfieldCount : Fintype.card {k : K // P k} =
      Fintype.card K - (nonGenerators K).card := by
    have hnon : Fintype.card {k : K // ¬ P k} = (nonGenerators K).card := by
      rw [Fintype.card_subtype]
      simp [P, nonGenerators]
    rw [Fintype.card_subtype_compl (p := fun k : K => ¬ P k), hnon]
  have hng := card_nonGenerators_le_proper_degree_sum K
  rw [hfieldCount] at hseedCount
  rw [hseedCount]
  omega

end CorruptedFieldRecovery
