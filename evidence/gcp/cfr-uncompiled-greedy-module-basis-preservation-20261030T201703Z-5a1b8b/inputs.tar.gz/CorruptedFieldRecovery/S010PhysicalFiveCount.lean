import CorruptedFieldRecovery.SamplingCounts
import CorruptedFieldRecovery.ProbabilityActualTapeBridge
import CorruptedFieldRecovery.ProbabilityFiveTupleAssembly
import Mathlib.Tactic

namespace CorruptedFieldRecovery

noncomputable section

/-- Physical clean vectors, transported to hidden finite-field coordinates by
Q. The support observation map is explicit and surjective. -/
def physicalCleanFieldSet {K : Type*} [Field K] {s r : Nat}
    (Q : BinaryVector (3 * s) ≃ₗ[BinaryField] FieldTriple K)
    (u : BinaryVector (3 * s) →ₗ[BinaryField] BinaryVector r) :
    Finset (FieldTriple K) :=
  (Finset.univ.filter fun x => u x = 0).map ⟨Q, Q.injective⟩

private theorem binaryVector_finrank (n : Nat) :
    Module.finrank BinaryField (BinaryVector n) = n := by
  rw [Module.finrank_eq_card_basis (Pi.basisFun BinaryField (Fin n))]
  simp [BinaryField]

private theorem card_clean_kernel
    {s r : Nat}
    (u : BinaryVector (3 * s) →ₗ[BinaryField] BinaryVector r)
    (hu : Function.Surjective u) :
    (Finset.univ.filter fun x : BinaryVector (3 * s) => u x = 0).card =
      2 ^ (3 * s - r) := by
  classical
  have hdimV : Module.finrank BinaryField (BinaryVector (3 * s)) = 3 * s :=
    binaryVector_finrank (3 * s)
  have hdimW : Module.finrank BinaryField (BinaryVector r) = r :=
    binaryVector_finrank r
  have hker := card_ker_support_f2 u hu (3 * s) r hdimV hdimW
  have hkerCard : Fintype.card (LinearMap.ker u) = 2 ^ (3 * s - r) := by
    rw [← Nat.card_eq_fintype_card, hker]
  have hsub : Fintype.card {x : BinaryVector (3 * s) // u x = 0} =
      Fintype.card (LinearMap.ker u) := by
    apply Fintype.card_congr
    exact {
      toFun := fun x => ⟨x.1, x.2⟩
      invFun := fun x => ⟨x.1, x.2⟩
      left_inv := by intro x; apply Subtype.ext; rfl
      right_inv := by intro x; apply Subtype.ext; rfl
    }
  calc
    (Finset.univ.filter fun x : BinaryVector (3 * s) => u x = 0).card =
        Fintype.card {x : BinaryVector (3 * s) // u x = 0} := by
      symm
      rw [Fintype.card_subtype]
    _ = Fintype.card (LinearMap.ker u) := hsub
    _ = 2 ^ (3 * s - r) := hkerCard

theorem physicalCleanFieldSet_card
    {K : Type*} [Field K] {s r : Nat}
    (Q : BinaryVector (3 * s) ≃ₗ[BinaryField] FieldTriple K)
    (u : BinaryVector (3 * s) →ₗ[BinaryField] BinaryVector r)
    (hu : Function.Surjective u) :
    (physicalCleanFieldSet Q u).card = 2 ^ (3 * s - r) := by
  rw [physicalCleanFieldSet, Finset.card_map]
  exact card_clean_kernel u hu

private theorem card_field_eq_pow_finrank
    (K : Type*) [Field K] [Fintype K]
    [Algebra BinaryField K] [FiniteDimensional BinaryField K]
    (s : Nat) (hs : Module.finrank BinaryField K = s) :
    Fintype.card K = 2 ^ s := by
  rw [Module.card_eq_pow_finrank (K := BinaryField) (V := K), hs]
  simp [BinaryField]

/-- Instantiate the existing dependent five-word count with the actual clean
kernel set, then transport that count to the physical independent-bit tape. -/
theorem physicalFiveTape_count_lower
    {K : Type*} [Field K] [Fintype K] [DecidableEq K]
    [Algebra BinaryField K] [FiniteDimensional BinaryField K] [Finite K]
    {s r : Nat} (hs : Module.finrank BinaryField K = s)
    (Q : BinaryVector (3 * s) ≃ₗ[BinaryField] FieldTriple K)
    (u : BinaryVector (3 * s) →ₗ[BinaryField] BinaryVector r)
    (hu : Function.Surjective u)
    (U : Submodule BinaryField (KTriple K))
    (hU : Module.finrank BinaryField U = r)
    (b : (Fin 4 → FieldTriple K) → Basis (Fin s) BinaryField K) :
    ((2 ^ (3 * s - r) - (nonGenerators K).card * (2 ^ s) ^ 2) *
      ((2 ^ (3 * s - r) - (2 ^ s) ^ 2) *
        ((2 ^ (3 * s - r) - 2 ^ s) * (2 ^ (3 * s - r) - 1)))) *
      (2 ^ s - ((∑ d ∈ properDegrees K, 2 ^ d) + (2 ^ (2 * r) - 1))) ≤
      (actualFiveGoodTapeSet K Q (physicalCleanFieldSet Q u) U b).card := by
  classical
  let A := physicalCleanFieldSet Q u
  have hA : A.card = 2 ^ (3 * s - r) := physicalCleanFieldSet_card Q u hu
  have hK : Fintype.card K = 2 ^ s := card_field_eq_pow_finrank K s hs
  have hsemantic := card_goodFiveTupleSigma_lower K A U b r hU
  rw [hA, hK] at hsemantic
  calc
    _ ≤ (goodFiveTupleSigma K A U b).card := hsemantic
    _ = (actualFiveGoodTapeSet K Q A U b).card := by
      symm
      exact card_actualFiveGoodTapeSet K Q A U b

end

end CorruptedFieldRecovery
