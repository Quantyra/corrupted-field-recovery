import CorruptedFieldRecovery.RawCoefficientFitCompactProjection

/-! # Computable compact-column indexing for the fit matrix

The zero-padded `d^3`-column matrix is easy to flatten, but it makes the
compact-solution projection depend on dropping many zero columns. This file
constructs the compact support-column order directly: enumerate the `d^3`
ordered triples, filter to increasing triples, and use the resulting duplicate-
free list's `get` equivalence. The execution path therefore uses only a
finite polynomial-size list, not a noncomputable `Fintype.equivFin` and not a
search over coefficient vectors.

The fit-equation equivalence and solver output can then use exactly
`s + supportTripleList.length` columns. Their semantic proof remains separate
from this index construction.
-/

namespace CorruptedFieldRecovery

/-- Explicit ordered positions in the support triple cube that satisfy the
increasing predicate. -/
def rawIncreasingSupportPositionList (d : Nat) : List (Fin ((d * d) * d)) :=
  (List.ofFn fun position : Fin ((d * d) * d) => position).filter fun position =>
    decide (rawOrderedTripleIncreasing (rawOrderedTripleAt position))

/-- The ordered position list has no duplicates. -/
theorem rawIncreasingSupportPositionList_nodup (d : Nat) :
    (rawIncreasingSupportPositionList d).Nodup := by
  unfold rawIncreasingSupportPositionList
  apply List.Nodup.filter
  apply List.nodup_ofFn_ofInjective
  intro x y hxy
  exact hxy

/-- An element of the filtered position list is exactly a position whose
decoded triple is increasing. -/
def rawIncreasingSupportPositionMembershipEquiv (d : Nat) :
    {position // position ∈ rawIncreasingSupportPositionList d} ≃
      {position : Fin ((d * d) * d) //
        rawOrderedTripleIncreasing (rawOrderedTripleAt position)} where
  toFun position :=
    ⟨position.1, of_decide_eq_true
      (List.mem_filter.mp position.2).2⟩
  invFun position := by
    refine ⟨position.1, ?_⟩
    apply List.mem_filter.mpr
    refine ⟨?_, decide_eq_true position.2⟩
    rw [List.mem_ofFn']
    exact ⟨position.1, rfl⟩
  left_inv position := by
    apply Subtype.ext
    rfl
  right_inv position := by
    apply Subtype.ext
    rfl

/-- Equivalence from the filtered computable position order to the subtype of
increasing support triples. The forward map reads a list entry; the inverse
uses the explicit triple flattening equivalence. -/
def rawIncreasingSupportListEquiv (d : Nat) :
    Fin (rawIncreasingSupportPositionList d).length ≃ IncreasingTriple d :=
  (List.Nodup.getEquiv (rawIncreasingSupportPositionList d)
    (rawIncreasingSupportPositionList_nodup d)).trans
    ((rawIncreasingSupportPositionMembershipEquiv d).trans
      { toFun := fun position =>
          rawOrderedTripleAsIncreasing (rawOrderedTripleAt position.1) position.2
        invFun := fun triple =>
          ⟨rawOrderedTripleFinEquiv d triple.1,
            by simpa [rawOrderedTripleAt, rawOrderedTripleIncreasing,
              rawOrderedTripleFinEquiv] using triple.2⟩
        left_inv := by
          intro position
          apply Subtype.ext
          simp [rawOrderedTripleAt, rawOrderedTripleFinEquiv]
        right_inv := by
          intro triple
          apply Subtype.ext
          rfl })

/-- The computed list length is exactly the finite cardinality of increasing
support triples. This is a proof about the explicit enumeration, not an
ordering chosen by a noncomputable equivalence. -/
theorem rawIncreasingSupportPositionList_length (d : Nat) :
    (rawIncreasingSupportPositionList d).length = Fintype.card (IncreasingTriple d) := by
  simpa using Fintype.card_congr (rawIncreasingSupportListEquiv d)

/-- Compact source columns in executable order: scalar positions first,
followed by the increasing support triples in the filtered list order. -/
def rawCoefficientFitCompactFinEquiv (s d : Nat) :
    RawCoefficientFitColumnIndex s d ≃
      Fin (s + (rawIncreasingSupportPositionList d).length) :=
  (Equiv.sumCongr (Equiv.refl (Fin s))
    (rawIncreasingSupportListEquiv d).symm).trans finSumFinEquiv

/-- The compact finite matrix entry uses precisely the original compact
column evaluator. Its column count is `s + |IncreasingTriple d|`, with the
ordered list providing the concrete executable ordering. -/
def rawCoefficientFitCompactFiniteEntry {s d : Nat}
    (candidate : RawFieldCandidate s)
    (hcheck : rawFieldCandidateCheck candidate = true)
    (inverse : RawCoordinateMatrix) (supportMatrix : RawBinaryArray)
    (row : Fin (((3 * s) * (3 * s)) * (3 * s)))
    (column : Fin (s + (rawIncreasingSupportPositionList d).length)) : ZMod 2 := by
  let triple := rawOrderedTripleAt row
  exact if hrow : rawOrderedTripleIncreasing triple then
      rawCoefficientFitEntry candidate hcheck inverse supportMatrix
        (rawOrderedTripleAsIncreasing triple hrow)
        ((rawCoefficientFitCompactFinEquiv s d).symm column)
    else 0

/-- Compact finite matrix with zero-padded ordered physical rows and exactly
the manuscript's compact coefficient-column count. -/
def rawCoefficientFitCompactFiniteMatrix {s d : Nat}
    (candidate : RawFieldCandidate s)
    (hcheck : rawFieldCandidateCheck candidate = true)
    (inverse : RawCoordinateMatrix) (supportMatrix : RawBinaryArray) :
    Matrix (Fin (((3 * s) * (3 * s)) * (3 * s)))
      (Fin (s + (rawIncreasingSupportPositionList d).length)) (ZMod 2) :=
  fun row column =>
    rawCoefficientFitCompactFiniteEntry candidate hcheck inverse supportMatrix row column

/-- Compact source coefficient arrays and finite compact-order coefficient
arrays are related by the explicit sum/list equivalence. -/
def rawCoefficientFitCompactCoefficientsToFin {s d : Nat}
    (coefficients : RawCoefficientFitColumnIndex s d → ZMod 2) :
    Fin (s + (rawIncreasingSupportPositionList d).length) → ZMod 2 :=
  fun position => coefficients ((rawCoefficientFitCompactFinEquiv s d).symm position)

def rawCoefficientFitCompactCoefficientsFromFin {s d : Nat}
    (coefficients : Fin (s + (rawIncreasingSupportPositionList d).length) → ZMod 2) :
    RawCoefficientFitColumnIndex s d → ZMod 2 :=
  fun source => coefficients (rawCoefficientFitCompactFinEquiv s d source)

/-- The reverse coefficient translation is a left inverse of the forward
translation. -/
theorem rawCoefficientFitCompactCoefficientsToFrom {s d : Nat}
    (coefficients : Fin (s + (rawIncreasingSupportPositionList d).length) → ZMod 2) :
    rawCoefficientFitCompactCoefficientsToFin
      (rawCoefficientFitCompactCoefficientsFromFin coefficients) = coefficients := by
  funext position
  simp [rawCoefficientFitCompactCoefficientsToFin,
    rawCoefficientFitCompactCoefficientsFromFin]

/-- The explicit executable column mapping round-trips exactly. -/
theorem rawCoefficientFitCompactCoefficientsFromTo {s d : Nat}
    (coefficients : RawCoefficientFitColumnIndex s d → ZMod 2) :
    rawCoefficientFitCompactCoefficientsFromFin
      (rawCoefficientFitCompactCoefficientsToFin coefficients) = coefficients := by
  funext source
  simp [rawCoefficientFitCompactCoefficientsFromFin,
    rawCoefficientFitCompactCoefficientsToFin]

/-- The row-sum identity needed for the compact finite system. This states
that evaluating the finite matrix against the translated coefficient array
at an increasing row equals the original source-indexed compact row sum. -/
def RawCoefficientFitCompactFinRowEquationTarget {s d : Nat}
    (candidate : RawFieldCandidate s)
    (hcheck : rawFieldCandidateCheck candidate = true)
    (inverse : RawCoordinateMatrix) (supportMatrix : RawBinaryArray)
    (raw : RawCoefficientArray)
    (coefficients : RawCoefficientFitColumnIndex s d → ZMod 2) : Prop :=
  ∀ row : IncreasingTriple (3 * s),
    (rawCoefficientFitCompactFiniteMatrix candidate hcheck inverse supportMatrix *ᵥ
      rawCoefficientFitCompactCoefficientsToFin coefficients)
        (rawOrderedTripleFinEquiv (3 * s) row.val) =
      (∑ column : RawCoefficientFitColumnIndex s d,
        rawCoefficientFitEntry candidate hcheck inverse supportMatrix row column *
          coefficients column)

/-- The complete compact row-equation equivalence target. Invalid physical
rows are zero on both sides; valid rows are handled by the row-sum identity.
No solution is asserted. -/
def RawCoefficientFitCompactFinSystemEquivalenceTarget {s d : Nat}
    (candidate : RawFieldCandidate s)
    (hcheck : rawFieldCandidateCheck candidate = true)
    (inverse : RawCoordinateMatrix) (supportMatrix : RawBinaryArray)
    (raw : RawCoefficientArray) : Prop :=
  RawCoefficientFitAffineSolution candidate hcheck inverse supportMatrix raw ↔
    RawFiniteAffineSolution
      (rawCoefficientFitCompactFiniteMatrix candidate hcheck inverse supportMatrix)
      (fun row => rawCoefficientFitFiniteRhs raw row)

/-- A compact row's finite matrix dot product is exactly its source-indexed
coefficient sum. This is a direct reindex by the explicit compact-column
equivalence; no padded columns occur in this matrix. -/
theorem rawCoefficientFitCompactFinRowDotProduct {s d : Nat}
    (candidate : RawFieldCandidate s)
    (hcheck : rawFieldCandidateCheck candidate = true)
    (inverse : RawCoordinateMatrix) (supportMatrix : RawBinaryArray)
    (coefficients : RawCoefficientFitColumnIndex s d → ZMod 2)
    (row : IncreasingTriple (3 * s)) :
    (rawCoefficientFitCompactFiniteMatrix candidate hcheck inverse supportMatrix *ᵥ
      rawCoefficientFitCompactCoefficientsToFin coefficients)
        (rawOrderedTripleFinEquiv (3 * s) row.val) =
      (∑ column : RawCoefficientFitColumnIndex s d,
        rawCoefficientFitEntry candidate hcheck inverse supportMatrix row column *
          coefficients column) := by
  classical
  simp [Matrix.mulVec, dotProduct,
    rawCoefficientFitCompactFiniteMatrix,
    rawCoefficientFitCompactFiniteEntry,
    rawCoefficientFitCompactCoefficientsToFin,
    rawCoefficientFitCompactFinEquiv, rawOrderedTripleAt,
    rawOrderedTripleIncreasing, rawOrderedTripleAsIncreasing,
    rawOrderedTripleFinEquiv, Equiv.sum_comp]

/-- Compact source-indexed fit equations and the explicitly flattened compact
finite matrix equations are equivalent. The only extra rows are invalid
ordered physical triples, and their matrix entries and RHS are zero. -/
theorem rawCoefficientFitCompactFinSystem_iff {s d : Nat}
    (candidate : RawFieldCandidate s)
    (hcheck : rawFieldCandidateCheck candidate = true)
    (inverse : RawCoordinateMatrix) (supportMatrix : RawBinaryArray)
    (raw : RawCoefficientArray) :
    RawCoefficientFitAffineSolution candidate hcheck inverse supportMatrix raw ↔
      RawFiniteAffineSolution
        (rawCoefficientFitCompactFiniteMatrix candidate hcheck inverse supportMatrix)
        (fun row => rawCoefficientFitFiniteRhs raw row) := by
  classical
  constructor
  · rintro ⟨coefficients, hfit⟩
    refine ⟨rawCoefficientFitCompactCoefficientsToFin coefficients, ?_⟩
    apply funext
    intro position
    let triple := rawOrderedTripleAt position
    by_cases hrow : rawOrderedTripleIncreasing triple
    · let row : IncreasingTriple (3 * s) := rawOrderedTripleAsIncreasing triple hrow
      have hval : rawOrderedTripleFinEquiv (3 * s) row.val = position := by
        simp [row, triple, rawOrderedTripleAt, rawOrderedTripleFinEquiv]
      rw [← hval, rawCoefficientFitCompactFinRowDotProduct]
      simpa [rawCoefficientFitFiniteRhs, triple, row,
        rawOrderedTripleAt, rawOrderedTripleIncreasing,
        rawOrderedTripleAsIncreasing] using hfit row
    · simp [rawCoefficientFitCompactFiniteMatrix,
        rawCoefficientFitCompactFiniteEntry, rawCoefficientFitFiniteRhs,
        triple, rawOrderedTripleAt, hrow]
  · rintro ⟨coefficients, hfit⟩
    let compact := rawCoefficientFitCompactCoefficientsFromFin coefficients
    refine ⟨compact, ?_⟩
    intro row
    have hrow := congrFun hfit (rawOrderedTripleFinEquiv (3 * s) row.val)
    rw [rawCoefficientFitCompactFinRowDotProduct] at hrow
    have hcoeff : rawCoefficientFitCompactCoefficientsToFin compact = coefficients :=
      rawCoefficientFitCompactCoefficientsToFrom coefficients
    simpa [compact, hcoeff] using hrow

end CorruptedFieldRecovery
