import CorruptedFieldRecovery.S010BalanceGaussianPrimitiveSeedLowerBound
import CorruptedFieldRecovery.S010ActualScalarBounds

namespace CorruptedFieldRecovery

/-! A positive count for the ordered primitive-seed event under the manuscript
size condition. The proof composes the existing scaled proper-degree estimate
with the seed/scalar bijection draft. No Lean compilation was run. -/

/-- Under `s ≥ 2R + 5`, at least three quarters of the ordered coefficient
seeds select a scalar generating K as an algebra. The conclusion is stated as
an integer count inequality; it does not model continuous probabilities or
claim that all subsequent raw scalar-bit gates accept. -/
theorem actualBalanceGaussianGoodTape_primitiveSeedCount_threeQuarter_lowerBound
    {K : Type*} [Field K] [Fintype K] [DecidableEq K] [Finite K]
    [CharP K 2] [Algebra BinaryField K] [FiniteDimensional BinaryField K]
    [Algebra (ZMod (ringChar K)) K]
    {s R : Nat}
    (Q : BinaryVector (3 * s) ≃ₗ[BinaryField] FieldTriple K)
    (E : BinaryTensor (3 * s))
    (U : Submodule BinaryField (KTriple K))
    (b : (Fin 4 → FieldTriple K) → Module.Basis (Fin s) BinaryField K)
    (raw : RawCoefficientArray) (tape : FiveWordTape s)
    (htape : tape ∈ actualFiveGoodTapeSet K Q
      (modeImageSemanticCleanFieldSet Q E) U b)
    (c : K) (hc : c ≠ 0)
    (hmodel : HasObservedTraceDeterminantDecomposition
      (decodeRawArray (n := 3 * s) raw) E LinearMap.id Q c)
    (hrawSize : raw.size = (3 * s) * (3 * s) * (3 * s))
    (hK : Module.finrank BinaryField K = s)
    (hsize : 2 * R + 5 ≤ s) :
    let selected : (Fin s → BinaryField) →
        Module.End BinaryField (BinaryVector (3 * s)) := fun seed =>
      actualBalanceGaussianArrayFlagSelectBySeed raw tape
        (by rw [← actualBalanceGaussianRawFreeIndex_card_eq
          Q E U b raw tape htape c hc hmodel hrawSize hK]; rfl) seed
    let scalar : (Fin s → BinaryField) → K := fun seed =>
      actualBalanceGaussianQScalarParameter Q (selected seed)
    3 * 2 ^ s ≤ 4 * Fintype.card {seed : Fin s → BinaryField //
      Algebra.adjoin BinaryField ({scalar seed} : Set K) = ⊤} := by
  classical
  let selected : (Fin s → BinaryField) →
      Module.End BinaryField (BinaryVector (3 * s)) := fun seed =>
    actualBalanceGaussianArrayFlagSelectBySeed raw tape
      (by rw [← actualBalanceGaussianRawFreeIndex_card_eq
        Q E U b raw tape htape c hc hmodel hrawSize hK]; rfl) seed
  let scalar : (Fin s → BinaryField) → K := fun seed =>
    actualBalanceGaussianQScalarParameter Q (selected seed)
  let Tsum : Nat := ∑ d ∈ properDegrees K, 2 ^ d
  have hscaled : 4 * (2 ^ R * Tsum) < 2 ^ s :=
    actual_proper_degree_scaled_bound K s R hK hsize
  have hpowR : 1 ≤ 2 ^ R := Nat.one_le_pow R 2 (by decide)
  have hT : 4 * Tsum < 2 ^ s := by
    calc
      4 * Tsum = 4 * (1 * Tsum) := by simp
      _ ≤ 4 * (2 ^ R * Tsum) :=
        Nat.mul_le_mul_left 4 (Nat.mul_le_mul_right Tsum hpowR)
      _ < 2 ^ s := hscaled
  have hKcard : Fintype.card K = 2 ^ s := by
    rw [Module.card_eq_pow_finrank (K := BinaryField) (V := K), hK, ZMod.card]
  have hseedLower :
      Fintype.card {seed : Fin s → BinaryField //
        Algebra.adjoin BinaryField ({scalar seed} : Set K) = ⊤} ≥
        Fintype.card K - Tsum := by
    simpa [selected, scalar, Tsum] using
      actualBalanceGaussianGoodTape_primitiveSeedCount_lowerBound
        Q E U b raw tape htape c hc hmodel hrawSize hK
  rw [hKcard]
  omega

/-- The preceding count is strictly positive whenever the manuscript size
condition holds. -/
theorem actualBalanceGaussianGoodTape_primitiveSeedCount_pos
    {K : Type*} [Field K] [Fintype K] [DecidableEq K] [Finite K]
    [CharP K 2] [Algebra BinaryField K] [FiniteDimensional BinaryField K]
    [Algebra (ZMod (ringChar K)) K]
    {s R : Nat}
    (Q : BinaryVector (3 * s) ≃ₗ[BinaryField] FieldTriple K)
    (E : BinaryTensor (3 * s))
    (U : Submodule BinaryField (KTriple K))
    (b : (Fin 4 → FieldTriple K) → Module.Basis (Fin s) BinaryField K)
    (raw : RawCoefficientArray) (tape : FiveWordTape s)
    (htape : tape ∈ actualFiveGoodTapeSet K Q
      (modeImageSemanticCleanFieldSet Q E) U b)
    (c : K) (hc : c ≠ 0)
    (hmodel : HasObservedTraceDeterminantDecomposition
      (decodeRawArray (n := 3 * s) raw) E LinearMap.id Q c)
    (hrawSize : raw.size = (3 * s) * (3 * s) * (3 * s))
    (hK : Module.finrank BinaryField K = s)
    (hsize : 2 * R + 5 ≤ s) :
    let selected : (Fin s → BinaryField) →
        Module.End BinaryField (BinaryVector (3 * s)) := fun seed =>
      actualBalanceGaussianArrayFlagSelectBySeed raw tape
        (by rw [← actualBalanceGaussianRawFreeIndex_card_eq
          Q E U b raw tape htape c hc hmodel hrawSize hK]; rfl) seed
    let scalar : (Fin s → BinaryField) → K := fun seed =>
      actualBalanceGaussianQScalarParameter Q (selected seed)
    0 < Fintype.card {seed : Fin s → BinaryField //
      Algebra.adjoin BinaryField ({scalar seed} : Set K) = ⊤} := by
  classical
  have hcount := actualBalanceGaussianGoodTape_primitiveSeedCount_threeQuarter_lowerBound
    Q E U b raw tape htape c hc hmodel hrawSize hK hsize
  have hpos : 0 < 2 ^ s := by positivity
  omega

end CorruptedFieldRecovery
