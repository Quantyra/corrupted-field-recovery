import CorruptedFieldRecovery.S010BalanceGaussianArrayInstrumentedScan

namespace CorruptedFieldRecovery

private theorem actualBalanceGaussianArrayCountedFindUnusedRow_trace_bounds
    {m n : Nat} (cells : Array (Array (ZMod 2))) (column : Fin n)
    (used : Finset (Fin m)) (rows : List (Fin m)) :
    let trace :=
      (actualBalanceGaussianArrayCountedFindUnusedRow cells column used rows).2
    trace.selectorPredicateTests ≤ rows.length ∧
      trace.usedMembershipChecks = trace.selectorPredicateTests ∧
      trace.selectorArrayViewCalls ≤ trace.selectorPredicateTests := by
  induction rows with
  | nil => simp [actualBalanceGaussianArrayCountedFindUnusedRow,
      actualBalanceGaussianArrayEventTrace.zero]
  | cons row rows ih =>
      by_cases hused : row ∈ used
      · simp [actualBalanceGaussianArrayCountedFindUnusedRow, hused,
          actualBalanceGaussianArrayEventTrace.add,
          actualBalanceGaussianArrayUsedRowProbe] at *
        omega
      · by_cases hvalue : actualBalanceGaussianArrayView cells row column = 1
        · simp [actualBalanceGaussianArrayCountedFindUnusedRow, hused, hvalue,
            actualBalanceGaussianArrayFreshRowProbe,
            actualBalanceGaussianArrayEventTrace.zero]
        · simp [actualBalanceGaussianArrayCountedFindUnusedRow, hused, hvalue,
            actualBalanceGaussianArrayEventTrace.add,
            actualBalanceGaussianArrayFreshRowProbe] at *
          omega

private theorem actualBalanceGaussianArrayCountedFirstUnusedPivotRow_trace_bounds
    {m n : Nat} (cells : Array (Array (ZMod 2))) (column : Fin n)
    (used : Finset (Fin m)) :
    let trace :=
      (actualBalanceGaussianArrayCountedFirstUnusedPivotRow
        cells column used).2
    trace.rowIndexListNodes = m ∧
      trace.selectorPredicateTests ≤ m ∧
      trace.usedMembershipChecks = trace.selectorPredicateTests ∧
      trace.selectorArrayViewCalls ≤ trace.selectorPredicateTests := by
  have hsearch :=
    actualBalanceGaussianArrayCountedFindUnusedRow_trace_bounds
      cells column used (List.ofFn fun row : Fin m => row)
  simpa [actualBalanceGaussianArrayCountedFirstUnusedPivotRow,
    actualBalanceGaussianArrayEventTrace.add,
    actualBalanceGaussianArrayEventTrace.zero] using hsearch

/-- Componentwise accounting theorem for the instrumented scan. Search
predicate and membership counts are actual branch counters; update view,
arithmetic, write, and allocation fields are the explicit per-pivot upper
charges attached by `actualBalanceGaussianArrayPivotUpdateCharge`. -/
theorem actualBalanceGaussianArrayColumnScanInstrumented_trace_bounds
    {m n : Nat} (cells : Array (Array (ZMod 2))) (used : Finset (Fin m))
    (columns : List (Fin n)) :
    let run := actualBalanceGaussianArrayColumnScanInstrumented cells used columns
    let trace := run.2
    trace.columnsProcessed = columns.length ∧
      trace.rowIndexListNodes = columns.length * m ∧
      trace.selectorPredicateTests ≤ columns.length * m ∧
      trace.usedMembershipChecks = trace.selectorPredicateTests ∧
      trace.selectorArrayViewCalls ≤ trace.selectorPredicateTests ∧
      trace.pivotUpdates = run.1.2.length ∧
      trace.pivotUpdateArrayViewCallsUpper = 3 * trace.pivotUpdates * m * n ∧
      trace.pivotRowComparisons = trace.pivotUpdates * m * n ∧
      trace.fieldMultiplicationsUpper = trace.pivotUpdates * m * n ∧
      trace.fieldAdditionsUpper = trace.pivotUpdates * m * n ∧
      trace.coefficientCellWrites = trace.pivotUpdates * m * n ∧
      trace.newArraySlots = trace.pivotUpdates * m * (n + 1) ∧
      trace.transcriptCons = trace.pivotUpdates := by
  induction columns generalizing cells used with
  | nil => simp [actualBalanceGaussianArrayColumnScanInstrumented,
      actualBalanceGaussianArrayEventTrace.zero]
  | cons column columns ih =>
      let selected := actualBalanceGaussianArrayCountedFirstUnusedPivotRow
        cells column used
      have hsearch :=
        actualBalanceGaussianArrayCountedFirstUnusedPivotRow_trace_bounds
          cells column used
      cases hselected : selected.1 with
      | none =>
          have htail := ih cells used
          simp_all [actualBalanceGaussianArrayColumnScanInstrumented,
            selected, hselected, actualBalanceGaussianArrayEventTrace.add,
            actualBalanceGaussianArrayEventTrace.zero]
          omega
      | some row =>
          have htail := ih
            (actualBalanceGaussianArrayPivotRow cells row column)
            (insert row used)
          simp_all [actualBalanceGaussianArrayColumnScanInstrumented,
            selected, hselected, actualBalanceGaussianArrayEventTrace.add,
            actualBalanceGaussianArrayEventTrace.zero,
            actualBalanceGaussianArrayPivotUpdateCharge]
          omega

/-- Map the counters returned by the instrumented execution into the previous
resource-model record. Search counters remain dynamic; update counters are the
per-pivot upper charges carried by the execution trace. -/
def actualBalanceGaussianArrayEventResourceModel {m n : Nat}
    (columns : List (Fin n))
    (trace : ActualBalanceGaussianArrayEventTrace) :
    ActualBalanceGaussianArrayResourceModel :=
  { rowListCons := trace.rowIndexListNodes
    selectorTests := trace.selectorPredicateTests
    usedMembershipTests := trace.usedMembershipChecks
    usedSetInserts := trace.pivotUpdates
    arrayOptionReads := 2 *
      (trace.selectorArrayViewCalls + trace.pivotUpdateArrayViewCallsUpper)
    fieldMultiplications := trace.fieldMultiplicationsUpper
    fieldAdditions := trace.fieldAdditionsUpper
    rowComparisons := trace.pivotRowComparisons
    coefficientCellWrites := trace.coefficientCellWrites
    cumulativeArraySlots := trace.newArraySlots
    transcriptCons := trace.transcriptCons
    columnListCons := trace.columnsProcessed
    liveArrayAndListSlotsUpper :=
      (trace.pivotUpdates + 2) * m * (n + 1) + m +
        trace.pivotUpdates + columns.length }

/-- Componentwise comparison from counters produced by the instrumented scan
to the earlier dimensional model. This is the explicit bridge from the run's
trace to the polynomial source-level charge. -/
theorem actualBalanceGaussianArrayInstrumentedResourceModel_le
    {m n : Nat} (cells : Array (Array (ZMod 2))) (used : Finset (Fin m))
    (columns : List (Fin n)) :
    let run := actualBalanceGaussianArrayColumnScanInstrumented cells used columns
    let eventModel := actualBalanceGaussianArrayEventResourceModel columns run.2
    let formulaModel := actualBalanceGaussianArrayResourceModel m n
      columns.length run.2.pivotUpdates
    eventModel.rowListCons = formulaModel.rowListCons ∧
      eventModel.selectorTests ≤ formulaModel.selectorTests ∧
      eventModel.usedMembershipTests ≤ formulaModel.usedMembershipTests ∧
      eventModel.usedSetInserts = formulaModel.usedSetInserts ∧
      eventModel.arrayOptionReads ≤ formulaModel.arrayOptionReads ∧
      eventModel.fieldMultiplications ≤ formulaModel.fieldMultiplications ∧
      eventModel.fieldAdditions ≤ formulaModel.fieldAdditions ∧
      eventModel.rowComparisons ≤ formulaModel.rowComparisons ∧
      eventModel.coefficientCellWrites ≤ formulaModel.coefficientCellWrites ∧
      eventModel.cumulativeArraySlots = formulaModel.cumulativeArraySlots ∧
      eventModel.transcriptCons = formulaModel.transcriptCons ∧
      eventModel.columnListCons = formulaModel.columnListCons ∧
      eventModel.liveArrayAndListSlotsUpper =
        formulaModel.liveArrayAndListSlotsUpper := by
  have h := actualBalanceGaussianArrayColumnScanInstrumented_trace_bounds
    cells used columns
  rcases h with ⟨hcols, hrows, htests, hmem, hviews, hpivots,
    hupViews, hrowcmp, hmul, hadd, hwrites, halloc, htranscript⟩
  have hselectorViews :
      ((actualBalanceGaussianArrayColumnScanInstrumented cells used columns).2).selectorArrayViewCalls ≤
        columns.length * m :=
    Nat.le_trans hviews htests
  have harrayReads :
      2 * (((actualBalanceGaussianArrayColumnScanInstrumented cells used columns).2).selectorArrayViewCalls +
        ((actualBalanceGaussianArrayColumnScanInstrumented cells used columns).2).pivotUpdateArrayViewCallsUpper) ≤
      2 * (columns.length * m +
        3 * ((actualBalanceGaussianArrayColumnScanInstrumented cells used columns).2).pivotUpdates * m * n) := by
    rw [hupViews]
    gcongr
  dsimp only [actualBalanceGaussianArrayEventResourceModel,
    actualBalanceGaussianArrayResourceModel]
  simp_all

/-- The instrumented source-operation charge is componentwise bounded by the
previous dimension/pivot resource model, with its pivot parameter set to the
actual transcript length. -/
theorem actualBalanceGaussianArrayColumnScanInstrumented_sourceWork_le_model
    {m n : Nat} (cells : Array (Array (ZMod 2))) (used : Finset (Fin m))
    (columns : List (Fin n)) :
    ((actualBalanceGaussianArrayColumnScanInstrumented cells used columns).2).sourceOperationCountUpper ≤
      actualBalanceGaussianArraySourceOperationCount
        (actualBalanceGaussianArrayResourceModel m n columns.length
          ((actualBalanceGaussianArrayColumnScanInstrumented cells used columns).2).pivotUpdates) := by
  have h := actualBalanceGaussianArrayColumnScanInstrumented_trace_bounds
    cells used columns
  rcases h with ⟨hcols, hrows, htests, hmem, hviews, hpivots,
    hupViews, hrowcmp, hmul, hadd, hwrites, halloc, htranscript⟩
  simp [actualBalanceGaussianArrayEventTrace.sourceOperationCountUpper,
    actualBalanceGaussianArraySourceOperationCount,
    actualBalanceGaussianArrayResourceModel,
    hrows, hcols, hmem,
    hpivots, hupViews, hrowcmp, hmul, hadd, hwrites, htranscript, halloc]
  omega

/-- The accumulated instrumented event charge is polynomial for the raw
balance dimensions. This theorem concerns only the declared source-level
charge: it is not a machine-runtime or bit-complexity theorem. -/
theorem actualBalanceGaussianSerializedArrayInstrumented_sourceWork_le
    {s : Nat} (raw : RawCoefficientArray) (tape : FiveWordTape s) :
    ((actualBalanceGaussianSerializedArrayScanInstrumented raw tape).2).sourceOperationCountUpper ≤
      40 * (3 * s) ^ 6 + 20 * (3 * s) ^ 4 + 3 * (3 * s) ^ 2 := by
  calc
    _ ≤ actualBalanceGaussianArraySourceOperationCount
        (actualBalanceGaussianArrayResourceModel
          (4 * ((3 * s) * (3 * s)))
          ((3 * s) * (3 * s))
          ((3 * s) * (3 * s))
          ((actualBalanceGaussianSerializedArrayScanInstrumented raw tape).2).pivotUpdates) := by
          unfold actualBalanceGaussianSerializedArrayScanInstrumented
          exact actualBalanceGaussianArrayColumnScanInstrumented_sourceWork_le_model
            _ _ _
    _ ≤ 40 * (3 * s) ^ 6 + 20 * (3 * s) ^ 4 + 3 * (3 * s) ^ 2 := by
          have hp :
              ((actualBalanceGaussianSerializedArrayScanInstrumented raw tape).2).pivotUpdates ≤
                (3 * s) * (3 * s) := by
            have htrace := actualBalanceGaussianArrayColumnScanInstrumented_trace_bounds
              (actualBalanceSerializedCoefficientMatrix
                (decodeRawArray (n := 3 * s) raw) tape)
              (∅ : Finset (Fin (4 * ((3 * s) * (3 * s)))))
              (List.ofFn fun column : Fin ((3 * s) * (3 * s)) => column)
            rcases htrace with ⟨_, _, _, _, _, hpivots, _, _, _, _, _, _, _⟩
            rw [← hpivots]
            have hrun := actualBalanceGaussianArrayColumnScanInstrumented_refines
              (actualBalanceSerializedCoefficientMatrix
                (decodeRawArray (n := 3 * s) raw) tape)
              (∅ : Finset (Fin (4 * ((3 * s) * (3 * s)))))
              (List.ofFn fun column : Fin ((3 * s) * (3 * s)) => column)
            have hlength :
                (actualBalanceGaussianArrayColumnScanInstrumented
                    (actualBalanceSerializedCoefficientMatrix
                      (decodeRawArray (n := 3 * s) raw) tape)
                    ∅ (List.ofFn fun column : Fin ((3 * s) * (3 * s)) => column)).1.2.length =
                  (actualBalanceGaussianArrayColumnScan
                    (actualBalanceSerializedCoefficientMatrix
                      (decodeRawArray (n := 3 * s) raw) tape)
                    ∅ (List.ofFn fun column : Fin ((3 * s) * (3 * s)) => column)).2.length := by
              have h := congrArg Prod.snd hrun
              simpa using h
            rw [hlength]
            exact actualBalanceGaussianArrayColumnScan_pivotCount_le
              (actualBalanceSerializedCoefficientMatrix
                (decodeRawArray (n := 3 * s) raw) tape)
              ∅ (List.ofFn fun column : Fin ((3 * s) * (3 * s)) => column)
          have hwork := actualBalanceGaussianArraySourceOperationCount_le
            (4 * ((3 * s) * (3 * s)))
            ((3 * s) * (3 * s))
            ((3 * s) * (3 * s))
            ((actualBalanceGaussianSerializedArrayScanInstrumented raw tape).2).pivotUpdates hp
          simpa only [actualBalanceGaussianArraySourceOperationCount_eq,
            List.length_ofFn] using hwork

end CorruptedFieldRecovery
