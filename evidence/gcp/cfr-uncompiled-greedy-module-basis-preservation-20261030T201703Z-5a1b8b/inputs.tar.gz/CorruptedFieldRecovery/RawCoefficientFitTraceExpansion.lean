import CorruptedFieldRecovery.RawCoefficientFitModelConsistency
import CorruptedFieldRecovery.RawCoefficientFitAugmentedSolverBridge
import CorruptedFieldRecovery.RawPhysicalTraceComposition

/-! # One-hot raw trace columns expand the actual candidate trace

This is an uncompiled proof draft of the missing scalar-column identity. It
uses the existing quotient soundness theorem for raw multiplication,
determinant and trace, identifies one-hot arrays with `X^j`, and applies
linearity of the field trace. No fitted coefficient vector is assumed. -/

namespace CorruptedFieldRecovery

open Polynomial AdjoinRoot

/-- Interpret an accepted scalar bit array as the sum of its power-basis
monomials. -/
theorem rawFieldArrayPolynomial_eq_fin_power_sum {s : Nat}
    (bits : RawFieldBits) (hsize : bits.size = s) :
    rawFieldArrayPolynomial bits =
      ∑ j : Fin s,
        if bits[j.val]! then Polynomial.X ^ j.val else 0 := by
  classical
  let coeff : Fin s → Bool := fun j => bits[j.val]!
  have hbits : bits = (List.ofFn coeff).toArray := by
    apply Array.ext
    · simp [hsize]
    · intro j hj
      simp [coeff]
  rw [hbits, rawFieldArrayPolynomial]
  simp only [Array.toList_toArray]
  rw [rawBoolListPolynomial_ofFn]
  apply Finset.sum_congr rfl
  intro j hj
  by_cases hb : coeff j
  · simp [coeff, hb, Polynomial.monomial_eq_C_mul_X_pow]
  · simp [coeff, hb]

/-- General-scalar version of raw evaluator correctness. The Nat result is
exactly the trace bit of the product of the supplied scalar mask and the
decoded determinant; the candidate's stored scalar is not substituted. -/
theorem rawFieldTraceDet3WithScalarBits_eq_baseTrace {s : Nat}
    (candidate : RawFieldCandidate s)
    (hcheck : rawFieldCandidateCheck candidate = true)
    (scalarBits : RawFieldBits) (x y z : Nat × Nat × Nat) :
    rawFieldTraceDet3WithScalarBits candidate hcheck scalarBits x y z =
      if Algebra.trace (ZMod 2) (AdjoinRoot (rawCandidateModulus candidate))
        (rawCandidateQuotientClass candidate (rawFieldBitsToNat scalarBits) *
          fieldDet3
            (rawCandidateQuotientClass candidate x.1,
              rawCandidateQuotientClass candidate x.2.1,
              rawCandidateQuotientClass candidate x.2.2)
            (rawCandidateQuotientClass candidate y.1,
              rawCandidateQuotientClass candidate y.2.1,
              rawCandidateQuotientClass candidate y.2.2)
            (rawCandidateQuotientClass candidate z.1,
              rawCandidateQuotientClass candidate z.2.1,
              rawCandidateQuotientClass candidate z.2.2)) = 0 then 0 else 1 := by
  let det := rawFieldDet3Bits candidate hcheck x y z
  let product := rawFieldMulBits candidate hcheck
    (rawFieldBitsToNat scalarBits) det
  have hproductBound : product < 2 ^ s := by
    simpa [product, rawFieldMulBits] using
      rawFieldMulFuel_lt_of_accepted candidate hcheck
        (rawFieldBitsToNat scalarBits) det
  unfold rawFieldTraceDet3WithScalarBits
  rw [rawFieldTraceBits_eq_baseBit candidate hcheck _ hproductBound]
  rw [rawFieldMulBits_quotient_sound, rawFieldDet3Bits_quotient_sound]
  simp [rawNatTraceBit, rawFieldTraceDet3WithScalarBits, htrace, hmul, hdet,
    rawFieldMul3Bits, product, det]

/-- One-hot evaluator column, interpreted as the actual quotient-field trace
with scalar `X^j` on the canonically decoded physical row. -/
theorem rawTraceUnitFitColumn_eq_canonicalPowerTrace {s d : Nat}
    (candidate : RawFieldCandidate s)
    (hfield : rawFieldCandidateCheck candidate = true)
    (inverse : RawCoordinateMatrix) (j : Fin s)
    (row : IncreasingTriple (3 * s)) :
    rawTraceUnitFitColumn candidate hfield inverse j row =
      Algebra.trace (ZMod 2) (AdjoinRoot (rawCandidateModulus candidate))
        ((AdjoinRoot.mk (rawCandidateModulus candidate) (Polynomial.X ^ j.val)) *
          fieldDet3
            (rawPhysicalCanonicalTriple candidate hfield inverse
              (coordinateVectorCode (increasingTripleI row)))
            (rawPhysicalCanonicalTriple candidate hfield inverse
              (coordinateVectorCode (increasingTripleJ row)))
            (rawPhysicalCanonicalTriple candidate hfield inverse
              (coordinateVectorCode (increasingTripleK row)))) := by
  let x := coordinateVectorCode (increasingTripleI row)
  let y := coordinateVectorCode (increasingTripleJ row)
  let z := coordinateVectorCode (increasingTripleK row)
  have hraw := rawFieldTraceDet3WithScalarBits_eq_baseTrace candidate hfield
    (rawUnitScalarBits s j) (rawPhysicalTripleMasks inverse x)
    (rawPhysicalTripleMasks inverse y) (rawPhysicalTripleMasks inverse z)
  have hunit := rawUnitScalarBits_polynomial j
  rw [rawTraceUnitFitColumn, hraw]
  rw [rawCandidateQuotientClass]
  rw [← rawFieldArrayPolynomial_eq_mask, hunit]
  rw [rawPhysicalTripleMasks_eq_canonical candidate hfield inverse x,
    rawPhysicalTripleMasks_eq_canonical candidate hfield inverse y,
    rawPhysicalTripleMasks_eq_canonical candidate hfield inverse z]
  have hbit (a : ZMod 2) : (if a = 0 then (0 : ZMod 2) else 1) = a := by
    fin_cases a <;> decide
  simpa [rawNatTraceBit, hbit, hunit, x, y, z]

/-- The actual trace tensor's coordinate table is the linear combination of
the executable one-hot trace columns with the candidate's serialized scalar
bits. This removes `RawCoefficientFitTraceColumnExpansion` as an assumption
in the model-consistency theorem once this draft is compiler-validated. -/
theorem rawCoefficientFitTraceColumnExpansion_fromRawScalar {s d : Nat}
    (candidate : RawFieldCandidate s)
    (hfield : rawFieldCandidateCheck candidate = true)
    (forward inverse : RawCoordinateMatrix)
    (hcoordinates : rawCoordinateMatrixCheck (n := 3 * s) forward inverse = true)
    (hscalarSize : candidate.scalar.size = s) :
    RawCoefficientFitTraceColumnExpansion candidate hfield forward inverse
      hcoordinates := by
  classical
  intro row
  let K := AdjoinRoot (rawCandidateModulus candidate)
  let coords := accepted_rawCandidatePhysicalCoordinates candidate hfield
    forward inverse hcoordinates
  let det := fieldDet3
    (coords.symm (coordinateVectorCode (increasingTripleI row)))
    (coords.symm (coordinateVectorCode (increasingTripleJ row)))
    (coords.symm (coordinateVectorCode (increasingTripleK row)))
  have hscalarPoly := rawFieldArrayPolynomial_eq_fin_power_sum
    candidate.scalar hscalarSize
  have hscalarClass :
      rawCandidateQuotientClass candidate (rawFieldBitsToNat candidate.scalar) =
        ∑ j : Fin s,
          rawCoefficientFitScalarCoefficient candidate j •
            AdjoinRoot.mk (rawCandidateModulus candidate) (Polynomial.X ^ j.val) := by
    change AdjoinRoot.mk (rawCandidateModulus candidate)
        (rawMaskPolynomial (rawFieldBitsToNat candidate.scalar)) = _
    rw [← rawFieldArrayPolynomial_eq_mask]
    rw [hscalarPoly]
    simp [rawCoefficientFitScalarCoefficient, rawFieldArrayPolynomial,
      Polynomial.monomial_eq_C_mul_X_pow, Algebra.smul_def]
  have hcoordsI : rawPhysicalCanonicalTriple candidate hfield inverse
      (coordinateVectorCode (increasingTripleI row)) =
        coords.symm (coordinateVectorCode (increasingTripleI row)) := by
    simpa [rawPhysicalCanonicalTriple, accepted_rawCandidatePowerBasisCoordinates,
      coords] using
      (accepted_rawCandidatePhysicalCoordinates_symm_eq_powerBasisInverse
        candidate hfield forward inverse hcoordinates
        (coordinateVectorCode (increasingTripleI row))).symm
  have hcoordsJ : rawPhysicalCanonicalTriple candidate hfield inverse
      (coordinateVectorCode (increasingTripleJ row)) =
        coords.symm (coordinateVectorCode (increasingTripleJ row)) := by
    simpa [rawPhysicalCanonicalTriple, accepted_rawCandidatePowerBasisCoordinates,
      coords] using
      (accepted_rawCandidatePhysicalCoordinates_symm_eq_powerBasisInverse
        candidate hfield forward inverse hcoordinates
        (coordinateVectorCode (increasingTripleJ row))).symm
  have hcoordsK : rawPhysicalCanonicalTriple candidate hfield inverse
      (coordinateVectorCode (increasingTripleK row)) =
        coords.symm (coordinateVectorCode (increasingTripleK row)) := by
    simpa [rawPhysicalCanonicalTriple, accepted_rawCandidatePowerBasisCoordinates,
      coords] using
      (accepted_rawCandidatePhysicalCoordinates_symm_eq_powerBasisInverse
        candidate hfield forward inverse hcoordinates
        (coordinateVectorCode (increasingTripleK row))).symm
  rw [rawTraceDetTensor, encodeDenseInput]
  rw [hcoordsI, hcoordsJ, hcoordsK]
  rw [hscalarClass]
  rw [Finset.sum_mul]
  rw [map_sum]
  simp only [map_smul]
  apply Finset.sum_congr rfl
  intro j hj
  rw [rawTraceUnitFitColumn_eq_canonicalPowerTrace candidate hfield inverse j row]
  simp [Algebra.smul_def, det, coords, hcoordsI, hcoordsJ, hcoordsK,
    mul_comm]

end CorruptedFieldRecovery
