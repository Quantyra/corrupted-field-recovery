import CorruptedFieldRecovery.S010BalanceGaussianArrayPivot

open scoped Matrix

namespace CorruptedFieldRecovery

/-- The matrix returned by the deterministic column scan is obtained by
applying its recorded row operations in order. This connects the scan's
certificate to the accepted matrix update semantics. -/
theorem balanceGaussianColumnScan_pivotSequence {m n : Nat}
    (columns : List (Fin n))
    (A : Matrix (Fin m) (Fin n) (ZMod 2)) (used : Finset (Fin m)) :
    balanceGaussianPivotSequence A
      (balanceGaussianColumnScan A used columns).2 =
        (balanceGaussianColumnScan A used columns).1 := by
  induction columns generalizing A used with
  | nil => rfl
  | cons column columns ih =>
      cases hpivot : balanceFirstUnusedPivotRow A column used with
      | none =>
          simpa [balanceGaussianColumnScan, hpivot] using ih A used
      | some row =>
          simpa [balanceGaussianColumnScan, hpivot,
            balanceGaussianPivotSequence] using
              ih (balanceGaussianPivotRow A row column) (insert row used)

/-- The executable nested-array update sequence associated with the actual
raw balance scan. The pivots are the deterministic scan's recorded transcript;
each update itself is performed on nested arrays. -/
def actualBalanceGaussianSerializedArrayPivotScan {s : Nat}
    (raw : RawCoefficientArray) (tape : FiveWordTape s) :=
  actualBalanceGaussianArrayPivotSequence
    (actualBalanceSerializedCoefficientMatrix
      (decodeRawArray (n := 3 * s) raw) tape)
    (actualBalanceGaussianRawScan raw tape).2

/-- Reading the result of the array-backed updates gives exactly the reduced
matrix returned by the deterministic Gaussian scan on the same serialized
physical coefficient matrix. This is a refinement statement for execution of
the supplied transcript, not a runtime bound or a proof of the physical
interpreter's loop implementation. -/
theorem actualBalanceGaussianSerializedArrayPivotScan_view_eq_rawScan
    {s : Nat} (raw : RawCoefficientArray) (tape : FiveWordTape s) :
    actualBalanceGaussianArrayView
        (actualBalanceGaussianSerializedArrayPivotScan raw tape) =
      (actualBalanceGaussianRawScan raw tape).1 := by
  rw [actualBalanceGaussianSerializedArrayPivotScan,
    actualBalanceGaussianArrayPivotSequence_view_eq,
    actualBalanceGaussianSerializedArrayView_eq_rawMatrix]
  simpa [actualBalanceGaussianRawScan] using
    (balanceGaussianColumnScan_pivotSequence
      (List.ofFn fun column : Fin ((3 * s) * (3 * s)) => column)
      (actualBalanceGaussianRawMatrix raw tape) ∅)

/-- The array-backed run's final matrix has the same kernel as the original
raw balance matrix, by transporting the accepted per-pivot kernel invariant
through the deterministic scan transcript. -/
theorem actualBalanceGaussianSerializedArrayPivotScan_kernel_iff
    {s : Nat} (raw : RawCoefficientArray) (tape : FiveWordTape s)
    (x : Fin ((3 * s) * (3 * s)) → ZMod 2) :
    actualBalanceGaussianArrayView
        (actualBalanceGaussianSerializedArrayPivotScan raw tape) *ᵥ x = 0 ↔
      actualBalanceGaussianRawMatrix raw tape *ᵥ x = 0 := by
  rw [actualBalanceGaussianSerializedArrayPivotScan_view_eq_rawScan]
  exact balanceGaussianColumnScan_kernel_iff
    (List.ofFn fun column : Fin ((3 * s) * (3 * s)) => column)
    (actualBalanceGaussianRawMatrix raw tape) ∅ x

end CorruptedFieldRecovery
