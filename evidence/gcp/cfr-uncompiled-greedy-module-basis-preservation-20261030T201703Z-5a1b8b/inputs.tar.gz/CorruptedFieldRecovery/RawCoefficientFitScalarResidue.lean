import CorruptedFieldRecovery.RawCoefficientFitCleanSeparation
import CorruptedFieldRecovery.RawPhysicalPowerBasis
import CorruptedFieldRecovery.RawFieldArrayPolynomial
import CorruptedFieldRecovery.RawFieldQuotient

/-! # Interpreting fitted scalar coefficients in the candidate quotient

Uncompiled source draft. A coefficient vector indexed by `Fin s` denotes the
quotient class of its degree-`< s` power polynomial. The accepted raw-candidate
check supplies a monic degree-`s` modulus, so this interpretation is
injective. The draft connects the actual deterministic output to a nonzero
quotient residue and separately identifies the model-prescribed coefficient
vector with the serialized candidate scalar. It deliberately does not assert
that an arbitrary returned fit vector equals the model-prescribed vector;
that stronger equality needs a fit-tensor expansion and support-factor
uniqueness theorem. -/

namespace CorruptedFieldRecovery

open Polynomial AdjoinRoot

/-- The quotient-field element represented by an `s`-bit coefficient vector. -/
noncomputable def rawCoefficientFitScalarResidue {s : Nat}
    (candidate : RawFieldCandidate s)
    (coefficients : Fin s → ZMod 2) :
    AdjoinRoot (rawCandidateModulus candidate) :=
  ∑ j : Fin s,
    coefficients j • AdjoinRoot.mk (rawCandidateModulus candidate)
      (Polynomial.X ^ j.val)

/-- The fitted power polynomial is exactly the power-basis reconstruction of
its quotient residue. -/
theorem rawCoefficientFitScalarResidue_eq_powerCoordinates {s : Nat}
    (candidate : RawFieldCandidate s)
    (hcheck : rawFieldCandidateCheck candidate = true)
    (coefficients : Fin s → ZMod 2) :
    rawCoefficientFitScalarResidue candidate coefficients =
      (rawQuotientPowerCoordinates (rawCandidateModulus candidate)
        (accepted_rawCandidateModulus_monic candidate hcheck)
        (by
          have hv := accepted_rawFieldCandidateCheck candidate hcheck
          have hm := rawFieldCandidateValid_modulus_polynomial candidate hv
          simpa [rawCandidateModulus] using hm.2)).symm coefficients := by
  classical
  let hdegree : (rawCandidateModulus candidate).natDegree = s := by
    have hv := accepted_rawFieldCandidateCheck candidate hcheck
    have hm := rawFieldCandidateValid_modulus_polynomial candidate hv
    simpa [rawCandidateModulus] using hm.2
  let b : Module.Basis (Fin s) (ZMod 2)
      (AdjoinRoot (rawCandidateModulus candidate)) :=
    (AdjoinRoot.powerBasisAux'
      (accepted_rawCandidateModulus_monic candidate hcheck)).reindex
        (finCongr hdegree)
  change (∑ j : Fin s, coefficients j •
      AdjoinRoot.mk (rawCandidateModulus candidate) (Polynomial.X ^ j.val)) =
    b.equivFun.symm coefficients
  rw [Module.Basis.equivFun_symm_apply]
  apply Finset.sum_congr rfl
  intro j hj
  have hbj : b j = AdjoinRoot.mk (rawCandidateModulus candidate)
      (Polynomial.X ^ j.val) := by
    dsimp [b]
    rw [Module.Basis.reindex_apply, AdjoinRoot.powerBasisAux']
    rw [Module.Basis.coe_ofEquivFun]
    let k : Fin (rawCandidateModulus candidate).natDegree :=
      (finCongr hdegree).symm j
    change AdjoinRoot.mk (rawCandidateModulus candidate)
        (∑ i : Fin (rawCandidateModulus candidate).natDegree,
          Polynomial.monomial i
            ((Pi.single k (1 : ZMod 2) :
              Fin (rawCandidateModulus candidate).natDegree → ZMod 2) i)) = _
    apply congrArg (AdjoinRoot.mk (rawCandidateModulus candidate))
    rw [Finset.sum_eq_single k]
    · simp [k, hdegree, Polynomial.monomial_eq_C_mul_X_pow]
    · intro i hi hik
      simp [hik]
    · simp [k]
  rw [hbj]

/-- A nonzero coefficient mask of length `s` cannot represent zero modulo a
monic degree-`s` candidate modulus. This is the finite-degree power-basis
injectivity statement; irreducibility is supplied by the validity check but
the vector-space basis argument itself only needs monicity and degree. -/
theorem rawCoefficientFitScalarResidue_ne_zero_of_nonzero
    {s : Nat} (candidate : RawFieldCandidate s)
    (hcheck : rawFieldCandidateCheck candidate = true)
    (coefficients : Fin s → ZMod 2)
    (hnonzero : ∃ j : Fin s, coefficients j ≠ 0) :
    rawCoefficientFitScalarResidue candidate coefficients ≠ 0 := by
  have hcoordinates := rawCoefficientFitScalarResidue_eq_powerCoordinates
    candidate hcheck coefficients
  intro hresidue
  have hzero :
      (rawQuotientPowerCoordinates (rawCandidateModulus candidate)
        (accepted_rawCandidateModulus_monic candidate hcheck)
        (by
          have hv := accepted_rawFieldCandidateCheck candidate hcheck
          have hm := rawFieldCandidateValid_modulus_polynomial candidate hv
          simpa [rawCandidateModulus] using hm.2)).symm coefficients = 0 := by
    rw [← hcoordinates]
    exact hresidue
  have hcoefficients : coefficients = 0 := by
    apply (rawQuotientPowerCoordinates (rawCandidateModulus candidate)
      (accepted_rawCandidateModulus_monic candidate hcheck)
      (by
        have hv := accepted_rawFieldCandidateCheck candidate hcheck
        have hm := rawFieldCandidateValid_modulus_polynomial candidate hv
        simpa [rawCandidateModulus] using hm.2)).symm.injective
    simpa using hzero
  rcases hnonzero with ⟨j, hj⟩
  have hjzero := congrFun hcoefficients j
  exact hj hjzero

/-- The model-prescribed coefficient vector is the serialized raw scalar in
the quotient field. This identifies that particular fit witness's scalar;
it does not identify a different arbitrary affine-solver output. -/
theorem rawCoefficientFitModelScalarResidue_eq_rawCandidateScalar {s : Nat}
    (candidate : RawFieldCandidate s)
    (hcheck : rawFieldCandidateCheck candidate = true)
    (hscalarSize : candidate.scalar.size = s) :
    rawCoefficientFitScalarResidue candidate
      (rawCoefficientFitScalarCoefficient candidate) =
        AdjoinRoot.mk (rawCandidateModulus candidate)
          (rawCandidateScalar candidate) := by
  classical
  have hpoly := rawFieldArrayPolynomial_eq_fin_power_sum candidate.scalar hscalarSize
  have hclass :
      rawCandidateQuotientClass candidate (rawFieldBitsToNat candidate.scalar) =
        rawCoefficientFitScalarResidue candidate
          (rawCoefficientFitScalarCoefficient candidate) := by
    change AdjoinRoot.mk (rawCandidateModulus candidate)
        (rawMaskPolynomial (rawFieldBitsToNat candidate.scalar)) = _
    rw [← rawFieldArrayPolynomial_eq_mask]
    rw [hpoly]
    simp [rawCoefficientFitScalarResidue, rawCoefficientFitScalarCoefficient,
      rawFieldArrayPolynomial, Polynomial.monomial_eq_C_mul_X_pow,
      Algebra.smul_def]
  have hscalar :
      rawCandidateQuotientClass candidate (rawFieldBitsToNat candidate.scalar) =
        AdjoinRoot.mk (rawCandidateModulus candidate)
          (rawCandidateScalar candidate) := by
    rw [rawCandidateQuotientClass, rawCandidateScalar,
      ← rawFieldArrayPolynomial_eq_mask]
  exact hclass.symm.trans hscalar

/-- Under the model-derived consistency and separation premises, the scalar
residue read from the exact deterministic output is nonzero. Together with
the preceding model-vector identity, this shows both the raw candidate
scalar and the returned fit scalar are nonzero; equality of those two
elements is deliberately left to the fit-tensor uniqueness bridge. -/
theorem rawCoefficientFitModel_deterministicOutput_residue_ne_zero
    {s R d : Nat}
    (input : RawCoefficientArray) (candidate : RawFieldCandidate s)
    (hfield : rawFieldCandidateCheck candidate = true)
    (forward inverse : RawCoordinateMatrix)
    (hcoordinates : rawCoordinateMatrixCheck (n := 3 * s) forward inverse = true)
    (residual : RawCoefficientArray) (supportMatrix : RawBinaryArray)
    (hinputSize : input.size = ((3 * s) * (3 * s)) * (3 * s))
    (hscalarSize : candidate.scalar.size = s)
    (hresidualSize : residual.size = ((d * d) * d))
    (hsupportSize : supportMatrix.size = (3 * s) * d)
    (hmodel : RawCoefficientFitModelDecomposition input candidate hfield
      forward inverse hcoordinates residual supportMatrix)
    (htrace : RawCoefficientFitTraceColumnExpansion candidate hfield forward inverse
      hcoordinates)
    (hd : d ≤ R) (hs : 2 * R + 5 ≤ s) :
    ∃ padded,
      rawCoefficientFitDeterministicOutput candidate hfield inverse supportMatrix input =
        some padded ∧
      rawCoefficientFitScalarResidue candidate
        (fun j => rawCoefficientFitProjectCompact padded (Sum.inl j)) ≠ 0 := by
  obtain ⟨padded, houtput, hnonzeroCoefficients⟩ :=
    rawCoefficientFitModel_deterministicOutput_scalar_ne_zero input candidate hfield
      forward inverse hcoordinates residual supportMatrix hinputSize hscalarSize
      hresidualSize hsupportSize hmodel htrace hd hs
  have hresidue := rawCoefficientFitScalarResidue_ne_zero_of_nonzero candidate hfield
    (fun j => rawCoefficientFitProjectCompact padded (Sum.inl j))
    hnonzeroCoefficients
  exact ⟨padded, houtput, hresidue⟩

/-- Uniqueness of the trace scalar once both decompositions are expressed as
the same clean determinant family plus pullbacks through the same support
map. The equation premise is the semantic tensor form that must be obtained
from the exact fit-row equations; it is not a scalar-separation assumption.
Subtracting the two decompositions makes the difference trace tensor factor
through the support map. A nonzero scalar difference would have full mode
image dimension `n`, contradicting the support bound `d ≤ R < n`. -/
theorem traceDeterminant_scalar_eq_of_common_supported_decomposition
    {K : Type*} [Field K] [Finite K] [Algebra BinaryField K]
    [FiniteDimensional BinaryField K]
    {n d R : Nat}
    (Q : BinaryVector n ≃ₗ[BinaryField] FieldTriple K)
    (U : BinaryVector n →ₗ[ZMod 2] BinaryVector d)
    (modelResidual fitResidual : BinaryTensor d)
    (modelScalar fitScalar : K)
    (hdecomp :
      traceDeterminantTensor K modelScalar Q.symm.toLinearMap +
          pullback modelResidual U =
        traceDeterminantTensor K fitScalar Q.symm.toLinearMap +
          pullback fitResidual U)
    (hd : d ≤ R) (hn : R < n) :
    fitScalar = modelScalar := by
  classical
  let modelTensor := traceDeterminantTensor K modelScalar Q.symm.toLinearMap
  let fitTensor := traceDeterminantTensor K fitScalar Q.symm.toLinearMap
  have hdiff : modelTensor - fitTensor =
      pullback (fitResidual - modelResidual) U := by
    calc
      modelTensor - fitTensor =
          (modelTensor + pullback modelResidual U) -
            (fitTensor + pullback modelResidual U) := by abel
      _ = (fitTensor + pullback fitResidual U) -
            (fitTensor + pullback modelResidual U) := by rw [hdecomp]
      _ = pullback fitResidual U - pullback modelResidual U := by abel
      _ = pullback (fitResidual - modelResidual) U := by
        ext x y z
        simp [pullback_apply]
  have htraceDiff : modelTensor - fitTensor =
      traceDeterminantTensor K (modelScalar - fitScalar) Q.symm.toLinearMap := by
    ext x y z
    simp only [modelTensor, fitTensor, traceDeterminantTensor_apply]
    rw [← map_sub]
    congr 1
    ring
  have hfactor :
      traceDeterminantTensor K (modelScalar - fitScalar) Q.symm.toLinearMap =
        pullback (fitResidual - modelResidual) U := htraceDiff.symm.trans hdiff
  by_contra hne
  have hscalarDiff : modelScalar - fitScalar ≠ 0 := by
    intro hzero
    apply hne
    exact (sub_eq_zero.mp hzero).symm
  have hrank := traceDeterminantTensor_modeImage_finrank Q
    (modelScalar - fitScalar) hscalarDiff
  have hsmall := modeImage_pullback_finrank_le_supportDimension
    (fitResidual - modelResidual) U hd
  have heq := congrArg
    (fun tensor : BinaryTensor n =>
      Module.finrank BinaryField (modeImage tensor)) hfactor
  rw [hrank] at heq
  omega

end CorruptedFieldRecovery
