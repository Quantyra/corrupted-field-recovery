import CorruptedFieldRecovery.S010BalanceGaussianOrderedSeedIndex
import CorruptedFieldRecovery.S010BalanceGaussianScalarRangeBridge
import CorruptedFieldRecovery.ProbabilityFiveTupleAssembly

namespace CorruptedFieldRecovery

/-! A source-level bridge from the manuscript's physical fifth word to the
computed free-column coefficient seed. The physical suffix is a field scalar
in the basis selected from the first four words; it is not itself the list of
free-column coefficients. The conversion below uses explicit matrix
coordinates. This file is uncompiled and depends on the preserved,
uncompiled ordered-seed/random-selection drafts. -/

/-- Changing only the independent fifth word does not change the raw balance
matrix: its rows are the four physical contractions, which use `tape.1`. -/
theorem actualBalanceGaussianRawMatrix_eq_of_fst_eq {s : Nat}
    (raw : RawCoefficientArray) (tape tape' : FiveWordTape s)
    (hwords : tape.1 = tape'.1) :
    actualBalanceGaussianRawMatrix raw tape =
      actualBalanceGaussianRawMatrix raw tape' := by
  cases tape with
  | mk words index =>
    cases tape' with
    | mk words' index' =>
      dsimp at hwords
      subst words'
      simp [actualBalanceGaussianRawMatrix,
        actualBalanceRawInputCoefficientMatrix,
        actualBalanceComputableCoefficientMatrix,
        actualBalanceBasisResidual]

/-- Therefore the deterministic Gaussian scan, including its pivot transcript,
is also a function of the first four words only. -/
theorem actualBalanceGaussianRawScan_eq_of_fst_eq {s : Nat}
    (raw : RawCoefficientArray) (tape tape' : FiveWordTape s)
    (hwords : tape.1 = tape'.1) :
    actualBalanceGaussianRawScan raw tape =
      actualBalanceGaussianRawScan raw tape' := by
  simp [actualBalanceGaussianRawScan,
    actualBalanceGaussianRawMatrix_eq_of_fst_eq raw tape tape' hwords]

/-- For a fixed coefficient seed, changing the fifth physical suffix leaves
the selected endomorphism unchanged. This is the solver-side independence
needed before conditioning on the first four words. -/
theorem actualBalanceGaussianArrayFlagSelectBySeed_eq_of_fst_eq {s : Nat}
    (raw : RawCoefficientArray) (tape tape' : FiveWordTape s)
    (hwords : tape.1 = tape'.1)
    (hcard : Fintype.card (actualBalanceGaussianRawFreeIndex raw tape) = s)
    (hcard' : Fintype.card (actualBalanceGaussianRawFreeIndex raw tape') = s)
    (seed : Fin s → BinaryField) :
    actualBalanceGaussianArrayFlagSelectBySeed raw tape hcard seed =
      actualBalanceGaussianArrayFlagSelectBySeed raw tape' hcard' seed := by
  have hscan := actualBalanceGaussianRawScan_eq_of_fst_eq raw tape tape' hwords
  have hindex : actualBalanceGaussianRawFreeIndex raw tape =
      actualBalanceGaussianRawFreeIndex raw tape' := by
    unfold actualBalanceGaussianRawFreeIndex
    rw [hscan]
  subst hindex
  have hproof : hcard = hcard' := Subsingleton.elim _ _
  subst hproof
  simp [actualBalanceGaussianArrayFlagSelectBySeed,
    actualBalanceGaussianRawWeightedCombination,
    actualBalanceGaussianRawCandidateFamily, hscan]

/-- Convert a physical fifth suffix into the coefficients of the computed
free-column basis. The suffix first denotes a field scalar using the model's
ordered basis `b`; the explicit endomorphism coordinates then give its
weights on the actual Gaussian free-column candidates. -/
def actualBalanceGaussianSeedOfPhysicalSuffix
    {K : Type*} [Field K] [Algebra BinaryField K] {s : Nat}
    (Q : BinaryVector (3 * s) ≃ₗ[BinaryField] FieldTriple K)
    (b : (Fin 4 → FieldTriple K) → Module.Basis (Fin s) BinaryField K)
    (raw : RawCoefficientArray) (tape : FiveWordTape s)
    (hcard : Fintype.card (actualBalanceGaussianRawFreeIndex raw tape) = s)
    (suffix : BinaryVector s) : Fin s → BinaryField := by
  let words : Fin 4 → FieldTriple K := fun i => Q (tape.1 i)
  let k : K := basisFifthIndexEquiv K (b words) suffix
  let T : Module.End BinaryField (BinaryVector (3 * s)) :=
    qScalarConjugateLinearMap Q k
  let hindex := actualBalanceGaussianRawFreeIndexFinEquiv raw tape hcard
  exact fun i => actualBalanceGaussianInputCoordinates T (hindex i).1

/-- The selected endomorphism from these computed coordinates is exactly the
Q-conjugated scalar represented by the physical suffix. This is the substantive
suffix-to-kernel-coordinate identity needed to use the fifth word as the
solver's random seed, rather than drawing a second independent seed. -/
theorem actualBalanceGaussianSelectByPhysicalSuffix_eq
    {K : Type*} [Field K] [Fintype K] [DecidableEq K] [Finite K]
    [CharP K 2] [Algebra BinaryField K] [FiniteDimensional BinaryField K]
    [Algebra (ZMod (ringChar K)) K]
    {s : Nat}
    (Q : BinaryVector (3 * s) ≃ₗ[BinaryField] FieldTriple K)
    (E : BinaryTensor (3 * s))
    (U : Submodule BinaryField (KTriple K))
    (b : (Fin 4 → FieldTriple K) → Module.Basis (Fin s) BinaryField K)
    (raw : RawCoefficientArray) (tape : FiveWordTape s)
    (htape : tape ∈ actualFiveGoodTapeSet K Q
      (modeImageSemanticCleanFieldSet Q E) U b)
    (c : K) (hc : c ≠ 0)
    (hmodel : HasObservedTraceDeterminantDecomposition
      (decodeRawArray (n := 3 * s) raw) E LinearMap.id Q c)
    (hsize : raw.size = (3 * s) * (3 * s) * (3 * s))
    (hK : Module.finrank BinaryField K = s)
    (suffix : BinaryVector s) :
    actualBalanceGaussianArrayFlagSelectBySeed raw tape
      (by rw [← actualBalanceGaussianRawFreeIndex_card_eq
        Q E U b raw tape htape c hc hmodel hsize hK]; rfl)
      (actualBalanceGaussianSeedOfPhysicalSuffix Q b raw tape
        (by rw [← actualBalanceGaussianRawFreeIndex_card_eq
          Q E U b raw tape htape c hc hmodel hsize hK]; rfl) suffix) =
    qScalarConjugateLinearMap Q
      (basisFifthIndexEquiv K (b (fun i => Q (tape.1 i))) suffix) := by
  let hcard : Fintype.card (actualBalanceGaussianRawFreeIndex raw tape) = s :=
    actualBalanceGaussianRawFreeIndex_card_eq
      Q E U b raw tape htape c hc hmodel hsize hK
  let words : Fin 4 → FieldTriple K := fun i => Q (tape.1 i)
  let k : K := basisFifthIndexEquiv K (b words) suffix
  let T : Module.End BinaryField (BinaryVector (3 * s)) :=
    qScalarConjugateLinearMap Q k
  have hT : T ∈ qScalarConjugateEndRange Q := ⟨k, rfl⟩
  have hspan := (actualBalanceGaussianRawBasis_spans_QScalarRange
    Q E U b raw tape htape c hc hmodel hsize T).mp hT
  let hindex := actualBalanceGaussianRawFreeIndexFinEquiv raw tape hcard
  have hweights :
      (fun free : actualBalanceGaussianRawFreeIndex raw tape =>
        actualBalanceGaussianSeedOfPhysicalSuffix Q b raw tape hcard suffix
          (hindex.symm free)) =
        fun free => actualBalanceGaussianInputCoordinates T free.1 := by
    funext free
    simp [actualBalanceGaussianSeedOfPhysicalSuffix, hindex, T, k]
  change actualBalanceGaussianRawWeightedCombination raw tape
      (fun free => actualBalanceGaussianSeedOfPhysicalSuffix Q b raw tape hcard suffix
        (hindex.symm free)) = T
  rw [hweights]
  exact hspan.symm

/-- The scalar recovered from the endomorphism selected with the converted
suffix is exactly the model-basis scalar decoded from that physical suffix.
This is the event-semantic bridge: generator and translate predicates can be
transported by rewriting this equality, rather than assuming two bases agree. -/
theorem actualBalanceGaussianSelectedScalar_eq_physicalSuffix
    {K : Type*} [Field K] [Fintype K] [DecidableEq K] [Finite K]
    [CharP K 2] [Algebra BinaryField K] [FiniteDimensional BinaryField K]
    [Algebra (ZMod (ringChar K)) K]
    {s : Nat}
    (Q : BinaryVector (3 * s) ≃ₗ[BinaryField] FieldTriple K)
    (E : BinaryTensor (3 * s))
    (U : Submodule BinaryField (KTriple K))
    (b : (Fin 4 → FieldTriple K) → Module.Basis (Fin s) BinaryField K)
    (raw : RawCoefficientArray) (tape : FiveWordTape s)
    (htape : tape ∈ actualFiveGoodTapeSet K Q
      (modeImageSemanticCleanFieldSet Q E) U b)
    (c : K) (hc : c ≠ 0)
    (hmodel : HasObservedTraceDeterminantDecomposition
      (decodeRawArray (n := 3 * s) raw) E LinearMap.id Q c)
    (hsize : raw.size = (3 * s) * (3 * s) * (3 * s))
    (hK : Module.finrank BinaryField K = s)
    (suffix : BinaryVector s) :
    actualBalanceGaussianQScalarParameter Q
      (actualBalanceGaussianArrayFlagSelectBySeed raw tape
        (by rw [← actualBalanceGaussianRawFreeIndex_card_eq
          Q E U b raw tape htape c hc hmodel hsize hK]; rfl)
        (actualBalanceGaussianSeedOfPhysicalSuffix Q b raw tape
          (by rw [← actualBalanceGaussianRawFreeIndex_card_eq
            Q E U b raw tape htape c hc hmodel hsize hK]; rfl) suffix)) =
      basisFifthIndexEquiv K (b (fun i => Q (tape.1 i))) suffix := by
  have hselected := actualBalanceGaussianSelectByPhysicalSuffix_eq
    Q E U b raw tape htape c hc hmodel hsize hK suffix
  have hparam : actualBalanceGaussianQScalarParameter Q
      (qScalarConjugateLinearMap Q
        (basisFifthIndexEquiv K (b (fun i => Q (tape.1 i))) suffix)) =
      basisFifthIndexEquiv K (b (fun i => Q (tape.1 i))) suffix := by
    simp [actualBalanceGaussianQScalarParameter,
      qScalarConjugateLinearMap, basisFifthIndexEquiv, fieldBasis0]
  rw [hselected]
  exact hparam

/-- The primitive/generator predicate on the selected computed scalar is
equivalent to the predicate on the original physical fifth suffix. The same
rewrite can transport membership in any scalar subset, including the
translate-avoiding fifth-coordinate event. -/
theorem actualBalanceGaussianSelectedScalar_primitive_iff_physicalSuffix
    {K : Type*} [Field K] [Fintype K] [DecidableEq K] [Finite K]
    [CharP K 2] [Algebra BinaryField K] [FiniteDimensional BinaryField K]
    [Algebra (ZMod (ringChar K)) K]
    {s : Nat}
    (Q : BinaryVector (3 * s) ≃ₗ[BinaryField] FieldTriple K)
    (E : BinaryTensor (3 * s))
    (U : Submodule BinaryField (KTriple K))
    (b : (Fin 4 → FieldTriple K) → Module.Basis (Fin s) BinaryField K)
    (raw : RawCoefficientArray) (tape : FiveWordTape s)
    (htape : tape ∈ actualFiveGoodTapeSet K Q
      (modeImageSemanticCleanFieldSet Q E) U b)
    (c : K) (hc : c ≠ 0)
    (hmodel : HasObservedTraceDeterminantDecomposition
      (decodeRawArray (n := 3 * s) raw) E LinearMap.id Q c)
    (hsize : raw.size = (3 * s) * (3 * s) * (3 * s))
    (hK : Module.finrank BinaryField K = s)
    (suffix : BinaryVector s) :
    Algebra.adjoin BinaryField
        ({actualBalanceGaussianQScalarParameter Q
          (actualBalanceGaussianArrayFlagSelectBySeed raw tape
            (by rw [← actualBalanceGaussianRawFreeIndex_card_eq
              Q E U b raw tape htape c hc hmodel hsize hK]; rfl)
            (actualBalanceGaussianSeedOfPhysicalSuffix Q b raw tape
              (by rw [← actualBalanceGaussianRawFreeIndex_card_eq
                Q E U b raw tape htape c hc hmodel hsize hK]; rfl) suffix))} : Set K) = ⊤ ↔
      Algebra.adjoin BinaryField
        ({basisFifthIndexEquiv K (b (fun i => Q (tape.1 i))) suffix} : Set K) = ⊤ := by
  rw [actualBalanceGaussianSelectedScalar_eq_physicalSuffix
    Q E U b raw tape htape c hc hmodel hsize hK suffix]

/-- The whole fifth-coordinate event, including both the generator exclusion
and the translate exclusion, is preserved by the explicit physical-suffix to
computed-seed conversion. This is the precise event relation needed before
using a conditional fair-bit count. -/
theorem actualBalanceGaussianSelectedScalar_goodFifth_iff_physicalSuffix
    {K : Type*} [Field K] [Fintype K] [DecidableEq K] [Finite K]
    [CharP K 2] [Algebra BinaryField K] [FiniteDimensional BinaryField K]
    [Algebra (ZMod (ringChar K)) K]
    {s : Nat}
    (Q : BinaryVector (3 * s) ≃ₗ[BinaryField] FieldTriple K)
    (E : BinaryTensor (3 * s))
    (U : Submodule BinaryField (KTriple K))
    (b : (Fin 4 → FieldTriple K) → Module.Basis (Fin s) BinaryField K)
    (raw : RawCoefficientArray) (tape : FiveWordTape s)
    (htape : tape ∈ actualFiveGoodTapeSet K Q
      (modeImageSemanticCleanFieldSet Q E) U b)
    (c : K) (hc : c ≠ 0)
    (hmodel : HasObservedTraceDeterminantDecomposition
      (decodeRawArray (n := 3 * s) raw) E LinearMap.id Q c)
    (hsize : raw.size = (3 * s) * (3 * s) * (3 * s))
    (hK : Module.finrank BinaryField K = s)
    (suffix : BinaryVector s) :
    actualBalanceGaussianQScalarParameter Q
      (actualBalanceGaussianArrayFlagSelectBySeed raw tape
        (by rw [← actualBalanceGaussianRawFreeIndex_card_eq
          Q E U b raw tape htape c hc hmodel hsize hK]; rfl)
        (actualBalanceGaussianSeedOfPhysicalSuffix Q b raw tape
          (by rw [← actualBalanceGaussianRawFreeIndex_card_eq
            Q E U b raw tape htape c hc hmodel hsize hK]; rfl) suffix)) ∈
      goodFifthScalars K U ↔
    basisFifthIndexEquiv K (b (fun i => Q (tape.1 i))) suffix ∈
      goodFifthScalars K U := by
  rw [actualBalanceGaussianSelectedScalar_eq_physicalSuffix
    Q E U b raw tape htape c hc hmodel hsize hK suffix]

/-- For a fixed good four-word prefix (represented by any one good reference
tape), the physical fifth-word map to computed coefficient seeds is a
bijection. Thus an independent uniform fifth s-bit suffix remains uniform
after the basis-coordinate conversion. The reference tape supplies the
prefix's already-proved balance-space dimension; the selector matrix itself is
prefix-only by `actualBalanceGaussianRawScan_eq_of_fst_eq`. -/
theorem actualBalanceGaussianPhysicalSuffixSeed_bijective
    {K : Type*} [Field K] [Fintype K] [DecidableEq K] [Finite K]
    [CharP K 2] [Algebra BinaryField K] [FiniteDimensional BinaryField K]
    [Algebra (ZMod (ringChar K)) K]
    {s : Nat}
    (Q : BinaryVector (3 * s) ≃ₗ[BinaryField] FieldTriple K)
    (E : BinaryTensor (3 * s))
    (U : Submodule BinaryField (KTriple K))
    (b : (Fin 4 → FieldTriple K) → Module.Basis (Fin s) BinaryField K)
    (raw : RawCoefficientArray) (referenceTape : FiveWordTape s)
    (htape : referenceTape ∈ actualFiveGoodTapeSet K Q
      (modeImageSemanticCleanFieldSet Q E) U b)
    (c : K) (hc : c ≠ 0)
    (hmodel : HasObservedTraceDeterminantDecomposition
      (decodeRawArray (n := 3 * s) raw) E LinearMap.id Q c)
    (hsize : raw.size = (3 * s) * (3 * s) * (3 * s))
    (hK : Module.finrank BinaryField K = s) :
    Function.Bijective
      (actualBalanceGaussianSeedOfPhysicalSuffix Q b raw referenceTape
        (by rw [← actualBalanceGaussianRawFreeIndex_card_eq
          Q E U b raw referenceTape htape c hc hmodel hsize hK]; rfl)) := by
  classical
  let hcard : Fintype.card
      (actualBalanceGaussianRawFreeIndex raw referenceTape) = s :=
    actualBalanceGaussianRawFreeIndex_card_eq
      Q E U b raw referenceTape htape c hc hmodel hsize hK
  let f : (Fin s → BinaryField) → K := fun seed =>
    actualBalanceGaussianQScalarParameter Q
      (actualBalanceGaussianArrayFlagSelectBySeed raw referenceTape hcard seed)
  have hf : Function.Bijective f := by
    simpa [f, hcard] using
      actualBalanceGaussianArrayFlagSeedScalar_bijective
        Q E U b raw referenceTape htape c hc hmodel hsize hK
  let ef : (Fin s → BinaryField) ≃ K := Equiv.ofBijective f hf
  let ek : BinaryVector s ≃ K :=
    basisFifthIndexEquiv K (b (fun i => Q (referenceTape.1 i)))
  have hfactor : ∀ suffix,
      actualBalanceGaussianSeedOfPhysicalSuffix Q b raw referenceTape hcard suffix =
        ef.symm (ek suffix) := by
    intro suffix
    apply ef.injective
    have hselected := actualBalanceGaussianSelectByPhysicalSuffix_eq
      Q E U b raw referenceTape htape c hc hmodel hsize hK suffix
    have hparam : actualBalanceGaussianQScalarParameter Q
        (qScalarConjugateLinearMap Q (ek suffix)) = ek suffix := by
      simp [actualBalanceGaussianQScalarParameter,
        qScalarConjugateLinearMap, ek, basisFifthIndexEquiv, fieldBasis0]
    simpa [f, ef, ek, hcard] using
      (congrArg (actualBalanceGaussianQScalarParameter Q) hselected).trans hparam
  have heq : actualBalanceGaussianSeedOfPhysicalSuffix Q b raw referenceTape hcard =
      fun suffix => ef.symm (ek suffix) := by
    funext suffix
    exact hfactor suffix
  rw [heq]
  exact (ef.symm).bijective.comp ek.bijective

end CorruptedFieldRecovery
