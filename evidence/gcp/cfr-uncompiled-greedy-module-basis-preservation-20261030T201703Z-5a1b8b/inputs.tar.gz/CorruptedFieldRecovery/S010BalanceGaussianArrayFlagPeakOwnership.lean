import CorruptedFieldRecovery.S010BalanceGaussianArrayFlagTraceBounds

namespace CorruptedFieldRecovery

/-- Source ownership phases for the recursive flag scan. `matrixRebuild`
means a new coefficient matrix is being constructed while all arrays held by
ancestor frames remain reachable; `flagRebuild` also has the completed new
matrix and a new flag array under construction. `recursiveCall` has both new
arrays. The phase model deliberately counts distinct retained array versions,
not cumulative allocation events. -/
inductive ActualBalanceGaussianFlagOwnershipPhase where
  | selector
  | matrixRebuild
  | flagRebuild
  | recursiveCall
  | returnPhase
  deriving DecidableEq, Repr

/-- A source-level ownership snapshot. `completedPivots` is the number of
successful updates before the current phase; `totalPivots` bounds all updates
in the full scan; `transcriptNodes` counts already-live output cons cells. -/
structure ActualBalanceGaussianFlagOwnershipState where
  phase : ActualBalanceGaussianFlagOwnershipPhase
  completedPivots : Nat
  totalPivots : Nat
  transcriptNodes : Nat
  deriving DecidableEq, Repr

def ActualBalanceGaussianFlagOwnershipState.matrixArrayVersions
    (state : ActualBalanceGaussianFlagOwnershipState) : Nat :=
  match state.phase with
  | .selector => state.completedPivots + 1
  | .matrixRebuild => state.completedPivots + 2
  | .flagRebuild => state.completedPivots + 2
  | .recursiveCall => state.completedPivots + 1
  | .returnPhase => state.completedPivots + 1

def ActualBalanceGaussianFlagOwnershipState.flagArrayVersions
    (state : ActualBalanceGaussianFlagOwnershipState) : Nat :=
  match state.phase with
  | .selector => state.completedPivots + 1
  | .matrixRebuild => state.completedPivots + 1
  | .flagRebuild => state.completedPivots + 2
  | .recursiveCall => state.completedPivots + 1
  | .returnPhase => state.completedPivots + 1

def ActualBalanceGaussianFlagOwnershipState.selectorListSlots
    (state : ActualBalanceGaussianFlagOwnershipState) (m : Nat) : Nat :=
  match state.phase with
  | .selector => m
  | _ => 0

/-- Live slots in the explicit ownership model: each retained nested matrix
version accounts for `m*n` cells and `m` row references; each flag version
accounts for `m` bits. The active selector may own one `m`-node row list. The
original `k`-node column list and currently accumulated pivot transcript are
included when reachable. Runtime headers and control-stack storage are outside
this slot unit. -/
def ActualBalanceGaussianFlagOwnershipState.liveSlots
    (state : ActualBalanceGaussianFlagOwnershipState)
    (m n k : Nat) : Nat :=
  state.matrixArrayVersions * (m * (n + 1)) +
    state.flagArrayVersions * m +
    state.selectorListSlots m + k + state.transcriptNodes

/-- A trace-compatible ownership state records no more completed updates or
transcript cells than the full instrumented run will produce. This relation
is the explicit phase invariant required to apply the peak theorem. -/
def ActualBalanceGaussianFlagOwnershipState.CompatibleWithTrace
    (state : ActualBalanceGaussianFlagOwnershipState)
    (trace : ActualBalanceGaussianFlagExecutionTrace) : Prop :=
  state.totalPivots = trace.pivotUpdates ∧
    state.completedPivots ≤ state.totalPivots ∧
    state.transcriptNodes ≤ state.totalPivots

/-- Every ownership phase within the trace invariant has a peak-slot bound.
This is proved from simultaneous live versions and scratch structures, not
from the cumulative allocation counter. -/
theorem actualBalanceGaussianFlagOwnershipState_liveSlots_le
    (state : ActualBalanceGaussianFlagOwnershipState) (m n k : Nat)
    (hcompleted : state.completedPivots ≤ state.totalPivots)
    (htranscript : state.transcriptNodes ≤ state.totalPivots) :
    state.liveSlots m n k ≤
      (state.totalPivots + 2) * m * (n + 2) + m + k + state.totalPivots := by
  have hmatrix : state.matrixArrayVersions ≤ state.totalPivots + 2 := by
    cases state.phase <;>
      simp [ActualBalanceGaussianFlagOwnershipState.matrixArrayVersions] <;>
      omega
  have hflags : state.flagArrayVersions ≤ state.totalPivots + 2 := by
    cases state.phase <;>
      simp [ActualBalanceGaussianFlagOwnershipState.flagArrayVersions] <;>
      omega
  have hselector : state.selectorListSlots m ≤ m := by
    cases state.phase <;>
      simp [ActualBalanceGaussianFlagOwnershipState.selectorListSlots]
  calc
    state.liveSlots m n k ≤
        (state.totalPivots + 2) * (m * (n + 1)) +
          (state.totalPivots + 2) * m + m + k + state.totalPivots := by
            unfold ActualBalanceGaussianFlagOwnershipState.liveSlots
            gcongr
    _ = (state.totalPivots + 2) * m * (n + 2) +
          m + k + state.totalPivots := by ring

/-- Trace-compatible phase construction. The phase family separates the
selector scratch list from pivot-update array buffers and the recursive-call
state, so its peak bound is an ownership argument rather than a cumulative
allocation estimate. This remains an abstract source model: no Lean runtime
semantics theorem is asserted. -/
def actualBalanceGaussianFlagOwnershipSnapshot
    (phase : ActualBalanceGaussianFlagOwnershipPhase)
    (completed total transcript : Nat) : ActualBalanceGaussianFlagOwnershipState :=
  { phase := phase
    completedPivots := completed
    totalPivots := total
    transcriptNodes := transcript }

/-- Raw-system specialization of the phase peak bound for `d=3*s`,
`m=4*d^2`, and `n=k=d^2`. It is conditional on the state matching the
instrumented run's final pivot count. -/
theorem actualBalanceGaussianFlagOwnershipState_rawPeak_le
    {s : Nat} (state : ActualBalanceGaussianFlagOwnershipState)
    (hcompleted : state.completedPivots ≤ state.totalPivots)
    (htranscript : state.transcriptNodes ≤ state.totalPivots)
    (hpivots : state.totalPivots ≤ (3 * s) * (3 * s)) :
    state.liveSlots
        (4 * ((3 * s) * (3 * s)))
        ((3 * s) * (3 * s))
        ((3 * s) * (3 * s)) ≤
      4 * (3 * s) ^ 6 + 16 * (3 * s) ^ 4 + 22 * (3 * s) ^ 2 := by
  let d := 3 * s
  let k := d * d
  let m := 4 * k
  have hgeneral := actualBalanceGaussianFlagOwnershipState_liveSlots_le
    state m k k hcompleted htranscript
  calc
    _ ≤ (state.totalPivots + 2) * m * (k + 2) + m + k +
        state.totalPivots := by simpa [ActualBalanceGaussianFlagOwnershipState.liveSlots,
          m, k] using hgeneral
    _ ≤ (k + 2) * m * (k + 2) + m + 2 * k := by
      have htotal : state.totalPivots + 2 ≤ k + 2 := Nat.add_le_add_right hpivots 2
      gcongr
    _ = 4 * d ^ 6 + 16 * d ^ 4 + 22 * d ^ 2 := by
      simp [m, k]
      ring
    _ = 4 * (3 * s) ^ 6 + 16 * (3 * s) ^ 4 + 22 * (3 * s) ^ 2 := by
      rfl

/-- The current source model's ownership hypothesis is explicit: recursive
frames may retain all previous matrix/flag versions; only the active selector
owns an `m`-row list; the source column list and pivot transcript are counted
as live roots. The theorem does not count actual Lean heap words, garbage
collection, sharing/uniqueness optimizations, object headers, closures, or
call-stack bytes, and it does not prove that Lean's evaluator implements this
abstract ownership model. -/
theorem actualBalanceGaussianFlagOwnershipState_rawPeak_fromTrace
    {s : Nat} (state : ActualBalanceGaussianFlagOwnershipState)
    (trace : ActualBalanceGaussianFlagExecutionTrace)
    (hcompatible : state.CompatibleWithTrace trace)
    (htracePivots : trace.pivotUpdates ≤ (3 * s) * (3 * s)) :
    state.liveSlots
        (4 * ((3 * s) * (3 * s)))
        ((3 * s) * (3 * s))
        ((3 * s) * (3 * s)) ≤
      4 * (3 * s) ^ 6 + 16 * (3 * s) ^ 4 + 22 * (3 * s) ^ 2 := by
  rcases hcompatible with ⟨htotal, hcompleted, htranscript⟩
  apply actualBalanceGaussianFlagOwnershipState_rawPeak_le
    state hcompleted htranscript
  simpa [htotal] using htracePivots

end CorruptedFieldRecovery
