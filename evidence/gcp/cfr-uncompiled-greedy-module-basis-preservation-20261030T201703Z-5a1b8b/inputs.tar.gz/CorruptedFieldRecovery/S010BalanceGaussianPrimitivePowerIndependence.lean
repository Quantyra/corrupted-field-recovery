import CorruptedFieldRecovery.S010BalanceGaussianSampledGeneratorFilter
import Mathlib.FieldTheory.PrimitiveElement
import Mathlib.FieldTheory.IntermediateField.Adjoin.Basic

namespace CorruptedFieldRecovery

/-! A primitive scalar has a power basis of length `finrank K`.  This file
relates that scalar power basis to the first `s` powers of the corresponding
Q-conjugated endomorphism.  It is a source-level draft only; it has not been
checked by Lean. -/

/-- The first `s` powers of a primitive scalar form a linearly independent
family when the extension degree is `s`. -/
theorem actualBalanceGaussian_scalarPowers_linearIndependent_of_primitive
    {K : Type*} [Field K] [FiniteDimensional BinaryField K]
    [Algebra BinaryField K] {s : Nat} (k : K)
    (hgen : Algebra.adjoin BinaryField ({k} : Set K) = ⊤)
    (hK : Module.finrank BinaryField K = s) :
    LinearIndependent BinaryField (fun i : Fin s => k ^ i.val) := by
  let L : IntermediateField BinaryField K :=
    IntermediateField.adjoin BinaryField ({k} : Set K)
  let pb : PowerBasis BinaryField L :=
    IntermediateField.adjoin.powerBasis (Algebra.IsIntegral.isIntegral k)
  have hgen' : BinaryField⟮k⟯ = ⊤ := by
    simpa [L] using hgen
  have hdegree : (minpoly BinaryField k).natDegree = s := by
    exact (Field.primitive_element_iff_minpoly_natDegree_eq
      (F := BinaryField) (E := K) k).mp hgen' |>.trans hK
  have hdim : pb.dim = s := by
    simp [pb, hdegree]
  let incl : L →ₗ[BinaryField] K := L.val.toLinearMap
  have hincl : LinearMap.ker incl = ⊥ := by
    apply LinearMap.ker_eq_bot'.2
    exact L.val.injective
  have hpb : LinearIndependent BinaryField
      (fun i : Fin pb.dim => incl (pb.basis i)) :=
    pb.basis.linearIndependent.map' incl hincl
  have hcast : LinearIndependent BinaryField
      (fun i : Fin s => incl (pb.basis (Fin.cast hdim.symm i))) := by
    exact hpb.comp (fun i => Fin.cast hdim.symm i)
      (Equiv.injective (finCongr hdim.symm))
  have hgenval : incl pb.gen = k := by
    simp [incl, pb, IntermediateField.adjoin.powerBasis_gen]
  have hterms (i : Fin s) : incl (pb.basis (Fin.cast hdim.symm i)) = k ^ i.val := by
    rw [pb.basis_eq_pow]
    simp [hgenval]
  simpa only [hterms] using hcast

/-- The Q-conjugated endomorphism has the same first-power independence as
its scalar parameter. -/
theorem actualBalanceGaussian_conjugatePowers_linearIndependent_of_primitive
    {K : Type*} [Field K] [FiniteDimensional BinaryField K]
    [Algebra BinaryField K] {s : Nat}
    (Q : BinaryVector (3 * s) ≃ₗ[BinaryField] FieldTriple K)
    (k : K)
    (hgen : Algebra.adjoin BinaryField ({k} : Set K) = ⊤)
    (hK : Module.finrank BinaryField K = s) :
    LinearIndependent BinaryField
      (fun i : Fin s => (qScalarConjugateLinearMap Q k) ^ i.val) := by
  have hscalar := actualBalanceGaussian_scalarPowers_linearIndependent_of_primitive
    k hgen hK
  have hinj : Function.Injective
      (qScalarConjugateAlgHom Q).toLinearMap := by
    intro a b hab
    apply qScalarConjugateLinearMap_injective Q
    exact hab
  have hmapped := hscalar.map' (qScalarConjugateAlgHom Q).toLinearMap
    (LinearMap.ker_eq_bot'.2 hinj)
  simpa only [Function.comp_apply, map_pow] using hmapped

/-- The first `s` powers of any endomorphism in the Q-scalar range are
linearly independent if its associated scalar is primitive. -/
theorem actualBalanceGaussian_endPowers_linearIndependent_of_primitive
    {K : Type*} [Field K] [FiniteDimensional BinaryField K]
    [Algebra BinaryField K] {s : Nat}
    (Q : BinaryVector (3 * s) ≃ₗ[BinaryField] FieldTriple K)
    (T : Module.End BinaryField (BinaryVector (3 * s)))
    (hT : T ∈ qScalarConjugateEndRange Q)
    (hgen : Algebra.adjoin BinaryField
      ({actualBalanceGaussianQScalarParameter Q T} : Set K) = ⊤)
    (hK : Module.finrank BinaryField K = s) :
    LinearIndependent BinaryField (fun i : Fin s => T ^ i.val) := by
  let k := actualBalanceGaussianQScalarParameter Q T
  have hconj : qScalarConjugateLinearMap Q k = T :=
    actualBalanceGaussianQScalarParameter_spec Q hT
  have hli := actualBalanceGaussian_conjugatePowers_linearIndependent_of_primitive
    Q k (by simpa [k] using hgen) hK
  simpa [hconj]

end CorruptedFieldRecovery
