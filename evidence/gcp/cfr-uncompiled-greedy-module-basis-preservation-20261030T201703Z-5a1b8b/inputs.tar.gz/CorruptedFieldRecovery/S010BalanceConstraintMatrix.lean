import CorruptedFieldRecovery.S010ObservedHiddenBalance
import Mathlib.Tactic

namespace CorruptedFieldRecovery

/-- A row of the finite linear system encoding all four physical balance
forms. The rows retain the actual four sampled tape words and arbitrary
physical input vectors. -/
abbrev ActualBalanceConstraintRow (s : Nat) :=
  Fin 4 × BinaryVector (3 * s) × BinaryVector (3 * s)

/-- The row residual is the left contraction minus the right contraction in
the manuscript's balance equation. -/
def actualBalanceConstraintResidual {s : Nat}
    (A : BinaryTensor (3 * s)) (tape : FiveWordTape s)
    (T : Module.End (ZMod 2) (BinaryVector (3 * s)))
    (row : ActualBalanceConstraintRow s) : ZMod 2 :=
  let (i, x, y) := row
  physicalThirdSlotBilinForm A (tape.1 i) (T x) y -
    physicalThirdSlotBilinForm A (tape.1 i) x (T y)

/-- The actual balance-constraint linear map. Its columns are endomorphisms
of the physical input space, and its rows are the four sampled words paired
with every ordered pair of physical vectors. Its kernel is exactly the space
of endomorphisms satisfying all actual balance equations. -/
def actualBalanceConstraintMap {s : Nat}
    (A : BinaryTensor (3 * s)) (tape : FiveWordTape s) :
    Module.End (ZMod 2) (BinaryVector (3 * s)) →ₗ[ZMod 2]
      (ActualBalanceConstraintRow s → ZMod 2) where
  toFun T := fun row => actualBalanceConstraintResidual A tape T row
  map_add' T S := by
    funext row
    rcases row with ⟨i, x, y⟩
    simp [actualBalanceConstraintResidual, physicalThirdSlotBilinForm, map_add]
  map_smul' a T := by
    funext row
    rcases row with ⟨i, x, y⟩
    simp [actualBalanceConstraintResidual, physicalThirdSlotBilinForm, map_smul]

@[simp] theorem actualBalanceConstraintMap_apply {s : Nat}
    (A : BinaryTensor (3 * s)) (tape : FiveWordTape s)
    (T : Module.End (ZMod 2) (BinaryVector (3 * s)))
    (i : Fin 4) (x y : BinaryVector (3 * s)) :
    actualBalanceConstraintMap A tape T (i, x, y) =
      physicalThirdSlotBilinForm A (tape.1 i) (T x) y -
        physicalThirdSlotBilinForm A (tape.1 i) x (T y) := rfl

/-- The finite Boolean checker evaluates every row of the actual constraint
system. This is a concrete executable check for a supplied endomorphism. -/
def actualBalanceConstraintCheck {s : Nat}
    [Fintype (BinaryVector (3 * s))]
    (A : BinaryTensor (3 * s)) (tape : FiveWordTape s)
    (T : Module.End (ZMod 2) (BinaryVector (3 * s))) : Bool :=
  decide (∀ row : ActualBalanceConstraintRow s,
    actualBalanceConstraintResidual A tape T row = 0)

theorem actualBalanceConstraintCheck_iff {s : Nat}
    [Fintype (BinaryVector (3 * s))]
    (A : BinaryTensor (3 * s)) (tape : FiveWordTape s)
    (T : Module.End (ZMod 2) (BinaryVector (3 * s))) :
    actualBalanceConstraintCheck A tape T = true ↔
      actualFourBilinearBalanced A tape T := by
  constructor
  · intro h i x y
    have hall := of_decide_eq_true h
    have hz := hall (i, x, y)
    exact sub_eq_zero.mp hz
  · intro h
    apply decide_eq_true_iff.mpr
    intro row
    rcases row with ⟨i, x, y⟩
    exact sub_eq_zero.mpr (h i x y)

theorem actualBalanceConstraintMap_ker_iff {s : Nat}
    (A : BinaryTensor (3 * s)) (tape : FiveWordTape s)
    (T : Module.End (ZMod 2) (BinaryVector (3 * s))) :
    T ∈ LinearMap.ker (actualBalanceConstraintMap A tape) ↔
      actualFourBilinearBalanced A tape T := by
  constructor
  · intro h i x y
    have hzero : actualBalanceConstraintMap A tape T = 0 :=
      LinearMap.mem_ker.mp h
    have hz := congrFun hzero (i, x, y)
    rw [actualBalanceConstraintMap_apply] at hz
    exact sub_eq_zero.mp hz
  · intro h
    apply LinearMap.mem_ker.mpr
    apply funext
    intro row
    rcases row with ⟨i, x, y⟩
    rw [actualBalanceConstraintMap_apply]
    exact sub_eq_zero.mpr (h i x y)

/-- Exhaustive finite solution set of the encoded balance matrix. When a
finite enumeration of endomorphisms is supplied, this returns precisely the
balanced endomorphisms; it makes no completeness claim about an unimplemented
fast elimination routine. -/
def actualBalanceConstraintSolutions {s : Nat}
    [Fintype (BinaryVector (3 * s))]
    [Fintype (Module.End (ZMod 2) (BinaryVector (3 * s)))]
    [DecidableEq (Module.End (ZMod 2) (BinaryVector (3 * s)))]
    (A : BinaryTensor (3 * s)) (tape : FiveWordTape s) :
    Finset (Module.End (ZMod 2) (BinaryVector (3 * s))) :=
  Finset.univ.filter fun T => actualBalanceConstraintCheck A tape T

theorem mem_actualBalanceConstraintSolutions_iff {s : Nat}
    [Fintype (BinaryVector (3 * s))]
    [Fintype (Module.End (ZMod 2) (BinaryVector (3 * s)))]
    [DecidableEq (Module.End (ZMod 2) (BinaryVector (3 * s)))]
    (A : BinaryTensor (3 * s)) (tape : FiveWordTape s)
    (T : Module.End (ZMod 2) (BinaryVector (3 * s))) :
    T ∈ actualBalanceConstraintSolutions A tape ↔
      actualFourBilinearBalanced A tape T := by
  rw [actualBalanceConstraintSolutions, Finset.mem_filter, Finset.mem_univ,
    true_and, actualBalanceConstraintCheck_iff]

end CorruptedFieldRecovery