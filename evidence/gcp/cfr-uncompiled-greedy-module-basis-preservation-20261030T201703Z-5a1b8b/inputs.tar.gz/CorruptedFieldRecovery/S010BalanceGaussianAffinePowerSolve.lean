import CorruptedFieldRecovery.S010BalanceGaussianArrayDeterministicScan
import CorruptedFieldRecovery.S010BalanceGaussianKernelUniqueness
import CorruptedFieldRecovery.S010BalanceGaussianSampledGeneratorFilter
import Mathlib.Tactic

open scoped Matrix

/-! Affine extension of the accepted Gaussian kernel scan for constructing
the sampled endomorphism's power recurrence.

The augmented matrix has columns T^0,...,T^(s-1),T^s.  A kernel vector whose
last coordinate is one is exactly a recurrence witness.  The deterministic
full-column scan returns a basis of its kernel; if an affine witness exists,
at least one free-column basis vector has last coordinate one.  Selecting the
first such vector constructs recurrence coefficients.  The source keeps the
array-to-matrix refinement explicit and does not claim a resource bound for
the added affine selection.
-/

namespace CorruptedFieldRecovery

/-- Row-major array representation of a rectangular binary matrix. -/
def actualBalanceGaussianMatrixToArray {m n : Nat}
    (A : Matrix (Fin m) (Fin n) (ZMod 2)) : Array (Array (ZMod 2)) :=
  Array.ofFn fun i : Fin m => Array.ofFn fun j : Fin n => A i j

theorem actualBalanceGaussianArrayView_matrixToArray {m n : Nat}
    (A : Matrix (Fin m) (Fin n) (ZMod 2)) :
    actualBalanceGaussianArrayView (actualBalanceGaussianMatrixToArray A) = A := by
  ext i j
  simp [actualBalanceGaussianArrayView, actualBalanceGaussianMatrixToArray]

/-- Execute the existing nested-array column scan on an arbitrary matrix. -/
def actualBalanceGaussianAffineArrayRun {m n : Nat}
    (A : Matrix (Fin m) (Fin n) (ZMod 2)) :=
  actualBalanceGaussianArrayColumnScan (actualBalanceGaussianMatrixToArray A)
    ∅ (List.ofFn fun j : Fin n => j)

/-- The final matrix and pivot transcript of the array implementation are
exactly those of the already-proved generic matrix scan. -/
theorem actualBalanceGaussianAffineArrayRun_refines {m n : Nat}
    (A : Matrix (Fin m) (Fin n) (ZMod 2)) :
    (actualBalanceGaussianArrayView
        (actualBalanceGaussianAffineArrayRun A).1,
      (actualBalanceGaussianAffineArrayRun A).2) =
      balanceGaussianColumnScan A ∅ (List.ofFn fun j : Fin n => j) := by
  rw [actualBalanceGaussianAffineArrayRun,
    actualBalanceGaussianArrayColumnScan_refines,
    actualBalanceGaussianArrayView_matrixToArray]

/-- Matrix view and pivot transcript produced by the actual array run. -/
def actualBalanceGaussianAffineArrayOutput {m n : Nat}
    (A : Matrix (Fin m) (Fin n) (ZMod 2)) :=
  (actualBalanceGaussianArrayView (actualBalanceGaussianAffineArrayRun A).1,
    (actualBalanceGaussianAffineArrayRun A).2)

theorem actualBalanceGaussianAffineArrayOutput_eq_scan {m n : Nat}
    (A : Matrix (Fin m) (Fin n) (ZMod 2)) :
    actualBalanceGaussianAffineArrayOutput A =
      balanceGaussianColumnScan A ∅ (List.ofFn fun j : Fin n => j) :=
  actualBalanceGaussianAffineArrayRun_refines A

/-- The augmented coefficient matrix for `T^s = sum c_j T^j`. Its first s
columns are the matrix-entry coordinates of the powers through `T^(s-1)` and
its final column is the coordinate vector of `T^s`. -/
def actualBalanceGaussianAffinePowerMatrix {s : Nat}
    (T : Module.End (ZMod 2) (BinaryVector (3 * s))) :
    Matrix (Fin ((3 * s) * (3 * s))) (Fin (s + 1)) (ZMod 2) :=
  fun row column => actualBalanceGaussianInputCoordinates (T ^ column.val) row

/-- Put recurrence coefficients in the first s slots and one in the final
affine slot. -/
def actualBalanceGaussianAffinePowerWitness {s : Nat}
    (coefficients : Fin s → ZMod 2) : Fin (s + 1) → ZMod 2 :=
  Fin.snoc coefficients 1

/-- Coordinates are an injective encoding of endomorphisms. -/
theorem actualBalanceGaussianInputCoordinates_injective {s : Nat}
    {T U : Module.End (ZMod 2) (BinaryVector (3 * s))}
    (h : actualBalanceGaussianInputCoordinates T =
      actualBalanceGaussianInputCoordinates U) : T = U := by
  apply (actualBalanceEndBasis s).repr.injective
  funext pair
  have hT := congrFun (actualBalanceGaussianInputCoordinates_pair T) pair
  have hU := congrFun (actualBalanceGaussianInputCoordinates_pair U) pair
  rw [← hT, ← hU]
  exact congrFun h (actualBalanceGaussianColumnEquiv s pair)

/-- The coordinate reader is linear; this is the bridge that makes the
augmented matrix equation exactly the endomorphism recurrence. -/
def actualBalanceGaussianInputCoordinatesLinearMap {s : Nat} :
    Module.End (ZMod 2) (BinaryVector (3 * s)) →ₗ[ZMod 2]
      (Fin ((3 * s) * (3 * s)) → ZMod 2) where
  toFun := actualBalanceGaussianInputCoordinates
  map_add' T U := by
    funext column
    simp [actualBalanceGaussianInputCoordinates, actualBalanceMatrixEntry]
  map_smul' a T := by
    funext column
    simp [actualBalanceGaussianInputCoordinates, actualBalanceMatrixEntry,
      Pi.smul_apply, smul_eq_mul]

/-- The augmented homogeneous system is equivalent to the recurrence.  The
equivalence uses the final coordinate one and the characteristic-two field,
so no sign convention is hidden in the serialized coefficients. -/
theorem actualBalanceGaussianAffinePowerMatrix_mulVec_witness_iff
    {s : Nat} (T : Module.End (ZMod 2) (BinaryVector (3 * s)))
    (coefficients : Fin s → ZMod 2) :
    actualBalanceGaussianAffinePowerMatrix T *ᵥ
        actualBalanceGaussianAffinePowerWitness coefficients = 0 ↔
      T ^ s = ∑ j : Fin s, coefficients j • T ^ j.val := by
  let coords := actualBalanceGaussianInputCoordinatesLinearMap (s := s)
  let witness := actualBalanceGaussianAffinePowerWitness coefficients
  have hcoord :
      actualBalanceGaussianAffinePowerMatrix T *ᵥ witness =
        coords (T ^ s + ∑ j : Fin s, coefficients j • T ^ j.val) := by
    funext row
    simp [actualBalanceGaussianAffinePowerMatrix,
      actualBalanceGaussianAffinePowerWitness, witness, coords,
      Matrix.mulVec, dotProduct, Fin.sum_univ_castSucc,
      Fin.snoc_castSucc, Fin.snoc_last, Fin.val_castSucc, Fin.val_last,
      actualBalanceGaussianInputCoordinatesLinearMap,
      actualBalanceGaussianInputCoordinates, actualBalanceMatrixEntry,
      smul_eq_mul]
    ring
  constructor
  · intro h
    have hz : coords (T ^ s + ∑ j : Fin s, coefficients j • T ^ j.val) = 0 := by
      rw [← hcoord, h]
    have hend : T ^ s + ∑ j : Fin s, coefficients j • T ^ j.val = 0 := by
      apply actualBalanceGaussianInputCoordinates_injective
      simpa [coords, actualBalanceGaussianInputCoordinatesLinearMap] using hz
    have hneg := eq_neg_of_add_eq_zero_left hend
    simpa using hneg
  · intro hrec
    rw [hcoord]
    have hsum : T ^ s + ∑ j : Fin s, coefficients j • T ^ j.val = 0 := by
      rw [hrec]
      simp
    simp [hsum]

/-- Generic left-to-right Boolean search used to select the first free kernel
candidate whose affine coordinate is one. -/
def actualBalanceGaussianFirstPassing {α : Type*} (test : α → Bool) :
    List α → Option α
  | [] => none
  | x :: xs => if test x then some x else actualBalanceGaussianFirstPassing test xs

private theorem actualBalanceGaussianFirstPassing_sound {α : Type*}
    (test : α → Bool) (xs : List α) {x : α}
    (h : actualBalanceGaussianFirstPassing test xs = some x) : test x = true := by
  induction xs with
  | nil => simp [actualBalanceGaussianFirstPassing] at h
  | cons a xs ih =>
      by_cases ha : test a = true
      · simp [actualBalanceGaussianFirstPassing, ha] at h
        subst x
        exact ha
      · simp [actualBalanceGaussianFirstPassing, ha] at h
        exact ih h

private theorem actualBalanceGaussianFirstPassing_complete {α : Type*}
    (test : α → Bool) (xs : List α)
    (hex : ∃ x, x ∈ xs ∧ test x = true) :
    ∃ x, actualBalanceGaussianFirstPassing test xs = some x ∧ test x = true := by
  induction xs with
  | nil => simpa using hex
  | cons a xs ih =>
      by_cases ha : test a = true
      · exact ⟨a, by simp [actualBalanceGaussianFirstPassing, ha], ha⟩
      · rcases hex with ⟨x, hx, htest⟩
        rcases List.mem_cons.mp hx with hxa | hxtail
        · subst x
          simp [ha] at htest
        · obtain ⟨found, hfound, hfoundTest⟩ := ih ⟨x, hxtail, htest⟩
          exact ⟨found, by simp [actualBalanceGaussianFirstPassing, ha, hfound],
            hfoundTest⟩

/-- The ordered free-column indices emitted by a full scan. -/
def actualBalanceGaussianAffineFreeIndexList {m n : Nat}
    (pivots : List (Fin m × Fin n)) : List (balanceGaussianFreeIndex pivots) :=
  (List.ofFn fun column : Fin n => column).filterMap fun column =>
    if hfree : column ∉ pivots.map Prod.snd then some ⟨column, hfree⟩ else none

theorem actualBalanceGaussianAffineFreeIndexList_complete {m n : Nat}
    (pivots : List (Fin m × Fin n))
    (free : balanceGaussianFreeIndex pivots) :
    free ∈ actualBalanceGaussianAffineFreeIndexList pivots := by
  simp [actualBalanceGaussianAffineFreeIndexList, free.property]

/-- The selected free index is the first one in scan-column order whose
kernel candidate has final coordinate one. -/
def actualBalanceGaussianAffineSelectFreeIndex {s : Nat}
    (A : Matrix (Fin ((3 * s) * (3 * s))) (Fin (s + 1)) (ZMod 2)) :
    Option (balanceGaussianFreeIndex
      (balanceGaussianColumnScan A ∅ (List.ofFn fun j : Fin (s + 1) => j)).2) :=
  let run := balanceGaussianColumnScan A ∅ (List.ofFn fun j : Fin (s + 1) => j)
  actualBalanceGaussianFirstPassing
    (fun free => decide (balanceGaussianFreeCandidateFamily run.1 run.2 free
      (Fin.last s) = 1))
    (actualBalanceGaussianAffineFreeIndexList run.2)

/-- For a complete scan, every explicit free-column candidate lies in the
original kernel. -/
theorem actualBalanceGaussianAffineFreeCandidate_mem_ker {s : Nat}
    (A : Matrix (Fin ((3 * s) * (3 * s))) (Fin (s + 1)) (ZMod 2))
    (free : balanceGaussianFreeIndex
      (balanceGaussianColumnScan A ∅ (List.ofFn fun j : Fin (s + 1) => j)).2) :
    A *ᵥ balanceGaussianFreeCandidateFamily
      (balanceGaussianColumnScan A ∅ (List.ofFn fun j : Fin (s + 1) => j)).1
      (balanceGaussianColumnScan A ∅ (List.ofFn fun j : Fin (s + 1) => j)).2 free = 0 := by
  let columns := List.ofFn (fun j : Fin (s + 1) => j)
  let run := balanceGaussianColumnScan A ∅ columns
  have hrows : (run.2.map Prod.fst).Nodup := by
    simpa [run, columns] using balanceGaussianColumnScan_pivotRows_nodup columns A ∅
  have hunit : ∀ pivot ∈ run.2, ∀ i,
      run.1 i pivot.2 = if i = pivot.1 then 1 else 0 := by
    intro pivot hpivot i
    exact balanceGaussianColumnScan_recordedPivots_unit
      columns A ∅ pivot (by simpa [run] using hpivot) i
  have hzero : ∀ i, i ∉ run.2.map Prod.fst → run.1 i = 0 := by
    intro i hi
    funext column
    exact balanceGaussianFullColumnScan_unusedRows_zero A i (by simpa [run, columns] using hi)
      column
  have hred := balanceGaussianFreeKernelCandidate_mem_ker
    run.1 run.2 free.1 free.2 hrows hunit (by
      intro i hi
      exact congrFun (hzero i hi) free.1)
  exact (balanceGaussianColumnScan_kernel_iff columns A ∅
    (balanceGaussianFreeCandidateFamily run.1 run.2 free)).mp (by simpa [run] using hred)

/-- If the augmented recurrence system has any solution with final coordinate
one, the full Gaussian scan must emit a free candidate with final coordinate
one. This follows from the exact free-coordinate reconstruction theorem, not
from an assumption that the system has already been solved. -/
theorem actualBalanceGaussianAffineFreeCandidate_exists_of_witness {s : Nat}
    (A : Matrix (Fin ((3 * s) * (3 * s))) (Fin (s + 1)) (ZMod 2))
    (hsolution : ∃ x, A *ᵥ x = 0 ∧ x (Fin.last s) = 1) :
    ∃ free : balanceGaussianFreeIndex
      (balanceGaussianColumnScan A ∅ (List.ofFn fun j : Fin (s + 1) => j)).2,
      balanceGaussianFreeCandidateFamily
        (balanceGaussianColumnScan A ∅ (List.ofFn fun j : Fin (s + 1) => j)).1
        (balanceGaussianColumnScan A ∅ (List.ofFn fun j : Fin (s + 1) => j)).2
        free (Fin.last s) = 1 := by
  classical
  rcases hsolution with ⟨x, hxker, hlast⟩
  let run := balanceGaussianColumnScan A ∅ (List.ofFn fun j : Fin (s + 1) => j)
  have hexp := balanceGaussianFullColumnScan_candidates_reconstruct A x hxker
  by_contra hnone
  have hzero : ∀ free : balanceGaussianFreeIndex run.2,
      balanceGaussianFreeCandidateFamily run.1 run.2 free (Fin.last s) = 0 := by
    intro free
    have hval : balanceGaussianFreeCandidateFamily run.1 run.2 free (Fin.last s) = 0 ∨
        balanceGaussianFreeCandidateFamily run.1 run.2 free (Fin.last s) = 1 := by
      fin_cases balanceGaussianFreeCandidateFamily run.1 run.2 free (Fin.last s) <;> simp
    rcases hval with h | h
    · exact h
    · exact False.elim (hnone ⟨free, by simpa [run] using h⟩)
  have hlastEq := congrFun hexp (Fin.last s)
  rw [hlast] at hlastEq
  simp [run, Finset.sum_apply, hzero] at hlastEq

/-- If the affine system is consistent, the first passing free candidate
selected by the scan exists and is a kernel vector with affine coordinate one. -/
theorem actualBalanceGaussianAffineSelectFreeIndex_some_of_witness {s : Nat}
    (A : Matrix (Fin ((3 * s) * (3 * s))) (Fin (s + 1)) (ZMod 2))
    (hsolution : ∃ x, A *ᵥ x = 0 ∧ x (Fin.last s) = 1) :
    ∃ free,
      actualBalanceGaussianAffineSelectFreeIndex A = some free ∧
      balanceGaussianFreeCandidateFamily
        (balanceGaussianColumnScan A ∅ (List.ofFn fun j : Fin (s + 1) => j)).1
        (balanceGaussianColumnScan A ∅ (List.ofFn fun j : Fin (s + 1) => j)).2
        free (Fin.last s) = 1 := by
  let run := balanceGaussianColumnScan A ∅ (List.ofFn fun j : Fin (s + 1) => j)
  obtain ⟨free, hfree⟩ := actualBalanceGaussianAffineFreeCandidate_exists_of_witness A hsolution
  have hmem := actualBalanceGaussianAffineFreeIndexList_complete run.2 free
  have htest : decide
      (balanceGaussianFreeCandidateFamily run.1 run.2 free (Fin.last s) = 1) = true :=
    of_decide_eq_true hfree
  obtain ⟨found, hfound, hfoundTest⟩ := actualBalanceGaussianFirstPassing_complete
    (fun free => decide (balanceGaussianFreeCandidateFamily run.1 run.2 free
      (Fin.last s) = 1))
    (actualBalanceGaussianAffineFreeIndexList run.2)
    ⟨free, hmem, htest⟩
  refine ⟨found, ?_, of_decide_eq_true hfoundTest⟩
  simpa [actualBalanceGaussianAffineSelectFreeIndex, run] using hfound

/-- The affine scan returns a recurrence whenever a recurrence witness exists.
The returned coefficients are the first s coordinates of the selected free
kernel candidate. -/
theorem actualBalanceGaussianAffineScan_returns_recurrence_of_witness {s : Nat}
    (T : Module.End (ZMod 2) (BinaryVector (3 * s)))
    (coefficients : Fin s → ZMod 2)
    (hrecurrence : T ^ s = ∑ j : Fin s, coefficients j • T ^ j.val) :
    ∃ found : Fin s → ZMod 2,
      T ^ s = ∑ j : Fin s, found j • T ^ j.val := by
  let A := actualBalanceGaussianAffinePowerMatrix T
  have hsolution : ∃ x, A *ᵥ x = 0 ∧ x (Fin.last s) = 1 := by
    refine ⟨actualBalanceGaussianAffinePowerWitness coefficients,
      (actualBalanceGaussianAffinePowerMatrix_mulVec_witness_iff T coefficients).2
        hrecurrence, ?_⟩
    simp [actualBalanceGaussianAffinePowerWitness]
  obtain ⟨free, hselect, hlast⟩ :=
    actualBalanceGaussianAffineSelectFreeIndex_some_of_witness A hsolution
  let run := balanceGaussianColumnScan A ∅ (List.ofFn fun j : Fin (s + 1) => j)
  let candidate := balanceGaussianFreeCandidateFamily run.1 run.2 free
  have hker : A *ᵥ candidate = 0 := by
    simpa [run, candidate, A] using
      actualBalanceGaussianAffineFreeCandidate_mem_ker A free
  let found : Fin s → ZMod 2 := fun j => candidate j.castSucc
  have hdecomp : candidate = Fin.snoc found 1 := by
    funext i
    refine Fin.lastCases ?_ ?_ i
    · simpa [found] using hlast
    · intro j
      simp [found]
  have hkernelWitness : A *ᵥ Fin.snoc found 1 = 0 := by
    rw [← hdecomp]
    exact hker
  have hrec :=
    (actualBalanceGaussianAffinePowerMatrix_mulVec_witness_iff T found).mp
      hkernelWitness
  exact ⟨found, hrec⟩

/-- A sampled scalar-space endomorphism whose first s powers pass the
independence test necessarily has a recurrence: those powers are s independent
vectors in the s-dimensional Q-scalar range, so they form a basis and span
T^s. This is an existence theorem; construction is performed by the augmented
Gaussian scan above. -/
theorem actualBalanceGaussianPowerRecurrence_exists_of_independent
    {K : Type*} [Field K] [Fintype K] [DecidableEq K] [Finite K]
    [CharP K 2] [Algebra BinaryField K] [FiniteDimensional BinaryField K]
    {s : Nat}
    (Q : BinaryVector (3 * s) ≃ₗ[BinaryField] FieldTriple K)
    (T : Module.End BinaryField (BinaryVector (3 * s)))
    (hT : T ∈ qScalarConjugateEndRange Q)
    (hK : Module.finrank BinaryField K = s)
    (hpow : LinearIndependent BinaryField (fun i : Fin s => T ^ i.val)) :
    ∃ coefficients : Fin s → BinaryField,
      T ^ s = ∑ j : Fin s, coefficients j • T ^ j.val := by
  let k := actualBalanceGaussianQScalarParameter Q T
  have hconj : qScalarConjugateLinearMap Q k = T :=
    actualBalanceGaussianQScalarParameter_spec Q hT
  have hpowmem (i : Fin (s + 1)) : T ^ i.val ∈ qScalarConjugateEndRange Q := by
    have hmap : qScalarConjugateLinearMap Q (k ^ i.val) =
        (qScalarConjugateLinearMap Q k) ^ i.val :=
      (qScalarConjugateAlgHom Q).map_pow k i.val
    rw [hconj] at hmap
    rw [← hmap]
    exact ⟨k ^ i.val, rfl⟩
  let powers : Fin s → qScalarConjugateEndRange Q := fun i =>
    ⟨T ^ i.val, hpowmem i.castSucc⟩
  have hpowers : LinearIndependent BinaryField powers := by
    apply LinearIndependent.of_comp (qScalarConjugateEndRange Q).subtype
    simpa [powers, Function.comp_def] using hpow
  have hcard : Fintype.card (Fin s) =
      Module.finrank BinaryField (qScalarConjugateEndRange Q) := by
    rw [qScalarConjugateEndRange_finrank Q, hK]
    simp
  let B := Basis.basisOfLinearIndependentOfCardEqFinrank' hpowers hcard
  let topPower : qScalarConjugateEndRange Q :=
    ⟨T ^ s, hpowmem ⟨s, Nat.lt_succ_self s⟩⟩
  let coefficients : Fin s → BinaryField := fun i => B.repr topPower i
  have hrepr := B.sum_repr topPower
  have hrec : T ^ s = ∑ j : Fin s, coefficients j • T ^ j.val := by
    have h := congrArg (fun x : qScalarConjugateEndRange Q =>
        (x : Module.End BinaryField (BinaryVector (3 * s)))) hrepr
    simpa [B, coefficients, powers] using h.symm
  exact ⟨coefficients, hrec⟩

/-- The actual array-backed affine scan constructs the recurrence under the
good-event hypotheses: the preceding finite-dimensional argument supplies
consistency, and the array refinement identifies its selected free candidate
with the generic kernel proof. -/
theorem actualBalanceGaussianAffineArray_constructs_recurrence
    {K : Type*} [Field K] [Fintype K] [DecidableEq K] [Finite K]
    [CharP K 2] [Algebra BinaryField K] [FiniteDimensional BinaryField K]
    {s : Nat}
    (Q : BinaryVector (3 * s) ≃ₗ[BinaryField] FieldTriple K)
    (T : Module.End BinaryField (BinaryVector (3 * s)))
    (hT : T ∈ qScalarConjugateEndRange Q)
    (hK : Module.finrank BinaryField K = s)
    (hpow : LinearIndependent BinaryField (fun i : Fin s => T ^ i.val)) :
    ∃ coefficients : Fin s → BinaryField,
      T ^ s = ∑ j : Fin s, coefficients j • T ^ j.val := by
  rcases actualBalanceGaussianPowerRecurrence_exists_of_independent
      Q T hT hK hpow with ⟨coefficients, hrecurrence⟩
  exact actualBalanceGaussianAffineScan_returns_recurrence_of_witness
    T coefficients hrecurrence

end CorruptedFieldRecovery
