import CorruptedFieldRecovery.S010BalanceGaussianAffineOutput
import CorruptedFieldRecovery.RawFieldArrayPolynomial
import CorruptedFieldRecovery.RawPolynomialIrreducibility
import CorruptedFieldRecovery.RawPhysicalPowerBasis
import CorruptedFieldRecovery.RawPolynomialMaskCompleteness

namespace CorruptedFieldRecovery

open Polynomial

/-! Computable low-endian serialization of the affine Gaussian solver's
recurrence coefficients. The output is exactly s low coefficients followed
by a true leading bit. This draft proves the mask decoder returns the same
polynomial as the recurrence definition; it does not prove that the separate
scalar bits encode the model coefficient c or that the irreducibility filter
accepts the resulting candidate. -/

/-- Serialize the coefficients of the recurrence in low-endian order and
append the monic leading coefficient. This definition uses only the finite
coefficient function and array/list constructors. -/
def actualBalanceGaussianRecurrenceModulusBits {s : Nat}
    (coefficients : Fin s → BinaryField) : RawFieldBits :=
  ((List.ofFn fun j : Fin s => rawCoeffBit (coefficients j)) ++ [true]).toArray

/-- Candidate construction using the computed recurrence modulus and an
explicitly supplied raw scalar encoding. -/
def actualBalanceGaussianCandidateOfRecurrence {s : Nat}
    (coefficients : Fin s → BinaryField) (scalarBits : RawFieldBits) :
    RawFieldCandidate s :=
  ⟨actualBalanceGaussianRecurrenceModulusBits coefficients, scalarBits⟩

/-- The bit list has exactly s low coefficients and one leading bit. -/
theorem actualBalanceGaussianRecurrenceModulusBits_length {s : Nat}
    (coefficients : Fin s → BinaryField) :
    (actualBalanceGaussianRecurrenceModulusBits coefficients).size = s + 1 := by
  simp [actualBalanceGaussianRecurrenceModulusBits]

private theorem rawBoolListPolynomial_append_true (bits : List Bool) :
    rawBoolListPolynomial (bits ++ [true]) =
      rawBoolListPolynomial bits + X ^ bits.length := by
  induction bits with
  | nil => simp [rawBoolListPolynomial]
  | cons bit bits ih =>
      simp only [List.cons_append, rawBoolListPolynomial, List.length_cons]
      rw [ih]
      simp only [pow_succ]
      ring

/-- The low part of the recurrence bit list expands to its coefficient
monomials. -/
private theorem actualBalanceGaussianRecurrenceLowBits_polynomial {s : Nat}
    (coefficients : Fin s → BinaryField) :
    rawBoolListPolynomial (List.ofFn fun j : Fin s =>
      rawCoeffBit (coefficients j)) =
      ∑ j : Fin s, C (coefficients j) * X ^ j.val := by
  rw [rawBoolListPolynomial_ofFn]
  calc
    _ = ∑ j : Fin s, Polynomial.monomial j
          (if rawCoeffBit (coefficients j) then (1 : BinaryField) else 0) := rfl
    _ = ∑ j : Fin s, Polynomial.monomial j (coefficients j) := by
      apply Finset.sum_congr rfl
      intro j hj
      rw [rawCoeffBit_sound]
    _ = ∑ j : Fin s, C (coefficients j) * X ^ j.val := by
      simp_rw [← Polynomial.C_mul_X_pow_eq_monomial]

/-- The actual array mask decodes to the exact recurrence polynomial, not
merely to a polynomial with the same root. -/
theorem actualBalanceGaussianRecurrenceModulusBits_mask_polynomial {s : Nat}
    (coefficients : Fin s → BinaryField) :
    rawMaskPolynomial
        (rawFieldBitsToNat (actualBalanceGaussianRecurrenceModulusBits coefficients)) =
      actualBalanceGaussianRecurrencePolynomial coefficients := by
  rw [← rawFieldArrayPolynomial_eq_mask]
  change rawBoolListPolynomial
      ((List.ofFn fun j : Fin s => rawCoeffBit (coefficients j)) ++ [true]) = _
  rw [rawBoolListPolynomial_append_true,
    actualBalanceGaussianRecurrenceLowBits_polynomial]
  rw [actualBalanceGaussianRecurrencePolynomial]
  simp only [sub_eq_add_neg]
  have hneg : -(∑ j : Fin s, C (coefficients j) * X ^ j.val) =
      ∑ j : Fin s, C (coefficients j) * X ^ j.val := by
    apply Polynomial.ext
    intro d
    simp
  rw [hneg]
  ac_rfl

/-- A candidate built from the recurrence coefficients has the generated
modulus length and the exact decoded modulus polynomial. Scalar-array shape
and nonzeroness remain explicit obligations of the caller. -/
theorem actualBalanceGaussianCandidateOfRecurrence_modulus {s : Nat}
    (coefficients : Fin s → BinaryField) (scalarBits : RawFieldBits) :
    (actualBalanceGaussianCandidateOfRecurrence coefficients scalarBits).modulus.size = s + 1 ∧
      rawMaskPolynomial (rawFieldBitsToNat
        (actualBalanceGaussianCandidateOfRecurrence coefficients scalarBits).modulus) =
        actualBalanceGaussianRecurrencePolynomial coefficients := by
  constructor
  · exact actualBalanceGaussianRecurrenceModulusBits_length coefficients
  · exact actualBalanceGaussianRecurrenceModulusBits_mask_polynomial coefficients

/-- Run the affine solver and, if it returns coefficients, serialize those
coefficients into the raw candidate modulus while retaining the caller's
scalar bit array. -/
def actualBalanceGaussianSerializedRecurrenceCandidate? {s : Nat}
    (T : Module.End BinaryField (BinaryVector (3 * s)))
    (scalarBits : RawFieldBits) : Option (RawFieldCandidate s) :=
  (actualBalanceGaussianAffineRecurrence? T).map
    (fun coefficients => actualBalanceGaussianCandidateOfRecurrence
      coefficients scalarBits)

/-- Conditional filter bridge for the exact serialized solver output. The
returned candidate modulus is constructed from the returned recurrence
coefficients, and the previous sampled-generator theorem then proves the
minimal-polynomial and primitive-element conclusions if the actual shape and
Rabin checks pass. -/
theorem actualBalanceGaussianSerializedRecurrenceCandidate_primitive
    {K : Type*} [Field K] [Fintype K] [DecidableEq K] [Finite K]
    [CharP K 2] [Algebra BinaryField K] [FiniteDimensional BinaryField K]
    {s : Nat}
    (Q : BinaryVector (3 * s) ≃ₗ[BinaryField] FieldTriple K)
    (T : Module.End BinaryField (BinaryVector (3 * s)))
    (hT : T ∈ qScalarConjugateEndRange Q)
    (hK : Module.finrank BinaryField K = s)
    (hpow : LinearIndependent BinaryField (fun i : Fin s => T ^ i.val))
    (scalarBits : RawFieldBits)
    (candidate : RawFieldCandidate s)
    (houtput : actualBalanceGaussianSerializedRecurrenceCandidate? T scalarBits =
      some candidate)
    (hfast : rawFieldCandidateFastCheck candidate = true) :
    ∃ coefficients,
      actualBalanceGaussianAffineRecurrence? T = some coefficients ∧
      actualBalanceGaussianRecurrencePolynomial coefficients =
        minpoly BinaryField (actualBalanceGaussianQScalarParameter Q T) ∧
      Algebra.adjoin BinaryField
        ({actualBalanceGaussianQScalarParameter Q T} : Set K) = ⊤ := by
  have hsolver := actualBalanceGaussianAffineRecurrence?_correct Q T hT hK hpow
  rcases hsolver with ⟨coefficients, hcoeff, hrecurrence⟩
  have hcandidate : candidate =
      actualBalanceGaussianCandidateOfRecurrence coefficients scalarBits := by
    have hmap := houtput
    simp [actualBalanceGaussianSerializedRecurrenceCandidate?, hcoeff] at hmap
    exact hmap.symm
  have hencoded :
      rawMaskPolynomial (rawFieldBitsToNat candidate.modulus) =
        actualBalanceGaussianRecurrencePolynomial coefficients := by
    rw [hcandidate]
    exact (actualBalanceGaussianCandidateOfRecurrence_modulus
      coefficients scalarBits).2
  have hpass : ActualBalanceGaussianGeneratorFilterPass candidate coefficients T := by
    have hfast' : rawFieldCandidateShapeCheck candidate = true ∧
        rawCandidateRabinCheck candidate = true := by
      simpa [rawFieldCandidateFastCheck, Bool.and_eq_true] using hfast
    exact ⟨hpow, hrecurrence, hencoded, hfast'.1, hfast'.2⟩
  have hprimitive := actualBalanceGaussianSampledScalar_primitive_of_filterPass
    Q candidate coefficients T hT hpass hK
  exact ⟨coefficients, hcoeff, hprimitive.1, hprimitive.2.1⟩

end CorruptedFieldRecovery
