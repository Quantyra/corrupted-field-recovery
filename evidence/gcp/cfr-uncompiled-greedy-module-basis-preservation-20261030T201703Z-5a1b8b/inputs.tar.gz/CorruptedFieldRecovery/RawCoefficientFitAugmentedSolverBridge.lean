import CorruptedFieldRecovery.RawCoefficientFitFlattening
import CorruptedFieldRecovery.RawPhysicalPowerBasis
import CorruptedFieldRecovery.RawExecutableQuotient

/-! # Scalar-column semantics and augmented Gaussian input

This draft records the concrete finite-index bridge for the raw fit columns.
All computation uses one-hot `Bool` arrays, row-major raw coefficients, and
the existing deterministic nested-array Gaussian scan. The semantic
polynomial decoder is used only in proof statements; it is not called by the
fit-matrix or solver definitions.

The ordered-triple flattening deliberately uses all `n^3` triples and zero
padding, avoiding a chosen finite-type enumeration of increasing triples.
This costs a polynomial factor only. The remaining solver gap is to extract a
last-coordinate-one free-kernel candidate from the scan when the augmented
system is consistent, then prove consistency for the manuscript's model
inputs.
-/

namespace CorruptedFieldRecovery

/-- The natural-number mask represented by the one-hot scalar bit array.
This is the exact target for the little-endian interpretation theorem below.
-/
def rawUnitScalarMask (s : Nat) (j : Fin s) : Nat := 2 ^ j.val

/-- Little-endian bit-list interpretation equals the weighted sum of its
finite coordinates. This proof is a pure list/Fin indexing identity. -/
theorem rawBitsToNat_ofFn_weightedSum {s : Nat} (bits : Fin s → Bool) :
    rawBitsToNat (List.ofFn bits) =
      ∑ i : Fin s, if bits i then 2 ^ i.val else 0 := by
  induction s with
  | zero => simp [rawBitsToNat]
  | succ s ih =>
      rw [List.ofFn_succ]
      simp only [rawBitsToNat]
      rw [ih]
      rw [Fin.sum_univ_succ]
      simp only [Fin.val_zero, pow_zero]
      have htail :
          2 * (∑ i : Fin s, if bits i.succ then 2 ^ i.val else 0) =
            ∑ i : Fin s, if bits i.succ then 2 ^ i.succ.val else 0 := by
        rw [Finset.mul_sum]
        apply Finset.sum_congr rfl
        intro i hi
        by_cases hb : bits i.succ
        · simp [hb, Fin.val_succ, Nat.pow_succ]
          ring
        · simp [hb]
      rw [htail]
      simp

/-- The serialized one-hot scalar array has exactly mask `2^j`. This removes
the first semantic gap between a trace-fit coefficient column and the
quotient-field basis element `X^j`. -/
theorem rawUnitScalarBits_toNat {s : Nat} (j : Fin s) :
    rawFieldBitsToNat (rawUnitScalarBits s j) = rawUnitScalarMask s j := by
  unfold rawFieldBitsToNat rawUnitScalarMask rawUnitScalarBits
  simp only [Array.toList_toArray]
  rw [rawBitsToNat_ofFn_weightedSum]
  rw [Finset.sum_eq_single j]
  · simp
  · intro i hi hij
    simp [hij]
  · intro h
    exact False.elim (h (Finset.mem_univ j))

/-- The proof-only polynomial denoted by the one-hot bits is exactly the
power-basis monomial `X^j`. This uses the already established bit-mask and
array-polynomial bridges. -/
theorem rawUnitScalarBits_polynomial {s : Nat} (j : Fin s) :
    rawFieldArrayPolynomial (rawUnitScalarBits s j) = Polynomial.X ^ j.val := by
  rw [rawFieldArrayPolynomial_eq_mask, rawUnitScalarBits_toNat]
  have hone : rawMaskPolynomial 1 = (1 : Polynomial (ZMod 2)) := by
    rw [rawMaskPolynomial_eq_of_ne_zero 1 (by decide)]
    simp [rawMaskPolynomial_zero]
  have hpow := rawMaskPolynomial_mul_pow_two 1 j.val
  simpa [rawUnitScalarMask, hone] using hpow

/-- The flattened all-triples row order is the existing `finProdFinEquiv`
order, with the pair `(i,j)` as the major coordinate and `k` as the minor
coordinate. -/
theorem rawOrderedTripleFinEquiv_apply (n : Nat)
    (triple : (Fin n × Fin n) × Fin n) :
    rawOrderedTripleFinEquiv n triple =
      finProdFinEquiv (finProdFinEquiv triple.1, triple.2) := by
  rfl

/-- A checked row-major input array returns its decoded increasing
coefficient at the flattened row. Invalid rows are intentionally zero. -/
theorem rawCoefficientFitFiniteRhs_validRow {s : Nat}
    (raw : RawCoefficientArray)
    (row : Fin (((3 * s) * (3 * s)) * (3 * s)))
    (hrow : rawOrderedTripleIncreasing (rawOrderedTripleAt row)) :
    rawCoefficientFitFiniteRhs raw row =
      rawCoefficientFitRhs raw
        (rawOrderedTripleAsIncreasing (rawOrderedTripleAt row) hrow) := by
  simp [rawCoefficientFitFiniteRhs, hrow]

/-- For raw arrays with the dense shape required by `RawCertificate`, the
RHS finite row at every increasing triple is its row-major serialized input
bit. This specializes the existing raw-array decoder correspondence. -/
theorem rawCoefficientFitFiniteRhs_validRow_eq_serialized {s : Nat}
    (raw : RawCoefficientArray)
    (row : Fin (((3 * s) * (3 * s)) * (3 * s)))
    (hrow : rawOrderedTripleIncreasing (rawOrderedTripleAt row)) :
    rawCoefficientFitFiniteRhs raw row =
      raw[(rawCoefficientOffset (3 * s)
          (rawOrderedTripleAt row).1.1
          (rawOrderedTripleAt row).1.2
          (rawOrderedTripleAt row).2)]! := by
  rw [rawCoefficientFitFiniteRhs_validRow]
  rfl

/-- Computable row-major `Matrix` serialization for arbitrary rectangular
finite matrices. -/
def rawFitMatrixToArray {m n : Nat}
    (matrix : Matrix (Fin m) (Fin n) (ZMod 2)) : Array (Array (ZMod 2)) :=
  Array.ofFn fun i : Fin m => Array.ofFn fun j : Fin n => matrix i j

/-- Exact matrix view of the row-major array serializer. -/
theorem rawFitMatrixToArray_view {m n : Nat}
    (matrix : Matrix (Fin m) (Fin n) (ZMod 2)) :
    actualBalanceGaussianArrayView (rawFitMatrixToArray matrix) = matrix := by
  ext i j
  simp [actualBalanceGaussianArrayView, rawFitMatrixToArray]

/-- The augmented coefficient-fit system is run through the existing
deterministic full-column array scan. The scan itself performs no search over
coefficient vectors. -/
def rawCoefficientFitDeterministicScan {s d : Nat}
    (candidate : RawFieldCandidate s)
    (hcheck : rawFieldCandidateCheck candidate = true)
    (inverse : RawCoordinateMatrix) (supportMatrix : RawBinaryArray)
    (raw : RawCoefficientArray) :=
  let matrix := rawCoefficientFitAugmentedMatrix candidate hcheck inverse
    supportMatrix raw
  actualBalanceGaussianArrayColumnScan (rawFitMatrixToArray matrix) ∅
    (List.ofFn fun column : Fin ((s + (d * d) * d) + 1) => column)

/-- The actual array execution refines the deterministic generic matrix scan
on precisely the flattened augmented fit matrix. -/
theorem rawCoefficientFitDeterministicScan_refines {s d : Nat}
    (candidate : RawFieldCandidate s)
    (hcheck : rawFieldCandidateCheck candidate = true)
    (inverse : RawCoordinateMatrix) (supportMatrix : RawBinaryArray)
    (raw : RawCoefficientArray) :
    (actualBalanceGaussianArrayView
        (rawCoefficientFitDeterministicScan candidate hcheck inverse supportMatrix raw).1,
      (rawCoefficientFitDeterministicScan candidate hcheck inverse supportMatrix raw).2) =
      balanceGaussianColumnScan
        (rawCoefficientFitAugmentedMatrix candidate hcheck inverse supportMatrix raw)
        ∅ (List.ofFn fun column : Fin ((s + (d * d) * d) + 1) => column) := by
  unfold rawCoefficientFitDeterministicScan
  rw [actualBalanceGaussianArrayColumnScan_refines,
    rawFitMatrixToArray_view]

/-- The exact affine-solution theorem still required after this flattening:
the coefficient fit has a solution iff the augmented matrix kernel contains a
vector whose last coordinate is one. The executable scan refines that matrix,
but a separate free-kernel-basis extraction theorem is required to turn this
criterion into a returned coefficient array. -/
def RawCoefficientFitAugmentedConsistencyTarget {s d : Nat}
    (candidate : RawFieldCandidate s)
    (hcheck : rawFieldCandidateCheck candidate = true)
    (inverse : RawCoordinateMatrix) (supportMatrix : RawBinaryArray)
    (raw : RawCoefficientArray) : Prop :=
  RawCoefficientFitAffineSolution candidate hcheck inverse supportMatrix raw ↔
    ∃ x : Fin ((s + (d * d) * d) + 1) → ZMod 2,
      rawCoefficientFitAugmentedMatrix candidate hcheck inverse supportMatrix raw
          *ᵥ x = 0 ∧ x (Fin.last (s + (d * d) * d)) = 1

end CorruptedFieldRecovery
