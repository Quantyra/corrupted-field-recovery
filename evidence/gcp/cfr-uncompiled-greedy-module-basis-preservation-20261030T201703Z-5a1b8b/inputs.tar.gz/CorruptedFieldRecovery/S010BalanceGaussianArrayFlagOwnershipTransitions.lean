import CorruptedFieldRecovery.S010BalanceGaussianArrayFlagPeakOwnership

namespace CorruptedFieldRecovery

/-- Counter state for an abstract control-flow execution of the recursive
flag scan. `selectedPivots` counts successful selector outcomes; each is either
still waiting to cons its transcript entry (`pendingTranscriptFrames`) or has
already been emitted (`transcriptNodes`). `completedPivots` counts finished
matrix/flag updates. -/
structure ActualBalanceGaussianFlagOwnershipMachineState where
  phase : ActualBalanceGaussianFlagOwnershipPhase
  columnsRemaining : Nat
  completedPivots : Nat
  selectedPivots : Nat
  totalPivots : Nat
  pendingTranscriptFrames : Nat
  transcriptNodes : Nat
  deriving DecidableEq, Repr

/-- Initial abstract state for a scan with `k` columns and `p` successful
selector outcomes. The value `p` is supplied from the corresponding complete
instrumented scan; it is not computed by this ownership machine. -/
def actualBalanceGaussianFlagOwnershipInitial
    (k p : Nat) : ActualBalanceGaussianFlagOwnershipMachineState :=
  { phase := .selector
    columnsRemaining := k
    completedPivots := 0
    selectedPivots := 0
    totalPivots := p
    pendingTranscriptFrames := 0
    transcriptNodes := 0 }

/-- Actual selector-outcome projection of the recursive flag scan. Each
column contributes `false` exactly when the source selector returns `none`,
and `true` exactly when it returns a pivot row; the recursive inputs are the
same updated arrays as in `actualBalanceGaussianFlagColumnScan`. -/
def actualBalanceGaussianFlagPivotDecisionSequence {m n : Nat}
    (cells : Array (Array (ZMod 2))) (flags : Array Bool) :
    List (Fin n) → List Bool
  | [] => []
  | column :: columns =>
      match actualBalanceGaussianFlagFirstUnusedPivotRow cells flags column with
      | none => false :: actualBalanceGaussianFlagPivotDecisionSequence
          cells flags columns
      | some row => true :: actualBalanceGaussianFlagPivotDecisionSequence
          (actualBalanceGaussianArrayPivotRow cells row column)
          (actualBalanceGaussianSetUsedFlag flags row) columns

def actualBalanceGaussianFlagDecisionPivotCount (decisions : List Bool) : Nat :=
  (decisions.filter id).length

theorem actualBalanceGaussianFlagPivotDecisionSequence_length
    {m n : Nat} (cells : Array (Array (ZMod 2))) (flags : Array Bool)
    (columns : List (Fin n)) :
    (actualBalanceGaussianFlagPivotDecisionSequence cells flags columns).length =
      columns.length := by
  induction columns generalizing cells flags with
  | nil => rfl
  | cons column columns ih =>
      cases hpivot : actualBalanceGaussianFlagFirstUnusedPivotRow
          cells flags column with
      | none =>
          simp [actualBalanceGaussianFlagPivotDecisionSequence, hpivot, ih]
      | some row =>
          simp [actualBalanceGaussianFlagPivotDecisionSequence, hpivot, ih]

/-- The number of true decisions in the actual selector projection equals
the recursive scan's pivot transcript length. This supplies the successful
pivot total used as the ownership machine's `totalPivots` parameter. -/
theorem actualBalanceGaussianFlagPivotDecisionSequence_count_eq_scanPivots
    {m n : Nat} (cells : Array (Array (ZMod 2))) (flags : Array Bool)
    (columns : List (Fin n)) :
    actualBalanceGaussianFlagDecisionPivotCount
      (actualBalanceGaussianFlagPivotDecisionSequence cells flags columns) =
        (actualBalanceGaussianFlagColumnScan cells flags columns).2.length := by
  induction columns generalizing cells flags with
  | nil => rfl
  | cons column columns ih =>
      cases hpivot : actualBalanceGaussianFlagFirstUnusedPivotRow
          cells flags column with
      | none =>
          simp [actualBalanceGaussianFlagDecisionPivotCount,
            actualBalanceGaussianFlagPivotDecisionSequence,
            actualBalanceGaussianFlagColumnScan, hpivot, ih]
      | some row =>
          simp [actualBalanceGaussianFlagDecisionPivotCount,
            actualBalanceGaussianFlagPivotDecisionSequence,
            actualBalanceGaussianFlagColumnScan, hpivot, ih]

/-- Counter invariant for the phase machine. Each chosen pivot contributes
one to `selectedPivots`; while descending the recursion it remains pending,
and during return it moves from pending frames to transcript cons cells. -/
def ActualBalanceGaussianFlagOwnershipMachineState.Invariant
    (state : ActualBalanceGaussianFlagOwnershipMachineState) : Prop :=
  state.completedPivots ≤ state.selectedPivots ∧
    state.selectedPivots ≤ state.totalPivots ∧
    state.pendingTranscriptFrames + state.transcriptNodes =
      state.selectedPivots ∧
    (match state.phase with
      | .selector => state.completedPivots = state.selectedPivots
      | .matrixRebuild => state.selectedPivots = state.completedPivots + 1
      | .flagRebuild => state.selectedPivots = state.completedPivots + 1
      | .recursiveCall => state.completedPivots = state.selectedPivots
      | .returnPhase => state.completedPivots = state.selectedPivots)

/-- One source-control transition. `skipColumn` is a selector result of none.
`selectPivot` is a selector result of some row and consumes that column. The
three update/call transitions model matrix rebuilding, flag rebuilding, and
recursive descent. The return transitions cons one transcript entry per
pending pivot. Selector outcomes are abstract inputs here: this relation does
not yet carry array values or prove which branch the actual selector takes. -/
inductive ActualBalanceGaussianFlagOwnershipStep :
    ActualBalanceGaussianFlagOwnershipMachineState →
      ActualBalanceGaussianFlagOwnershipMachineState → Prop where
  | skipColumn (r selected total pending transcript remaining : Nat) :
      ActualBalanceGaussianFlagOwnershipStep
        { phase := .selector
          columnsRemaining := remaining + 1
          completedPivots := r
          selectedPivots := selected
          totalPivots := total
          pendingTranscriptFrames := pending
          transcriptNodes := transcript }
        { phase := .selector
          columnsRemaining := remaining
          completedPivots := r
          selectedPivots := selected
          totalPivots := total
          pendingTranscriptFrames := pending
          transcriptNodes := transcript }
  | selectPivot (r selected total pending transcript remaining : Nat)
      (hcomplete : r = selected) (hfresh : selected < total) :
      ActualBalanceGaussianFlagOwnershipStep
        { phase := .selector
          columnsRemaining := remaining + 1
          completedPivots := r
          selectedPivots := selected
          totalPivots := total
          pendingTranscriptFrames := pending
          transcriptNodes := transcript }
        { phase := .matrixRebuild
          columnsRemaining := remaining
          completedPivots := r
          selectedPivots := selected + 1
          totalPivots := total
          pendingTranscriptFrames := pending + 1
          transcriptNodes := transcript }
  | matrixRebuilt (remaining r selected total pending transcript : Nat) :
      ActualBalanceGaussianFlagOwnershipStep
        { phase := .matrixRebuild
          columnsRemaining := remaining
          completedPivots := r
          selectedPivots := selected
          totalPivots := total
          pendingTranscriptFrames := pending
          transcriptNodes := transcript }
        { phase := .flagRebuild
          columnsRemaining := remaining
          completedPivots := r
          selectedPivots := selected
          totalPivots := total
          pendingTranscriptFrames := pending
          transcriptNodes := transcript }
  | flagsRebuilt (remaining r selected total pending transcript : Nat)
      (hactive : r + 1 = selected) :
      ActualBalanceGaussianFlagOwnershipStep
        { phase := .flagRebuild
          columnsRemaining := remaining
          completedPivots := r
          selectedPivots := selected
          totalPivots := total
          pendingTranscriptFrames := pending
          transcriptNodes := transcript }
        { phase := .recursiveCall
          columnsRemaining := remaining
          completedPivots := r + 1
          selectedPivots := selected
          totalPivots := total
          pendingTranscriptFrames := pending
          transcriptNodes := transcript }
  | recursiveCallEntered (remaining completed selected total pending transcript : Nat) :
      ActualBalanceGaussianFlagOwnershipStep
        { phase := .recursiveCall
          columnsRemaining := remaining
          completedPivots := completed
          selectedPivots := selected
          totalPivots := total
          pendingTranscriptFrames := pending
          transcriptNodes := transcript }
        { phase := .selector
          columnsRemaining := remaining
          completedPivots := completed
          selectedPivots := selected
          totalPivots := total
          pendingTranscriptFrames := pending
          transcriptNodes := transcript }
  | scanEnded (completed selected total pending transcript : Nat)
      (hfinished : completed = selected) :
      ActualBalanceGaussianFlagOwnershipStep
        { phase := .selector
          columnsRemaining := 0
          completedPivots := completed
          selectedPivots := selected
          totalPivots := total
          pendingTranscriptFrames := pending
          transcriptNodes := transcript }
        { phase := .returnPhase
          columnsRemaining := 0
          completedPivots := completed
          selectedPivots := selected
          totalPivots := total
          pendingTranscriptFrames := pending
          transcriptNodes := transcript }
  | transcriptEmitted (completed selected total pending transcript : Nat) :
      ActualBalanceGaussianFlagOwnershipStep
        { phase := .returnPhase
          columnsRemaining := 0
          completedPivots := completed
          selectedPivots := selected
          totalPivots := total
          pendingTranscriptFrames := pending + 1
          transcriptNodes := transcript }
        { phase := .returnPhase
          columnsRemaining := 0
          completedPivots := completed
          selectedPivots := selected
          totalPivots := total
          pendingTranscriptFrames := pending
          transcriptNodes := transcript + 1 }

/-- Reflexive-transitive reachability for the ownership control machine. -/
inductive ActualBalanceGaussianFlagOwnershipReachable :
    ActualBalanceGaussianFlagOwnershipMachineState →
      ActualBalanceGaussianFlagOwnershipMachineState → Prop where
  | refl (state) : ActualBalanceGaussianFlagOwnershipReachable state state
  | oneStep {start finish}
      (hstep : ActualBalanceGaussianFlagOwnershipStep start finish) :
      ActualBalanceGaussianFlagOwnershipReachable start finish
  | trans {start middle finish}
      (hfirst : ActualBalanceGaussianFlagOwnershipReachable start middle)
      (hsecond : ActualBalanceGaussianFlagOwnershipReachable middle finish) :
      ActualBalanceGaussianFlagOwnershipReachable start finish

theorem actualBalanceGaussianFlagOwnershipStep_preservesInvariant
    {before after : ActualBalanceGaussianFlagOwnershipMachineState}
    (hstep : ActualBalanceGaussianFlagOwnershipStep before after)
    (hinv : before.Invariant) : after.Invariant := by
  cases hstep <;> simp_all [ActualBalanceGaussianFlagOwnershipMachineState.Invariant] <;> omega

theorem actualBalanceGaussianFlagOwnershipReachable_invariant
    {start finish : ActualBalanceGaussianFlagOwnershipMachineState}
    (hreach : ActualBalanceGaussianFlagOwnershipReachable start finish)
    (hstart : start.Invariant) : finish.Invariant := by
  induction hreach with
  | refl state => exact hstart
  | oneStep hstep =>
      exact actualBalanceGaussianFlagOwnershipStep_preservesInvariant hstep hstart
  | trans hfirst hsecond ihfirst ihsecond =>
      exact ihsecond (ihfirst hstart)

theorem actualBalanceGaussianFlagOwnershipInitial_invariant (k p : Nat) :
    (actualBalanceGaussianFlagOwnershipInitial k p).Invariant := by
  simp [actualBalanceGaussianFlagOwnershipInitial,
    ActualBalanceGaussianFlagOwnershipMachineState.Invariant]

/-- Returning from the recursive call emits one transcript cons for each
pending successful-pivot frame. The transition path accounts for the output
list nodes while the ancestor matrix/flag snapshots are still reachable. -/
theorem actualBalanceGaussianFlagOwnershipUnwind
    (completed selected total pending transcript : Nat)
    (hframes : pending + transcript = selected) :
    ActualBalanceGaussianFlagOwnershipReachable
      { phase := .returnPhase
        columnsRemaining := 0
        completedPivots := completed
        selectedPivots := selected
        totalPivots := total
        pendingTranscriptFrames := pending
        transcriptNodes := transcript }
      { phase := .returnPhase
        columnsRemaining := 0
        completedPivots := completed
        selectedPivots := selected
        totalPivots := total
        pendingTranscriptFrames := 0
        transcriptNodes := selected } := by
  induction pending generalizing transcript with
  | zero =>
      have htrans : transcript = selected := by simpa using hframes
      subst transcript
      exact ActualBalanceGaussianFlagOwnershipReachable.refl _
  | succ pending ih =>
      have hframes' : pending + (transcript + 1) = selected := by omega
      let start : ActualBalanceGaussianFlagOwnershipMachineState :=
        { phase := .returnPhase
          columnsRemaining := 0
          completedPivots := completed
          selectedPivots := selected
          totalPivots := total
          pendingTranscriptFrames := pending + 1
          transcriptNodes := transcript }
      let next : ActualBalanceGaussianFlagOwnershipMachineState :=
        { start with
          pendingTranscriptFrames := pending
          transcriptNodes := transcript + 1 }
      have hstep : ActualBalanceGaussianFlagOwnershipStep start next := by
        exact ActualBalanceGaussianFlagOwnershipStep.transcriptEmitted
          completed selected total pending transcript
      have htail := ih (transcript + 1) hframes'
      simpa [start, next] using
        ActualBalanceGaussianFlagOwnershipReachable.trans
          (ActualBalanceGaussianFlagOwnershipReachable.oneStep hstep) htail

/-- The actual outcome list drives a path through the abstract ownership
machine. This scheduler consumes one Boolean per column. A true outcome passes
through the matrix/flag rebuild and recursive-call phases; false consumes the
column directly. `hcount` states that the number of true outcomes plus pivots
already selected equals the scan's final pivot total. -/
theorem actualBalanceGaussianFlagOwnershipSchedule
    (decisions : List Bool) (completed selected total pending transcript : Nat)
    (hcomplete : completed = selected)
    (hcount : actualBalanceGaussianFlagDecisionPivotCount decisions + selected = total)
    (hframes : pending + transcript = selected) :
    ActualBalanceGaussianFlagOwnershipReachable
      { phase := .selector
        columnsRemaining := decisions.length
        completedPivots := completed
        selectedPivots := selected
        totalPivots := total
        pendingTranscriptFrames := pending
        transcriptNodes := transcript }
      { phase := .returnPhase
        columnsRemaining := 0
        completedPivots := completed + actualBalanceGaussianFlagDecisionPivotCount decisions
        selectedPivots := selected + actualBalanceGaussianFlagDecisionPivotCount decisions
        totalPivots := total
        pendingTranscriptFrames := 0
        transcriptNodes := selected + actualBalanceGaussianFlagDecisionPivotCount decisions } := by
  induction decisions generalizing completed selected total pending with
  | nil =>
      have hstep : ActualBalanceGaussianFlagOwnershipStep
          { phase := .selector
            columnsRemaining := 0
            completedPivots := completed
            selectedPivots := selected
            totalPivots := total
            pendingTranscriptFrames := pending
            transcriptNodes := transcript }
          { phase := .returnPhase
            columnsRemaining := 0
            completedPivots := completed
            selectedPivots := selected
            totalPivots := total
            pendingTranscriptFrames := pending
            transcriptNodes := transcript } :=
        .scanEnded completed selected total pending transcript hcomplete
      have hscanEnd := ActualBalanceGaussianFlagOwnershipReachable.oneStep hstep
      have hunwind := actualBalanceGaussianFlagOwnershipUnwind
        completed selected total pending transcript hframes
      simpa [actualBalanceGaussianFlagDecisionPivotCount] using
        ActualBalanceGaussianFlagOwnershipReachable.trans hscanEnd hunwind
  | cons decision decisions ih =>
      cases decision with
      | false =>
          have hcount' :
              actualBalanceGaussianFlagDecisionPivotCount decisions + selected = total := by
            simpa [actualBalanceGaussianFlagDecisionPivotCount] using hcount
          let start : ActualBalanceGaussianFlagOwnershipMachineState :=
            { phase := .selector
              columnsRemaining := (false :: decisions).length
              completedPivots := completed
              selectedPivots := selected
              totalPivots := total
              pendingTranscriptFrames := pending
              transcriptNodes := transcript }
          let next : ActualBalanceGaussianFlagOwnershipMachineState :=
            { phase := .selector
              columnsRemaining := decisions.length
              completedPivots := completed
              selectedPivots := selected
              totalPivots := total
              pendingTranscriptFrames := pending
              transcriptNodes := transcript }
          have hstep : ActualBalanceGaussianFlagOwnershipStep start next := by
            simpa [start, next, List.length] using
              (ActualBalanceGaussianFlagOwnershipStep.skipColumn
                completed selected total pending transcript decisions.length)
          have htail := ih completed selected total pending transcript
            hcomplete hcount' hframes
          simpa [start, next, actualBalanceGaussianFlagDecisionPivotCount,
            List.length] using
            ActualBalanceGaussianFlagOwnershipReachable.trans
              (ActualBalanceGaussianFlagOwnershipReachable.oneStep hstep) htail
      | true =>
          have hcount' :
              actualBalanceGaussianFlagDecisionPivotCount decisions + (selected + 1) = total := by
            have hcount'' :
                actualBalanceGaussianFlagDecisionPivotCount decisions + 1 + selected = total := by
              simpa [actualBalanceGaussianFlagDecisionPivotCount] using hcount
            omega
          have hfresh : selected < total := by omega
          have hcomplete' : completed + 1 = selected + 1 := by omega
          have hframes' : pending + 1 + transcript = selected + 1 := by omega
          let start : ActualBalanceGaussianFlagOwnershipMachineState :=
            { phase := .selector
              columnsRemaining := (true :: decisions).length
              completedPivots := completed
              selectedPivots := selected
              totalPivots := total
              pendingTranscriptFrames := pending
              transcriptNodes := transcript }
          let chosen : ActualBalanceGaussianFlagOwnershipMachineState :=
            { phase := .matrixRebuild
              columnsRemaining := decisions.length
              completedPivots := completed
              selectedPivots := selected + 1
              totalPivots := total
              pendingTranscriptFrames := pending + 1
              transcriptNodes := transcript }
          let matrixDone : ActualBalanceGaussianFlagOwnershipMachineState :=
            { chosen with phase := .flagRebuild }
          let flagsDone : ActualBalanceGaussianFlagOwnershipMachineState :=
            { matrixDone with phase := .recursiveCall,
              completedPivots := completed + 1 }
          let child : ActualBalanceGaussianFlagOwnershipMachineState :=
            { flagsDone with phase := .selector }
          have hchoose : ActualBalanceGaussianFlagOwnershipStep start chosen := by
            simpa [start, chosen, List.length] using
              (ActualBalanceGaussianFlagOwnershipStep.selectPivot
                completed selected total pending transcript decisions.length
                hcomplete hfresh)
          have hmatrix : ActualBalanceGaussianFlagOwnershipStep chosen matrixDone := by
            exact ActualBalanceGaussianFlagOwnershipStep.matrixRebuilt
              decisions.length completed (selected + 1) total (pending + 1) transcript
          have hflags : ActualBalanceGaussianFlagOwnershipStep matrixDone flagsDone := by
            exact ActualBalanceGaussianFlagOwnershipStep.flagsRebuilt
              decisions.length completed (selected + 1) total (pending + 1) transcript
              hcomplete'
          have hcall : ActualBalanceGaussianFlagOwnershipStep flagsDone child := by
            exact ActualBalanceGaussianFlagOwnershipStep.recursiveCallEntered
              decisions.length (completed + 1) (selected + 1) total
              (pending + 1) transcript
          have htail := ih (completed + 1) (selected + 1) total
            (pending + 1) transcript hcomplete' hcount' hframes'
          have hpath : ActualBalanceGaussianFlagOwnershipReachable start child := by
            exact ActualBalanceGaussianFlagOwnershipReachable.trans
              (ActualBalanceGaussianFlagOwnershipReachable.oneStep hchoose)
              (ActualBalanceGaussianFlagOwnershipReachable.trans
                (ActualBalanceGaussianFlagOwnershipReachable.oneStep hmatrix)
                (ActualBalanceGaussianFlagOwnershipReachable.trans
                  (ActualBalanceGaussianFlagOwnershipReachable.oneStep hflags)
                  (ActualBalanceGaussianFlagOwnershipReachable.oneStep hcall)))
          simpa [start, child, flagsDone, matrixDone, chosen,
            actualBalanceGaussianFlagDecisionPivotCount, List.length,
            Nat.add_assoc] using
            ActualBalanceGaussianFlagOwnershipReachable.trans hpath htail

/-- The actual selector-outcome projection drives a complete path in the
ownership machine, with `totalPivots` taken from the actual recursive scan's
transcript length. Thus every phase along this control projection satisfies
the machine invariant and the conditional peak-slot theorem. This is a source
control-flow correspondence; it is not Lean evaluator memory coverage. -/
theorem actualBalanceGaussianFlagOwnershipPath_ofScan
    {m n : Nat} (cells : Array (Array (ZMod 2))) (flags : Array Bool)
    (columns : List (Fin n)) :
    ActualBalanceGaussianFlagOwnershipReachable
      (actualBalanceGaussianFlagOwnershipInitial columns.length
        ((actualBalanceGaussianFlagColumnScan cells flags columns).2.length))
      { phase := .returnPhase
        columnsRemaining := 0
        completedPivots := (actualBalanceGaussianFlagColumnScan
          cells flags columns).2.length
        selectedPivots := (actualBalanceGaussianFlagColumnScan
          cells flags columns).2.length
        totalPivots := (actualBalanceGaussianFlagColumnScan
          cells flags columns).2.length
        pendingTranscriptFrames := 0
        transcriptNodes := (actualBalanceGaussianFlagColumnScan
          cells flags columns).2.length } := by
  let decisions := actualBalanceGaussianFlagPivotDecisionSequence
    cells flags columns
  let p := (actualBalanceGaussianFlagColumnScan cells flags columns).2.length
  have hlen : decisions.length = columns.length := by
    exact actualBalanceGaussianFlagPivotDecisionSequence_length cells flags columns
  have hcount : actualBalanceGaussianFlagDecisionPivotCount decisions = p := by
    exact actualBalanceGaussianFlagPivotDecisionSequence_count_eq_scanPivots
      cells flags columns
  have hpath := actualBalanceGaussianFlagOwnershipSchedule
    decisions 0 0 p 0 0 rfl (by simpa [hcount]) rfl
  simpa [decisions, p, actualBalanceGaussianFlagOwnershipInitial, hlen,
    hcount] using hpath

/-- Convert a reachable phase into the live-slot state used by the peak model.
Its phase-specific matrix/flag version counts are set by the ownership
functions in `S010BalanceGaussianArrayFlagPeakOwnership`. -/
def ActualBalanceGaussianFlagOwnershipMachineState.toOwnershipState
    (state : ActualBalanceGaussianFlagOwnershipMachineState) :
    ActualBalanceGaussianFlagOwnershipState :=
  { phase := state.phase
    completedPivots := state.completedPivots
    totalPivots := state.totalPivots
    transcriptNodes := state.transcriptNodes }

/-- Every reachable control state stays below the peak-slot expression under
the source ownership model. `selectedPivots` and pending frames establish that
the transcript count is bounded by the final successful-pivot count. -/
theorem actualBalanceGaussianFlagOwnershipReachable_liveSlots_le
    {start finish : ActualBalanceGaussianFlagOwnershipMachineState}
    (hreach : ActualBalanceGaussianFlagOwnershipReachable start finish)
    (hstart : start.Invariant) (m n k : Nat) :
    finish.toOwnershipState.liveSlots m n k ≤
      (finish.totalPivots + 2) * m * (n + 2) + m + k + finish.totalPivots := by
  have hinv := actualBalanceGaussianFlagOwnershipReachable_invariant hreach hstart
  have htranscript : finish.transcriptNodes ≤ finish.totalPivots := by
    rcases hinv with ⟨_, hselected, hpending, _⟩
    omega
  have hcompleted : finish.completedPivots ≤ finish.totalPivots := by
    rcases hinv with ⟨hcompleted, hselected, _, _⟩
    omega
  exact actualBalanceGaussianFlagOwnershipState_liveSlots_le
    finish.toOwnershipState m n k hcompleted htranscript

/-- Peak-slot bound for every intermediate ownership state on the path
generated from an actual flag scan's selector outcomes. The path theorem
provides the concrete initial state and final pivot total; this theorem applies
the invariant to any reachable prefix state. -/
theorem actualBalanceGaussianFlagOwnershipPath_phase_liveSlots_le
    {m n : Nat} (cells : Array (Array (ZMod 2))) (flags : Array Bool)
    (columns : List (Fin n))
    (state : ActualBalanceGaussianFlagOwnershipMachineState)
    (hreach : ActualBalanceGaussianFlagOwnershipReachable
      (actualBalanceGaussianFlagOwnershipInitial columns.length
        ((actualBalanceGaussianFlagColumnScan cells flags columns).2.length)) state)
    (arrayRows arrayColumns columnSlots : Nat) :
    state.toOwnershipState.liveSlots arrayRows arrayColumns columnSlots ≤
      ((actualBalanceGaussianFlagColumnScan cells flags columns).2.length + 2) *
          arrayRows * (arrayColumns + 2) + arrayRows + columnSlots +
        (actualBalanceGaussianFlagColumnScan cells flags columns).2.length := by
  exact actualBalanceGaussianFlagOwnershipReachable_liveSlots_le hreach
    (actualBalanceGaussianFlagOwnershipInitial_invariant columns.length
      ((actualBalanceGaussianFlagColumnScan cells flags columns).2.length))
    arrayRows arrayColumns columnSlots

/-- `actualBalanceGaussianFlagOwnershipPath_ofScan` supplies this machine with
the exact branch-outcome sequence generated by the source selector and update
functions. The machine still tracks only that control projection and ownership
counts: relating these abstract states to Lean evaluator heap reachability,
including runtime sharing, GC, headers, and call-stack storage, remains open. -/
end CorruptedFieldRecovery
