import CorruptedFieldRecovery.RawCoefficientFitTraceExpansion

/-! # Model-derived compact output and an explicit scalar nonzero gate

This uncompiled draft composes model-derived fit consistency with the
deterministic padded Gaussian output and its compact projection. A separate
Boolean check rejects outputs whose scalar coefficient vector is zero. The
draft proves only this coefficient-level nonzero fact; identifying it with a
nonzero quotient-field residue still needs the degree-`s` polynomial-basis
argument and is not claimed here. -/

namespace CorruptedFieldRecovery

/-- Project the existing deterministic padded solver result to the compact
scalar/support coefficient indexing. -/
def rawCoefficientFitCompactDeterministicOutput {s d : Nat}
    (candidate : RawFieldCandidate s)
    (hcheck : rawFieldCandidateCheck candidate = true)
    (inverse : RawCoordinateMatrix) (supportMatrix : RawBinaryArray)
    (raw : RawCoefficientArray) :
    Option (RawCoefficientFitColumnIndex s d → ZMod 2) :=
  (rawCoefficientFitDeterministicOutput candidate hcheck inverse supportMatrix raw).map
    rawCoefficientFitProjectCompact

/-- Execute the actual scalar-bit nonzero filter after compact projection.
The option is empty if the Gaussian routine has no output or if its returned
scalar coordinates are all zero. -/
def rawCoefficientFitNonzeroScalarOutput {s d : Nat}
    (candidate : RawFieldCandidate s)
    (hcheck : rawFieldCandidateCheck candidate = true)
    (inverse : RawCoordinateMatrix) (supportMatrix : RawBinaryArray)
    (raw : RawCoefficientArray) :
    Option (RawCoefficientFitColumnIndex s d → ZMod 2) := do
  let coefficients ← rawCoefficientFitCompactDeterministicOutput candidate hcheck
    inverse supportMatrix raw
  if hnonzero : ∃ j : Fin s, coefficients (Sum.inl j) ≠ 0 then
    some coefficients
  else none

/-- A successful checked output is exactly the compact projection of the
Gaussian result, together with the explicit nonzero coefficient witness. -/
theorem rawCoefficientFitNonzeroScalarOutput_spec {s d : Nat}
    (candidate : RawFieldCandidate s)
    (hcheck : rawFieldCandidateCheck candidate = true)
    (inverse : RawCoordinateMatrix) (supportMatrix : RawBinaryArray)
    (raw : RawCoefficientArray)
    (coefficients : RawCoefficientFitColumnIndex s d → ZMod 2)
    (hout : rawCoefficientFitNonzeroScalarOutput candidate hcheck inverse
      supportMatrix raw = some coefficients) :
    rawCoefficientFitCompactDeterministicOutput candidate hcheck inverse
      supportMatrix raw = some coefficients ∧
      ∃ j : Fin s, coefficients (Sum.inl j) ≠ 0 := by
  classical
  cases hrun : rawCoefficientFitDeterministicOutput candidate hcheck inverse
      supportMatrix raw with
  | none =>
      simp [rawCoefficientFitNonzeroScalarOutput,
        rawCoefficientFitCompactDeterministicOutput, hrun] at hout
  | some padded =>
      let compact := rawCoefficientFitProjectCompact padded
      have hout' : (if hn : ∃ j : Fin s, compact (Sum.inl j) ≠ 0 then
          some compact else none) = some coefficients := by
        simpa [rawCoefficientFitNonzeroScalarOutput,
          rawCoefficientFitCompactDeterministicOutput, hrun, compact] using hout
      by_cases hn : ∃ j : Fin s, compact (Sum.inl j) ≠ 0
      · have heq : compact = coefficients := Option.some.inj (by simpa [hn] using hout')
        constructor
        · simpa [rawCoefficientFitCompactDeterministicOutput, hrun, compact, heq]
        · rcases hn with ⟨j, hj⟩
          exact ⟨j, by simpa [heq] using hj⟩
      · simp [hn] at hout'

/-- A model and its explicit trace-column semantics establish consistency;
the deterministic affine scanner therefore returns some padded vector, and
projection supplies a compact scalar/residual output. This theorem does not
claim the scalar nonzero gate passes. -/
theorem rawCoefficientFitModel_yields_compactSolverOutput {s d : Nat}
    (input : RawCoefficientArray) (candidate : RawFieldCandidate s)
    (hfield : rawFieldCandidateCheck candidate = true)
    (forward inverse : RawCoordinateMatrix)
    (hcoordinates : rawCoordinateMatrixCheck (n := 3 * s) forward inverse = true)
    (residual : RawCoefficientArray) (supportMatrix : RawBinaryArray)
    (hinputSize : input.size = ((3 * s) * (3 * s)) * (3 * s))
    (hscalarSize : candidate.scalar.size = s)
    (hresidualSize : residual.size = ((d * d) * d))
    (hsupportSize : supportMatrix.size = (3 * s) * d)
    (hmodel : RawCoefficientFitModelDecomposition input candidate hfield
      forward inverse hcoordinates residual supportMatrix)
    (htrace : RawCoefficientFitTraceColumnExpansion candidate hfield forward inverse
      hcoordinates) :
    ∃ coefficients,
      rawCoefficientFitCompactDeterministicOutput candidate hfield inverse
        supportMatrix input = some coefficients ∧
      RawCoefficientFitAffineSolution candidate hfield inverse supportMatrix input ∧
      RawCoefficientFitModelArrayShape candidate forward inverse supportMatrix input
        residual := by
  have hconsistent := rawCoefficientFitModelDecomposition_finiteConsistent
    input candidate hfield forward inverse hcoordinates residual supportMatrix
    hinputSize hscalarSize hresidualSize hsupportSize hmodel htrace
  have hshape : RawCoefficientFitExecutionShape forward inverse supportMatrix input :=
    (rawCoefficientFitModelDecomposition_consistent input candidate hfield
      forward inverse hcoordinates residual supportMatrix hinputSize hscalarSize
      hresidualSize hsupportSize hmodel htrace).2.2.2
  obtain ⟨padded, hpaddedOutput, hpaddedFit, _⟩ :=
    rawCoefficientFitDeterministicOutput_spec candidate hfield forward inverse
      supportMatrix input hshape hconsistent
  refine ⟨rawCoefficientFitProjectCompact padded, ?_, ?_, ?_⟩
  · simpa [rawCoefficientFitCompactDeterministicOutput, hpaddedOutput]
  · exact rawCoefficientFitCompactSolution_of_padded candidate hfield inverse
      supportMatrix input padded hpaddedFit
  · exact (rawCoefficientFitModelDecomposition_consistent input candidate hfield
      forward inverse hcoordinates residual supportMatrix hinputSize hscalarSize
      hresidualSize hsupportSize hmodel htrace).2

/-- Same model-to-output connection when the tensor decomposition is supplied
as an accepted raw trace-decomposition check. The serialized dimensions and
the trace-column expansion remain explicit, separate premises. -/
theorem rawCoefficientFitAcceptedTraceCheck_yields_compactSolverOutput
    {s R : Nat} (p : RawDecomposition (3 * s) R)
    (candidate : RawFieldCandidate s)
    (hfield : rawFieldCandidateCheck candidate = true)
    (forward inverse : RawCoordinateMatrix)
    (hcoordinates : rawCoordinateMatrixCheck (n := 3 * s) forward inverse = true)
    (hcheck : rawTraceDecompositionCheck p candidate hfield forward inverse
      hcoordinates = true)
    (hinputSize : p.input.size = ((3 * s) * (3 * s)) * (3 * s))
    (hscalarSize : candidate.scalar.size = s)
    (hresidualSize : p.residual.size = ((p.supportDimension * p.supportDimension) *
      p.supportDimension))
    (hsupportSize : p.supportMatrix.size = (3 * s) * p.supportDimension)
    (htrace : RawCoefficientFitTraceColumnExpansion candidate hfield forward inverse
      hcoordinates) :
    ∃ coefficients,
      rawCoefficientFitCompactDeterministicOutput candidate hfield inverse
        p.supportMatrix p.input = some coefficients ∧
      RawCoefficientFitAffineSolution candidate hfield inverse p.supportMatrix p.input ∧
      RawCoefficientFitModelArrayShape candidate forward inverse p.supportMatrix p.input
        p.residual := by
  apply rawCoefficientFitModel_yields_compactSolverOutput p.input candidate hfield
    forward inverse hcoordinates p.residual p.supportMatrix hinputSize hscalarSize
    hresidualSize hsupportSize
    (rawCoefficientFitModelDecomposition_of_acceptedTraceCheck p candidate hfield
      forward inverse hcoordinates hcheck) htrace

/-- If the model-derived solver output passes the scalar coefficient check,
it returns a compact fit and its scalar coefficient vector is nonzero. No
success of this final check is assumed. -/
theorem rawCoefficientFitModel_nonzeroOutput_sound {s d : Nat}
    (input : RawCoefficientArray) (candidate : RawFieldCandidate s)
    (hfield : rawFieldCandidateCheck candidate = true)
    (forward inverse : RawCoordinateMatrix)
    (hcoordinates : rawCoordinateMatrixCheck (n := 3 * s) forward inverse = true)
    (residual : RawCoefficientArray) (supportMatrix : RawBinaryArray)
    (hinputSize : input.size = ((3 * s) * (3 * s)) * (3 * s))
    (hscalarSize : candidate.scalar.size = s)
    (hresidualSize : residual.size = ((d * d) * d))
    (hsupportSize : supportMatrix.size = (3 * s) * d)
    (hmodel : RawCoefficientFitModelDecomposition input candidate hfield
      forward inverse hcoordinates residual supportMatrix)
    (htrace : RawCoefficientFitTraceColumnExpansion candidate hfield forward inverse
      hcoordinates)
    (coefficients : RawCoefficientFitColumnIndex s d → ZMod 2)
    (hout : rawCoefficientFitNonzeroScalarOutput candidate hfield inverse
      supportMatrix input = some coefficients) :
    RawCoefficientFitAffineSolution candidate hfield inverse supportMatrix input ∧
      ∃ j : Fin s, coefficients (Sum.inl j) ≠ 0 := by
  obtain ⟨found, hrawOutput, hfit, _⟩ :=
    rawCoefficientFitModel_yields_compactSolverOutput input candidate hfield forward
      inverse hcoordinates residual supportMatrix hinputSize hscalarSize
      hresidualSize hsupportSize hmodel htrace
  have hchecked := rawCoefficientFitNonzeroScalarOutput_spec candidate hfield
    inverse supportMatrix input coefficients hout
  have hsame : found = coefficients := Option.some.inj
    (hrawOutput.symm.trans hchecked.1)
  subst coefficients
  exact ⟨hfit, hchecked.2⟩

end CorruptedFieldRecovery
