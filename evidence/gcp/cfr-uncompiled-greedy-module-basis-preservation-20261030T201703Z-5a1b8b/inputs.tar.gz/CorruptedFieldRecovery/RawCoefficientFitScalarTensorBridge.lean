import CorruptedFieldRecovery.RawCoefficientFitScalarResidue
import CorruptedFieldRecovery.RawCoefficientFitTraceExpansion
import CorruptedFieldRecovery.RawExecutableTraceCertificate

/-! # Decode fitted rows to one clean trace tensor and one support pullback

Uncompiled proof draft. This is the semantic bridge required to identify the
scalar represented by the actual fit vector. It derives, rather than assumes,
the fitted tensor decomposition from the compact row equations, the one-hot
trace-column evaluation theorem, and the support-minor expansion. The final
uniqueness step then compares this decomposition with the input model through
the same serialized support map. -/

namespace CorruptedFieldRecovery

open AdjoinRoot

/-- The clean trace tensor represented by a fitted scalar coefficient vector
in the candidate's quotient field and accepted physical coordinates. -/
noncomputable def rawCoefficientFitSemanticTraceTensor {s : Nat}
    (candidate : RawFieldCandidate s)
    (hfield : rawFieldCandidateCheck candidate = true)
    (forward inverse : RawCoordinateMatrix)
    (hcoordinates : rawCoordinateMatrixCheck (n := 3 * s) forward inverse = true)
    (coefficients : Fin s → ZMod 2) : BinaryTensor (3 * s) := by
  have hv := accepted_rawFieldCandidateCheck candidate hfield
  have hm := rawFieldCandidateValid_modulus_polynomial candidate hv
  letI : Fact (Irreducible (rawCandidateModulus candidate)) :=
    ⟨accepted_rawCandidateModulus_irreducible candidate hfield⟩
  let K := AdjoinRoot (rawCandidateModulus candidate)
  letI : Module.Finite BinaryField K := by
    simpa [rawCandidateModulus] using hm.1.finite_adjoinRoot
  let coords := accepted_rawCandidatePhysicalCoordinates candidate hfield
    forward inverse hcoordinates
  exact traceDeterminantTensor K
    (rawCoefficientFitScalarResidue candidate coefficients)
    coords.symm.toLinearMap

/-- On each increasing row, the semantic fitted trace tensor is the linear
combination of the actual raw one-hot trace columns. -/
theorem rawCoefficientFitSemanticTraceTensor_columnExpansion {s d : Nat}
    (candidate : RawFieldCandidate s)
    (hfield : rawFieldCandidateCheck candidate = true)
    (forward inverse : RawCoordinateMatrix)
    (hcoordinates : rawCoordinateMatrixCheck (n := 3 * s) forward inverse = true)
    (coefficients : Fin s → ZMod 2)
    (row : IncreasingTriple (3 * s)) :
    encodeDenseInput
        (rawCoefficientFitSemanticTraceTensor candidate hfield forward inverse
          hcoordinates coefficients) row =
      ∑ j : Fin s,
        rawTraceUnitFitColumn candidate hfield inverse j row * coefficients j := by
  classical
  have hv := accepted_rawFieldCandidateCheck candidate hfield
  have hm := rawFieldCandidateValid_modulus_polynomial candidate hv
  letI : Fact (Irreducible (rawCandidateModulus candidate)) :=
    ⟨accepted_rawCandidateModulus_irreducible candidate hfield⟩
  let K := AdjoinRoot (rawCandidateModulus candidate)
  letI : Module.Finite BinaryField K := by
    simpa [rawCandidateModulus] using hm.1.finite_adjoinRoot
  let coords := accepted_rawCandidatePhysicalCoordinates candidate hfield
    forward inverse hcoordinates
  let x := coordinateVectorCode (increasingTripleI row)
  let y := coordinateVectorCode (increasingTripleJ row)
  let z := coordinateVectorCode (increasingTripleK row)
  have hx : rawPhysicalCanonicalTriple candidate hfield inverse x = coords.symm x := by
    simpa [rawPhysicalCanonicalTriple, accepted_rawCandidatePowerBasisCoordinates,
      coords] using
      (accepted_rawCandidatePhysicalCoordinates_symm_eq_powerBasisInverse
        candidate hfield forward inverse hcoordinates x).symm
  have hy : rawPhysicalCanonicalTriple candidate hfield inverse y = coords.symm y := by
    simpa [rawPhysicalCanonicalTriple, accepted_rawCandidatePowerBasisCoordinates,
      coords] using
      (accepted_rawCandidatePhysicalCoordinates_symm_eq_powerBasisInverse
        candidate hfield forward inverse hcoordinates y).symm
  have hz : rawPhysicalCanonicalTriple candidate hfield inverse z = coords.symm z := by
    simpa [rawPhysicalCanonicalTriple, accepted_rawCandidatePowerBasisCoordinates,
      coords] using
      (accepted_rawCandidatePhysicalCoordinates_symm_eq_powerBasisInverse
        candidate hfield forward inverse hcoordinates z).symm
  change Algebra.trace BinaryField K
      (rawCoefficientFitScalarResidue candidate coefficients *
        fieldDet3 (coords.symm x) (coords.symm y) (coords.symm z)) = _
  rw [rawCoefficientFitScalarResidue, Finset.sum_mul, map_sum]
  simp only [map_smul]
  apply Finset.sum_congr rfl
  intro j hj
  rw [rawTraceUnitFitColumn_eq_canonicalPowerTrace candidate hfield inverse j row]
  rw [hx, hy, hz]
  simp [Algebra.smul_def, mul_assoc, mul_comm, mul_left_comm]

/-- A compact vector-specific fit equation decodes to the exact sum of its
fitted clean trace tensor and its support-minor pullback. No tensor equation
is taken as a premise. -/
theorem rawCoefficientFitVectorSolution_tensorDecomposition {s d : Nat}
    (candidate : RawFieldCandidate s)
    (hfield : rawFieldCandidateCheck candidate = true)
    (forward inverse : RawCoordinateMatrix)
    (hcoordinates : rawCoordinateMatrixCheck (n := 3 * s) forward inverse = true)
    (supportMatrix : RawBinaryArray) (raw : RawCoefficientArray)
    (coefficients : RawCoefficientFitColumnIndex s d → ZMod 2)
    (hfit : RawCoefficientFitVectorSolution candidate hfield inverse supportMatrix
      raw coefficients) :
    decodeRawArray (n := 3 * s) raw =
      rawCoefficientFitSemanticTraceTensor candidate hfield forward inverse
          hcoordinates (fun j => coefficients (Sum.inl j)) +
        pullback
          (decodeDenseInput (fun e : IncreasingTriple d => coefficients (Sum.inr e)))
          (rawSupportMap (n := 3 * s) (d := d) supportMatrix) := by
  classical
  have hv := accepted_rawFieldCandidateCheck candidate hfield
  have hm := rawFieldCandidateValid_modulus_polynomial candidate hv
  letI : Fact (Irreducible (rawCandidateModulus candidate)) :=
    ⟨accepted_rawCandidateModulus_irreducible candidate hfield⟩
  let K := AdjoinRoot (rawCandidateModulus candidate)
  letI : Module.Finite BinaryField K := by
    simpa [rawCandidateModulus] using hm.1.finite_adjoinRoot
  let fitTrace := rawCoefficientFitSemanticTraceTensor candidate hfield forward
    inverse hcoordinates (fun j => coefficients (Sum.inl j))
  let fitSupport := pullback
    (decodeDenseInput (fun e : IncreasingTriple d => coefficients (Sum.inr e)))
    (rawSupportMap (n := 3 * s) (d := d) supportMatrix)
  have htraceExpansion : ∀ row : IncreasingTriple (3 * s),
      encodeDenseInput fitTrace row =
        ∑ j : Fin s,
          rawTraceUnitFitColumn candidate hfield inverse j row *
            coefficients (Sum.inl j) := by
    intro row
    exact rawCoefficientFitSemanticTraceTensor_columnExpansion candidate hfield
      forward inverse hcoordinates (fun j => coefficients (Sum.inl j)) row
  have hsupportExpansion : ∀ row : IncreasingTriple (3 * s),
      encodeDenseInput fitSupport row =
        ∑ e : IncreasingTriple d,
          rawExteriorSupportFitColumn supportMatrix e row *
            coefficients (Sum.inr e) := by
    intro row
    simp [fitSupport, encodeDenseInput, pullback_apply, decodeDenseInput,
      rawExteriorSupportFitColumn, LinearMap.sum_apply, LinearMap.smul_apply]
  have htable : ∀ row : IncreasingTriple (3 * s),
      encodeDenseInput (decodeRawArray (n := 3 * s) raw) row =
        encodeDenseInput (fitTrace + fitSupport) row := by
    intro row
    have hrow := hfit row
    rw [Fintype.sum_sum_type] at hrow
    rw [rawCoefficientFitRhs_eq_decoded] at hrow
    rw [rawCoefficientFitEntry] at hrow
    rw [← htraceExpansion row, ← hsupportExpansion row] at hrow
    simpa [encodeDenseInput] using hrow.symm
  have htraceAlt : IsAlternating fitTrace := by
    dsimp [fitTrace]
    exact traceDeterminantTensor_alternating _ _ _
  have hsupportAlt : IsAlternating fitSupport := by
    have hE := decodeDenseInput_isAlternating
      (fun e : IncreasingTriple d => coefficients (Sum.inr e))
    refine ⟨?_, ?_, ?_⟩
    · intro x z
      simpa only [pullback_apply] using hE.1
        (rawSupportMap supportMatrix x) (rawSupportMap supportMatrix z)
    · intro x y
      simpa only [pullback_apply] using hE.2.1
        (rawSupportMap supportMatrix x) (rawSupportMap supportMatrix y)
    · intro x y
      simpa only [pullback_apply] using hE.2.2
        (rawSupportMap supportMatrix x) (rawSupportMap supportMatrix y)
  have hsumAlt : IsAlternating (fitTrace + fitSupport) := by
    refine ⟨?_, ?_, ?_⟩
    · intro x y
      simp [htraceAlt.1 x y, hsupportAlt.1 x y]
    · intro x y
      simp [htraceAlt.2.1 x y, hsupportAlt.2.1 x y]
    · intro x y
      simp [htraceAlt.2.2 x y, hsupportAlt.2.2 x y]
  apply binaryTensor_ext_of_increasing_coefficients
  · exact decodeRawArray_isAlternating (n := 3 * s) raw
  · exact hsumAlt
  · intro i j k hij hjk
    let row : IncreasingTriple (3 * s) := ⟨((i, j), k), ⟨hij, hjk⟩⟩
    have hr := htable row
    simpa [row, encodeDenseInput_eq_semanticCoefficient] using hr

/-- The exact fitted coefficient vector has quotient residue equal to the
candidate's serialized scalar, provided its actual row solution and the
input's same-support model decomposition hold. The row-to-tensor equation is
proved above from the raw columns; the final scalar equality is forced by
full mode-image rank, not assumed. -/
theorem rawCoefficientFitVectorScalarResidue_eq_rawCandidateScalar
    {s R d : Nat}
    (candidate : RawFieldCandidate s)
    (hfield : rawFieldCandidateCheck candidate = true)
    (forward inverse : RawCoordinateMatrix)
    (hcoordinates : rawCoordinateMatrixCheck (n := 3 * s) forward inverse = true)
    (supportMatrix : RawBinaryArray) (raw residual : RawCoefficientArray)
    (hmodel : RawCoefficientFitModelDecomposition raw candidate hfield forward
      inverse hcoordinates residual supportMatrix)
    (coefficients : RawCoefficientFitColumnIndex s d → ZMod 2)
    (hfit : RawCoefficientFitVectorSolution candidate hfield inverse supportMatrix
      raw coefficients)
    (hd : d ≤ R) (hs : 2 * R + 5 ≤ s) :
    rawCoefficientFitScalarResidue candidate
        (fun j => coefficients (Sum.inl j)) =
      AdjoinRoot.mk (rawCandidateModulus candidate) (rawCandidateScalar candidate) := by
  classical
  letI : Fact (Irreducible (rawCandidateModulus candidate)) :=
    ⟨accepted_rawCandidateModulus_irreducible candidate hfield⟩
  let K := AdjoinRoot (rawCandidateModulus candidate)
  have hv := accepted_rawFieldCandidateCheck candidate hfield
  have hm := rawFieldCandidateValid_modulus_polynomial candidate hv
  letI : Module.Finite BinaryField K := by
    simpa [rawCandidateModulus] using hm.1.finite_adjoinRoot
  let coords := accepted_rawCandidatePhysicalCoordinates candidate hfield
    forward inverse hcoordinates
  let fittedScalar := rawCoefficientFitScalarResidue candidate
    (fun j => coefficients (Sum.inl j))
  have hfitTensor := rawCoefficientFitVectorSolution_tensorDecomposition candidate
    hfield forward inverse hcoordinates supportMatrix raw coefficients hfit
  have hmodelTensor : decodeRawArray (n := 3 * s) raw =
      traceDeterminantTensor K
        (AdjoinRoot.mk (rawCandidateModulus candidate) (rawCandidateScalar candidate))
        coords.symm.toLinearMap +
      pullback (decodeRawArray (n := d) residual)
        (rawSupportMap (n := 3 * s) (d := d) supportMatrix) := by
    simpa [rawTraceDetTensor, K, coords] using hmodel
  have hcommon :
      traceDeterminantTensor K
          (AdjoinRoot.mk (rawCandidateModulus candidate) (rawCandidateScalar candidate))
          coords.symm.toLinearMap +
        pullback (decodeRawArray (n := d) residual)
          (rawSupportMap (n := 3 * s) (d := d) supportMatrix) =
      traceDeterminantTensor K fittedScalar coords.symm.toLinearMap +
        pullback
          (decodeDenseInput (fun e : IncreasingTriple d => coefficients (Sum.inr e)))
          (rawSupportMap (n := 3 * s) (d := d) supportMatrix) := by
    calc
      _ = decodeRawArray (n := 3 * s) raw := hmodelTensor.symm
      _ = _ := by simpa [rawCoefficientFitSemanticTraceTensor, K, coords] using hfitTensor
  have hdim : R < 3 * s := by omega
  exact traceDeterminant_scalar_eq_of_common_supported_decomposition coords
    (rawSupportMap (n := 3 * s) (d := d) supportMatrix)
    (decodeRawArray (n := d) residual)
    (decodeDenseInput (fun e : IncreasingTriple d => coefficients (Sum.inr e)))
    (AdjoinRoot.mk (rawCandidateModulus candidate) (rawCandidateScalar candidate))
    fittedScalar hcommon hd hdim

/-- End-to-end scalar identity for the actual deterministic Gaussian output.
The raw model and exact array shapes give a consistent finite affine system;
the deterministic-output theorem supplies the particular padded result, its
matrix equation gives the exact projected row fit, and the tensor uniqueness
argument proves that this returned coefficient residue is the original raw
candidate scalar. No success flag or scalar-equality premise is assumed. -/
theorem rawCoefficientFitModel_deterministicOutput_scalar_eq_rawCandidateScalar
    {s R d : Nat}
    (input : RawCoefficientArray) (candidate : RawFieldCandidate s)
    (hfield : rawFieldCandidateCheck candidate = true)
    (forward inverse : RawCoordinateMatrix)
    (hcoordinates : rawCoordinateMatrixCheck (n := 3 * s) forward inverse = true)
    (residual : RawCoefficientArray) (supportMatrix : RawBinaryArray)
    (hinputSize : input.size = ((3 * s) * (3 * s)) * (3 * s))
    (hscalarSize : candidate.scalar.size = s)
    (hresidualSize : residual.size = ((d * d) * d))
    (hsupportSize : supportMatrix.size = (3 * s) * d)
    (hmodel : RawCoefficientFitModelDecomposition input candidate hfield forward
      inverse hcoordinates residual supportMatrix)
    (hd : d ≤ R) (hs : 2 * R + 5 ≤ s) :
    ∃ padded,
      rawCoefficientFitDeterministicOutput candidate hfield inverse supportMatrix input =
        some padded ∧
      rawCoefficientFitScalarResidue candidate
        (fun j => rawCoefficientFitProjectCompact padded (Sum.inl j)) =
          AdjoinRoot.mk (rawCandidateModulus candidate) (rawCandidateScalar candidate) := by
  have hshape : RawCoefficientFitExecutionShape forward inverse supportMatrix input :=
    ⟨hinputSize, hsupportSize, hcoordinates⟩
  have htrace := rawCoefficientFitTraceColumnExpansion_fromRawScalar candidate hfield
    forward inverse hcoordinates hscalarSize
  have hconsistent := rawCoefficientFitModelDecomposition_finiteConsistent
    input candidate hfield forward inverse hcoordinates residual supportMatrix
    hinputSize hscalarSize hresidualSize hsupportSize hmodel htrace
  obtain ⟨padded, houtput, hpaddedFit, _⟩ :=
    rawCoefficientFitDeterministicOutput_spec candidate hfield forward inverse
      supportMatrix input hshape hconsistent
  have hvector := rawCoefficientFitVectorSolution_of_padded candidate hfield
    inverse supportMatrix input padded hpaddedFit
  have hscalar := rawCoefficientFitVectorScalarResidue_eq_rawCandidateScalar
    candidate hfield forward inverse hcoordinates supportMatrix input residual
    hmodel (fun j => rawCoefficientFitProjectCompact padded (Sum.inl j)) hvector
    hd hs
  exact ⟨padded, houtput, hscalar⟩

end CorruptedFieldRecovery
