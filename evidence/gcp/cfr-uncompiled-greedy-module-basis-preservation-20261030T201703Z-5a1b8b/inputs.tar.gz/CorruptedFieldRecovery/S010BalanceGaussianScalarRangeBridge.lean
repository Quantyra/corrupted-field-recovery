import CorruptedFieldRecovery.S010BalanceGaussianRawKernelBasis
import CorruptedFieldRecovery.S010ObservedHiddenBalance

namespace CorruptedFieldRecovery

/-- Recover the scalar parameter of a Q-conjugated endomorphism by evaluating
it on the distinguished first field-triple basis vector. -/
def actualBalanceGaussianQScalarParameter
    {K : Type*} [Field K] [Algebra BinaryField K] {s : Nat}
    (Q : BinaryVector (3 * s) ≃ₗ[BinaryField] FieldTriple K)
    (T : Module.End BinaryField (BinaryVector (3 * s))) : K :=
  (Q (T (Q.symm (fieldBasis0 : FieldTriple K)))).1

/-- On the Q-conjugated scalar range, evaluation at the first basis vector
recovers the unique scalar parameter. -/
theorem actualBalanceGaussianQScalarParameter_spec
    {K : Type*} [Field K] [Algebra BinaryField K] {s : Nat}
    (Q : BinaryVector (3 * s) ≃ₗ[BinaryField] FieldTriple K)
    {T : Module.End BinaryField (BinaryVector (3 * s))}
    (hT : T ∈ qScalarConjugateEndRange Q) :
    qScalarConjugateLinearMap Q
      (actualBalanceGaussianQScalarParameter Q T) = T := by
  rcases hT with ⟨k, hk⟩
  have hvalue : actualBalanceGaussianQScalarParameter Q T = k := by
    dsimp [actualBalanceGaussianQScalarParameter]
    have heval := congrArg
      (fun S : Module.End BinaryField (BinaryVector (3 * s)) =>
        Q (S (Q.symm (fieldBasis0 : FieldTriple K)))) hk
    calc
      (Q (T (Q.symm (fieldBasis0 : FieldTriple K)))).1 =
        (k • (fieldBasis0 : FieldTriple K)).1 := by
          simpa [qScalarConjugateLinearMap] using
            congrArg Prod.fst heval.symm
      _ = k := by simp [fieldBasis0, smul_eq_mul]
  rw [hvalue]
  exact hk

/-- Under the actual good-tape event and the explicit observed trace-
determinant decomposition, the raw Gaussian basis spans exactly the
Q-conjugated scalar endomorphisms. The size hypothesis keeps the statement
attached to a well-formed dense raw tensor. -/
theorem actualBalanceGaussianRawBasis_spans_QScalarRange
    {K : Type*} [Field K] [Fintype K] [DecidableEq K] [Finite K]
    [CharP K 2] [Algebra BinaryField K] [FiniteDimensional BinaryField K]
    [Algebra (ZMod (ringChar K)) K]
    {s : Nat}
    (Q : BinaryVector (3 * s) ≃ₗ[BinaryField] FieldTriple K)
    (E : BinaryTensor (3 * s))
    (U : Submodule BinaryField (KTriple K))
    (b : (Fin 4 → FieldTriple K) → Module.Basis (Fin s) BinaryField K)
    (raw : RawCoefficientArray) (tape : FiveWordTape s)
    (htape : tape ∈ actualFiveGoodTapeSet K Q
      (modeImageSemanticCleanFieldSet Q E) U b)
    (c : K) (hc : c ≠ 0)
    (hmodel : HasObservedTraceDeterminantDecomposition
      (decodeRawArray (n := 3 * s) raw) E LinearMap.id Q c)
    (hsize : raw.size = (3 * s) * (3 * s) * (3 * s))
    (T : Module.End BinaryField (BinaryVector (3 * s))) :
    T ∈ qScalarConjugateEndRange Q ↔
      T = ∑ free : balanceGaussianFreeIndex
          (actualBalanceGaussianRawScan raw tape).2,
        actualBalanceGaussianInputCoordinates T free.1 •
          actualBalanceGaussianRawCandidateFamily raw tape free := by
  let hiff := actual_good_tape_observed_balance_iff_mem_qScalarConjugateEndRange
    Q E U b tape htape (decodeRawArray (n := 3 * s) raw) c hmodel hc
  have hcandidateRange : ∀ free : balanceGaussianFreeIndex
      (actualBalanceGaussianRawScan raw tape).2,
      actualBalanceGaussianRawCandidateFamily raw tape free ∈
        qScalarConjugateEndRange Q := by
    intro free
    have hcheck := actualBalanceGaussianRawCandidate_checker_true
      raw tape hsize free
    have hchecked := (actualBalanceRawInputConstraintCheck_iff raw tape
      (actualBalanceGaussianRawCandidateFamily raw tape free)).mp hcheck
    exact (hiff (actualBalanceGaussianRawCandidateFamily raw tape free)).mp
      hchecked.2
  constructor
  · intro hT
    exact actualBalanceGaussianRawBalanced_endomorphism_reconstruct
      raw tape T ((hiff T).mpr hT)
  · intro hexp
    rw [hexp]
    apply Submodule.sum_smul_mem
    intro free hfree
    exact hcandidateRange free

/-- Each executable free-column candidate computes the scalar that generates
it inside the promised Q-conjugated scalar range. This uses the supplied true
Q and good-event/model hypotheses; it does not discover the field or Q from
the raw array. -/
theorem actualBalanceGaussianRawCandidate_QScalar_eq
    {K : Type*} [Field K] [Fintype K] [DecidableEq K] [Finite K]
    [CharP K 2] [Algebra BinaryField K] [FiniteDimensional BinaryField K]
    [Algebra (ZMod (ringChar K)) K]
    {s : Nat}
    (Q : BinaryVector (3 * s) ≃ₗ[BinaryField] FieldTriple K)
    (E : BinaryTensor (3 * s))
    (U : Submodule BinaryField (KTriple K))
    (b : (Fin 4 → FieldTriple K) → Module.Basis (Fin s) BinaryField K)
    (raw : RawCoefficientArray) (tape : FiveWordTape s)
    (htape : tape ∈ actualFiveGoodTapeSet K Q
      (modeImageSemanticCleanFieldSet Q E) U b)
    (c : K) (hc : c ≠ 0)
    (hmodel : HasObservedTraceDeterminantDecomposition
      (decodeRawArray (n := 3 * s) raw) E LinearMap.id Q c)
    (hsize : raw.size = (3 * s) * (3 * s) * (3 * s))
    (free : balanceGaussianFreeIndex (actualBalanceGaussianRawScan raw tape).2) :
    qScalarConjugateLinearMap Q
      (actualBalanceGaussianQScalarParameter Q
        (actualBalanceGaussianRawCandidateFamily raw tape free)) =
      actualBalanceGaussianRawCandidateFamily raw tape free := by
  have hiff := actual_good_tape_observed_balance_iff_mem_qScalarConjugateEndRange
    Q E U b tape htape (decodeRawArray (n := 3 * s) raw) c hmodel hc
  have hcheck := actualBalanceGaussianRawCandidate_checker_true
    raw tape hsize free
  have hchecked := (actualBalanceRawInputConstraintCheck_iff raw tape
    (actualBalanceGaussianRawCandidateFamily raw tape free)).mp hcheck
  exact actualBalanceGaussianQScalarParameter_spec Q
    ((hiff (actualBalanceGaussianRawCandidateFamily raw tape free)).mp hchecked.2)

end CorruptedFieldRecovery
