import CorruptedFieldRecovery.S010BalanceGaussianDynamicSpan

namespace CorruptedFieldRecovery

/-! A direct executable transcription of the manuscript's greedy physical
unit/orbit construction.  It searches only the `n` physical coordinate
vectors, never all `2^n` vectors.  The result is a raw list of selected unit
indices and orbit columns.  This draft does not yet prove that each orbit
adds `s` independent columns, that three passes fill the space, or that the
array refines the manuscript's certified coordinate map.  Its imported
Gaussian chain is itself uncompiled.  Syntactically the fixed three passes
terminate and inspect at most `3*n` physical unit candidates; each candidate
invokes one span scan with `n` rows and at most `3*s+1` columns.  The resulting
polynomial operation envelope and peak live-space bound have not been proved
against the implementation's cost semantics. -/

/-- A column family stored in order as a finite array of physical binary
vectors. -/
abbrev RawGreedyOrbitColumns (n : Nat) := Array (BinaryVector n)

/-- A small state for the deterministic scan: selected physical unit indices
and the concatenated T-orbit columns emitted so far. -/
structure RawGreedyOrbitState (n : Nat) where
  selectedUnits : Array (Fin n)
  columns : RawGreedyOrbitColumns n

/-- Initial state before any module generator has been chosen. -/
def rawGreedyOrbitInitial (n : Nat) : RawGreedyOrbitState n :=
  ⟨#[], #[]⟩

/-- The ordered `Fin n` family represented by an array of columns. -/
def rawGreedyOrbitColumnFamily {n : Nat} (columns : RawGreedyOrbitColumns n) :
    Fin columns.size → BinaryVector n :=
  fun j => columns[j.val]!

/-- Executable column-span membership via the augmented deterministic
Gaussian scan from `S010BalanceGaussianDynamicSpan`. -/
def rawGreedyOrbitMemSpan? {n : Nat}
    (columns : RawGreedyOrbitColumns n) (v : BinaryVector n) : Bool :=
  match balanceGaussianSpanWitness? (rawGreedyOrbitColumnFamily columns) v with
  | none => false
  | some _ => true

/-- Physical standard coordinate vector, in the order used by the manuscript's
greedy scan. -/
def rawGreedyOrbitUnitVector {n : Nat} (i : Fin n) : BinaryVector n :=
  fun j => if j = i then 1 else 0

/-- First physical unit vector not in the span of the current orbit columns.
The scan is over the `n` standard vectors only. -/
def rawGreedyOrbitFirstOutside? {n : Nat}
    (columns : RawGreedyOrbitColumns n) : Option (Fin n) :=
  (List.ofFn fun i : Fin n => i).find? fun i =>
    !(rawGreedyOrbitMemSpan? columns (rawGreedyOrbitUnitVector i))

/-- The s orbit columns of one selected physical unit vector. -/
def rawGreedyTOrbit {n s : Nat}
    (T : Module.End (ZMod 2) (BinaryVector n)) (v : BinaryVector n) :
    RawGreedyOrbitColumns n :=
  Array.ofFn fun j : Fin s => (T ^ j.val) v

/-- One deterministic greedy pass. If a unit vector outside the current span
exists, append its first s T-iterates; otherwise leave the state unchanged. -/
def rawGreedyOrbitStep {n s : Nat}
    (T : Module.End (ZMod 2) (BinaryVector n))
    (state : RawGreedyOrbitState n) : RawGreedyOrbitState n :=
  match rawGreedyOrbitFirstOutside? state.columns with
  | none => state
  | some i =>
      let orbit := rawGreedyTOrbit T (rawGreedyOrbitUnitVector i)
      ⟨state.selectedUnits.push i, state.columns ++ orbit⟩

/-- A fixed number of greedy passes, structurally recursive and hence
terminating.  The manuscript uses exactly three passes when `n = 3*s`. -/
def rawGreedyOrbitRun {n s : Nat}
    (T : Module.End (ZMod 2) (BinaryVector n)) :
    Nat → RawGreedyOrbitState n → RawGreedyOrbitState n
  | 0, state => state
  | k + 1, state => rawGreedyOrbitRun T k (rawGreedyOrbitStep T state)

/-- The manuscript's three-pass coordinate-column output. -/
def rawGreedyModuleBasisColumns {s : Nat}
    (T : Module.End (ZMod 2) (BinaryVector (3 * s))) :
    RawGreedyOrbitState (3 * s) :=
  rawGreedyOrbitRun T 3 (rawGreedyOrbitInitial (3 * s))

/-- Shape predicate for the emitted coordinate matrix.  The separate
two-sided inverse/independence verifier remains the final acceptance gate. -/
def rawGreedyModuleBasisHasFullShape {s : Nat}
    (T : Module.End (ZMod 2) (BinaryVector (3 * s))) : Prop :=
  (rawGreedyModuleBasisColumns T).selectedUnits.size = 3 ∧
    (rawGreedyModuleBasisColumns T).columns.size = 3 * s

/-- Explicit semantic obligation for the greedy output: the emitted orbit
columns form a binary basis.  This is a specification only, not a proved fact
in this draft. -/
def rawGreedyModuleBasisCorrect {s : Nat}
    (T : Module.End (ZMod 2) (BinaryVector (3 * s))) : Prop :=
  LinearIndependent (ZMod 2) (fun j : Fin (3 * s) =>
    (rawGreedyModuleBasisColumns T).columns[j.val]!)

end CorruptedFieldRecovery
