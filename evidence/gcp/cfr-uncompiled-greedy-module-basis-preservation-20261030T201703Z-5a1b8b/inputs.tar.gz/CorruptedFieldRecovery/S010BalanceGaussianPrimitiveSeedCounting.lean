import CorruptedFieldRecovery.S010BalanceGaussianOrderedSeedIndex
import CorruptedFieldRecovery.S010BalanceGaussianGeneratorFastCheck
import CorruptedFieldRecovery.S010BalanceGaussianPrimitivePowerIndependence

namespace CorruptedFieldRecovery

/-! Exact seed counting for the primitive-element event.  The ordered list
equivalence identifies every `Fin s → BinaryField` seed with one scalar in
K.  This file records the event-count transfer and a conditional inclusion
into serialized fast-check acceptance.  It makes no lower bound for the
primitive-element proportion and no claim that all seeds pass.  This source
is an uncompiled draft. -/

/-- On a good tape with the supplied model promise and dense-size hypothesis,
the actual ordered coefficient seed and the selected scalar have exactly the
same primitive-element event count.  This is an equality of finite cardinality
counts, not a probability estimate. -/
theorem actualBalanceGaussianGoodTape_primitiveSeedCount_eq
    {K : Type*} [Field K] [Fintype K] [DecidableEq K] [Finite K]
    [CharP K 2] [Algebra BinaryField K] [FiniteDimensional BinaryField K]
    [Algebra (ZMod (ringChar K)) K]
    {s : Nat}
    (Q : BinaryVector (3 * s) ≃ₗ[BinaryField] FieldTriple K)
    (E : BinaryTensor (3 * s))
    (U : Submodule BinaryField (KTriple K))
    (b : (Fin 4 → FieldTriple K) → Module.Basis (Fin s) BinaryField K)
    (raw : RawCoefficientArray) (tape : FiveWordTape s)
    (htape : tape ∈ actualFiveGoodTapeSet K Q
      (modeImageSemanticCleanFieldSet Q E) U b)
    (c : K) (hc : c ≠ 0)
    (hmodel : HasObservedTraceDeterminantDecomposition
      (decodeRawArray (n := 3 * s) raw) E LinearMap.id Q c)
    (hsize : raw.size = (3 * s) * (3 * s) * (3 * s))
    (hK : Module.finrank BinaryField K = s) :
    let hcard : Fintype.card (actualBalanceGaussianRawFreeIndex raw tape) = s :=
      actualBalanceGaussianRawFreeIndex_card_eq
        Q E U b raw tape htape c hc hmodel hsize hK
    let selected : (Fin s → BinaryField) →
        Module.End BinaryField (BinaryVector (3 * s)) := fun seed =>
      actualBalanceGaussianArrayFlagSelectBySeed raw tape
        (by rw [← actualBalanceGaussianRawFreeIndex_card_eq
          Q E U b raw tape htape c hc hmodel hsize hK]; rfl) seed
    let scalar : (Fin s → BinaryField) → K := fun seed =>
      actualBalanceGaussianQScalarParameter Q (selected seed)
    Fintype.card {seed : Fin s → BinaryField //
      Algebra.adjoin BinaryField ({scalar seed} : Set K) = ⊤} =
    Fintype.card {k : K //
      Algebra.adjoin BinaryField ({k} : Set K) = ⊤} := by
  classical
  let selected : (Fin s → BinaryField) →
      Module.End BinaryField (BinaryVector (3 * s)) := fun seed =>
    actualBalanceGaussianArrayFlagSelectBySeed raw tape
      (by rw [← actualBalanceGaussianRawFreeIndex_card_eq
        Q E U b raw tape htape c hc hmodel hsize hK]; rfl) seed
  let scalar : (Fin s → BinaryField) → K := fun seed =>
    actualBalanceGaussianQScalarParameter Q (selected seed)
  have hbij : Function.Bijective scalar := by
    simpa [scalar, selected] using
      actualBalanceGaussianArrayFlagSeedScalar_bijective
        Q E U b raw tape htape c hc hmodel hsize hK
  let e : (Fin s → BinaryField) ≃ K := Equiv.ofBijective scalar hbij
  have hevent :
      {seed : Fin s → BinaryField //
        Algebra.adjoin BinaryField ({scalar seed} : Set K) = ⊤} ≃
      {k : K // Algebra.adjoin BinaryField ({k} : Set K) = ⊤} :=
    e.subtypeEquiv (by intro seed; rfl)
  exact Fintype.card_congr hevent

/-- With nonzero scalar encoding bits of the right length, every primitive
ordered seed passes the shape and Rabin fast check.  Consequently the number
of passing seeds is at least the exact primitive-seed count above.  This does
not assume or bound the primitive-seed proportion. -/
theorem actualBalanceGaussianGoodTape_fastCheckSeedCount_lowerBound
    {K : Type*} [Field K] [Fintype K] [DecidableEq K] [Finite K]
    [CharP K 2] [Algebra BinaryField K] [FiniteDimensional BinaryField K]
    [Algebra (ZMod (ringChar K)) K]
    {s : Nat}
    (Q : BinaryVector (3 * s) ≃ₗ[BinaryField] FieldTriple K)
    (E : BinaryTensor (3 * s))
    (U : Submodule BinaryField (KTriple K))
    (b : (Fin 4 → FieldTriple K) → Module.Basis (Fin s) BinaryField K)
    (raw : RawCoefficientArray) (tape : FiveWordTape s)
    (htape : tape ∈ actualFiveGoodTapeSet K Q
      (modeImageSemanticCleanFieldSet Q E) U b)
    (c : K) (hc : c ≠ 0)
    (hmodel : HasObservedTraceDeterminantDecomposition
      (decodeRawArray (n := 3 * s) raw) E LinearMap.id Q c)
    (hsize : raw.size = (3 * s) * (3 * s) * (3 * s))
    (hK : Module.finrank BinaryField K = s)
    (hs : 1 ≤ s) (scalarBits : RawFieldBits)
    (hscalarSize : scalarBits.size = s)
    (hscalarNe : rawFieldBitsToNat scalarBits ≠ 0) :
    let selected : (Fin s → BinaryField) →
        Module.End BinaryField (BinaryVector (3 * s)) := fun seed =>
      actualBalanceGaussianArrayFlagSelectBySeed raw tape
        (by rw [← actualBalanceGaussianRawFreeIndex_card_eq
          Q E U b raw tape htape c hc hmodel hsize hK]; rfl) seed
    let scalar : (Fin s → BinaryField) → K := fun seed =>
      actualBalanceGaussianQScalarParameter Q (selected seed)
    Fintype.card {seed : Fin s → BinaryField //
      ∃ candidate,
        actualBalanceGaussianSerializedRecurrenceCandidate?
          (selected seed) scalarBits = some candidate ∧
        rawFieldCandidateFastCheck candidate = true} ≥
    Fintype.card {seed : Fin s → BinaryField //
      Algebra.adjoin BinaryField ({scalar seed} : Set K) = ⊤} := by
  classical
  let selected : (Fin s → BinaryField) →
      Module.End BinaryField (BinaryVector (3 * s)) := fun seed =>
    actualBalanceGaussianArrayFlagSelectBySeed raw tape
      (by rw [← actualBalanceGaussianRawFreeIndex_card_eq
        Q E U b raw tape htape c hc hmodel hsize hK]; rfl) seed
  let scalar : (Fin s → BinaryField) → K := fun seed =>
    actualBalanceGaussianQScalarParameter Q (selected seed)
  let P : (Fin s → BinaryField) → Prop := fun seed =>
    Algebra.adjoin BinaryField ({scalar seed} : Set K) = ⊤
  let S : (Fin s → BinaryField) → Prop := fun seed =>
    ∃ candidate,
      actualBalanceGaussianSerializedRecurrenceCandidate?
        (selected seed) scalarBits = some candidate ∧
      rawFieldCandidateFastCheck candidate = true
  have hsubset : ∀ seed, P seed → S seed := by
    intro seed hprimitive
    exact actualBalanceGaussianGoodSeedSerializedCandidate_fastCheck
      Q E U b raw tape htape c hc hmodel hsize hK seed
      (actualBalanceGaussian_endPowers_linearIndependent_of_primitive
        Q (selected seed)
        (actualBalanceGaussianArrayFlagSelectBySeed_mem_qScalarRange
          Q E U b raw tape htape c hc hmodel hsize hK seed)
        (by simpa [scalar] using hprimitive) hK)
      (by simpa [scalar] using hprimitive)
      hs scalarBits hscalarSize hscalarNe
  let incl : {seed : Fin s → BinaryField // P seed} →
      {seed : Fin s → BinaryField // S seed} := fun seed =>
    ⟨seed.1, hsubset seed.1 seed.2⟩
  have hinj : Function.Injective incl := by
    intro x y hxy
    exact Subtype.ext (congrArg Subtype.val hxy)
  exact Fintype.card_le_of_injective incl hinj

end CorruptedFieldRecovery
