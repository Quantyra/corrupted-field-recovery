import CorruptedFieldRecovery.RawCoefficientFitPaddedProjectionProof
import CorruptedFieldRecovery.RawExecutableTraceSemantic

/-! # Model decomposition to an explicit coefficient-fit witness

This uncompiled bridge constructs the coefficient vector from the serialized
candidate scalar and residual array. It does not assume the fit equation or
ask Lean to choose a noncomputable solution. The model decomposition and the
two column-expansion facts are kept as visible hypotheses: proving that the
raw one-hot trace columns expand the candidate's scalar trace, and that the
serialized support basis expands the residual, is the remaining semantic
work. -/

namespace CorruptedFieldRecovery

/-- The coefficient vector prescribed by the input data: scalar bits in the
power-basis slots, followed by the serialized increasing residual
coefficients in the support-minor slots. Out-of-shape reads remain total;
the theorem below carries the corresponding exact-size conditions. -/
def rawCoefficientFitScalarCoefficient {s : Nat}
    (candidate : RawFieldCandidate s) (j : Fin s) : ZMod 2 :=
  if candidate.scalar[j.val]! then 1 else 0

def rawCoefficientFitModelCoefficients {s d : Nat}
    (candidate : RawFieldCandidate s) (residual : RawCoefficientArray) :
    RawCoefficientFitColumnIndex s d → ZMod 2
  | Sum.inl j => rawCoefficientFitScalarCoefficient candidate j
  | Sum.inr e => residual[rawCoefficientOffset d
      (increasingTripleI e) (increasingTripleJ e) (increasingTripleK e)]!

/-- A pointwise form of the actual model promise on encoded coordinates. This
is stated over the literal trace tensor and the raw support map; it does not
mention or assume a coefficient-fit solution. -/
def RawCoefficientFitModelDecomposition {s d : Nat}
    (input : RawCoefficientArray) (candidate : RawFieldCandidate s)
    (hfield : rawFieldCandidateCheck candidate = true)
    (forward inverse : RawCoordinateMatrix)
    (hcoordinates : rawCoordinateMatrixCheck (n := 3 * s) forward inverse = true)
    (residual : RawCoefficientArray) (supportMatrix : RawBinaryArray) : Prop :=
  decodeRawArray (n := 3 * s) input =
    rawTraceDetTensor candidate hfield forward inverse hcoordinates +
      pullback (decodeRawArray (n := d) residual)
        (rawSupportMap (n := 3 * s) (d := d) supportMatrix)

/-- The existing accepted trace-decomposition check supplies exactly the
literal tensor model identity used below. -/
theorem rawCoefficientFitModelDecomposition_of_acceptedTraceCheck
    {s R : Nat} (p : RawDecomposition (3 * s) R)
    (candidate : RawFieldCandidate s)
    (hfield : rawFieldCandidateCheck candidate = true)
    (forward inverse : RawCoordinateMatrix)
    (hcoordinates : rawCoordinateMatrixCheck (n := 3 * s) forward inverse = true)
    (hcheck : rawTraceDecompositionCheck p candidate hfield forward inverse
      hcoordinates = true) :
    RawCoefficientFitModelDecomposition p.input candidate hfield forward inverse
      hcoordinates p.residual p.supportMatrix := by
  have hpoint := accepted_rawTraceDecompositionCheck_sound p candidate hfield
    forward inverse hcoordinates hcheck
  change decodeRawArray (n := 3 * s) p.input = _
  ext x y z
  exact hpoint x y z

/-- Required scalar-column identity, stated against the actual quotient-field
trace payload. This is the substantive one-hot/power-basis linearity bridge:
it must be derived from the candidate scalar bits and the raw evaluator, not
postulated as a recovered fit. -/
def RawCoefficientFitTraceColumnExpansion {s : Nat}
    (candidate : RawFieldCandidate s)
    (hfield : rawFieldCandidateCheck candidate = true)
    (forward inverse : RawCoordinateMatrix)
    (hcoordinates : rawCoordinateMatrixCheck (n := 3 * s) forward inverse = true) : Prop :=
  ∀ row : IncreasingTriple (3 * s),
    encodeDenseInput (rawTraceDetTensor candidate hfield forward inverse hcoordinates) row =
      ∑ j : Fin s,
        rawTraceUnitFitColumn candidate hfield inverse j row *
          rawCoefficientFitScalarCoefficient candidate j

/-- Required exterior-support expansion. Its right hand side uses the actual
serialized support map and residual coefficients; the intended proof is the
minor-basis expansion of `decodeRawArray residual` followed by pullback. -/
def RawCoefficientFitSupportColumnExpansion {s d : Nat}
    (residual : RawCoefficientArray) (supportMatrix : RawBinaryArray) : Prop :=
  ∀ row : IncreasingTriple (3 * s),
    encodeDenseInput
      (pullback (decodeRawArray (n := d) residual)
        (rawSupportMap (n := 3 * s) (d := d) supportMatrix)) row =
      ∑ e : IncreasingTriple d,
        rawExteriorSupportFitColumn supportMatrix e row *
          residual[rawCoefficientOffset d (increasingTripleI e)
            (increasingTripleJ e) (increasingTripleK e)]!

/-- The support-column expansion is definitional from the decoder's minor
basis and the actual raw support map. This proof is kept next to the model
bridge so the remaining semantic assumption is isolated to scalar/trace
columns. -/
theorem rawCoefficientFitSupportColumnExpansion_fromDecoder {s d : Nat}
    (residual : RawCoefficientArray) (supportMatrix : RawBinaryArray) :
    RawCoefficientFitSupportColumnExpansion residual supportMatrix := by
  classical
  intro row
  simp [RawCoefficientFitSupportColumnExpansion, encodeDenseInput, pullback_apply,
    decodeRawArray, decodeDenseInput, rawExteriorSupportFitColumn,
    LinearMap.sum_apply, LinearMap.smul_apply]

/-- Exact array-shape facts needed to interpret the total array reads as the
intended serialized scalar and dense residual coefficients. -/
def RawCoefficientFitModelArrayShape {s d : Nat}
    (candidate : RawFieldCandidate s) (forward inverse : RawCoordinateMatrix)
    (supportMatrix : RawBinaryArray) (input residual : RawCoefficientArray) : Prop :=
  candidate.scalar.size = s ∧
  residual.size = ((d * d) * d) ∧
  RawCoefficientFitExecutionShape forward inverse supportMatrix input

/-- Given the literal model decomposition and the two semantic column
identities, the data itself supplies a compact affine-fit witness. In
particular, this theorem constructs coefficients from the scalar and
residual arrays; it assumes no fit equation, consistency proposition, or
noncomputable output. The trace-column expansion remains an explicit
unproved obligation in this draft. -/
theorem rawCoefficientFitModelDecomposition_consistent {s d : Nat}
    (input : RawCoefficientArray) (candidate : RawFieldCandidate s)
    (hfield : rawFieldCandidateCheck candidate = true)
    (forward inverse : RawCoordinateMatrix)
    (hcoordinates : rawCoordinateMatrixCheck (n := 3 * s) forward inverse = true)
    (residual : RawCoefficientArray) (supportMatrix : RawBinaryArray)
    (hinputSize : input.size = ((3 * s) * (3 * s)) * (3 * s))
    (hscalarSize : candidate.scalar.size = s)
    (hresidualSize : residual.size = ((d * d) * d))
    (hsupportSize : supportMatrix.size = (3 * s) * d)
    (hmodel : RawCoefficientFitModelDecomposition input candidate hfield
      forward inverse hcoordinates residual supportMatrix)
    (htrace : RawCoefficientFitTraceColumnExpansion candidate hfield forward inverse
      hcoordinates) :
    RawCoefficientFitAffineSolution candidate hfield inverse supportMatrix input ∧
      RawCoefficientFitModelArrayShape candidate forward inverse supportMatrix input
        residual := by
  classical
  have hsupport := rawCoefficientFitSupportColumnExpansion_fromDecoder residual
    supportMatrix
  constructor
  · refine ⟨rawCoefficientFitModelCoefficients candidate residual, ?_⟩
    intro row
    have hmodelRow := congrArg (fun tensor : BinaryTensor (3 * s) =>
        encodeDenseInput tensor row) hmodel
    have hdata : rawCoefficientFitRhs input row =
        encodeDenseInput
          (rawTraceDetTensor candidate hfield forward inverse hcoordinates) row +
        encodeDenseInput
          (pullback (decodeRawArray (n := d) residual)
            (rawSupportMap (n := 3 * s) (d := d) supportMatrix)) row := by
      rw [rawCoefficientFitRhs_eq_decoded, ← hmodelRow]
      simp [encodeDenseInput]
    rw [hdata, htrace row, hsupport row]
    simp only [Fintype.sum_sum_type, rawCoefficientFitEntry,
      rawCoefficientFitModelCoefficients]
    simp [RawCoefficientFitColumnIndex, mul_comm, add_comm, add_left_comm, add_assoc]
  · exact ⟨hscalarSize, hresidualSize, hinputSize, hsupportSize, hcoordinates⟩

/-- The same constructed witness solves the original all-ordered-triples
zero-padded matrix, via the compact/padded equation equivalence. -/
theorem rawCoefficientFitModelDecomposition_finiteConsistent {s d : Nat}
    (input : RawCoefficientArray) (candidate : RawFieldCandidate s)
    (hfield : rawFieldCandidateCheck candidate = true)
    (forward inverse : RawCoordinateMatrix)
    (hcoordinates : rawCoordinateMatrixCheck (n := 3 * s) forward inverse = true)
    (residual : RawCoefficientArray) (supportMatrix : RawBinaryArray)
    (hinputSize : input.size = ((3 * s) * (3 * s)) * (3 * s))
    (hscalarSize : candidate.scalar.size = s)
    (hresidualSize : residual.size = ((d * d) * d))
    (hsupportSize : supportMatrix.size = (3 * s) * d)
    (hmodel : RawCoefficientFitModelDecomposition input candidate hfield
      forward inverse hcoordinates residual supportMatrix)
    (htrace : RawCoefficientFitTraceColumnExpansion candidate hfield forward inverse
      hcoordinates) :
    RawCoefficientFitFiniteSystemSolution candidate hfield inverse supportMatrix input := by
  apply (rawCoefficientFitCompactPaddedConsistency_iff candidate hfield inverse
    supportMatrix input).mp
  exact (rawCoefficientFitModelDecomposition_consistent input candidate hfield
    forward inverse hcoordinates residual supportMatrix hinputSize hscalarSize
    hresidualSize hsupportSize hmodel htrace).1

end CorruptedFieldRecovery
