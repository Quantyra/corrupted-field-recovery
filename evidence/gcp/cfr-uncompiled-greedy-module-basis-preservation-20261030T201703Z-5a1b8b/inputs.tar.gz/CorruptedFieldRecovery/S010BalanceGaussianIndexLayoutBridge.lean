import CorruptedFieldRecovery.S010BalanceGaussianRawSolverBridge
import CorruptedFieldRecovery.S010BalanceRawInputLayout
import Mathlib.Logic.Equiv.Fin.Basic

namespace CorruptedFieldRecovery

/-- The row-list order is exactly the inverse image of increasing finite row
indices under the Gaussian row equivalence. The product flattening is
slot-major, then first coordinate, then second coordinate. -/
theorem actualBalanceGaussianRowList_eq_ofFn_symm (s : Nat) :
    actualBalanceRowList s =
      List.ofFn (fun row : Fin (4 * ((3 * s) * (3 * s))) =>
        (actualBalanceGaussianRowEquiv s).symm row) := by
  rw [List.ofFn_mul]
  simp [actualBalanceRowList, actualBalanceCoordinateList,
    actualBalanceGaussianRowEquiv, finProdFinEquiv, List.ofFn_mul]

/-- The column-list order is exactly the inverse image of increasing finite
column indices under the Gaussian column equivalence: first matrix row, then
matrix column. -/
theorem actualBalanceGaussianColumnList_eq_ofFn_symm (s : Nat) :
    actualBalanceColumnList s =
      List.ofFn (fun col : Fin ((3 * s) * (3 * s)) =>
        (actualBalanceGaussianColumnEquiv s).symm col) := by
  rw [List.ofFn_mul]
  simp [actualBalanceColumnList, actualBalanceCoordinateList,
    actualBalanceGaussianColumnEquiv, finProdFinEquiv, List.ofFn_mul]

/-- Looking up a finite row index in the serialized row order returns the
corresponding physical four-slot row. -/
theorem actualBalanceGaussianRowList_getElem?_equiv (s : Nat)
    (row : Fin (4 * ((3 * s) * (3 * s)))) :
    (actualBalanceRowList s)[row.val]? =
      some ((actualBalanceGaussianRowEquiv s).symm row) := by
  rw [actualBalanceGaussianRowList_eq_ofFn_symm]
  simp

/-- Looking up a finite column index in the serialized column order returns
the corresponding matrix-entry coordinate pair. -/
theorem actualBalanceGaussianColumnList_getElem?_equiv (s : Nat)
    (col : Fin ((3 * s) * (3 * s))) :
    (actualBalanceColumnList s)[col.val]? =
      some ((actualBalanceGaussianColumnEquiv s).symm col) := by
  rw [actualBalanceGaussianColumnList_eq_ofFn_symm]
  simp

/-- Every nested-array cell in the serializer agrees with the corresponding
entry of the reindexed finite Gaussian matrix. This closes the position
correspondence between the declared row/column serialization order and the
solver's `Fin` indices. -/
theorem actualBalanceGaussianSerializedCell_eq_rawMatrix {s : Nat}
    (raw : RawCoefficientArray) (tape : FiveWordTape s)
    (row : Fin (4 * ((3 * s) * (3 * s))))
    (col : Fin ((3 * s) * (3 * s))) :
    ((actualBalanceSerializedCoefficientMatrix
        (decodeRawArray (n := 3 * s) raw) tape)[row.val]?.bind
      fun rowArray => rowArray[col.val]?) =
      some (actualBalanceGaussianRawMatrix raw tape row col) := by
  rw [actualBalanceSerializedCoefficientMatrix_row_spec
    (decodeRawArray (n := 3 * s) raw) tape row.val col.val
    ((actualBalanceGaussianRowEquiv s).symm row)
    ((actualBalanceGaussianColumnEquiv s).symm col)
    (actualBalanceGaussianRowList_getElem?_equiv s row)
    (actualBalanceGaussianColumnList_getElem?_equiv s col)]
  simp [actualBalanceGaussianRawMatrix, Matrix.reindex_apply,
    Matrix.submatrix_apply, actualBalanceRawInputCoefficientMatrix]

end CorruptedFieldRecovery
