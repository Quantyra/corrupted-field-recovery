import CorruptedFieldRecovery
import CorruptedFieldRecovery.CertificateSoundness

set_option pp.universes true
set_option pp.explicit false
set_option pp.fullNames true
set_option pp.piBinderTypes true
set_option pp.piBinderNames true
set_option pp.piBinderNames.hygienic true
set_option pp.proofs true
set_option pp.deepTerms true
set_option pp.maxSteps 1000000
set_option maxRecDepth 10000

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.RepresentationPayload"
#check @CorruptedFieldRecovery.RepresentationPayload
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.RepresentationPayload"
#print axioms CorruptedFieldRecovery.RepresentationPayload

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.RepresentationPayload.tensor"
#check @CorruptedFieldRecovery.RepresentationPayload.tensor
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.RepresentationPayload.tensor"
#print axioms CorruptedFieldRecovery.RepresentationPayload.tensor

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.RepresentationPayload.tensor_alternating"
#check @CorruptedFieldRecovery.RepresentationPayload.tensor_alternating
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.RepresentationPayload.tensor_alternating"
#print axioms CorruptedFieldRecovery.RepresentationPayload.tensor_alternating

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.increasingCoefficientCheck"
#check @CorruptedFieldRecovery.increasingCoefficientCheck
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.increasingCoefficientCheck"
#print axioms CorruptedFieldRecovery.increasingCoefficientCheck

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.accepted_certificate_sound"
#check @CorruptedFieldRecovery.accepted_certificate_sound
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.accepted_certificate_sound"
#print axioms CorruptedFieldRecovery.accepted_certificate_sound
