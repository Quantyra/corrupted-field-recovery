import CorruptedFieldRecovery
import CorruptedFieldRecovery.RawCertificate

set_option pp.universes true
set_option pp.explicit false
set_option pp.fullNames true
set_option pp.piBinderTypes true
set_option pp.piBinderNames true
set_option pp.piBinderNames.hygienic true
set_option pp.proofs true
set_option pp.deepTerms true
set_option pp.maxSteps 1000000
set_option maxRecDepth 10000

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.encode_decodeRawArray"
#check @CorruptedFieldRecovery.encode_decodeRawArray
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.encode_decodeRawArray"
#print axioms CorruptedFieldRecovery.encode_decodeRawArray

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.decodeRawArray_isAlternating"
#check @CorruptedFieldRecovery.decodeRawArray_isAlternating
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.decodeRawArray_isAlternating"
#print axioms CorruptedFieldRecovery.decodeRawArray_isAlternating

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.accepted_raw_array_decoders_equal"
#check @CorruptedFieldRecovery.accepted_raw_array_decoders_equal
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.accepted_raw_array_decoders_equal"
#print axioms CorruptedFieldRecovery.accepted_raw_array_decoders_equal
