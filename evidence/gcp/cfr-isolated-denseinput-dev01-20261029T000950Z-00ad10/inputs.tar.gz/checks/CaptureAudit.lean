import CorruptedFieldRecovery
import CorruptedFieldRecovery.DenseInput

set_option pp.universes true
set_option pp.explicit false
set_option pp.fullNames true
set_option pp.piBinderTypes true
set_option pp.piBinderNames true
set_option pp.piBinderNames.hygienic true
set_option pp.proofs true
set_option pp.deepTerms true
set_option pp.maxSteps 1000000
set_option maxRecDepth 10000

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.IncreasingTriple"
#check @CorruptedFieldRecovery.IncreasingTriple
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.IncreasingTriple"
#print axioms CorruptedFieldRecovery.IncreasingTriple

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.DenseInputPayload"
#check @CorruptedFieldRecovery.DenseInputPayload
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.DenseInputPayload"
#print axioms CorruptedFieldRecovery.DenseInputPayload

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.coordinateMonomial"
#check @CorruptedFieldRecovery.coordinateMonomial
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.coordinateMonomial"
#print axioms CorruptedFieldRecovery.coordinateMonomial

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.coordinateMonomial_apply"
#check @CorruptedFieldRecovery.coordinateMonomial_apply
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.coordinateMonomial_apply"
#print axioms CorruptedFieldRecovery.coordinateMonomial_apply

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.minorTensor"
#check @CorruptedFieldRecovery.minorTensor
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.minorTensor"
#print axioms CorruptedFieldRecovery.minorTensor

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.minorTensor_apply"
#check @CorruptedFieldRecovery.minorTensor_apply
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.minorTensor_apply"
#print axioms CorruptedFieldRecovery.minorTensor_apply

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.minorTensor_isAlternating"
#check @CorruptedFieldRecovery.minorTensor_isAlternating
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.minorTensor_isAlternating"
#print axioms CorruptedFieldRecovery.minorTensor_isAlternating

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.decodeDenseInput"
#check @CorruptedFieldRecovery.decodeDenseInput
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.decodeDenseInput"
#print axioms CorruptedFieldRecovery.decodeDenseInput
