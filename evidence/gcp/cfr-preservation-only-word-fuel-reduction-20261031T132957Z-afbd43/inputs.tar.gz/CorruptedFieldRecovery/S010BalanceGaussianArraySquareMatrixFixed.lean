import CorruptedFieldRecovery.S010BalanceGaussianArrayOrbitRun
import Mathlib.LinearAlgebra.Matrix.ToLin

namespace CorruptedFieldRecovery

/-! # Corrected square-matrix view of the actual greedy array

Disjoint uncompiled successor to `S010BalanceGaussianArraySquareMatrix`.
The three-pass result is destructured in its public theorem order, rather than
the different field order of the recursive summary. -/

def actualGreedyArraySquareMatrixFixed {m : Nat}
    (columns : Array (BinaryVector m)) : Matrix (Fin m) (Fin m) (ZMod 2) :=
  fun row column => columns[column.val]! row

theorem actualGreedyArraySquareMatrixFixed_colFamily {m : Nat}
    (columns : Array (BinaryVector m)) (hsize : columns.size = m) :
    (actualGreedyArraySquareMatrixFixed columns).col =
      actualGreedyArrayColumnFamily columns ∘ Fin.cast hsize.symm := by
  funext column row
  rfl

theorem actualGreedyArraySquareMatrixFixed_colRange {m : Nat}
    (columns : Array (BinaryVector m)) (hsize : columns.size = m) :
    Set.range (actualGreedyArraySquareMatrixFixed columns).col =
      Set.range (actualGreedyArrayColumnFamily columns) := by
  have hfamily := actualGreedyArraySquareMatrixFixed_colFamily columns hsize
  ext x
  constructor
  · rintro ⟨j, rfl⟩
    exact ⟨Fin.cast hsize.symm j, (congrFun hfamily j).symm⟩
  · rintro ⟨i, rfl⟩
    refine ⟨Fin.cast hsize i, ?_⟩
    rw [hfamily]
    simp

theorem actualGreedyArraySquareMatrixFixed_span_eq_top_of_array_top {m : Nat}
    (columns : Array (BinaryVector m)) (hsize : columns.size = m)
    (hspan : actualGreedyArrayColumnSubmodule columns = ⊤) :
    Submodule.span (ZMod 2)
      (Set.range (actualGreedyArraySquareMatrixFixed columns).col) = ⊤ := by
  have harray : Submodule.span (ZMod 2)
      (Set.range (actualGreedyArrayColumnFamily columns)) = ⊤ := by
    rw [← actualGreedyArrayColumnSubmodule_eq_span]
    exact hspan
  rw [actualGreedyArraySquareMatrixFixed_colRange columns hsize]
  exact harray

/-- The accepted three-pass run returns a square matrix whose columns span
physical coordinates, under the explicit annihilator hypotheses. -/
theorem actualGreedyArrayOrbitRun_threePass_squareMatrixFixed
    {s : Nat} (hs : 1 ≤ s)
    (T : Module.End (ZMod 2) (BinaryVector (3 * s)))
    (p : Polynomial (ZMod 2)) (hp : Irreducible p) (hmonic : p.Monic)
    (hdeg : p.natDegree = s) (hroot : Polynomial.aeval T p = 0) :
    ∃ outColumns outSelected,
      actualGreedyArrayOrbitRun T 3
        (#[] : Array (BinaryVector (3 * s))) #[] =
          some (outColumns, outSelected) ∧
      outColumns.size = 3 * s ∧
      Submodule.span (ZMod 2)
        (Set.range (actualGreedyArraySquareMatrixFixed outColumns).col) = ⊤ := by
  obtain ⟨outColumns, outSelected, outSpan, hrun, _, houtColumnsSize,
      houtDim, houtSpan, _⟩ :=
    actualGreedyArrayOrbitRun_threePass hs T p hp hmonic hdeg hroot
  have houtColumnsTop : actualGreedyArrayColumnSubmodule outColumns = ⊤ := by
    rw [houtSpan]
    apply Submodule.eq_top_of_finrank_eq
    simpa [BinaryVector, finrank_pi] using houtDim
  refine ⟨outColumns, outSelected, hrun, houtColumnsSize, ?_⟩
  exact actualGreedyArraySquareMatrixFixed_span_eq_top_of_array_top
    outColumns houtColumnsSize houtColumnsTop

end CorruptedFieldRecovery
