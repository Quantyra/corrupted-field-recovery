import CorruptedFieldRecovery.RawRabinIndexOperationalMachine
import CorruptedFieldRecovery.RawRabinScanExecutableCost
import CorruptedFieldRecovery.RawListRangeBitCost

/-! A short-circuit scan machine composed from the one-index Rabin machine.
The failed branch stops without a tail execution; the successful branch
continues on the remaining indices. Charges remain the declared index-check
charges. This does not charge construction of Lean's library `List.range` or
claim Lean/compiled-machine runtime or heap bounds. -/

namespace CorruptedFieldRecovery

/-- Short-circuit execution of a list of Rabin degree checks. -/
inductive RawRabinListMachineExec (modulus : Nat) :
    List Nat → Bool → Nat → Prop where
  | nil : RawRabinListMachineExec modulus [] true 0
  | failed (index : Nat) (tail : List Nat) (checkCharge : Nat)
      (hcheck : RawRabinIndexMachineExec modulus (index + 1)
        false checkCharge) :
      RawRabinListMachineExec modulus (index :: tail) false checkCharge
  | passed (index : Nat) (tail : List Nat) (result : Bool)
      (checkCharge tailCharge : Nat)
      (hcheck : RawRabinIndexMachineExec modulus (index + 1)
        true checkCharge)
      (htail : RawRabinListMachineExec modulus tail result tailCharge) :
      RawRabinListMachineExec modulus (index :: tail) result
        (checkCharge + tailCharge)

/-- Every list-machine execution agrees with the exact short-circuit
costed-list recurrence, in both Boolean result and total declared charge. -/
theorem rawRabinListMachineExec_sound
    {modulus : Nat} {indices : List Nat} {result : Bool} {charge : Nat}
    (hexec : RawRabinListMachineExec modulus indices result charge) :
    rawRabinCheckListBitCosted modulus indices = (result, charge) := by
  induction hexec with
  | nil => rfl
  | failed index tail checkCharge hcheck =>
      have hcheckEq := rawRabinIndexMachineExec_sound hcheck
      simp [rawRabinCheckListBitCosted, hcheckEq]
  | passed index tail result checkCharge tailCharge hcheck htail ih =>
      have hcheckEq := rawRabinIndexMachineExec_sound hcheck
      simp [rawRabinCheckListBitCosted, hcheckEq, ih]

/-- For modulus greater than one, every finite input list has an execution
that follows the same first-failure short-circuit order as `List.all`. -/
theorem rawRabinListMachineExec_exists
    (modulus : Nat) (hmodOne : 1 < modulus) (indices : List Nat) :
    RawRabinListMachineExec modulus indices
      (rawRabinCheckListBitCosted modulus indices).1
      (rawRabinCheckListBitCosted modulus indices).2 := by
  induction indices with
  | nil =>
      exact RawRabinListMachineExec.nil
  | cons index tail ih =>
      let check := rawRabinCheckIndexBitCosted modulus (index + 1)
      have hcheck : RawRabinIndexMachineExec modulus (index + 1)
          check.1 check.2 := by
        simpa [check] using
          (rawRabinIndexMachineExec_exists modulus (index + 1) hmodOne)
      cases hresult : check.1 with
      | false =>
          have hcheck' : RawRabinIndexMachineExec modulus (index + 1)
              false check.2 := by
            simpa [hresult] using hcheck
          simpa [rawRabinCheckListBitCosted, check, hresult] using
            (RawRabinListMachineExec.failed index tail check.2 hcheck')
      | true =>
          have hcheck' : RawRabinIndexMachineExec modulus (index + 1)
              true check.2 := by
            simpa [hresult] using hcheck
          simpa [rawRabinCheckListBitCosted, check, hresult] using
            (RawRabinListMachineExec.passed index tail
              (rawRabinCheckListBitCosted modulus tail).1
              check.2 (rawRabinCheckListBitCosted modulus tail).2
              hcheck' ih)

/-- The short-circuit machine returns exactly the same Boolean as the list
of degree predicates. -/
theorem rawRabinListMachineExec_refines_all
    {modulus : Nat} {indices : List Nat} {result : Bool} {charge : Nat}
    (hexec : RawRabinListMachineExec modulus indices result charge) :
    result = indices.all (fun i => decide
      (rawPolynomialGcd modulus
        (Nat.xor (rawCandidateFrobeniusAux modulus (i + 1) 2) 2) = 1)) := by
  have hsound := rawRabinListMachineExec_sound hexec
  have hresult := congrArg Prod.fst hsound
  exact hresult.symm.trans (rawRabinCheckListBitCosted_fst modulus indices)

/-- Every short-circuit list-machine execution inherits the accepted uniform
declared-charge bound, with the stated upper bound on every tested index. -/
theorem rawRabinListMachineExec_charge_le
    {modulus W q : Nat} {indices : List Nat} {result : Bool} {charge : Nat}
    (hmod : modulus ≠ 0) (hmodOne : 1 < modulus)
    (hmodWidth : modulus < 2 ^ W) (hW : 2 ≤ W)
    (hindices : ∀ i, i ∈ indices → i + 1 ≤ q)
    (hexec : RawRabinListMachineExec modulus indices result charge) :
    charge ≤ indices.length * rawRabinScanUniformCharge W q := by
  have hsound := rawRabinListMachineExec_sound hexec
  have hcharge : charge = (rawRabinCheckListBitCosted modulus indices).2 := by
    have h := congrArg Prod.snd hsound
    exact h.symm
  rw [hcharge]
  exact rawRabinCheckListBitCosted_cost_le
    hmod hmodOne hmodWidth hW indices hindices

/-- In particular, the machine can execute the public bounded degree list.
This result concerns the resulting list of indices; the separate range
builder's cost must still be charged at the outer verifier level. -/
theorem rawRabinRangeMachineExec_exists
    (modulus q : Nat) (hmodOne : 1 < modulus) :
    RawRabinListMachineExec modulus (List.range q)
      (rawRabinCheckListBitCosted modulus (List.range q)).1
      (rawRabinCheckListBitCosted modulus (List.range q)).2 := by
  exact rawRabinListMachineExec_exists modulus hmodOne (List.range q)

/-- The same machine execution accepts the explicit range builder's produced
list, which is the list consumed by the full verifier cost recurrence. This
does not assign a cost to Lean's library `List.range`. -/
theorem rawCandidateRabinScanMachineExec_exists {s : Nat}
    (candidate : RawFieldCandidate s)
    (hmodOne : 1 < rawFieldBitsToNat candidate.modulus) :
    RawRabinListMachineExec (rawFieldBitsToNat candidate.modulus)
      (rawListRangeBitCosted (s / 2)).1
      (rawRabinCheckListBitCosted (rawFieldBitsToNat candidate.modulus)
        (rawListRangeBitCosted (s / 2)).1).1
      (rawRabinCheckListBitCosted (rawFieldBitsToNat candidate.modulus)
        (rawListRangeBitCosted (s / 2)).1).2 := by
  exact rawRabinListMachineExec_exists
    (rawFieldBitsToNat candidate.modulus) hmodOne
    (rawListRangeBitCosted (s / 2)).1

/-- For any such candidate scan execution, its Boolean is the established
candidate-level Rabin predicate. The shape-check branch remains the outer
verifier's separate responsibility. -/
theorem rawCandidateRabinScanMachineExec_refines
    {s : Nat} (candidate : RawFieldCandidate s)
    {result : Bool} {charge : Nat}
    (hexec : RawRabinListMachineExec (rawFieldBitsToNat candidate.modulus)
      (rawListRangeBitCosted (s / 2)).1 result charge) :
    result = rawCandidateRabinCheck candidate := by
  have hlist := rawRabinListMachineExec_refines_all hexec
  have hrange : (rawListRangeBitCosted (s / 2)).1 = List.range (s / 2) :=
    rawListRangeBitCosted_fst (s / 2)
  rw [hrange] at hlist
  simpa [rawCandidateRabinCheck, rawCandidateFrobenius] using hlist

/-- On the branch where the actual shape gate passes, the machine scan result
is the full hfield-free fast-verifier Boolean. -/
theorem rawCandidateRabinScanMachineExec_refines_fastCheck
    {s : Nat} (candidate : RawFieldCandidate s)
    (hshape : rawFieldCandidateShapeCheck candidate = true)
    {result : Bool} {charge : Nat}
    (hexec : RawRabinListMachineExec (rawFieldBitsToNat candidate.modulus)
      (rawListRangeBitCosted (s / 2)).1 result charge) :
    result = rawFieldCandidateFastCheck candidate := by
  have hscan := rawCandidateRabinScanMachineExec_refines candidate hexec
  simp [rawFieldCandidateFastCheck, hshape, hscan]

end CorruptedFieldRecovery
