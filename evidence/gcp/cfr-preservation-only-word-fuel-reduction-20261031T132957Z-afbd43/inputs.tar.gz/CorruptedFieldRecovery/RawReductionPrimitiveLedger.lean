import CorruptedFieldRecovery.RawReductionOperationalRefinement

/-! An explicit primitive-event ledger for the accepted fuel-bounded
reduction machine. The ledger records the operands and results of each Nat
operation used by the source recurrence, and its event charges sum exactly to
the declared bit-cost recurrence. These are abstract charged primitives; the
file does not implement Nat operations on bit arrays or claim processor,
Lean-runtime, allocation, or heap costs. -/

namespace CorruptedFieldRecovery

/-- Primitive events in the declared reducer model. `comparePowTwo` denotes
the comparison against `2^exponent`; the other events retain exact inputs and
outputs of the corresponding source operation. -/
inductive RawReductionPrimitiveEvent where
  | comparePowTwo (value exponent : Nat) (result : Bool)
  | log2 (value output : Nat)
  | subtract (left right output : Nat)
  | powerOfTwo (exponent output : Nat)
  | multiply (left right output : Nat)
  | xor (left right output : Nat)
  deriving DecidableEq, Repr

/-- The declared bit charge assigned to each abstract primitive event. -/
def rawReductionPrimitiveEventCharge : RawReductionPrimitiveEvent → Nat
  | .comparePowTwo value exponent _ => rawNatBitWidth value + exponent + 1
  | .log2 value _ => 1 + rawNatBitWidth value
  | .subtract _ right _ => rawNatBitWidth right
  | .powerOfTwo _ output => rawNatBitWidth output
  | .multiply left right _ => rawNatMulBitCharge left right
  | .xor left right _ => rawNatBitWidth left + rawNatBitWidth right

/-- Charge of a finite primitive-event trace. -/
def rawReductionPrimitiveTraceCharge :
    List RawReductionPrimitiveEvent → Nat
  | [] => 0
  | event :: tail =>
      rawReductionPrimitiveEventCharge event +
        rawReductionPrimitiveTraceCharge tail

theorem rawReductionPrimitiveTraceCharge_append
    (left right : List RawReductionPrimitiveEvent) :
    rawReductionPrimitiveTraceCharge (left ++ right) =
      rawReductionPrimitiveTraceCharge left +
        rawReductionPrimitiveTraceCharge right := by
  induction left with
  | nil => simp [rawReductionPrimitiveTraceCharge]
  | cons event tail ih =>
      simp [rawReductionPrimitiveTraceCharge, ih, Nat.add_assoc]

/-- The source reducer's one-step cancellation together with its explicit
primitive events. -/
def rawReduceStepPrimitiveTrace (modulus degree current : Nat) :
    Nat × List RawReductionPrimitiveEvent :=
  let logarithm := Nat.log2 current
  let shift := logarithm - degree
  let power := 2 ^ shift
  let shifted := modulus * power
  let output := Nat.xor current shifted
  (output,
    [ .log2 current logarithm
    , .subtract logarithm degree shift
    , .powerOfTwo shift power
    , .multiply modulus power shifted
    , .xor current shifted output ])

/-- The event trace computes exactly the source cancellation result. -/
theorem rawReduceStepPrimitiveTrace_fst (modulus degree current : Nat) :
    (rawReduceStepPrimitiveTrace modulus degree current).1 =
      rawReduceStep modulus degree current := by
  rfl

/-- The primitive-event charges for one cancellation add to precisely the
existing declared cancellation charge. -/
theorem rawReduceStepPrimitiveTrace_charge (modulus degree current : Nat) :
    rawReductionPrimitiveTraceCharge
        (rawReduceStepPrimitiveTrace modulus degree current).2 =
      (rawReduceStepBitCosted modulus degree current).2 := by
  simp [rawReduceStepPrimitiveTrace, rawReductionPrimitiveTraceCharge,
    rawReductionPrimitiveEventCharge, rawReduceStepBitCosted,
    rawNatMulBitCharge, Nat.add_assoc, Nat.add_left_comm, Nat.add_comm]

/-- Canonical ordered primitive trace of the fuel-bounded reduction source
recurrence. A stop records the comparison only; an active level records the
comparison, cancellation events, then the recursive suffix. -/
def rawReduceFuelPrimitiveTrace (modulus degree : Nat) :
    Nat → Nat → Nat × List RawReductionPrimitiveEvent
  | 0, current => (current, [])
  | fuel + 1, current =>
      let comparison :=
        RawReductionPrimitiveEvent.comparePowTwo current degree
          (decide (current < 2 ^ degree))
      if current < 2 ^ degree then
        (current, [comparison])
      else
        let step := rawReduceStepPrimitiveTrace modulus degree current
        let rest := rawReduceFuelPrimitiveTrace modulus degree fuel step.1
        (rest.1, comparison :: (step.2 ++ rest.2))

/-- The primitive trace returns exactly the existing uninstrumented reducer
output, including zero-fuel and early-stop cases. -/
theorem rawReduceFuelPrimitiveTrace_fst
    (modulus degree fuel current : Nat) :
    (rawReduceFuelPrimitiveTrace modulus degree fuel current).1 =
      rawReduceFuel modulus degree fuel current := by
  induction fuel generalizing current with
  | zero => rfl
  | succ fuel ih =>
      by_cases hsmall : current < 2 ^ degree
      · simp [rawReduceFuelPrimitiveTrace, rawReduceFuel, hsmall]
      · simp [rawReduceFuelPrimitiveTrace, rawReduceFuel, hsmall,
          rawReduceStepPrimitiveTrace_fst, ih]

/-- Summing event charges gives exactly the paired bit-cost recurrence, not
an estimate or an independently assumed total. -/
theorem rawReduceFuelPrimitiveTrace_charge
    (modulus degree fuel current : Nat) :
    rawReductionPrimitiveTraceCharge
        (rawReduceFuelPrimitiveTrace modulus degree fuel current).2 =
      (rawReduceFuelBitCosted modulus degree fuel current).2 := by
  induction fuel generalizing current with
  | zero => rfl
  | succ fuel ih =>
      by_cases hsmall : current < 2 ^ degree
      · simp [rawReduceFuelPrimitiveTrace, rawReduceFuelBitCosted,
          rawReductionPrimitiveTraceCharge, rawReductionPrimitiveEventCharge,
          hsmall]
      · let step := rawReduceStepPrimitiveTrace modulus degree current
        have hstep := rawReduceStepPrimitiveTrace_charge modulus degree current
        have htail := ih step.1
        simp [rawReduceFuelPrimitiveTrace, rawReduceFuelBitCosted,
          rawReductionPrimitiveTraceCharge,
          rawReductionPrimitiveEventCharge, hsmall, step, hstep, htail,
          rawReductionPrimitiveTraceCharge_append,
          Nat.add_assoc]

/-- Any accepted abstract reducer execution has a matching operation ledger:
the event outputs equal its final output and the event charges sum to its
transition-label charge. The event semantics still leaves primitive
implementation and physical machine costs open. -/
theorem rawReductionMachineExec_refines_primitiveTrace
    {modulus degree fuel current output charge : Nat}
    (hexec : RawReductionMachineExec modulus degree
      ⟨fuel, current⟩ output charge) :
    (rawReduceFuelPrimitiveTrace modulus degree fuel current).1 = output ∧
      rawReductionPrimitiveTraceCharge
        (rawReduceFuelPrimitiveTrace modulus degree fuel current).2 = charge := by
  have hmachine := rawReductionMachineExec_sound hexec
  have htraceValue := rawReduceFuelPrimitiveTrace_fst
    modulus degree fuel current
  have htraceCharge := rawReduceFuelPrimitiveTrace_charge
    modulus degree fuel current
  constructor
  · have hcostValue := congrArg Prod.fst hmachine
    rw [rawReduceFuelBitCosted_fst] at hcostValue
    exact htraceValue.trans hcostValue
  · exact htraceCharge.trans (congrArg Prod.snd hmachine)

end CorruptedFieldRecovery
