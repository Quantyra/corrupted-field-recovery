import CorruptedFieldRecovery.RawRabinListOperationalMachine
import CorruptedFieldRecovery.RawCandidateVerifierUniformBound

/-! Full hfield-free candidate-check control flow, composed from the
instrumented shape gate, the explicit custom range recurrence, and the
short-circuit Rabin list machine. This is a proof-level abstract execution
relation over declared charges, not Lean or compiled-machine runtime/heap. -/

namespace CorruptedFieldRecovery

/-- A successful shape check enters the range-and-scan stages; a failed shape
check returns false immediately and does not construct the range or execute
any Rabin index. -/
inductive RawCandidateFastCheckMachineExec {s : Nat}
    (candidate : RawFieldCandidate s) : Bool → Nat → Prop where
  | rejectShape
      (hshape : (rawFieldCandidateShapeCheckBitCosted candidate).1 = false) :
      RawCandidateFastCheckMachineExec candidate false
        (rawFieldCandidateShapeCheckBitCosted candidate).2
  | scan (result : Bool) (scanCharge : Nat)
      (hshape : (rawFieldCandidateShapeCheckBitCosted candidate).1 = true)
      (hscan : RawRabinListMachineExec
        (rawFieldBitsToNat candidate.modulus)
        (rawListRangeBitCosted (s / 2)).1 result scanCharge) :
      RawCandidateFastCheckMachineExec candidate result
        ((rawFieldCandidateShapeCheckBitCosted candidate).2 +
          (rawListRangeBitCosted (s / 2)).2 + scanCharge)

/-- Shape success supplies the nonunit-modulus premise needed to start every
Rabin index machine in the following list. -/
private theorem rawFieldCandidateShapeCheckBitCosted_modulus_one
    {s : Nat} (candidate : RawFieldCandidate s)
    (hshape : (rawFieldCandidateShapeCheckBitCosted candidate).1 = true) :
    1 < rawFieldBitsToNat candidate.modulus := by
  rw [rawFieldCandidateShapeCheckBitCosted_fst] at hshape
  rcases (rawFieldCandidateShapeCheck_iff candidate).mp hshape with
    ⟨hs, _, htop, _, _⟩
  have hmodLower : 2 ^ s ≤ rawFieldBitsToNat candidate.modulus := by
    by_contra h
    have hlt : rawFieldBitsToNat candidate.modulus < 2 ^ s :=
      Nat.lt_of_not_ge h
    have htop' := htop
    rw [Nat.div_eq_of_lt hlt] at htop'
    norm_num at htop'
  have htwo : 2 ≤ 2 ^ s := by
    have hpow : 2 ^ 1 ≤ 2 ^ s :=
      Nat.pow_le_pow_right (by decide : 0 < 2) hs
    simpa using hpow
  omega

/-- Every full candidate-machine execution agrees with the exact full
costed verifier, including shape rejection and conditional later work. -/
theorem rawCandidateFastCheckMachineExec_sound {s : Nat}
    {candidate : RawFieldCandidate s} {result : Bool} {charge : Nat}
    (hexec : RawCandidateFastCheckMachineExec candidate result charge) :
    rawFieldCandidateFastCheckFullBitCosted candidate = (result, charge) := by
  cases hexec with
  | rejectShape hshape =>
      simp [rawFieldCandidateFastCheckFullBitCosted, hshape]
  | scan result scanCharge hshape hscan =>
      have hscanEq := rawRabinListMachineExec_sound hscan
      simp [rawFieldCandidateFastCheckFullBitCosted, hshape, hscanEq]

/-- Every candidate has a full machine execution. A failed structural gate
uses only its shape charge; a successful gate uses the actual range-builder
output and the short-circuit list execution. -/
theorem rawCandidateFastCheckMachineExec_exists {s : Nat}
    (candidate : RawFieldCandidate s) :
    RawCandidateFastCheckMachineExec candidate
      (rawFieldCandidateFastCheckFullBitCosted candidate).1
      (rawFieldCandidateFastCheckFullBitCosted candidate).2 := by
  by_cases hpass : (rawFieldCandidateShapeCheckBitCosted candidate).1 = true
  · have hmodOne := rawFieldCandidateShapeCheckBitCosted_modulus_one
      candidate hpass
    have hscan := rawRabinListMachineExec_exists
      (rawFieldBitsToNat candidate.modulus) hmodOne
      (rawListRangeBitCosted (s / 2)).1
    simpa [rawFieldCandidateFastCheckFullBitCosted, hpass] using
      (RawCandidateFastCheckMachineExec.scan candidate
        (rawRabinCheckListBitCosted (rawFieldBitsToNat candidate.modulus)
          (rawListRangeBitCosted (s / 2)).1).1
        (rawRabinCheckListBitCosted (rawFieldBitsToNat candidate.modulus)
          (rawListRangeBitCosted (s / 2)).1).2
        hpass hscan)
  · have hfail : (rawFieldCandidateShapeCheckBitCosted candidate).1 = false := by
      cases h : (rawFieldCandidateShapeCheckBitCosted candidate).1 <;> simp_all
    simpa [rawFieldCandidateFastCheckFullBitCosted, hfail] using
      (RawCandidateFastCheckMachineExec.rejectShape candidate hfail)

/-- The complete abstract machine returns exactly the hfield-free fast
candidate-verifier Boolean. -/
theorem rawCandidateFastCheckMachineExec_refines_fastCheck {s : Nat}
    (candidate : RawFieldCandidate s) {result : Bool} {charge : Nat}
    (hexec : RawCandidateFastCheckMachineExec candidate result charge) :
    result = rawFieldCandidateFastCheck candidate := by
  have hsound := rawCandidateFastCheckMachineExec_sound hexec
  have hresult := congrArg Prod.fst hsound
  exact hresult.symm.trans
    (rawFieldCandidateFastCheckFullBitCosted_fst candidate)

/-- The composed execution accepts exactly the mathematically valid fast
candidate certificates. This transports the already-proved checker theorem
through the explicit shape-reject/scan execution relation; it adds no
irreducibility premise to the executable gate. -/
theorem rawCandidateFastCheckMachineExec_accepts_iff_valid {s : Nat}
    (candidate : RawFieldCandidate s) {result : Bool} {charge : Nat}
    (hexec : RawCandidateFastCheckMachineExec candidate result charge) :
    result = true ↔ rawFieldCandidateValid candidate := by
  rw [rawCandidateFastCheckMachineExec_refines_fastCheck candidate hexec]
  exact rawFieldCandidateFastCheck_eq_true_iff_valid candidate

/-- Every full machine execution inherits the established fifth-degree
declared-charge envelope, including candidates rejected at the shape gate. -/
theorem rawCandidateFastCheckMachineExec_charge_le {s : Nat}
    (candidate : RawFieldCandidate s) {result : Bool} {charge : Nat}
    (hexec : RawCandidateFastCheckMachineExec candidate result charge) :
    charge ≤ 2000000 *
      (s + candidate.modulus.size + candidate.scalar.size + 4) ^ 5 := by
  have hsound := rawCandidateFastCheckMachineExec_sound hexec
  have hcharge : charge =
      (rawFieldCandidateFastCheckFullBitCosted candidate).2 := by
    have h := congrArg Prod.snd hsound
    exact h.symm
  rw [hcharge]
  exact rawFieldCandidateFastCheckFullBitCosted_degree_five_bound candidate

end CorruptedFieldRecovery
