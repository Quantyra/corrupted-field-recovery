import CorruptedFieldRecovery.S010BalanceGaussianArrayOrbitBasis

namespace CorruptedFieldRecovery

/-! # Corrected basis witness for the actual three-pass array output

Disjoint uncompiled successor to `S010BalanceGaussianArrayOrbitBasisRun`.
The tuple destructuring below follows the public theorem's order: run result,
selected length, column length, finrank, span equality, invariance. -/

theorem actualGreedyArrayOrbitRun_threePass_basisWitnessFixed
    {s : Nat} (hs : 1 ≤ s)
    (T : Module.End (ZMod 2) (BinaryVector (3 * s)))
    (p : Polynomial (ZMod 2)) (hp : Irreducible p) (hmonic : p.Monic)
    (hdeg : p.natDegree = s) (hroot : Polynomial.aeval T p = 0) :
    ∃ outColumns outSelected,
      ∃ (outBasis : Basis (Fin outColumns.size) (ZMod 2)
        (BinaryVector (3 * s))),
      actualGreedyArrayOrbitRun T 3
        (#[] : Array (BinaryVector (3 * s))) #[] =
          some (outColumns, outSelected) ∧
      outColumns.size = 3 * s ∧
      actualGreedyArrayColumnSubmodule outColumns = ⊤ := by
  obtain ⟨outColumns, outSelected, outSpan, hrun, _, houtColumnsSize,
      houtDim, houtSpan, _⟩ :=
    actualGreedyArrayOrbitRun_threePass hs T p hp hmonic hdeg hroot
  have houtColumnsTop : actualGreedyArrayColumnSubmodule outColumns = ⊤ := by
    rw [houtSpan]
    apply Submodule.eq_top_of_finrank_eq
    simpa [finrank_pi] using houtDim
  refine ⟨outColumns, outSelected,
    actualGreedyArrayColumnBasis outColumns houtColumnsSize houtColumnsTop,
    hrun, houtColumnsSize, houtColumnsTop⟩

end CorruptedFieldRecovery
