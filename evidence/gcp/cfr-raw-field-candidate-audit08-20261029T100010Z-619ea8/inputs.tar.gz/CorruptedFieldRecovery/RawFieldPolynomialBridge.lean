import CorruptedFieldRecovery.RawFieldCandidate
import Mathlib.Data.Nat.Bitwise
import Mathlib.Algebra.Polynomial.FieldDivision
import Mathlib.Algebra.Field.ZMod

/-! Semantic bridge from raw natural-number bit masks to binary polynomials.

The decoder is proof-only. It interprets bit `i` as the coefficient of `X^i`.
The raw candidate checker itself remains finite Boolean/Nat computation.
-/

namespace CorruptedFieldRecovery

open Polynomial

noncomputable def rawMaskPolynomial (n : Nat) : Polynomial (ZMod 2) :=
  if n = 0 then 0 else
    C (if n.bodd then 1 else 0) + X * rawMaskPolynomial n.div2
termination_by n
decreasing_by
  exact Nat.div_lt_self (Nat.pos_of_ne_zero (by assumption)) (by decide)

theorem rawMaskPolynomial_bit (b : Bool) (n : Nat) :
    rawMaskPolynomial (Nat.bit b n) = C (if b then 1 else 0) + X * rawMaskPolynomial n := by
  cases b <;> simp [rawMaskPolynomial, Nat.bit_bodd_div2, Nat.bodd_bit,
    Nat.div2_bit, Nat.bit]

theorem rawMaskPolynomial_shift (n : Nat) :
    rawMaskPolynomial (2 * n) = X * rawMaskPolynomial n := by
  by_cases hn : n = 0
  · subst n
    simp [rawMaskPolynomial]
  · have hn' : 2 * n ≠ 0 := by omega
    simp [rawMaskPolynomial, hn, hn', Nat.bodd, Nat.div2]

theorem rawMaskPolynomial_xor (a b : Nat) :
    rawMaskPolynomial (Nat.xor a b) = rawMaskPolynomial a + rawMaskPolynomial b := by
  by_cases ha : a = 0
  · subst a
    simp [rawMaskPolynomial]
  by_cases hb : b = 0
  · subst b
    simp [rawMaskPolynomial]
  rw [Nat.bitwise_of_ne_zero ha hb]
  rw [rawMaskPolynomial_bit]
  simp only [rawMaskPolynomial]
  rw [if_neg ha, if_neg hb]
  have hbit : C (if Nat.bodd a != Nat.bodd b then (1 : ZMod 2) else 0) =
      C (if Nat.bodd a then 1 else 0) + C (if Nat.bodd b then 1 else 0) := by
    cases Nat.bodd a <;> cases Nat.bodd b <;> norm_num
  rw [hbit]
  ring

theorem rawPolyMul_polynomial (a b : Nat) :
    rawMaskPolynomial (rawPolyMul a b) = rawMaskPolynomial a * rawMaskPolynomial b := by
  induction b using Nat.strong_induction_on generalizing a with
  | h b ih =>
    by_cases hb : b = 0
    · subst b
      simp [rawPolyMul, rawMaskPolynomial]
    rw [rawPolyMul]
    simp only [if_neg hb]
    rw [rawMaskPolynomial_xor, rawMaskPolynomial_shift]
    have ih' := ih (b / 2) (Nat.div_lt_self (Nat.pos_of_ne_zero hb) (by decide)) a
    rw [ih']
    have hbit : rawMaskPolynomial (if b % 2 = 1 then a else 0) =
        (if b % 2 = 1 then rawMaskPolynomial a else 0) := by
      split <;> simp [rawMaskPolynomial]
    rw [hbit]
    have hbpoly := rawMaskPolynomial b
    simp [rawMaskPolynomial, hb] at hbpoly
    rw [hbpoly]
    by_cases hodd : b % 2 = 1 <;> simp [hodd] <;> ring

end CorruptedFieldRecovery
