import CorruptedFieldRecovery.S010BalanceGaussianArrayFlagExecutionTrace

namespace CorruptedFieldRecovery

/-- The counted selector evaluates no more row predicates than there are row
indices. Every evaluated predicate reads one flag; only a fresh row evaluates
the coefficient-array view. The charge counts these designated events; it is
not a complete Lean source-instruction or evaluator-cost count. -/
theorem actualBalanceGaussianFlagCountedFindUnusedRow_trace_bounds
    {m n : Nat} (cells : Array (Array (ZMod 2))) (flags : Array Bool)
    (column : Fin n) (rows : List (Fin m)) :
    let t := (actualBalanceGaussianFlagCountedFindUnusedRow
      cells flags column rows).2
    t.selectorPredicateTests ≤ rows.length ∧
      t.booleanFlagReads = t.selectorPredicateTests ∧
      t.selectorCoefficientViews ≤ t.selectorPredicateTests := by
  induction rows with
  | nil => simp [actualBalanceGaussianFlagCountedFindUnusedRow,
      actualBalanceGaussianFlagExecutionTrace.zero]
  | cons row rows ih =>
      obtain ⟨htests, hreads, hviews⟩ := ih
      cases hflag : actualBalanceGaussianUsedFlagView flags row with
      | true =>
          simp [actualBalanceGaussianFlagCountedFindUnusedRow,
            hflag, actualBalanceGaussianFlagExecutionTrace.add,
            actualBalanceGaussianFlagUsedProbe]
          omega
      | false =>
          by_cases hvalue : actualBalanceGaussianArrayView cells row column = 1
          · simp [actualBalanceGaussianFlagCountedFindUnusedRow,
              hflag, hvalue, actualBalanceGaussianFlagFreshProbe]
          · simp [actualBalanceGaussianFlagCountedFindUnusedRow,
              hflag, hvalue, actualBalanceGaussianFlagExecutionTrace.add,
              actualBalanceGaussianFlagFreshProbe]
            omega

/-- Per-call selector bounds after charging construction of the `Fin` row
list. -/
theorem actualBalanceGaussianFlagCountedFirstUnusedPivotRow_trace_bounds
    {m n : Nat} (cells : Array (Array (ZMod 2))) (flags : Array Bool)
    (column : Fin n) :
    let t := (actualBalanceGaussianFlagCountedFirstUnusedPivotRow
      (m := m) cells flags column).2
    t.rowIndexListNodes = m ∧
      t.selectorPredicateTests ≤ m ∧
      t.booleanFlagReads = t.selectorPredicateTests ∧
      t.selectorCoefficientViews ≤ t.selectorPredicateTests := by
  let rows := List.ofFn fun row : Fin m => row
  have h := actualBalanceGaussianFlagCountedFindUnusedRow_trace_bounds
    (m := m) cells flags column rows
  have hlength : rows.length = m := by
    simp [rows, List.length_ofFn]
  simp only [actualBalanceGaussianFlagCountedFirstUnusedPivotRow,
    actualBalanceGaussianFlagExecutionTrace.add,
    actualBalanceGaussianFlagExecutionTrace.zero]
  rw [hlength] at h
  exact ⟨rfl, h.1, h.2.1, h.2.2⟩

/-- Componentwise trace facts for the complete instrumented flag scan. The
selector work is actual recursive execution; pivot work and allocations are
the conservative per-pivot charges attached by the instrumented scan. -/
theorem actualBalanceGaussianFlagColumnScanInstrumented_trace_components
    {m n : Nat} (cells : Array (Array (ZMod 2))) (flags : Array Bool)
    (columns : List (Fin n)) :
    let run := actualBalanceGaussianFlagColumnScanInstrumented (m := m) cells flags columns
    let t := run.2
    let p := run.1.2.length
    t.columnsProcessed = columns.length ∧
      t.rowIndexListNodes = columns.length * m ∧
      t.selectorPredicateTests ≤ columns.length * m ∧
      t.booleanFlagReads = t.selectorPredicateTests ∧
      t.selectorCoefficientViews ≤ t.selectorPredicateTests ∧
      t.pivotUpdates = p ∧
      t.pivotCoefficientViewsUpper = 3 * p * m * n ∧
      t.pivotRowComparisons = p * m * n ∧
      t.fieldMultiplicationsUpper = p * m * n ∧
      t.fieldAdditionsUpper = p * m * n ∧
      t.coefficientCellWrites = p * m * n ∧
      t.matrixRowArrayWrites = p * m ∧
      t.flagUpdateReadsUpper = p * m ∧
      t.flagCellComparisons = p * m ∧
      t.flagCellWrites = p * m ∧
      t.newMatrixArraySlots = p * m * (n + 1) ∧
      t.newFlagArraySlots = p * m ∧
      t.initialFlagArraySlots = 0 ∧
      t.initialFlagCellWrites = 0 ∧
      t.transcriptCons = p ∧
      t.columnListNodes = 0 := by
  induction columns generalizing cells flags with
  | nil =>
      simp [actualBalanceGaussianFlagColumnScanInstrumented,
        actualBalanceGaussianFlagExecutionTrace.zero]
  | cons column columns ih =>
      let selected := actualBalanceGaussianFlagCountedFirstUnusedPivotRow
        (m := m) cells flags column
      have hselected := actualBalanceGaussianFlagCountedFirstUnusedPivotRow_eq
        (m := m) cells flags column
      have hsearch := actualBalanceGaussianFlagCountedFirstUnusedPivotRow_trace_bounds
        (m := m) cells flags column
      cases hpivot : selected.1 with
      | none =>
          simp only [actualBalanceGaussianFlagColumnScanInstrumented,
            selected, hpivot, actualBalanceGaussianFlagExecutionTrace.add,
            actualBalanceGaussianFlagExecutionTrace.zero]
          have htail := ih cells flags
          simp only [hsearch, htail]
          omega
      | some row =>
          have htail := ih
            (actualBalanceGaussianArrayPivotRow cells row column)
            (actualBalanceGaussianSetUsedFlag flags row)
          simp only [actualBalanceGaussianFlagColumnScanInstrumented,
            selected, hpivot, actualBalanceGaussianFlagExecutionTrace.add,
            actualBalanceGaussianFlagPivotUpdateCharge,
            actualBalanceGaussianFlagExecutionTrace.zero]
          simp only [hsearch, htail]
          omega

/-- The declared primitive charge of the generic instrumented scan is bounded
using the actual pivot count `p`; list cells for the caller-supplied column
list are not included here. -/
theorem actualBalanceGaussianFlagColumnScanInstrumented_sourceUpper
    {m n : Nat} (cells : Array (Array (ZMod 2))) (flags : Array Bool)
    (columns : List (Fin n)) :
    (actualBalanceGaussianFlagColumnScanInstrumented (m := m)
      cells flags columns).2.sourceOperationUpper ≤
      5 * columns.length * m +
        10 * (actualBalanceGaussianFlagColumnScanInstrumented (m := m)
          cells flags columns).1.2.length * m * n +
        4 * (actualBalanceGaussianFlagColumnScanInstrumented (m := m)
          cells flags columns).1.2.length * m +
        2 * (actualBalanceGaussianFlagColumnScanInstrumented (m := m)
          cells flags columns).1.2.length + columns.length := by
  let run := actualBalanceGaussianFlagColumnScanInstrumented (m := m) cells flags columns
  let t := run.2
  let p := run.1.2.length
  have hc := actualBalanceGaussianFlagColumnScanInstrumented_trace_components
    cells flags columns
  simp only [run, t, p] at hc ⊢
  rcases hc with ⟨hcols, hrows, htests, hreads, hviews, hpiv, hviewp,
    hcomp, hmul, hadd, hwrites, houter, hflagreads, hflagcomp, hflagwrites,
    hmatrixslots, hflagslots, hinit, hinitwrite, htranscript, hlist⟩
  simp [actualBalanceGaussianFlagExecutionTrace.sourceOperationUpper,
    hcols, hrows, hreads, hviews, hpiv, hviewp, hcomp, hmul, hadd,
    hwrites, houter, hflagreads, hflagcomp, hflagwrites, hinitwrite,
    htranscript, hlist]
  omega

/-- A scan has at most one successful pivot per listed column. This is the
executable trace consequence needed to eliminate `p` from the polynomial. -/
theorem actualBalanceGaussianFlagColumnScanInstrumented_pivots_le_columns
    {m n : Nat} (cells : Array (Array (ZMod 2))) (flags : Array Bool)
    (columns : List (Fin n)) :
    (actualBalanceGaussianFlagColumnScanInstrumented (m := m)
      cells flags columns).1.2.length ≤ columns.length := by
  have href := actualBalanceGaussianFlagColumnScanInstrumented_refines
    cells flags columns
  have htranscript := congrArg
    (fun out : ActualBalanceGaussianFlagScanOutput m n => out.2) href
  rw [htranscript]
  exact actualBalanceGaussianFlagColumnScan_pivotCount_le m cells flags columns

/-- Polynomial declared-charge theorem for the raw flag scan. Its trace comes
from the instrumented execution, including the initial false-flag allocation
and construction of the column list. This bounds only the primitive categories
in `ActualBalanceGaussianFlagExecutionTrace.sourceOperationUpper`; it does not
bound Fin-index arithmetic inside `List.ofFn`, loop/branch/call overhead,
implicit array bounds/default machinery beyond the explicitly charged views,
Lean runtime allocation headers, GC, stack space, or bit complexity. -/
theorem actualBalanceGaussianSerializedArrayFlagScanInstrumented_sourceUpper
    {s : Nat} (raw : RawCoefficientArray) (tape : FiveWordTape s) :
    (actualBalanceGaussianSerializedArrayFlagScanInstrumented raw tape).2.sourceOperationUpper ≤
      40 * (3 * s) ^ 6 + 36 * (3 * s) ^ 4 + 8 * (3 * s) ^ 2 := by
  let m := 4 * ((3 * s) * (3 * s))
  let k := (3 * s) * (3 * s)
  let cells := actualBalanceSerializedCoefficientMatrix
    (decodeRawArray (n := 3 * s) raw) tape
  let flags := actualBalanceGaussianEmptyUsedFlags m
  let columns := List.ofFn fun column : Fin k => column
  let run := actualBalanceGaussianFlagColumnScanInstrumented (m := m) cells flags columns
  let p := run.1.2.length
  have hp : p ≤ k := by
    dsimp [p, run, columns, k]
    simpa [List.length_ofFn] using
      actualBalanceGaussianFlagColumnScanInstrumented_pivots_le_columns
        (m := m) cells flags columns
  have hscan := actualBalanceGaussianFlagColumnScanInstrumented_sourceUpper
    (m := m) cells flags columns
  have hraw :
      (actualBalanceGaussianSerializedArrayFlagScanInstrumented
        raw tape).2.sourceOperationUpper ≤
        5 * k * m + 10 * p * m * k + 4 * p * m + 2 * p + 2 * k + m := by
    simpa [actualBalanceGaussianSerializedArrayFlagScanInstrumented,
      actualBalanceGaussianFlagExecutionTrace.sourceOperationUpper,
      m, k, cells, flags, columns, run, p] using hscan
  calc
    _ ≤ 5 * k * m + 10 * p * m * k + 4 * p * m + 2 * p + 2 * k + m := hraw
    _ ≤ 5 * k * m + 10 * k * m * k + 4 * k * m + 4 * k + m := by
      have h1 : p * m * k ≤ k * m * k :=
        Nat.mul_le_mul_right k (Nat.mul_le_mul_right m hp)
      have h2 : p * m ≤ k * m := Nat.mul_le_mul_right m hp
      have h3 : 2 * p ≤ 2 * k := Nat.mul_le_mul_left 2 hp
      nlinarith [h1, h2, h3]
    _ = 40 * (3 * s) ^ 6 + 36 * (3 * s) ^ 4 + 8 * (3 * s) ^ 2 := by
      simp [k, m]
      ring

end CorruptedFieldRecovery
