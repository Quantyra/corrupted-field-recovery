import CorruptedFieldRecovery
import CorruptedFieldRecovery.ProbabilityFiveTupleAssembly

set_option pp.universes true
set_option pp.explicit false
set_option pp.fullNames true
set_option pp.piBinderTypes true
set_option pp.piBinderNames true
set_option pp.piBinderNames.hygienic true
set_option pp.proofs true
set_option pp.deepTerms true
set_option pp.maxSteps 1000000
set_option maxRecDepth 10000

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.goodFifthScalars"
#check @CorruptedFieldRecovery.goodFifthScalars
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.goodFifthScalars"
#print axioms CorruptedFieldRecovery.goodFifthScalars

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.goodFiveTupleProduct"
#check @CorruptedFieldRecovery.goodFiveTupleProduct
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.goodFiveTupleProduct"
#print axioms CorruptedFieldRecovery.goodFiveTupleProduct

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.card_goodFiveTupleProduct_lower"
#check @CorruptedFieldRecovery.card_goodFiveTupleProduct_lower
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.card_goodFiveTupleProduct_lower"
#print axioms CorruptedFieldRecovery.card_goodFiveTupleProduct_lower
