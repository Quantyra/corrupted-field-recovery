import CorruptedFieldRecovery.ProbabilityCanonicalFlatTupleBridge
import CorruptedFieldRecovery.TranslateScalarCounts
import CorruptedFieldRecovery.ProperSubfieldCounts
import Mathlib.Tactic

/-! Concrete finite count for the four-word event and the independent fifth
scalar. The fifth good set is defined by the actual generator and translate
predicates; no probability or target numeric bound is assumed here. -/

namespace CorruptedFieldRecovery

noncomputable section

variable (K : Type*) [Field K] [Fintype K] [DecidableEq K]
  [Algebra BinaryField K] [FiniteDimensional BinaryField K] [Finite K]

/-- Fifth scalar indices which are generators and avoid every bad translate. -/
def goodFifthScalars (U : Submodule BinaryField (KTriple K)) : Finset K :=
  Finset.univ \ (nonGenerators K ∪
    badTranslateScalars K (supportCoordinateFinset K U))

/-- The five-event finite set: a distinct flat four-word event paired with an
independent fifth scalar index. -/
def goodFiveTupleProduct (A : Finset (FieldTriple K))
    (D : Finset K) (U : Submodule BinaryField (KTriple K)) :
    Finset ((Fin 4 → FieldTriple K) × K) :=
  (canonicalGoodFourFlatImage K A D).product (goodFifthScalars K U)

/-- Exact product cardinality and the two accepted component bounds combine
without conditional probability. `D` is supplied to the four-word generator
event; in the intended application it is `nonGenerators K`. -/
theorem card_goodFiveTupleProduct_lower
    (A : Finset (FieldTriple K)) (U : Submodule BinaryField (KTriple K))
    (r : Nat) (hr : Module.finrank BinaryField U = r) :
    ((A.card - (nonGenerators K).card * Fintype.card K ^ 2) *
      ((A.card - Fintype.card K ^ 2) *
        ((A.card - Fintype.card K) * (A.card - 1)))) *
      (Fintype.card K -
        ((∑ d ∈ properDegrees K, 2 ^ d) + (2 ^ (2 * r) - 1))) ≤
      (goodFiveTupleProduct K A (nonGenerators K) U).card := by
  classical
  let E := canonicalGoodFourFlatImage K A (nonGenerators K)
  let G := goodFifthScalars K U
  have hfour := card_canonicalGoodFourGeneratorFlatImage_lower K A
  have hgen := card_nonGenerators_le_proper_degree_sum K
  have htrans := card_badTranslateScalars_submodule_le K U
  have hbad : (nonGenerators K ∪
      badTranslateScalars K (supportCoordinateFinset K U)).card ≤
      (∑ d ∈ properDegrees K, 2 ^ d) + (2 ^ (2 * r) - 1) := by
    calc
      _ ≤ (nonGenerators K).card +
          (badTranslateScalars K (supportCoordinateFinset K U)).card :=
        Finset.card_union_le _ _
      _ ≤ (∑ d ∈ properDegrees K, 2 ^ d) + (2 ^ (2 * r) - 1) := by
        rw [hr] at htrans
        omega
  have hgood : Fintype.card K -
      ((∑ d ∈ properDegrees K, 2 ^ d) + (2 ^ (2 * r) - 1)) ≤ G.card := by
    let B := nonGenerators K ∪
      badTranslateScalars K (supportCoordinateFinset K U)
    have hsplit := Finset.card_filter_add_card_filter_not
      (s := (Finset.univ : Finset K)) (fun x : K => x ∈ B)
    have hbad' : B.card ≤
        (∑ d ∈ properDegrees K, 2 ^ d) + (2 ^ (2 * r) - 1) := by
      simpa [B] using hbad
    have hG : (Finset.univ.filter fun x : K => x ∉ B) = G := by
      ext x
      simp [G, goodFifthScalars, B]
    rw [hG, Finset.card_univ] at hsplit
    omega
  have hproduct : (E.card * G.card) ≤ (E.product G).card := by
    simp [Finset.card_product]
  have hfour' :
      (A.card - (nonGenerators K).card * Fintype.card K ^ 2) *
        ((A.card - Fintype.card K ^ 2) *
          ((A.card - Fintype.card K) * (A.card - 1))) ≤ E.card := by
    simpa [E] using hfour
  calc
    _ ≤ E.card * G.card := Nat.mul_le_mul hfour' hgood
    _ = (E.product G).card := by simp [Finset.card_product]
    _ = (goodFiveTupleProduct K A (nonGenerators K) U).card := by
      rfl

end

end CorruptedFieldRecovery
