import CorruptedFieldRecovery.RawVerifier
import CorruptedFieldRecovery.RawFieldCoordinateBridge
import CorruptedFieldRecovery.FourContractions

/-! S011 trace-compatible coefficient validation.

The supplied compatible array is checked against coefficients computed from
the accepted quotient-field scalar and the checked physical coordinates.  The
expected tensor is decoded from those computed alternating coefficients; no
identity is stored in the certificate.  The construction is noncomputable at
the current quotient-field boundary, so this is a formal finite coefficient
checker, not yet a serialized bit-level implementation of quotient arithmetic.
-/

namespace CorruptedFieldRecovery

open AdjoinRoot

/-- The expected increasing coefficients, evaluated from the actual
candidate field, nonzero scalar, and accepted physical coordinate map. -/
noncomputable def rawTraceDetPayload {s : Nat}
    (candidate : RawFieldCandidate s)
    (hfield : rawFieldCandidateCheck candidate = true)
    (forward inverse : RawCoordinateMatrix)
    (hcoordinates : rawCoordinateMatrixCheck (n := 3 * s) forward inverse = true) :
    DenseInputPayload (3 * s) := by
  letI : Fact (Irreducible (rawCandidateModulus candidate)) :=
    ⟨accepted_rawCandidateModulus_irreducible candidate hfield⟩
  let K := AdjoinRoot (rawCandidateModulus candidate)
  let coords := accepted_rawCandidatePhysicalCoordinates candidate hfield
    forward inverse hcoordinates
  let c : K := AdjoinRoot.mk (rawCandidateModulus candidate)
    (rawCandidateScalar candidate)
  intro t
  exact Algebra.trace (ZMod 2) K
    (c * fieldDet3 (coords.symm (coordinateVectorCode (increasingTripleI t)))
      (coords.symm (coordinateVectorCode (increasingTripleJ t)))
      (coords.symm (coordinateVectorCode (increasingTripleK t))))

/-- The alternating tensor represented by the computed finite coefficient
table. Its alternation follows from the dense minor decoder. -/
noncomputable def rawTraceDetTensor {s : Nat}
    (candidate : RawFieldCandidate s)
    (hfield : rawFieldCandidateCheck candidate = true)
    (forward inverse : RawCoordinateMatrix)
    (hcoordinates : rawCoordinateMatrixCheck (n := 3 * s) forward inverse = true) :
    BinaryTensor (3 * s) :=
  decodeDenseInput (rawTraceDetPayload candidate hfield forward inverse hcoordinates)

theorem rawTraceDetTensor_alternating {s : Nat}
    (candidate : RawFieldCandidate s)
    (hfield : rawFieldCandidateCheck candidate = true)
    (forward inverse : RawCoordinateMatrix)
    (hcoordinates : rawCoordinateMatrixCheck (n := 3 * s) forward inverse = true) :
    IsAlternating (rawTraceDetTensor candidate hfield forward inverse hcoordinates) :=
  decodeDenseInput_isAlternating _

/-- Finite comparison of the actual compatible array's decoded coefficients
with the coefficients calculated from the accepted field and coordinates. -/
noncomputable def rawTraceCompatibleCheck {s : Nat}
    (compatible : RawBinaryArray)
    (candidate : RawFieldCandidate s)
    (hfield : rawFieldCandidateCheck candidate = true)
    (forward inverse : RawCoordinateMatrix)
    (hcoordinates : rawCoordinateMatrixCheck (n := 3 * s) forward inverse = true) : Bool :=
  decide (∀ t : IncreasingTriple (3 * s),
    encodeDenseInput (decodeRawArray (n := 3 * s) compatible) t =
      rawTraceDetPayload candidate hfield forward inverse hcoordinates t)

theorem accepted_rawTraceCompatibleCheck {s : Nat}
    (compatible : RawBinaryArray)
    (candidate : RawFieldCandidate s)
    (hfield : rawFieldCandidateCheck candidate = true)
    (forward inverse : RawCoordinateMatrix)
    (hcoordinates : rawCoordinateMatrixCheck (n := 3 * s) forward inverse = true)
    (hcheck : rawTraceCompatibleCheck compatible candidate hfield forward inverse
      hcoordinates = true) :
    decodeRawArray (n := 3 * s) compatible =
      rawTraceDetTensor candidate hfield forward inverse hcoordinates := by
  apply binaryTensor_ext_of_increasing_coefficients
  · exact decodeRawArray_isAlternating (n := 3 * s) compatible
  · exact rawTraceDetTensor_alternating candidate hfield forward inverse hcoordinates
  · intro i j k hij hjk
    let t : IncreasingTriple (3 * s) := ⟨((i, j), k), ⟨hij, hjk⟩⟩
    have heq : ∀ t : IncreasingTriple (3 * s),
        encodeDenseInput (decodeRawArray (n := 3 * s) compatible) t =
          rawTraceDetPayload candidate hfield forward inverse hcoordinates t :=
      of_decide_eq_true (by simpa [rawTraceCompatibleCheck] using hcheck)
    have hc := heq t
    have hd := encode_decodeRawArray (n := 3 * s) compatible t
    have ht := decodeDenseInput_code_coordinate
      (rawTraceDetPayload candidate hfield forward inverse hcoordinates) t
    change coefficient (decodeRawArray (n := 3 * s) compatible) i j k =
      coefficient (rawTraceDetTensor candidate hfield forward inverse hcoordinates) i j k
    rw [← encodeDenseInput_eq_semanticCoefficient, hd, hc]
    rw [← encodeDenseInput_eq_semanticCoefficient]
    simpa [rawTraceDetTensor] using ht

/-- S011 combined gate: the original raw decomposition verifier must accept,
and the compatible array must independently match the computed trace-field
coefficients. -/
noncomputable def rawTraceDecompositionCheck {s R : Nat}
    (p : RawDecomposition (3 * s) R)
    (candidate : RawFieldCandidate s)
    (hfield : rawFieldCandidateCheck candidate = true)
    (forward inverse : RawCoordinateMatrix)
    (hcoordinates : rawCoordinateMatrixCheck (n := 3 * s) forward inverse = true) : Bool :=
  rawDecompositionCheck p &&
    rawTraceCompatibleCheck p.compatible candidate hfield forward inverse hcoordinates

/-- An accepted combined gate proves the complete input identity with the
computed trace-determinant-compatible tensor and the explicitly factored
residual. It proves compatibility, not uniqueness or recovery completeness. -/
theorem accepted_rawTraceDecompositionCheck_sound {s R : Nat}
    (p : RawDecomposition (3 * s) R)
    (candidate : RawFieldCandidate s)
    (hfield : rawFieldCandidateCheck candidate = true)
    (forward inverse : RawCoordinateMatrix)
    (hcoordinates : rawCoordinateMatrixCheck (n := 3 * s) forward inverse = true)
    (hcheck : rawTraceDecompositionCheck p candidate hfield forward inverse
      hcoordinates = true) :
    ∀ x y z,
      decodeRawArray (n := 3 * s) p.input x y z =
        (rawTraceDetTensor candidate hfield forward inverse hcoordinates +
          pullback (decodeRawArray (n := p.supportDimension) p.residual)
            (rawSupportMap p.supportMatrix)) x y z := by
  simp only [rawTraceDecompositionCheck, Bool.and_eq_true] at hcheck
  have hdecomp := accepted_rawDecompositionCheck_sound p hcheck.1
  have hclean := accepted_rawTraceCompatibleCheck p.compatible candidate hfield
    forward inverse hcoordinates hcheck.2
  have hsum : p.represented =
      rawTraceDetTensor candidate hfield forward inverse hcoordinates +
        pullback (decodeRawArray (n := p.supportDimension) p.residual)
          (rawSupportMap p.supportMatrix) := by
    rw [RawDecomposition.represented, hclean]
  intro x y z
  rw [hdecomp]
  exact congrArg (fun T : BinaryTensor (3 * s) => T x y z) hsum

end CorruptedFieldRecovery
