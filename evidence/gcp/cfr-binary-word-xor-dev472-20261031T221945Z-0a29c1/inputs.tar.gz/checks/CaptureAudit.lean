import CorruptedFieldRecovery
import CorruptedFieldRecovery.RawBinaryWordXor

set_option pp.universes true
set_option pp.explicit false
set_option pp.fullNames true
set_option pp.piBinderTypes true
set_option pp.piBinderNames true
set_option pp.piBinderNames.hygienic true
set_option pp.proofs true
set_option pp.deepTerms true
set_option pp.maxSteps 1000000
set_option maxRecDepth 10000

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawBinaryWordXorBit"
#check @CorruptedFieldRecovery.rawBinaryWordXorBit
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawBinaryWordXorBit"
#print axioms CorruptedFieldRecovery.rawBinaryWordXorBit

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawBinaryWordXor"
#check @CorruptedFieldRecovery.rawBinaryWordXor
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawBinaryWordXor"
#print axioms CorruptedFieldRecovery.rawBinaryWordXor

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawBinaryWordXor_length"
#check @CorruptedFieldRecovery.rawBinaryWordXor_length
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawBinaryWordXor_length"
#print axioms CorruptedFieldRecovery.rawBinaryWordXor_length

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawBinaryWordXor_refines_natXor"
#check @CorruptedFieldRecovery.rawBinaryWordXor_refines_natXor
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawBinaryWordXor_refines_natXor"
#print axioms CorruptedFieldRecovery.rawBinaryWordXor_refines_natXor

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawBitsToNat_natBits"
#check @CorruptedFieldRecovery.rawBitsToNat_natBits
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawBitsToNat_natBits"
#print axioms CorruptedFieldRecovery.rawBitsToNat_natBits

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawNatBitsXor_refines_natXor"
#check @CorruptedFieldRecovery.rawNatBitsXor_refines_natXor
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawNatBitsXor_refines_natXor"
#print axioms CorruptedFieldRecovery.rawNatBitsXor_refines_natXor

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawReduceStepWord"
#check @CorruptedFieldRecovery.rawReduceStepWord
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawReduceStepWord"
#print axioms CorruptedFieldRecovery.rawReduceStepWord

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawReduceStepWord_refines"
#check @CorruptedFieldRecovery.rawReduceStepWord_refines
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawReduceStepWord_refines"
#print axioms CorruptedFieldRecovery.rawReduceStepWord_refines

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawBinaryWordXorGateCount"
#check @CorruptedFieldRecovery.rawBinaryWordXorGateCount
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawBinaryWordXorGateCount"
#print axioms CorruptedFieldRecovery.rawBinaryWordXorGateCount

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawBinaryWordXorGateCount_eq_width"
#check @CorruptedFieldRecovery.rawBinaryWordXorGateCount_eq_width
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawBinaryWordXorGateCount_eq_width"
#print axioms CorruptedFieldRecovery.rawBinaryWordXorGateCount_eq_width

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawReduceStepWord_gateCount"
#check @CorruptedFieldRecovery.rawReduceStepWord_gateCount
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawReduceStepWord_gateCount"
#print axioms CorruptedFieldRecovery.rawReduceStepWord_gateCount
