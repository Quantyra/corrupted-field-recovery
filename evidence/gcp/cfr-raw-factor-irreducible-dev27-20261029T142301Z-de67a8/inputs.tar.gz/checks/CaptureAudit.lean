import CorruptedFieldRecovery
import CorruptedFieldRecovery.RawPolynomialIrreducibility

set_option pp.universes true
set_option pp.explicit false
set_option pp.fullNames true
set_option pp.piBinderTypes true
set_option pp.piBinderNames true
set_option pp.piBinderNames.hygienic true
set_option pp.proofs true
set_option pp.deepTerms true
set_option pp.maxSteps 1000000
set_option maxRecDepth 10000

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawMaskPolynomial_step"
#check @CorruptedFieldRecovery.rawMaskPolynomial_step
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawMaskPolynomial_step"
#print axioms CorruptedFieldRecovery.rawMaskPolynomial_step

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawMaskPolynomial_eval_zero"
#check @CorruptedFieldRecovery.rawMaskPolynomial_eval_zero
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawMaskPolynomial_eval_zero"
#print axioms CorruptedFieldRecovery.rawMaskPolynomial_eval_zero

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawDivX_X_mul"
#check @CorruptedFieldRecovery.rawDivX_X_mul
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawDivX_X_mul"
#print axioms CorruptedFieldRecovery.rawDivX_X_mul

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawMaskPolynomial_injective"
#check @CorruptedFieldRecovery.rawMaskPolynomial_injective
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawMaskPolynomial_injective"
#print axioms CorruptedFieldRecovery.rawMaskPolynomial_injective

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawBitsToNat_lt_pow_length"
#check @CorruptedFieldRecovery.rawBitsToNat_lt_pow_length
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawBitsToNat_lt_pow_length"
#print axioms CorruptedFieldRecovery.rawBitsToNat_lt_pow_length

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawBitsToNat_append"
#check @CorruptedFieldRecovery.rawBitsToNat_append
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawBitsToNat_append"
#print axioms CorruptedFieldRecovery.rawBitsToNat_append

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawBitsToNat_append_true"
#check @CorruptedFieldRecovery.rawBitsToNat_append_true
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawBitsToNat_append_true"
#print axioms CorruptedFieldRecovery.rawBitsToNat_append_true

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawPolynomialBitsFuel_length"
#check @CorruptedFieldRecovery.rawPolynomialBitsFuel_length
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawPolynomialBitsFuel_length"
#print axioms CorruptedFieldRecovery.rawPolynomialBitsFuel_length

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawPolynomialBits_length"
#check @CorruptedFieldRecovery.rawPolynomialBits_length
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawPolynomialBits_length"
#print axioms CorruptedFieldRecovery.rawPolynomialBits_length

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawBitsEndsTrue_cons"
#check @CorruptedFieldRecovery.rawBitsEndsTrue_cons
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawBitsEndsTrue_cons"
#print axioms CorruptedFieldRecovery.rawBitsEndsTrue_cons

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.monic_divX_of_natDegree_pos"
#check @CorruptedFieldRecovery.monic_divX_of_natDegree_pos
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.monic_divX_of_natDegree_pos"
#print axioms CorruptedFieldRecovery.monic_divX_of_natDegree_pos

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawPolynomialBitsFuel_monic_endsTrue"
#check @CorruptedFieldRecovery.rawPolynomialBitsFuel_monic_endsTrue
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawPolynomialBitsFuel_monic_endsTrue"
#print axioms CorruptedFieldRecovery.rawPolynomialBitsFuel_monic_endsTrue

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawPolynomialBits_monic_endsTrue"
#check @CorruptedFieldRecovery.rawPolynomialBits_monic_endsTrue
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawPolynomialBits_monic_endsTrue"
#print axioms CorruptedFieldRecovery.rawPolynomialBits_monic_endsTrue

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawPolynomialBits_mask_range"
#check @CorruptedFieldRecovery.rawPolynomialBits_mask_range
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawPolynomialBits_mask_range"
#print axioms CorruptedFieldRecovery.rawPolynomialBits_mask_range

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawIrreducible_mask_implies_polynomial_irreducible"
#check @CorruptedFieldRecovery.rawIrreducible_mask_implies_polynomial_irreducible
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawIrreducible_mask_implies_polynomial_irreducible"
#print axioms CorruptedFieldRecovery.rawIrreducible_mask_implies_polynomial_irreducible

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawPolynomialBits_mask_decode"
#check @CorruptedFieldRecovery.rawPolynomialBits_mask_decode
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawPolynomialBits_mask_decode"
#print axioms CorruptedFieldRecovery.rawPolynomialBits_mask_decode
