import CorruptedFieldRecovery.SamplingCounts
import CorruptedFieldRecovery.ConditionalCounts
import CorruptedFieldRecovery.ProperSubfieldCounts
import Mathlib.Tactic

/-! Finite-count assembly for the four-vector part of the actual trial.

This file keeps the clean set arbitrary: its only source is the binary support
kernel, and no K-linearity is introduced. The basis-triple count and the
basis-relative coordinate transport are separate obligations; the declarations
below assemble a proved per-fiber bound over every successful triple.
-/

namespace CorruptedFieldRecovery

noncomputable section

/-- Counting principle for the independent fourth draw. `B` is the set of
first-three tuples already certified as a K-basis. For each such tuple,
`goodFourth` contains clean fourth vectors whose first coordinate in that
sampled basis generates K. The finite sigma type is exactly the set of
qualifying clean four-tuples, represented as a triple followed by its fourth
word. -/
theorem card_good_four_tuples_lower
    {I O : Type*} [Fintype I] [Fintype O] [DecidableEq I]
    (B : Finset I) (goodFourth : I → Finset O) (m : ℕ)
    (hfiber : ∀ i ∈ B, m ≤ (goodFourth i).card) :
    m * B.card ≤
      Fintype.card (Σ i : {i // i ∈ B}, {o : O // o ∈ goodFourth i.1}) := by
  classical
  have hsum :
      m * B.card ≤
        ∑ i : {i // i ∈ B}, Fintype.card {o : O // o ∈ goodFourth i.1} := by
    calc
      m * B.card = ∑ _i : {i // i ∈ B}, m := by simp [Nat.mul_comm]
      _ ≤ ∑ i : {i // i ∈ B}, Fintype.card {o : O // o ∈ goodFourth i.1} :=
        Finset.sum_le_sum fun i _ => by
          rw [Fintype.card_coe]
          exact hfiber i.1 i.2
  rw [Fintype.card_sigma]
  exact hsum

/-- Apply the captured arbitrary-subset coordinate-fiber bound to the
fourth clean vector. The coordinate may be supplied by a sampled-basis
equivalence; the theorem does not assume the clean set is K-linear. -/
theorem bad_fourth_coordinate_count_le
    (K : Type*) [Fintype K] [DecidableEq K]
    (A D : Finset (Fin 3 → K)) :
    (A.filter fun x => x 0 ∈ D).card ≤ D.card * Fintype.card K ^ 2 :=
  card_subset_first_coordinate_values_le K A D

/-- The first-four-word contribution to the unconditional five-word count.
`m` is a uniform lower bound on good fourth clean vectors for every good
basis triple. Multiplying this count by `g` later accounts for the independent
fifth scalar word; no conditional probability or independence claim is hidden
in this finite cardinality statement. -/
theorem card_good_five_word_pairs_lower
    {I O : Type*} [Fintype I] [Fintype O] [DecidableEq I]
    (B : Finset I) (goodFourth : I → Finset O) (m g : ℕ)
    (hfiber : ∀ i ∈ B, m ≤ (goodFourth i).card) :
    (m * B.card) * g ≤
      Fintype.card (Σ i : {i // i ∈ B},
        ({o : O // o ∈ goodFourth i.1} × Fin g)) := by
  classical
  rw [Fintype.card_sigma]
  have hsum :
      (m * B.card) * g ≤
        ∑ i : {i // i ∈ B},
          Fintype.card ({o : O // o ∈ goodFourth i.1} × Fin g) := by
    calc
      (m * B.card) * g =
          ∑ _i : {i // i ∈ B}, m * g := by simp [Nat.mul_assoc, Nat.mul_left_comm]
      _ ≤ ∑ i : {i // i ∈ B},
          Fintype.card {o : O // o ∈ goodFourth i.1} * g :=
        Finset.sum_le_sum fun i _ => Nat.mul_le_mul_right g (by
          rw [Fintype.card_coe]
          exact hfiber i.1 i.2)
      _ = ∑ i : {i // i ∈ B},
          Fintype.card ({o : O // o ∈ goodFourth i.1} × Fin g) := by
        simp [Fintype.card_prod]
  exact hsum

end

end CorruptedFieldRecovery
