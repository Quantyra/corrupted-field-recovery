import CorruptedFieldRecovery
import CorruptedFieldRecovery.ProbabilityAssembly

set_option pp.universes true
set_option pp.explicit false
set_option pp.fullNames true
set_option pp.piBinderTypes true
set_option pp.piBinderNames true
set_option pp.piBinderNames.hygienic true
set_option pp.proofs true
set_option pp.deepTerms true
set_option pp.maxSteps 1000000
set_option maxRecDepth 10000

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.card_good_four_tuples_lower"
#check @CorruptedFieldRecovery.card_good_four_tuples_lower
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.card_good_four_tuples_lower"
#print axioms CorruptedFieldRecovery.card_good_four_tuples_lower

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.bad_fourth_coordinate_count_le"
#check @CorruptedFieldRecovery.bad_fourth_coordinate_count_le
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.bad_fourth_coordinate_count_le"
#print axioms CorruptedFieldRecovery.bad_fourth_coordinate_count_le

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.card_good_five_word_pairs_lower"
#check @CorruptedFieldRecovery.card_good_five_word_pairs_lower
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.card_good_five_word_pairs_lower"
#print axioms CorruptedFieldRecovery.card_good_five_word_pairs_lower
