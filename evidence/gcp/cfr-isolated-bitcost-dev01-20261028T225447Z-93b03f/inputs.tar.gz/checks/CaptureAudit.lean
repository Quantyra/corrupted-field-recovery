import CorruptedFieldRecovery
import CorruptedFieldRecovery.BitCostPrototype

set_option pp.universes true
set_option pp.explicit true
set_option pp.fullNames true

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.BitCostPrototype.fullAdder_correct"
#check @CorruptedFieldRecovery.BitCostPrototype.fullAdder_correct
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.BitCostPrototype.fullAdder_correct"
#print axioms CorruptedFieldRecovery.BitCostPrototype.fullAdder_correct

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.BitCostPrototype.stage_erasure"
#check @CorruptedFieldRecovery.BitCostPrototype.stage_erasure
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.BitCostPrototype.stage_erasure"
#print axioms CorruptedFieldRecovery.BitCostPrototype.stage_erasure

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.BitCostPrototype.stage_charge"
#check @CorruptedFieldRecovery.BitCostPrototype.stage_charge
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.BitCostPrototype.stage_charge"
#print axioms CorruptedFieldRecovery.BitCostPrototype.stage_charge

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.BitCostPrototype.stage_total_charge"
#check @CorruptedFieldRecovery.BitCostPrototype.stage_total_charge
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.BitCostPrototype.stage_total_charge"
#print axioms CorruptedFieldRecovery.BitCostPrototype.stage_total_charge

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.BitCostPrototype.execute_declared_measure_exact"
#check @CorruptedFieldRecovery.BitCostPrototype.execute_declared_measure_exact
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.BitCostPrototype.execute_declared_measure_exact"
#print axioms CorruptedFieldRecovery.BitCostPrototype.execute_declared_measure_exact

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.BitCostPrototype.stage_declared_measure_exact"
#check @CorruptedFieldRecovery.BitCostPrototype.stage_declared_measure_exact
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.BitCostPrototype.stage_declared_measure_exact"
#print axioms CorruptedFieldRecovery.BitCostPrototype.stage_declared_measure_exact

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.BitCostPrototype.ripple_correct"
#check @CorruptedFieldRecovery.BitCostPrototype.ripple_correct
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.BitCostPrototype.ripple_correct"
#print axioms CorruptedFieldRecovery.BitCostPrototype.ripple_correct
