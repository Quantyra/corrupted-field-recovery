import Mathlib.Data.Finset.Card
import Mathlib.Tactic

/-! Finite root counts for the fifth-word translate scalar.

The support is represented here by its actual finite set of K³ coordinates.
No K-linearity of this set is used: its binary-subspace structure enters only
through its cardinality in the caller. -/

namespace CorruptedFieldRecovery

noncomputable section

variable (K : Type*) [Field K] [Fintype K] [DecidableEq K]

abbrev KTriple := Fin 3 → K

def translateScalarRoots (u₀ u₁ : KTriple K) : Finset K :=
  Finset.univ.filter fun t => u₀ + t • u₁ = 0

theorem card_translateScalarRoots_le_one (u₀ u₁ : KTriple K)
    (hu₁ : u₁ ≠ 0) : (translateScalarRoots K u₀ u₁).card ≤ 1 := by
  classical
  apply Finset.card_le_one.mpr
  intro t ht u hu
  simp only [translateScalarRoots, Finset.mem_filter, Finset.mem_univ,
    true_and] at ht hu
  have hmul : (t - u) • u₁ = 0 := by
    have heq : t • u₁ = u • u₁ := by
      rw [eq_neg_of_add_eq_zero_left ht, eq_neg_of_add_eq_zero_left hu]
    rw [sub_smul, heq, sub_self]
  have hj : ∃ j : Fin 3, u₁ j ≠ 0 := by
    by_contra h
    apply hu₁
    funext j
    exact not_not.mp (by simpa using h j)
  obtain ⟨j, hj⟩ := hj
  have hcoord := congrFun hmul j
  simp only [Pi.smul_apply, smul_eq_mul] at hcoord
  have htu : t - u = 0 := (mul_eq_zero.mp hcoord).resolve_right hj
  exact sub_eq_zero.mp htu

abbrev TranslatePair (U : Finset (KTriple K)) :=
  {p : {x // x ∈ U} × {x // x ∈ U} // p.1.1 ≠ 0 ∨ p.2.1 ≠ 0}

def nonzeroTranslatePairs (U : Finset (KTriple K)) : Finset (TranslatePair K U) :=
  Finset.univ

def badTranslateScalars (U : Finset (KTriple K)) : Finset K :=
  (nonzeroTranslatePairs K U).biUnion fun p =>
    translateScalarRoots K p.1.1 p.2.1

theorem card_nonzeroTranslatePairs_le (U : Finset (KTriple K))
    (hzero : (0 : KTriple K) ∈ U) :
    Fintype.card (TranslatePair K U) ≤ U.card ^ 2 - 1 := by
  classical
  let P := {p : {x // x ∈ U} × {x // x ∈ U} // p.1.1 ≠ 0 ∨ p.2.1 ≠ 0}
  let Q := {p : {x // x ∈ U} × {x // x ∈ U} // p.1.1 = 0 ∧ p.2.1 = 0}
  have hcardQ : Fintype.card Q = 1 := by
    have hQ : Q = ({⟨⟨0, hzero⟩, ⟨0, hzero⟩⟩} : Finset _) := by
      ext p
      simp only [Q, Finset.mem_singleton, Finset.mem_univ, true_iff]
      apply Subtype.ext
      apply Prod.ext
      · apply Subtype.ext
        exact p.2.1
      · apply Subtype.ext
        exact p.2.2
    rw [← Fintype.card_coe, hQ]
    simp
  have hsplit : Fintype.card P + Fintype.card Q =
      Fintype.card ({x // x ∈ U} × {x // x ∈ U}) := by
    let p : ({x // x ∈ U} × {x // x ∈ U}) → Prop :=
      fun x => x.1.1 ≠ 0 ∨ x.2.1 ≠ 0
    letI : DecidablePred p := Classical.decPred p
    have h := Finset.card_filter_add_card_filter_not
      (s := (Finset.univ : Finset ({x // x ∈ U} × {x // x ∈ U}))) p
    have hQ' : (Finset.univ.filter fun x : {x // x ∈ U} × {x // x ∈ U} => ¬ p x).card =
        Fintype.card Q := by
      rw [← Fintype.card_coe]
      congr 1
      ext x
      simp [Q, p, not_or]
    simpa [P, p, hQ'] using h
  have hprod : Fintype.card ({x // x ∈ U} × {x // x ∈ U}) = U.card ^ 2 := by
    simp [Fintype.card_prod]
  rw [hprod, hcardQ] at hsplit
  omega

theorem card_badTranslateScalars_le (U : Finset (KTriple K))
    (hzero : (0 : KTriple K) ∈ U) :
    (badTranslateScalars K U).card ≤ U.card ^ 2 - 1 := by
  classical
  calc
    (badTranslateScalars K U).card ≤
        ∑ p ∈ nonzeroTranslatePairs K U,
          (translateScalarRoots K p.1.1 p.2.1).card := Finset.card_biUnion_le
    _ ≤ (nonzeroTranslatePairs K U).card := by
      apply Finset.sum_le_sum
      intro p hp
      have hne : p.1.1 ≠ 0 ∨ p.2.1 ≠ 0 := p.2
      have hu₁ : p.2.1 ≠ 0 ∨ p.1.1 ≠ 0 := Or.symm hne
      rcases hu₁ with h | h
      · exact card_translateScalarRoots_le_one K p.1.1 p.2.1 h
      · have hempty : translateScalarRoots K p.1.1 p.2.1 = ∅ := by
          ext t
          simp only [translateScalarRoots, Finset.mem_filter, Finset.mem_univ,
            true_and, Finset.not_mem_empty, iff_false]
          intro ht
          simp [h] at ht
        simp [hempty]
    _ ≤ U.card ^ 2 - 1 := by
      simpa [nonzeroTranslatePairs] using card_nonzeroTranslatePairs_le K U hzero

end

end CorruptedFieldRecovery
