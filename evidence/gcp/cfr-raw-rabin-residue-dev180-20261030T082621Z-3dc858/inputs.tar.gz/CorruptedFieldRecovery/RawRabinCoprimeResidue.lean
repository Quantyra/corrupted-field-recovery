import CorruptedFieldRecovery.RawRabinScan

/-! Relate the actual XOR-mask gcd operand to the standard Frobenius
polynomial using quotient congruence. -/

namespace CorruptedFieldRecovery

open Polynomial AdjoinRoot

/-- Common-divisor coprimality with a fixed mask is invariant when the second
polynomial is replaced by a quotient-congruent representative. -/
theorem rawMaskPairCoprime_quotient_congruent
    (modulus a b : Nat)
    (hcong : AdjoinRoot.mk (rawMaskPolynomial modulus) (rawMaskPolynomial a) =
      AdjoinRoot.mk (rawMaskPolynomial modulus) (rawMaskPolynomial b)) :
    rawMaskPairCoprime modulus a ↔ rawMaskPairCoprime modulus b := by
  have hdiv : rawMaskPolynomial modulus ∣
      rawMaskPolynomial b - rawMaskPolynomial a :=
    AdjoinRoot.mk_eq_mk.mp hcong
  constructor
  · intro ha c hcm hca
    apply ha c hcm
    have hdiff : c ∣ rawMaskPolynomial b - rawMaskPolynomial a := hcm.trans hdiv
    have hadd : rawMaskPolynomial b =
        (rawMaskPolynomial b - rawMaskPolynomial a) + rawMaskPolynomial a := by ring
    rw [hadd]
    exact dvd_add hdiff hca
  · intro hb c hcm hcb
    apply hb c hcm
    have hdiff : c ∣ rawMaskPolynomial b - rawMaskPolynomial a := hcm.trans hdiv
    have hsub : rawMaskPolynomial a =
        rawMaskPolynomial b - (rawMaskPolynomial b - rawMaskPolynomial a) := by ring
    rw [hsub]
    exact dvd_sub hcb hdiff

/-- The executable XOR operand represents `X^(2^d)-X` in the quotient by
the candidate modulus. This uses the proved raw Frobenius and XOR refinements. -/
theorem rawCandidateRabinOperand_quotient_sound {s : Nat}
    (candidate : RawFieldCandidate s) (d : Nat)
    (hmodulus : rawFieldBitsToNat candidate.modulus ≠ 0) :
    AdjoinRoot.mk (rawCandidateModulus candidate)
      (rawMaskPolynomial
        (Nat.xor (rawCandidateFrobenius candidate d) 2)) =
    AdjoinRoot.mk (rawCandidateModulus candidate) (X ^ (2 ^ d) - X) := by
  change AdjoinRoot.mk (rawMaskPolynomial (rawFieldBitsToNat candidate.modulus))
      (rawMaskPolynomial (Nat.xor (rawCandidateFrobenius candidate d) 2)) =
    AdjoinRoot.mk (rawMaskPolynomial (rawFieldBitsToNat candidate.modulus))
      (X ^ (2 ^ d) - X)
  have h1 : rawMaskPolynomial 1 = (1 : Polynomial (ZMod 2)) := by
    rw [rawMaskPolynomial_step]
    norm_num [rawMaskPolynomial_zero]
  have hX : rawMaskPolynomial 2 = (X : Polynomial (ZMod 2)) := by
    rw [rawMaskPolynomial_step]
    norm_num [Nat.bodd, Nat.div2, rawMaskPolynomial_zero, h1]
  have hxor : rawMaskPolynomial (Nat.xor (rawCandidateFrobenius candidate d) 2) =
      rawMaskPolynomial (rawCandidateFrobenius candidate d) + X := by
    rw [rawMaskPolynomial_xor, hX]
  calc
    AdjoinRoot.mk (rawMaskPolynomial (rawFieldBitsToNat candidate.modulus))
        (rawMaskPolynomial (Nat.xor (rawCandidateFrobenius candidate d) 2)) =
      AdjoinRoot.mk (rawMaskPolynomial (rawFieldBitsToNat candidate.modulus))
        (rawMaskPolynomial (rawCandidateFrobenius candidate d) + X) :=
          congrArg (AdjoinRoot.mk (rawMaskPolynomial (rawFieldBitsToNat candidate.modulus))) hxor
    _ = AdjoinRoot.mk (rawMaskPolynomial (rawFieldBitsToNat candidate.modulus))
          (rawMaskPolynomial (rawCandidateFrobenius candidate d)) +
        AdjoinRoot.mk (rawMaskPolynomial (rawFieldBitsToNat candidate.modulus)) X := by
          simp [map_add]
    _ = AdjoinRoot.mk (rawMaskPolynomial (rawFieldBitsToNat candidate.modulus))
          (X ^ (2 ^ d)) +
        AdjoinRoot.mk (rawMaskPolynomial (rawFieldBitsToNat candidate.modulus)) X := by
          rw [rawCandidateFrobenius_quotient_sound candidate d hmodulus]
    _ = AdjoinRoot.mk (rawMaskPolynomial (rawFieldBitsToNat candidate.modulus))
          (X ^ (2 ^ d) - X) := by
          have hchar : X ^ (2 ^ d) - X = X ^ (2 ^ d) + X := by ring
          rw [hchar, map_add]

end CorruptedFieldRecovery
