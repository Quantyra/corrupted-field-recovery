import CorruptedFieldRecovery.S010BalanceRawInputMatrix
import Mathlib.Tactic

namespace CorruptedFieldRecovery

theorem actualBalanceCoordinateList_length (n : Nat) :
    (actualBalanceCoordinateList n).length = n := by
  simp [actualBalanceCoordinateList]

private theorem ofFn_const_sum (n k : Nat) :
    (List.ofFn (fun _ : Fin n => k)).sum = n * k := by
  rw [List.ofFn_const, List.sum_const_nat]

theorem actualBalanceColumnList_length (s : Nat) :
    (actualBalanceColumnList s).length = (3 * s) * (3 * s) := by
  simp only [actualBalanceColumnList, actualBalanceCoordinateList,
    List.length_flatMap, List.length_map]
  change (List.ofFn (fun _ : Fin (3 * s) => 3 * s)).sum = (3 * s) * (3 * s)
  exact ofFn_const_sum (3 * s) (3 * s)

theorem actualBalanceRowList_length (s : Nat) :
    (actualBalanceRowList s).length = 4 * (3 * s) * (3 * s) := by
  simp only [actualBalanceRowList, actualBalanceCoordinateList,
    List.length_flatMap, List.length_map]
  simp only [Nat.mul_comm 4, Nat.mul_left_comm 4, Nat.mul_assoc]
  norm_num [ofFn_const_sum]

theorem actualBalanceSerializedRow_width {s : Nat}
    (A : BinaryTensor (3 * s)) (tape : FiveWordTape s)
    (row : ActualBalanceBasisRow s) :
    (((actualBalanceColumnList s).map fun col =>
      actualBalanceComputableCoefficientMatrix A tape row col).toArray).size =
        (3 * s) * (3 * s) := by
  simp [actualBalanceColumnList_length]

theorem actualBalanceSerializedCoefficientMatrix_exact_outer_size {s : Nat}
    (A : BinaryTensor (3 * s)) (tape : FiveWordTape s) :
    (actualBalanceSerializedCoefficientMatrix A tape).size =
      4 * (3 * s) * (3 * s) := by
  rw [actualBalanceSerializedCoefficientMatrix_outer_size,
    actualBalanceRowList_length]

end CorruptedFieldRecovery
