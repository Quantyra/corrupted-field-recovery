import CorruptedFieldRecovery.S010BalanceRawInputMatrix
import Mathlib.Tactic

namespace CorruptedFieldRecovery

theorem actualBalanceCoordinateList_length (n : Nat) :
    (actualBalanceCoordinateList n).length = n := by
  simp [actualBalanceCoordinateList]

theorem actualBalanceColumnList_length (s : Nat) :
    (actualBalanceColumnList s).length = (3 * s) * (3 * s) := by
  simp only [actualBalanceColumnList, List.length_flatMap, List.length_map,
    actualBalanceCoordinateList_length]
  rw [List.ofFn_const, List.sum_const_nat]

theorem actualBalanceRowList_length (s : Nat) :
    (actualBalanceRowList s).length = 4 * (3 * s) * (3 * s) := by
  simp only [actualBalanceRowList, List.length_flatMap, List.length_map,
    actualBalanceCoordinateList_length]
  rw [List.ofFn_const, List.sum_const_nat]
  simp [Nat.mul_comm, Nat.mul_left_comm, Nat.mul_assoc]

theorem actualBalanceSerializedRow_width {s : Nat}
    (A : BinaryTensor (3 * s)) (tape : FiveWordTape s)
    (row : ActualBalanceBasisRow s) :
    (((actualBalanceColumnList s).map fun col =>
      actualBalanceComputableCoefficientMatrix A tape row col).toArray).size =
        (3 * s) * (3 * s) := by
  simp [actualBalanceColumnList_length]

theorem actualBalanceSerializedCoefficientMatrix_exact_outer_size {s : Nat}
    (A : BinaryTensor (3 * s)) (tape : FiveWordTape s) :
    (actualBalanceSerializedCoefficientMatrix A tape).size =
      4 * (3 * s) * (3 * s) := by
  rw [actualBalanceSerializedCoefficientMatrix_outer_size,
    actualBalanceRowList_length]

end CorruptedFieldRecovery
