import CorruptedFieldRecovery
import CorruptedFieldRecovery.RawPhysicalTraceBits

set_option pp.universes true
set_option pp.explicit false
set_option pp.fullNames true
set_option pp.piBinderTypes true
set_option pp.piBinderNames true
set_option pp.piBinderNames.hygienic true
set_option pp.proofs true
set_option pp.deepTerms true
set_option pp.maxSteps 1000000
set_option maxRecDepth 10000

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawPhysicalBlockMask"
#check @CorruptedFieldRecovery.rawPhysicalBlockMask
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawPhysicalBlockMask"
#print axioms CorruptedFieldRecovery.rawPhysicalBlockMask

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawPhysicalTripleMasks"
#check @CorruptedFieldRecovery.rawPhysicalTripleMasks
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawPhysicalTripleMasks"
#print axioms CorruptedFieldRecovery.rawPhysicalTripleMasks

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawPhysicalTraceDet3Bits"
#check @CorruptedFieldRecovery.rawPhysicalTraceDet3Bits
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawPhysicalTraceDet3Bits"
#print axioms CorruptedFieldRecovery.rawPhysicalTraceDet3Bits

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.accepted_rawPhysicalCoordinateInverse"
#check @CorruptedFieldRecovery.accepted_rawPhysicalCoordinateInverse
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.accepted_rawPhysicalCoordinateInverse"
#print axioms CorruptedFieldRecovery.accepted_rawPhysicalCoordinateInverse

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.rawPhysicalTraceDet3Bits_eq_baseTrace"
#check @CorruptedFieldRecovery.rawPhysicalTraceDet3Bits_eq_baseTrace
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.rawPhysicalTraceDet3Bits_eq_baseTrace"
#print axioms CorruptedFieldRecovery.rawPhysicalTraceDet3Bits_eq_baseTrace
