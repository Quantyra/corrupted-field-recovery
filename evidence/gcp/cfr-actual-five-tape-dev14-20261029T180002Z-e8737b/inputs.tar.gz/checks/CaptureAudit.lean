import CorruptedFieldRecovery
import CorruptedFieldRecovery.ProbabilityActualTapeBridge

set_option pp.universes true
set_option pp.explicit false
set_option pp.fullNames true
set_option pp.piBinderTypes true
set_option pp.piBinderNames true
set_option pp.piBinderNames.hygienic true
set_option pp.proofs true
set_option pp.deepTerms true
set_option pp.maxSteps 1000000
set_option maxRecDepth 10000

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.FiveWordTape"
#check @CorruptedFieldRecovery.FiveWordTape
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.FiveWordTape"
#print axioms CorruptedFieldRecovery.FiveWordTape

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.fiveTapeSemanticEquiv"
#check @CorruptedFieldRecovery.fiveTapeSemanticEquiv
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.fiveTapeSemanticEquiv"
#print axioms CorruptedFieldRecovery.fiveTapeSemanticEquiv

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.actualFiveGoodTapeSet"
#check @CorruptedFieldRecovery.actualFiveGoodTapeSet
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.actualFiveGoodTapeSet"
#print axioms CorruptedFieldRecovery.actualFiveGoodTapeSet

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.card_actualFiveGoodTapeSet"
#check @CorruptedFieldRecovery.card_actualFiveGoodTapeSet
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.card_actualFiveGoodTapeSet"
#print axioms CorruptedFieldRecovery.card_actualFiveGoodTapeSet

#eval IO.println "CFR_TYPE_BEGIN:CorruptedFieldRecovery.card_fiveWordTape"
#check @CorruptedFieldRecovery.card_fiveWordTape
#eval IO.println "CFR_TYPE_END:CorruptedFieldRecovery.card_fiveWordTape"
#print axioms CorruptedFieldRecovery.card_fiveWordTape
