﻿import CorruptedFieldRecovery.ProbabilityActualTapeBridge
import Mathlib.Tactic

/-! Finite-count normalization for S010.  The probability statement is
represented only by a comparison of cardinalities: the sample space is the
actual four physical words and one independent s-bit index. -/

namespace CorruptedFieldRecovery

/-- A lower bound on the cardinality of the actual good-tape set, normalized
against the exact fair-bit sample space, implies the claimed one-trial bound.
This lemma is deliberately conditional on the finite-count inequality; it does
not assert that the beta/gamma estimates or the algorithmic event have been
proved. -/
theorem actual_five_tape_count_implies_trial_bound
    {s R : Nat} (K : Type*) [Field K] [Fintype K] [DecidableEq K]
    [Algebra BinaryField K] [FiniteDimensional BinaryField K] [Finite K]
    (Q : BinaryVector (3 * s) ≃ₗ[BinaryField] FieldTriple K)
    (A : Finset (FieldTriple K)) (U : Submodule BinaryField (KTriple K))
    (b : (Fin 4 → FieldTriple K) → Basis (Fin s) BinaryField K)
    (hcount : 2 ^ (4 * R + 3) * (actualFiveGoodTapeSet K Q A U b).card ≥
      2 ^ (13 * s)) :
    2 ^ (4 * R + 3) * (actualFiveGoodTapeSet K Q A U b).card ≥
      Fintype.card (FiveWordTape s) := by
  rw [card_fiveWordTape]
  exact hcount

/-- The semantic dependent count and physical tape count are equal under the
explicit coordinate equivalence. This is the precise bridge needed before
interpreting a finite count as a fair-bit probability. -/
theorem actual_five_tape_count_eq_semantic
    {s : Nat} (K : Type*) [Field K] [Fintype K] [DecidableEq K]
    [Algebra BinaryField K] [FiniteDimensional BinaryField K] [Finite K]
    (Q : BinaryVector (3 * s) ≃ₗ[BinaryField] FieldTriple K)
    (A : Finset (FieldTriple K)) (U : Submodule BinaryField (KTriple K))
    (b : (Fin 4 → FieldTriple K) → Basis (Fin s) BinaryField K) :
    (actualFiveGoodTapeSet K Q A U b).card =
      (goodFiveTupleSigma K A U b).card :=
  card_actualFiveGoodTapeSet K Q A U b

end CorruptedFieldRecovery
