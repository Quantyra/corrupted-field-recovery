﻿import Mathlib.Tactic

/-! Elementary multiplicative form of the union bound used to turn the
sequential finite-count factors in S010 into a probability lower bound. -/
namespace CorruptedFieldRecovery

/-- Two independent retained fractions lose at most the sum of their losses. -/
theorem one_sub_mul_one_sub_lower {x y : ℚ}
    (hx : 0 ≤ x) (hy : 0 ≤ y) (hxy : x + y ≤ 1) :
    (1 - x) * (1 - y) ≥ 1 - (x + y) := by
  nlinarith [mul_nonneg hx hy]

/-- Four sequential good fractions have total loss at most the sum of the
four individual bad fractions. The sum bound also ensures every factor being
multiplied is nonnegative. -/
theorem four_one_sub_product_lower {a b c d : ℚ}
    (ha : 0 ≤ a) (hb : 0 ≤ b) (hc : 0 ≤ c) (hd : 0 ≤ d)
    (habcd : a + b + c + d ≤ 1) :
    (1 - a) * (1 - b) * (1 - c) * (1 - d) ≥
      1 - (a + b + c + d) := by
  have hab : a + b ≤ 1 := by linarith
  have habc : a + b + c ≤ 1 := by linarith
  have h_ab := one_sub_mul_one_sub_lower ha hb hab
  have h_abc := one_sub_mul_one_sub_lower (by linarith : 0 ≤ a + b) hc habc
  have h_abc' : (1 - a) * (1 - b) * (1 - c) ≥ 1 - (a + b + c) := by
    calc
      (1 - a) * (1 - b) * (1 - c) ≥ (1 - (a + b)) * (1 - c) :=
        mul_le_mul_of_nonneg_right (le_of_ge h_ab) (by linarith)
      _ ≥ 1 - (a + b + c) := h_abc
  calc
    (1 - a) * (1 - b) * (1 - c) * (1 - d) ≥
        (1 - (a + b + c)) * (1 - d) :=
      mul_le_mul_of_nonneg_right (le_of_ge h_abc') (by linarith)
    _ ≥ 1 - (a + b + c + d) := by
      have := one_sub_mul_one_sub_lower (by linarith : 0 ≤ a + b + c) hd habcd
      simpa [add_assoc] using this

end CorruptedFieldRecovery


